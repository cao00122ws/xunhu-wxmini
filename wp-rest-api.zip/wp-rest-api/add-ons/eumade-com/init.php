<?php

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * @author rain
 *
 */
class WRest_Add_On_Eumade_Com extends Abstract_WRest_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WRest_Add_On_Eumade_Com
     */
    private static $_instance = null;
    public $domain_dir,$domain_url;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WRest_Add_On_Eumade_Com
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct(){
        $this->id='wrest_add_on_eumade_com';
        $this->title='eumade.com';
        $this->description='定制代码，放在这个里边';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author='迅虎网络';
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_dir = WRest_Helper_Uri::wp_dir(__FILE__) ;
        $this->domain_url = WRest_Helper_Uri::wp_url(__FILE__) ;
    }

    public function do_ajax()
    {
        $action = "wrest_{$this->id}";
        $request=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            'tab'=>null,
            $action=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));

        if ( ! current_user_can( 'manage_options') ){
            return;
        }

        if(!WRest::instance()->WP->ajax_validate($request, $request['hash'],true)){
            echo WRest_Error::err_code(701)->to_json();
            exit;
        }

        switch ($request['tab']){
            case 'pdf':
                if ( ! current_user_can( 'manage_options') ){
                    wp_die('您无权限访问当前页面！');
                }
                WRest::instance()->WP->requires($this->domain_dir,'pdf/shipping.php',array(
                        'domain_url'=>$this->domain_url
                ),true);
                exit;
            case 'send_code':
                $coupons = json_decode(stripslashes($_REQUEST['coupon']),true);
                $users = json_decode(stripslashes($_REQUEST['user']),true);
                if(!count($coupons)){
                    echo WRest_Error::error_custom('请至少选择一个优惠券！')->to_json();
                    exit;
                }
                if(!count($users)){
                    echo WRest_Error::error_custom('请至少选择一个用户！')->to_json();
                    exit;
                }

                foreach ($coupons as $coupon_id){
                    $coupon  = new WC_Coupon($coupon_id);

                   $mails =  $coupon->get_email_restrictions();
                   if(!$mails||!is_array($mails)){
                       $mails=array();
                   }
                   foreach ($users as $user_id){
                       $user = get_userdata($user_id);
                       if(!$user){continue;}
					   if(empty($user->user_email)){
                           echo WRest_Error::error_custom("用户(ID:{$user->ID})没有绑定邮箱！")->to_json();
                           exit;
                       }

					   $m = $user->user_email;
                       if(!in_array($m,$mails)){
                           $mails[]= $m;
                       }
                   }
                    $coupon->set_email_restrictions($mails);
                    $coupon->save();
                }

                echo WRest_Error::success()->to_json();
                exit;
        }
    }

    public function on_load(){
        add_filter('wrest_admin_menu_menu_default_basic',function($menus){
            require_once 'menu-coupon-send.php';
            $menus[]=WRest_Menu_Coupon_Send::instance();
            return $menus;
        },10,1);
        //禁用产品评论
        add_filter( 'woocommerce_product_tabs', 'woodmart_disable_reviews_tab', 98 );

        add_filter('wrest_pro_search_filters',function($filters){
            $filters = array(
                '__price__'=>$filters['__price__']
            );

            global $wp_registered_sidebars, $wp_registered_widgets;
            $index = 'sidebar-shop';
            $sidebars_widgets = wp_get_sidebars_widgets();
            $sidebar = isset($wp_registered_sidebars[$index])?$wp_registered_sidebars[$index]:null;

            if(!isset($sidebars_widgets[$index])||!$sidebar){
                return $filters;
            }

            $categoriesNow = array();
            if(!empty($_REQUEST['cat_id'])||!empty($_REQUEST['id'])){
                $cat_id = absint($_REQUEST['cat_id']);
                if(!empty($_REQUEST['id'])){
                    $cat_id = absint($_REQUEST['id']);
                }

                global $wpdb;
                $querys = $wpdb->get_results(
                    "SELECT tr.term_id 
			FROM `{$wpdb->prefix}term_relationships` r
			inner join {$wpdb->prefix}term_taxonomy tr on tr.term_taxonomy_id = r.term_taxonomy_id


			inner join {$wpdb->prefix}term_relationships r1 on r1.object_id = r.object_id
			inner join {$wpdb->prefix}term_taxonomy tr1 on tr1.term_taxonomy_id = r1.term_taxonomy_id


			where tr1.term_id={$cat_id};");

                if($querys){
                    foreach($querys as $c){
                        $categoriesNow[]=$c->term_id;
                    }
                }
            }

            $attributes = array();
            foreach ( (array) $sidebars_widgets[$index] as $id ) {

                if ( !isset($wp_registered_widgets[$id]) ) continue;

                $params = array_merge(
                    array( array_merge( $sidebar, array('widget_id' => $id, 'widget_name' => $wp_registered_widgets[$id]['name']) ) ),
                    (array) $wp_registered_widgets[$id]['params']
                );

                // Substitute HTML id and class attributes into before_widget
                $classname_ = '';
                foreach ( (array) $wp_registered_widgets[$id]['classname'] as $cn ) {
                    if ( is_string($cn) )
                        $classname_ .= '_' . $cn;
                    elseif ( is_object($cn) )
                        $classname_ .= '_' . get_class($cn);
                }

                $classname_ = ltrim($classname_, '_');
                $params[0]['before_widget'] = sprintf($params[0]['before_widget'], $id, $classname_);
                $params = apply_filters( 'dynamic_sidebar_params', $params );
                $callback = $wp_registered_widgets[$id]['callback'];
                if ( !is_array($callback)||count($callback)!==2 ) {
                    continue;
                }

                $obj = $callback[0];
                if(!$obj instanceof WOODMART_Widget_Layered_Nav){
                    continue;
                }

                $args = $params[0];
                $widget_args = $params[1];

                if ( is_numeric( $widget_args ) ) {
                    $widget_args = array( 'number' => $widget_args );
                }

                $widget_args = wp_parse_args( $widget_args, array( 'number' => -1 ) );
                $obj->_set( $widget_args['number'] );
                $instances = $obj->get_settings();
                if ( array_key_exists( $obj->number, $instances ) ) {
                    $instance = $instances[ $obj->number ];
                    $instance = apply_filters( 'widget_display_callback', $instance, $obj, $args );
                    if ( false === $instance ) {
                        continue;
                    }

                    $_chosen_attributes = WC_Query::get_layered_nav_chosen_attributes();
                    $taxonomy           = isset( $instance['attribute'] ) ? wc_attribute_taxonomy_name( $instance['attribute'] ) : '';
                    $category           = isset( $instance['category'] ) ? $instance['category'] : 'all';
                    $query_type         = isset( $instance['query_type'] ) ? $instance['query_type'] : 'and';
                    $display	  		= isset( $instance['display'] ) ? $instance['display'] : 'list';

                    $current_cat = get_queried_object();

                    if ( ! is_tax() && 'all' != $category ) {
                        continue;
                    }

                    if ( 'all' != $category && property_exists( $current_cat, 'term_id' ) && $current_cat->term_id != $category && $current_cat->parent != $category ) {
                        continue;
                    }

                    $template = isset( $instance['template'] ) ? $instance['template'] : 'default';
                    if ( ! taxonomy_exists( $taxonomy ) ) {
                        continue;
                    }

                    $get_terms_args = array( 'hide_empty' => '1' );

                    $orderby = wc_attribute_orderby( $taxonomy );

                    switch ( $orderby ) {
                        case 'name' :
                            $get_terms_args['orderby']    = 'name';
                            $get_terms_args['menu_order'] = false;
                            break;
                        case 'id' :
                            $get_terms_args['orderby']    = 'id';
                            $get_terms_args['order']      = 'ASC';
                            $get_terms_args['menu_order'] = false;
                            break;
                        case 'menu_order' :
                            $get_terms_args['menu_order'] = 'ASC';
                            break;
                    }

                    $terms = get_terms( $taxonomy, $get_terms_args );
                    if ( 0 === sizeof( $terms ) ) {
                        continue;
                    }

                    if($categoriesNow&&count($categoriesNow)){
                        $new_terms = array();
                        foreach($terms as $c){
                            if(in_array($c->term_id,$categoriesNow)){
                                $new_terms[]=$c;
                            }
                        }
                        if(!count($new_terms)){continue;}
                        $terms = $new_terms;
                    }



                    $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance ) ;
                    $attributes[$taxonomy ]=array(
                        'label'=> html_entity_decode($title),
                        'options'=>array()
                    );
                    foreach ($terms as $term){
                        $attributes[$taxonomy]['options'][$term->term_id]=html_entity_decode($term->name);
                    }
                }
            }

            foreach ($attributes as $taxonomy => $taxonomyObj) {
                $filters[$taxonomy] = array(
                    'title' => $taxonomyObj['label'],
                    'attribute_name'=>$taxonomy,
                    'type' => 'mult-select',
                    'options' => $taxonomyObj['options'],
                    'call' => function (&$args, $key, $request,$setting) {
                        if(!$request||!is_array($request)||count($request)==0){
                            return;
                        }
                        if(!isset($args['tax_query'])){
                            $args['tax_query']=array();
                        }

                        $query = array(
                            'relation'=>'AND'
                        );

                        $cat_ids = array();
                        foreach ($request as $tid=>$val){
                            $tid = absint($tid);
                            if($tid){
                                $cat_ids[]=$tid;
                            }
                        }

                        $query[] = array(
                            'taxonomy' => $key,
                            'field'    => 'term_id',
                            'terms'    => array_unique($cat_ids,SORT_NUMERIC),
                        );

                        $args['tax_query'][]=$query;
                        return $args;
                    }
                );
            }

            return $filters;
        },11,1);

        add_action('woocommerce_after_calculate_totals', __CLASS__.'::validate_shipping');

        add_filter('manage_shop_order_posts_columns',function($columns){
            $columns['wrest_shipping'] = 'Shipping';
            return $columns;
        },99,1);
        add_action('manage_shop_order_posts_custom_column',function($column, $post_id){
            if($column!='wrest_shipping'){return;}
            if(get_post_meta($post_id,'__wrest_printed__',true)==='yes'){
                ?>
                <a style="color:green;" href="<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_wrest_add_on_eumade_com",'tab'=>'pdf'),true,true)?>&order_id=<?php echo $post_id?>" class="button" target="_blank">Printed</a>
                <?php
            }else{
                ?>
                <a href="<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_wrest_add_on_eumade_com",'tab'=>'pdf'),true,true)?>&order_id=<?php echo $post_id?>" class="button" target="_blank">Print</a>
                <?php
            }

        },10,2);
    }

    public static function validate_shipping(){
        if(!wc()->cart->cart_contents){
            return;
        }

        $last_shipping_class = null;
        foreach (wc()->cart->cart_contents as $item_key=>$cart_item){
            $product = $cart_item['data'];
            $product instanceof WC_Product;
            $shipping_class = get_term($product->get_shipping_class_id(),'product_shipping_class');
            if(!$shipping_class){
                continue;
            }

            if(!$last_shipping_class){
                $last_shipping_class = $shipping_class;
            }else{
                if($last_shipping_class->term_id!=$shipping_class->term_id)
                {
                    wc_add_notice("配送：{$shipping_class->name}不能与 {$last_shipping_class->name}产品混装！",'error');
                    break;
                }
            }
        }
    }
}

return WRest_Add_On_Eumade_Com::instance();
?>