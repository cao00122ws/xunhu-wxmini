<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Coupon_Send extends Abstract_WRest_Settings{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
        return self::$_instance;
    }
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct(){
        $this->id='menu-store-coupon-send';
        $this->title='优惠券';

    }
    public function admin_form_start(){}

    public function admin_options(){
        ?>
        <div class="wrap">
        <h1 class="wp-heading-inline">发送优惠券</h1>
        <hr class="wp-header-end">

            <table class="form-table">
                <tr valign="top" class="">
                    <th scope="row" class="titledesc">
                        <label>客户：</label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <legend class="screen-reader-text">
                                <span>客户：</span>
                            </legend>
                            <select id="coupon-user"  class="wrest-search" data-type="wp_user" data-multiple="1" data-sortable="true" data-placeholder="用户ID或登录名..." data-allow_clear="true">

                            </select>
                        </fieldset>
                    </td>
                </tr>

                <tr valign="top" class="">
                    <th scope="row" class="titledesc">
                        <label>优惠券：</label>
                    </th>
                    <td class="forminp">
                        <fieldset>
                            <legend class="screen-reader-text">
                                <span>优惠券：</span>
                            </legend>
                            <select id="coupon-data"  class="wrest-search" data-type="shop_coupon" data-multiple="1" data-sortable="true" data-placeholder="优惠券ID或代码..." data-allow_clear="true">

                            </select>
                        </fieldset>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="button" id="btn-send-coupon" value="发送" class="button-primary">
            </p>
            <script type="text/javascript">
                (function($,undefined){
                    $('#btn-send-coupon').click(function(){
						var $this = $(this);
                        $this.attr('disabled','disabled').val('发送中...');

                        $.ajax({
                            url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_wrest_add_on_eumade_com",'tab'=>'send_code'),true,true)?>',
                            type:'post',
                            timeout:120*1000,
                            async:true,
                            cache:false,
                            data:{
                                user:JSON.stringify($('#coupon-user').val()),
                                coupon:JSON.stringify($('#coupon-data').val())
                            },
                            dataType:'json',
                            complete:function(){
                                $this.removeAttr('disabled').val('重新发送');
                            },
                            success:function(e){
                                if(e.errcode!=0){
                                    alert(e.errmsg);
                                    return;
                                }
                                alert('发送成功！');
                            },
                            error:function(e){
                                console.error(e.responseText);
                                alert('系统异常，请重试！');
                            }
                        });
                    });
                })(jQuery);
            </script>
        <?php
    }

    public function admin_form_end(){}
}