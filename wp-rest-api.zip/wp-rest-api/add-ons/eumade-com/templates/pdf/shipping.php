<?php
$attdata = WRest_Temp_Helper::clear('atts','templates');
$domain_url = $attdata['domain_url'];
$order = wc_get_order(isset($_GET['order_id'])?absint($_GET['order_id']):0);
if(!$order){
    wp_die('订单信息未找到！');
}
$customer = $order->get_customer_id()?get_userdata($order->get_customer_id()):null;
$img = WRest_Settings_Default_Basic_Default::instance()->get_option('img_company');
update_post_meta($order->get_id(),'__wrest_printed__','yes');
$ext = $customer?XH_Social_Channel_Mobile::instance()->get_ext_user_info_by_wp($customer->ID):null;
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo $domain_url;?>/assets/bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        .order-line{margin-bottom: 10px;margin-left:15px;}
        @media print {
            a[href]:after {
                content: none !important;
            }
            .noprint{
                display: none;
            }
        }
    </style>
</head>
<body>
<div class="d-flex justify-content-end">
    <button class="btn btn-success btn-short btn-sm" type="button" id="btn-print" style="width:100px;">Print</button>

</div>
<div  id="main-content" class="d-flex flex-column" style="margin-left: auto;margin-right: auto;max-width: 1200px; margin-top: 40px; padding:30px;border: .2rem solid #f8f9fa;">
    <!--printstart-->
    <div class="d-flex flex-column">
        <div class="d-flex flex-row justify-content-between align-items-start">
            <div class=" d-flex flex-column">
                <h5 style="margin-bottom: 20px;color:#007bc4;">Kundeninformation 客户信息：</h5>
                <div class="order-line">Kundenname 客户名称：<b><?php echo $customer?$customer->display_name:'-'; ?></b></div>
                <div class="order-line">Kundenadresse 地址：<b><?php echo str_replace('<br/>',' ',$order->get_formatted_shipping_address())?></b></div>
                <div class="order-line">Email 邮箱地址：<b><?php echo $customer?$customer->user_email:'-'; ?></b></div>
                <div class="order-line">Kundentelefon电话：<b><?php echo $ext?$ext['mobile']:'-'; ?></b></div>
            </div>
            <img src="<?php echo $img;?>" style="max-width: 200px;max-height: 240px;" />
        </div>
        <div style="margin:10px auto; border-top: 1px solid #dee2e6;width:100%;"></div>
        <h5 style="margin-bottom: 20px;color:#007bc4;">Bestellungsübersicht 订单信息：</h5>
        <?php
            $statusList = wc_get_order_statuses();
        ?>
        <div style="margin-left: 15px;">Bestellungsnummer 订单：<b>#<?php echo $order->get_id()?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Zeit 时间：<b><?php echo $order->get_date_created()->date_i18n('Y-m-d H:i')?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Status der Bestellung 订单状态：<b style="<?php echo $order->is_paid()?'color:green;':'color:red;'?>"><?php echo isset($statusList["wc-{$order->get_status()}"])?($statusList["wc-{$order->get_status()}"]."({$order->get_status()})"):$order->get_status()?></b></div>
        <table class="table table-bordered" style="margin-top: 20px;margin-left: 15px;">
        <thead>
            <tr>
                <th scope="col">Produktname<br/>产品名称</td>
                <th scope="col">Bild<br/>产品图片</td>
                <th scope="col">Menge<br/>数量</td>
                <th scope="col">SKU<br/>仓库编号</td>
                <th scope="col" style="width:100px;">Preis pro<br/>产品单价</td>
                <th scope="col" style="width:100px;">Kosten<br/>消费额</td>
            </tr>
        </thead>
        <tbody>
            <?php
                $order_items = $order->get_items('line_item');
                if($order_items){
                    foreach ($order_items as $order_item){
                       // $order_item = new WC_Order_Item_Product();
                        $product = $order_item->get_product();
                        if(!$product){continue;}
                        $productApi = new WRest_Product_WC($product);
                        $productData = $productApi->to_simple(null);
                        $subtitle = '';
                        $meta_data = $order_item->get_formatted_meta_data( '' ) ;
                        if($meta_data){
                            $index = 0;
                            foreach ( $meta_data as $meta_id => $meta ){
                                if ( in_array( $meta->key, $hidden_order_itemmeta, true ) ) {
                                    continue;
                                }
                                if ($index++ != 0) {
                                    $subtitle .= " ";
                                }
                                $subtitle.='"'.strip_tags(wc_clean($meta->display_value)).'"';
                            }
                        }

                        ?>
                        <tr>
                            <td><?php echo $product->get_title()?> <small><?php echo $subtitle;?></small> <br/><br/><?php echo  get_post_meta($product->get_id(),'__wrest_align__',true);?> <small><?php echo $subtitle;?></small></td>
                            <td><img src="<?php echo !empty($productData['image'])?$productData['image']['url']:''?>" style="max-width: 200px;max-height: 200px;"></td>
                            <td><?php echo $order_item->get_quantity();?></td>
                            <td><?php echo $product->get_sku();?></td>

                            <td><?php echo get_woocommerce_currency_symbol($order->get_currency());?><?php echo  Abstract_WRest_Doamin::format_price($order->get_item_total( $order_item, false, true ))?></td>
                            <td><?php echo get_woocommerce_currency_symbol($order->get_currency());?><?php echo Abstract_WRest_Doamin::format_price($order_item->get_subtotal())?></td>
                        </tr>
                        <?php
                    }
                }
            ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="2"></td>
            <td colspan="2"><b>Ordner Summe 订单总计：</b></td>
            <td colspan="2">
                <div>Rabatt：<?php echo get_woocommerce_currency_symbol($order->get_currency());?><?php echo Abstract_WRest_Doamin::format_price($order->get_discount_total() )?></div>
                <div>Lieferung：<?php echo get_woocommerce_currency_symbol($order->get_currency());?><?php echo Abstract_WRest_Doamin::format_price($order->get_shipping_total() )?></div>
                <div>Lieferungsart：<?php echo $order->get_shipping_method();?></div>
                <?php
                $rates = $order->get_taxes();
                $rates =$rates&&count($rates)? array_values($rates):null;
                $rate_value = 0;
                if($rates&&count($rates)&&$rates[0] instanceof WC_Order_Item_Tax) {
                    $rate_value = $rates[0]->get_tax_total();
                }
                ?>
                <div>TAX：<?php echo get_woocommerce_currency_symbol($order->get_currency());?><?php echo Abstract_WRest_Doamin::format_price($rate_value )?></div>
                <div>Summe：<?php echo get_woocommerce_currency_symbol($order->get_currency());?><?php echo Abstract_WRest_Doamin::format_price($order->get_total() )?></div>
            </td>
        </tr>
        </tfoot>
    </table>
    </div>
    <!--printend-->
</div>
<script src="/wp-includes/js/jquery/jquery.js" ></script>
<script type="text/javascript">
    window.$=jQuery;
</script>
<script src="<?php echo $domain_url;?>/assets/jQuery.print.js" ></script>
<script src="<?php echo $domain_url;?>/assets/bootstrap-4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript">
    jQuery('#btn-print').click(function(){
        $("#main-content").print({
            globalStyles:true,//是否包含父文档的样式，默认为true
            mediaPrint:false,//是否包含media='print'的链接标签。会被globalStyles选项覆盖，默认为false
            stylesheet:null,//外部样式表的URL地址，默认为null
            noPrintSelector:".no-print",//不想打印的元素的jQuery选择器，默认为".no-print"
            iframe:true,//是否使用一个iframe来替代打印表单的弹出窗口，true为在本页面进行打印，false就是说新开一个页面打印，默认为true
            append:null,//将内容添加到打印内容的后面
            prepend:null//将内容添加到打印内容的前面，可以用来作为要打印内容
        }); 
    });
</script>
</body>
</html>
