<?php
class WRest_Shop extends WRest_Post_Object{ 
    /**
     * {@inheritDoc}
     * @see WRest_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wrest_shop';
    }

    /**
     * {@inheritDoc}
     * @see WRest_Object::get_propertys()
     */
    public function get_propertys()
    {
        // TODO Auto-generated method stub
        return array(
            'post_ID'=>0,
            'path'=>null,
            'contact'=>null,
            'employee_list'=>null
        );
    }

    public function get_employee_list(){
        $employee_list  = isset($this->employee_list)&&$this->employee_list?json_decode($this->employee_list,true):null;
        if(!$employee_list){
            return null;
        }
        
        return array_unique(array_values($employee_list));
    }
}

class WRest_Shop_Fields extends Abstract_WRest_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Forms_Enrty_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="wrest_shop";
        $this->title = '门店';
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        $this->form_fields = array(
            'path'=>array(
                'title'=>'详细地址',
                'type'=>'map'
            ),
            'contact'=>array(
                'title'=>'联系电话',
                'type'=>'text'
            ),
            'employees0'=>array(
                'title'=>'绑定店员',
                'type'=>'employee_list'
            )
        );
    }

    public function get_post_types()
    {
        return array(
            'wrest_shop'=>'门店'
        );
    }

    /**
     * 
     * @return WShop_Forms_Entry
     */
    public function get_object($post){
        return new WRest_Shop($post->ID);
    }
    
    public function generate_employee_list_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'label' => '',
            'disabled' => false,
            'class' => '',
            'css' => '',
            'type' => 'text',
            'desc_tip' => false,
            'description' => '',
            'custom_attributes' => array ()
        );
        
        $data = wp_parse_args ( $data, $defaults );
        $api = WRest_Add_On_Shipping_SC::instance();
        global $post;
        ob_start ();
        ?>
        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
        	<th scope="row" class="titledesc">
        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
				<?php echo $this->get_tooltip_html( $data ); ?>
			</th>
        	<td class="forminp">
        		<fieldset>
        			<legend class="screen-reader-text">
        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
        			</legend>
        			<div style="display:flex;flex-direction:row;align-items:center;">
           			    <div id="wrest-btn-shopmanager-bindqrcode" style="width:150px;height:150px;display:flex;flex-wrap:wrap;border:solid 1px #f4f4f4;justify-content:center;align-items:center;">
           			    	<a href="javascript:void(0);" onclick="window.qrcodeView.loadQrcode();" >点击加载绑定码</a>
           			    </div>
           			    
               			<div id="wrest-shopmanagers" style="display:flex;flex-dierction:row;max-width:800px;">
               				
               			</div>
               		</div>
           			<script type="text/javascript">
            			(function($){
            				window.qrcodeView={
            						loading:false,
            						loadQrcode:function(){
            							if(this.loading){return;}
            							this.loading=true;
            							
            						    var data ={};
            
            							$.ajax({
            								url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_{$api->id}",'tab'=>'load_shopmanager_bind_qrcode','post_ID'=>$post->ID),true,true)?>',
            								type:'post',
            								timeout:60*1000,
            								async:true,
            								cache:false,
            								data:data,
            								dataType:'json',
            								beforeSend:function(){
            									$('#wrest-btn-shopmanager-bindqrcode').loading();
            								},
            								complete:function(){
            									window.qrcodeView.loading=false;
            									$('#wrest-btn-shopmanager-bindqrcode').loading('hide');
            								},
            								success:function(e){
            									if(e.errcode!=0){
            										alert( e.errmsg );
            										return;
            									}
            
            									$('#wrest-btn-shopmanager-bindqrcode').html('<img src="'+e.data.qrcode+'" style="width:120px;height:120px;"/><div style="color:black;"><a href="javascript:void(0);" onclick="window.qrcodeView.loadQrcode();">点我刷新</a>(30分钟内有效，限绑定一次)</div>');
            								},
            								error:function(e){
            									console.error(e.responseText);
            									alert('网络异常，请重试!' );
            								}
            							});
            						},
            						load_shopmanager:function(){
            							var data ={};
            
            							$.ajax({
            								url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_{$api->id}",'tab'=>'load_shop_manager','post_ID'=>$post->ID),true,true)?>',
            								type:'post',
            								timeout:60*1000,
            								async:true,
            								cache:false,
            								data:data,
            								dataType:'json',
            								success:function(e){
            									if(e.errcode==0){
            										var managers = e.data;
            										if(managers){
            											var html = '';
            											for(var p in managers){
            												var manager = managers[p];
            												html+='<div id="wrest-shopmanager-'+manager.id+'" style="display:flex;flex-direction:column;margin-left:10px;position:relative;width:80px;height:100px;">\
                					               						<img src="'+manager.img+'" style="width:80px;height:80px;border-radus:50%" />\
                					                   					<div style="text-align:center;">'+manager.nickname+'</div>\
                					                   					<img onclick="window.qrcodeView.remove_manager('+manager.id+');" src="<?php echo WREST_URL?>/assets/images/icon/delete.png" style="position:absolute;top:-10px;right:-10px;width:20px;height:20px;cursor:pointer;"/>\
                					                   				</div>';
            											}
            											$('#wrest-shopmanagers').html(html);
            										}
            									}
                								setTimeout(function(){
                									window.qrcodeView.load_shopmanager();
                								},3000);
            								},
            								error:function(e){
            									setTimeout(function(){
            										window.qrcodeView.load_shopmanager();
            									},3000);
            								}
            							});
            						},
            						remove_manager:function(id){
            							if(!confirm('当前店主绑定信息即将移除，确认执行？')){
            								return;
            							}
            							if(this.loading){return;}
            							this.loading=true;
                                        var data={
                                        	id:id
                                        };
            							$.ajax({
            								url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_{$api->id}",'tab'=>'remove_shop_manager','post_ID'=>$post->ID),true,true)?>',
            								type:'post',
            								timeout:60*1000,
            								async:true,
            								cache:false,
            								data:data,
            								dataType:'json',
            								beforeSend:function(){
            									$('#wrest-shopmanagers').loading();
            								},
            								complete:function(){
            									window.qrcodeView.loading=false;
            									$('#wrest-shopmanagers').loading('hide');
            								},
            								success:function(e){
            									if(e.errcode!=0){
            										alert( e.errmsg );
            										return;
            									}
            
            									$('#wrest-shopmanager-'+id).remove();
            								},
            								error:function(e){
            									console.error(e.responseText);
            									alert('网络异常，请重试!' );
            								}
            							});
            						}
            				};
            				window.qrcodeView.load_shopmanager();
            			})(jQuery);
            		</script>
					<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
        	</td>
        </tr>
        <?php
		
		return ob_get_clean ();
    }
}

class WRest_Shop_Model extends Abstract_WRest_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_shop` (
                `post_ID` INT(11) NOT NULL,
                `contact` VARCHAR(64) NULL DEFAULT NULL,
                `path` TEXT NULL DEFAULT NULL,
                `employee_list` TEXT NULL DEFAULT NULL,
                PRIMARY KEY (`post_ID`)
            )
            $collate;");

        if(!empty($wpdb->last_error)){
            WRest_Log::error($wpdb->last_error);
            //throw new Exception($wpdb->last_error);
        }
    }
}