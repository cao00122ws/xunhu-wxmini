<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
   
/**
 * @author rain
 *
 */
class WRest_Add_On_Shipping_SC extends Abstract_WRest_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WRest_Add_On_Shipping_SC
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WRest_Add_On_Shipping_SC
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wrest_add_on_shipping_sc';
        $this->title='配送 - 到店消费';
        $this->description='客户到实体店内，线下完成订单。';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author='迅虎网络';
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WRest_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WRest_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>'设置',
                'url'=>admin_url("admin.php?page=wrest_page_default&section=menu_default_basic&sub=wrest_add_on_shipping_sc")
            )
        );
        
        $this->init_form_fields();
    }
    
    public function on_load(){
    	require_once 'includes/class-wrest-shop.php';
    	add_action('wrest_register_routes_wp_user', array($this,'register_routes_wp_user'),10,1);
    	add_action('wrest_checkout_posted_data', array($this,'checkout_posted_data'),10,1);
    	add_filter('wrest_order_info', array($this,'order_detail_info'),10,2);
    	add_filter('wrest_order_detail_call', array($this,'order_detail_call'),10,2);
    }
    
    public function on_install(){
    	$model = new WRest_Shop_Model();
    	$model->init();
    }
    
    public function register_fields(){
    	WRest_Shop_Fields::instance();
    }
    
    public function register_post_types(){
    	register_post_type('wrest_shop',
    			array(
    					'labels' => array(
    							'name' => '门店',
    							'singular_name' =>'门店',
    							'add_new' => '新增',
    							'add_new_item' =>'新增门店',
    							'edit' =>  '编辑',
    							'edit_item' => '编辑门店',
    							'new_item' => '新门店',
    							'view' => '查看',
    							'view_item' =>'查看门店',
    							'search_items' => '搜索',
    							'not_found' => '未找到门店',
    							'not_found_in_trash' =>'回收站中暂无门店',
    							'parent' => '父级门店'
    					),
    					//决定自定义文章类型在管理后台和前端的可见性
    					'public' => true,
    					'menu_position' => 40,
    					'exclude_from_search '=>false,
    					'publicly_queryable'=>false,
    					'hierarchical'=>false,
    					'supports' => array( 'title', 'thumbnail', /*'comments','excerpt', 'editor','page-attributes'*/ ),
    					'has_archive' => false,
    					'show_in_menu'=>WRest_Admin::menu_tag
    			));
    }
    
    public function on_init(){
        add_filter('wrest_admin_menu_menu_default_basic', array($this,'register_menu'),10,1);
        add_action('wrest_user_dobind', array($this,'do_account_bind'),10,2);
        add_filter('wrest_user_prebind', array($this,'user_prebind'),10,2);
        add_filter('wrest_cart', array($this,'wrest_cart'),10,1);
    }
    
    public function register_menu($menus){
        $menus[]=$this;
        return $menus;
    }
    
    
    public function do_ajax(){
        if ( ! current_user_can( 'manage_options') ){
            return;
        }
        
        $action ="wrest_{$this->id}";
        $request=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'post_ID'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));
        
        do_action('wrest_admin_ajax_init');
        
        if(!WRest::instance()->WP->ajax_validate($request,$request['hash'],true)){
            echo (WRest_Error::err_code(701)->to_json());
            exit;
        }
        
        $post_ID = absint($request['post_ID']);
        switch ($request['tab']){
            case 'load_shopmanager_bind_qrcode':
                $api = WRest_Settings_Default_Basic_Default::instance();
                $appid = $api->get_option('appid');
                $appsecret = $api->get_option('appsecret');
                require_once WREST_DIR.'/includes/class-xh-wechat-api.php';
                $wechatApi = new WRest_Wechat_Api($appid,$appsecret);
                $shop = new WRest_Shop($post_ID);
                if(!$shop->is_load()){
                    $shop->post_ID = $post_ID;
                   
                    $error = $shop->insert();
                    if(!WRest_Error::is_valid($error)){
                        $error->output();exit;
                    }
                }
                
                $now = time();
                $action ="shop".$now.$post_ID.substr(md5(md5($post_ID.$now).WRest::instance()->get_hash_key()), 6,6);
                
                $qrcode = $wechatApi->get_smallprogram_qrcode_unlimit('/package_a/pages/bind/index',$action);
                if($qrcode instanceof WRest_Error){
                    $qrcode->output();exit;
                }
               
                WRest_Error::success(array(
                    'qrcode'=>$qrcode
                ))->output();
                exit;

            case 'load_shop_manager':
                global $wpdb;
                $shop = new WRest_Shop($post_ID);
                $employee_list=$shop->is_load()?$shop->employee_list:array();
                if(!$employee_list||!is_array($employee_list)){
                    $employee_list=array();
                }
                if(!count($employee_list)){
                    WRest_Error::success(array())->output();
                    exit;
                }
                
                $user_IDs = join(',', array_values($employee_list));
                
                $members = $wpdb->get_results(
                   "select *
                    from {$wpdb->prefix}wrest_user
                    where user_ID in ({$user_IDs});");
                
                $managers = array();
                if($members){
                    foreach ($members as $member){
                        $user = new WRest_User($member);
                        $managers[]=array(
                            'id'=>$user->user_ID,
                            'nickname'=>$user->get_nickname(),
                            'img'=>$user->img
                        );
                    }
                }
                WRest_Error::success($managers)->output();
                exit;
            case 'remove_shop_manager':
                $id = isset($_REQUEST['id'])?absint($_REQUEST['id']):0;
                $manager = new WRest_User($id);
                if(!$manager->is_load()){
                    echo WRest_Error::err_code(404)->to_json();
                    exit;
                }
                $shop = new WRest_Shop($post_ID);
                if(!$shop->is_load()){
                    WRest_Error::error_custom('店铺信息异常！')->output();
                    exit;
                }
                
                $employee_list=$shop->is_load()?$shop->employee_list:array();
                if(!$employee_list||!is_array($employee_list)){
                    $employee_list=array();
                }
                $new_employee_list = array();
                foreach ($employee_list as $time=>$user_ID){
                    if($user_ID!=$id){
                        $new_employee_list[$time] = $user_ID;
                    }
                }
                $shop->update(array(
                    'employee_list'=>$new_employee_list
                ))->output();
                exit;
        }
    }
    
    
    
    /**
     * 
     * @param Abstract_WRest_Controller $controller
     */
    public function register_routes_wp_user($controller){
    	register_rest_route( $controller->get_namespace(), "/{$controller->get_rest_base()}/shoplist" , array(
    			array(
    					'methods'             => WP_REST_Server::ALLMETHODS,
    					'callback'            => array( $this, 'get_shoplist' ),
    					'permission_callback' => array( $controller, 'get_private_items_permissions_check' ),
    			)
    	));
    	
    	register_rest_route( $controller->get_namespace(), "/{$controller->get_rest_base()}/shopDetail" , array(
    	    array(
    	        'methods'             => WP_REST_Server::ALLMETHODS,
    	        'callback'            => array( $this, 'get_shopDetail' ),
    	        'permission_callback' => array( $controller, 'get_private_items_permissions_check' ),
    	    )
    	));
    	
    	register_rest_route( $controller->get_namespace(), "/{$controller->get_rest_base()}/confirmShop" , array(
    	    array(
    	        'methods'             => WP_REST_Server::ALLMETHODS,
    	        'callback'            => array( $this, 'confirmShop' ),
    	        'permission_callback' => array( $controller, 'get_private_items_permissions_check' ),
    	    )
    	));

    	register_rest_route( $controller->get_namespace(), "/{$controller->get_rest_base()}/getShopQrcode" , array(
    	    array(
    	        'methods'             => WP_REST_Server::ALLMETHODS,
    	        'callback'            => array( $this, 'getShopQrcode' ),
    	        'permission_callback' => array( $controller, 'get_private_items_permissions_check' ),
    	    )
    	));

    	register_rest_route( $controller->get_namespace(), "/{$controller->get_rest_base()}/receiveOrder" , array(
    	    array(
    	        'methods'             => WP_REST_Server::ALLMETHODS,
    	        'callback'            => array( $this, 'receiveOrder' ),
    	        'permission_callback' => array( $controller, 'get_private_items_permissions_check' ),
    	    )
    	));
    }
    
    /**
     * @param WP_REST_Request $request
     */
    public function getShopQrcode($request){
        $version = WRest::instance()->WP->get_version($request);
        if(is_wp_error($version)){
            return $version;
        }
        
        $id = absint($request->get_param('id'));
        $orderApi = new WRest_Order_WC($id);
        if(!$orderApi->is_load()){
            return new WP_Error('no-found','订单信息未找到!',['status'=>500]);
        }
        
        if($orderApi->get_order()->is_paid()){
            return new WP_Error('no-found','订单信息未支付!',['status'=>500]);
        }
        
        $shop = $this->getOrderShopInfo($orderApi);
        if(!$shop){
            return new WP_Error('no-found','店铺信息未找到!',['status'=>500]);
        }
        
        $api = WRest_Settings_Default_Basic_Default::instance();
        $appid = $api->get_option('appid');
        $appsecret = $api->get_option('appsecret');
        require_once WREST_DIR.'/includes/class-xh-wechat-api.php';
        $wechatApi = new WRest_Wechat_Api($appid,$appsecret);
        
        $qrcode = $wechatApi->get_smallprogram_qrcode_unlimit('/package_a/pages/order/detail/index',"received_{$id}");
        if($qrcode instanceof WRest_Error){
            $qrcode->output();exit;
        }
        
        return new WP_REST_Response(array(
            'qrcode'=>$qrcode
        ));
    }

    public function receiveOrder($request){
        $order_id = absint($request->get_param('id'));
        $api = WRest::instance()->get_product_api();
        $order = $api->get_order($order_id);
        if (!$order->is_load()) {
            return new WP_Error('order-not-found', '订单信息未找到！', array('status' => 500));
        }
        
        if(!$order->get_order()->is_paid()){
            return new WP_Error('no-found','订单信息未支付!',['status'=>500]);
        }
        
        $shop = $this->getOrderShopInfo($order);
        if(!$shop){
            return new WP_Error('no-found','店铺信息未找到!',['status'=>500]);
        }
        
        //检测当前用户是否已绑定店铺
        $user_id = get_current_user_id();
        $employee_list = $shop->get_employee_list();
        if(!$employee_list||!in_array($user_id, $employee_list)){
            return new WP_Error('view-permission-limit', '您没有权限访问当前订单！', array('status' => 500));
        }
        
        if(!$order->get_order()->update_status( 'received', "确认收货:店员ID{$user_id}" )){
            return new WP_Error('system-error','系统异常！',array('status'=>500));
        }
        
        return new WP_REST_Response();
    }
    
    /**
     * @param function $call
     * @param WP_REST_Request $request
     */
    public function order_detail_call($call,$request){
        $scene = $request->get_param('scene');
        if(!$scene||!preg_match('/^received_[\d]+$/', $scene)){
            return $call;
        }
        
        return function($request){
            $scene = $request->get_param('scene');
            $order_id = absint(substr($scene, strlen('received_')));
            $api = WRest::instance()->get_product_api();
            $order = $api->get_order($order_id);
            if (!$order->is_load()) {
                return new WP_Error('order-not-found', '订单信息未找到！', array('status' => 500));
            }
            
            if(!$order->get_order()->is_paid()){
                return new WP_Error('no-found','订单信息未支付!',['status'=>500]);
            }
            
            $shop = $this->getOrderShopInfo($order);
            if(!$shop){
                return new WP_Error('no-found','店铺信息未找到!',['status'=>500]);
            }
            
            //检测当前用户是否已绑定店铺
            $user_id = get_current_user_id();
            $employee_list = $shop->get_employee_list();
            if(!$employee_list||!in_array($user_id, $employee_list)){
                return new WP_Error('view-permission-limit', '您没有权限访问当前订单！', array('status' => 500));
            }
            
            if ('Y' == $request->get_param('checkorder') && $order) {
                $order->process_payment_check();
            }
            
            $version = WRest::instance()->WP->get_version($request);
            if (is_wp_error($version)) {
                return $version;
            }
            
            $detail = $order->to_detail($version);
            $detail['is_can_shop_received'] = true;
            return $detail;
        };
    }
    /**
     * @param WP_REST_Request $request
     */
    public function confirmShop($request){
        $id = absint($request->get_param('id'));
        $shop = new WRest_Shop($id);
        if(!$shop->is_load()){
            return new WP_Error('no-found','店铺信息未找到!',['status'=>404]);
        }
        
        $version = WRest::instance()->WP->get_version($request);
        if(is_wp_error($version)){
            return $version;
        }
        
        WC()->session->set( 'wrest_shop_ID', $shop->post_ID );
        WC()->session->save_data();
        $api = WRest::instance()->get_product_api();
        return new WP_REST_Response($api->get_cart($version));
    }
    
    /**
     * @param WP_REST_Request $request
     */
    public function get_shopDetail($request){
        $id = $request->get_param('id');
        $shop = new WRest_Shop($id);
		if(!$shop->is_load()){
			return new WP_Error('no-found','店铺信息未找到!',['status'=>404]);
		}
		$post_thumbnail_id =get_post_meta( $shop->post_ID, '_thumbnail_id', true );
		$img = null;
		if ($post_thumbnail_id) {
		    $img = wp_get_attachment_image_src($post_thumbnail_id);
		}
		if (!$img) {
		    $img = [WREST_URL . '/assets/images/empty.png', 35, 35];
		}
		$posi = $shop->path&&is_array($shop->path)?$shop->path:null;
		return new WP_REST_Response(array(
		    'shop'=>array(
		        'post_ID'=>$shop->post_ID,
		        'title'=>$shop->post_title,
		        'path'=>$shop->path,
		        'contact'=>$shop->contact,
		        'markers'=>array(
		            array(
		                'id'=>1,
		                'latitude'=>isset($posi['lat'])?$posi['lat']:null,
		                'longitude'=>isset($posi['lng'])?$posi['lng']:null,
		                'title'=>isset($posi['path'])?$posi['path']:null,
		            )
		        ),
		        'img'=>['url' => $img[0], 'width' => $img[1], 'height' => $img[2]]
		    )
		));
    }
    /**
     * @param WP_REST_Request $request
     */
    public function get_shoplist($request){
    	$wp_query = new WP_Query(array(
    			'post_type'=>'wrest_shop',
    			'post_status'=>'publish',
    			'fields' => 'ids'
    	));
    	
    	$shops = array();
    	if($wp_query->posts){
    		foreach ($wp_query->posts as $post_ID){
    			$shop = new WRest_Shop($post_ID);
    			if(!$shop->is_load()){
    				continue;
    			}
    			
    			$post_thumbnail_id =get_post_meta( $post_ID, '_thumbnail_id', true );
    			$img = null;
    			if ($post_thumbnail_id) {
    				$img = wp_get_attachment_image_src($post_thumbnail_id);
    			}
    			if (!$img) {
    				$img = [WREST_URL . '/assets/images/empty.png', 35, 35];
    			}
    			
    			$shops[]=array(
    					'title'=>$shop->post_title,
    					'post_ID'=>$shop->post_ID,
    					'path'=>$shop->path,
    					'contact'=>$shop->contact,
    					'img'=> ['url' => $img[0], 'width' => $img[1], 'height' => $img[2]]
    			);
    		}
    	} 
    	
    	return new WP_REST_Response(array(
    			'items'=>$shops
    	));
    }
    
    /**
     *
     * @param unknown $order_id
     * @param unknown $posted_data
     * @param WC_Order $order
     */
    public function checkout_posted_data( $posted_data){
        if(!WC()->cart->needs_shipping()){
            return $posted_data;
        }
        $sdShipping = $this->get_option('shipping_method');
        if(!$sdShipping||!is_array($sdShipping)){
            $sdShipping=array();
        }
         
        if(!isset($sdShipping['method'])){
            return $posted_data;
        }
        
        $chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
        foreach ( WC()->shipping->get_packages() as $i => $package ) {
            if (  isset( $chosen_shipping_methods[ $i ], $package['rates'][ $chosen_shipping_methods[ $i ] ] ) ) {
                $shipping = $package['rates'][ $chosen_shipping_methods[ $i ] ] ;
                if($sdShipping['method']==$shipping->get_instance_id()){
                    $wrest_shop_ID = WC()->session->get( 'wrest_shop_ID');
                    $shop = new WRest_Shop($wrest_shop_ID);
                    if(!$shop->is_load()){
                        throw new Exception('请选择消费门店！');
                    }  
                    $posted_data['shipping_wrest_shop_ID'] = $wrest_shop_ID;
                }
            }
        }
        
        return $posted_data;
    }
    
    public function wrest_cart($cart){
        if(!WC()->cart->needs_shipping()){
            return $cart;
        }
    	if(!isset($cart['shipping'])||!$cart['shipping']){
    		return $cart;
    	}
    	
    	$sdShipping = $this->get_option('shipping_method');
    	if(!$sdShipping||!is_array($sdShipping)){
    		$sdShipping=array();
    	}
    	
    	if(!isset($sdShipping['method'])){
    		return $cart;
    	}
    	
    	foreach ($cart['shipping'] as $shipping){
    		if(!isset($shipping['available_methods'][$shipping['chosen_index']])){
    			continue;
    		}
    		
    		$shipping = $shipping['available_methods'][$shipping['chosen_index']];
    		if($shipping['instance_id']==$sdShipping['method']){
    			$cart['needShop'] = 'yes';
    			$wrest_shop_ID = WC()->session->get( 'wrest_shop_ID');
    			if($wrest_shop_ID){
    			    $shop = new WRest_Shop($wrest_shop_ID);
    			    if($shop->is_load()){
    			        $cart['shop'] = array(
    			            'title'=>$shop->post_title,
    			            'post_ID'=>$shop->post_ID,
    			            'path'=>$shop->path,
    			            'contact'=>$shop->contact
    			        );
    			    }
    			}
    			break;
    		}
    	}
    	return $cart;
    }
    
    /**
     * 
     * @param Array $orderInfo
     * @param WRest_Order_WC $orderApi
     * @return Array
     */
    public function order_detail_info($orderInfo,$orderApi){
        $shop = $this->getOrderShopInfo($orderApi);
        if(!$shop){return $orderInfo;}
        $orderInfo['hasOfflineQrcode'] = true;
        $orderInfo['shop'] = array(
            'post_ID'=>$shop->post_ID,
            'title'=>$shop->post_title
        );
        
        return $orderInfo;
    	
    }
    
    /**
     * 
     * @param WRest_Order_WC $orderApi
     * @return WRest_Shop
     */
    private function getOrderShopInfo($orderApi){
        $shipping_methods = $orderApi->get_order()->get_shipping_methods();
        if(!$shipping_methods||!count($shipping_methods)){
            return false;
        }
         
        $sdShipping = $this->get_option('shipping_method');
        if(!$sdShipping||!is_array($sdShipping)){
            $sdShipping=array();
        }
         
        if(!isset($sdShipping['method'])){
            return false;
        }
         
        foreach ($shipping_methods as $method){
            if($method->get_instance_id()==$sdShipping['method']){
                $shop_ID = $orderApi->get_order()->get_meta('_shipping_wrest_shop_ID',true);
                $shop = new WRest_Shop($shop_ID);
                if($shop->is_load()){
                    return $shop;
                }
                break;
            }
        }
        return false;
    }
    
    /**
     * 
     * @param WP_Error $error
     * @param WP_REST_Request $request
     */
    public function user_prebind($error,$request){
    	$scene = $request->get_param('scene');
    	if(!$scene||strpos($scene, 'shop')!==0){
    		return $error;
    	}
    	$scene = substr($scene, 4);
    	$now = time();
    	$totalLen = strlen($scene);
    	$timeLen = strlen($now);
    	
    	$time = substr($scene, 0,$timeLen);
    	$post_ID = substr($scene, $timeLen,$totalLen-$timeLen-6);
    	$hash = substr($scene, -6);
    	
    	try{
    		if($hash !=substr(md5(md5($post_ID.$time).WRest::instance()->get_hash_key()), 6,6)){
    			throw new Exception('身份验证失败：验证签名失败！');
    		}
    		
    		if($time<($now-30*60)){
    			throw new Exception('身份验证失败：验证密钥已过期！');
    		}
    		
    		global $current_wrest_user;
    		if(!$current_wrest_user){
    			$current_wrest_user= new WRest_User(get_current_user_id());
    		}
    		
    		if(!$current_wrest_user->is_load()){
    			throw new Exception('身份验证失败：用户信息加载失败！');
    		}
    		
    		$shop = new WRest_Shop($post_ID);
    		if(!$shop->is_load()){
    			throw new Exception('身份验证失败：门店信息加载失败！');
    		}
    		$employee_list = $shop->employee_list;
    		if(!$employee_list){
    			$employee_list=array();
    		}
    		
    		$res = array(
    				'title'=>"您将邀请成为门店【{$shop->post_title}】的店员!",
    				'confirm_txt'=>'我已确认并绑定'
    		);
    		foreach ($employee_list as $t=>$u){
    			if($u==$current_wrest_user->user_ID){
    				$res['isOK'] = 'yes';
    				$res['isOK_txt'] = '您已受邀为门店【{$shop->post_title}】的店员!';
    				return new WP_REST_Response($res);
    			}
    		}
    		return new WP_REST_Response($res);
    	}catch (Exception $e){
    		return new WP_Error('inner-error',$e->getMessage(),['status'=>500]);
    	}
    }
    
    public function do_account_bind($error,$request){
    	$scene = $request->get_param('scene');
    	if(!$scene||strpos($scene, 'shop')!==0){
    		return $error;
    	}
    	$scene = substr($scene, 4);
    	$now = time();
    	$totalLen = strlen($scene);
    	$timeLen = strlen($now);
    	
    	$time = substr($scene, 0,$timeLen);
    	$post_ID = substr($scene, $timeLen,$totalLen-$timeLen-6);
    	$hash = substr($scene, -6);
    	
    	try{
    		if($hash !=substr(md5(md5($post_ID.$time).WRest::instance()->get_hash_key()), 6,6)){
    			throw new Exception('身份验证失败：验证签名失败！');
    		}
    		
    		if($time<($now-30*60)){
    			throw new Exception('身份验证失败：验证密钥已过期！');
    		}
    		
    		global $current_wrest_user;
    		if(!$current_wrest_user){
    			$current_wrest_user= new WRest_User(get_current_user_id());
    		}
    		
    		if(!$current_wrest_user->is_load()){
    			throw new Exception('身份验证失败：用户信息加载失败！');
    		}
    		
    		$shop = new WRest_Shop($post_ID);
    		if(!$shop->is_load()){
    			throw new Exception('身份验证失败：门店信息加载失败！');
    		}
    		$employee_list = $shop->employee_list;
    		if(!$employee_list){
    			$employee_list=array();
    		}
    		
    		$res = array(
    				'title'=>"您将邀请成为门店【{$shop->post_title}】的店员!",
    				'confirm_txt'=>'我已确认并绑定'
    		);
    		foreach ($employee_list as $t=>$u){
    			if($u==$current_wrest_user->user_ID){
    				$res['isOK'] = 'yes';
    				$res['isOK_txt'] = '您已受邀为门店【{$shop->post_title}】的店员!';
    				return new WP_REST_Response($res);
    			}
    		}
    		
    		if(isset($employee_list[$time])){
    			throw new Exception('账户信息绑定失败：绑定码已被他人使用！');
    		}
    		
    		$employee_list[$time]=$current_wrest_user->user_ID;
    		
    		if(!WRest_Error::is_valid($shop->update(array(
    				'employee_list'=>$employee_list
    		)))){
    			throw new Exception('账户信息绑定失败：系统异常！');
    		}
    		
    		$res['isOK'] = 'yes';
    		$res['isOK_txt'] = '您已受邀为门店【{$shop->post_title}】的店员!';
    		return new WP_REST_Response($res);
    	}catch (Exception $e){
    		return new WP_Error('inner-error',$e->getMessage(),['status'=>500]);
    	}
    }
    
    public function init_form_fields(){
        $this->form_fields = array(
            'shipping_method'=>array(
                'title'=>'配送方式',
                'type'=>'shipping_method',
                'description'=>'选择到店消费对应的<a href="'.admin_url('admin.php?page=wc-settings&tab=shipping&section').'" target="_blank">配送区域 ->配送方式</a>'
            )
        );
    }

    public function generate_shipping_method_html($key, $data) {
		$field = $this->get_field_key ( $key );
		$defaults = array (
				'title' => '',
				'disabled' => false,
				'class' => '',
				'css' => 'min-width:150px;',
				'placeholder' => '',
				'type' => 'text',
				'desc_tip' => false,
		        'default'=>null,
				'description' => '',
				'custom_attributes' => array ()
		);
		
		$data = wp_parse_args ( $data, $defaults );
		$zones = array(
		    new WC_Shipping_Zone( 0 )
		);
		
		foreach ( WC_Data_Store::load( 'shipping-zone' )->get_zones() as $raw_zone ) {
		    $zones[]= new WC_Shipping_Zone( $raw_zone );
		}
		
		$zoneArray=array();
		foreach ($zones as $z){
		    $methods   = $z->get_shipping_methods();
		    uasort( $methods, 'wc_shipping_zone_method_order_uasort_comparison' );
		    $zoneItem = array(
		        'title'=>$z->get_zone_name(),
		        'shipping_methods'=>array()
		    );
		    
		    if ( ! empty( $methods ) ) {
		        foreach ( $methods as $method ) {
		            $zoneItem['shipping_methods'][$method->get_instance_id()] = $method->get_title();
		        }
		    }
		    $zoneArray[$z->get_id()]=$zoneItem;
		}
		$value = $this->get_option($key);
		if(!$value||!is_array($value)){$value=array();}
		$zone_id = isset($value['zone'])?$value['zone']:'';
		$shipping_method = isset($value['method'])?$value['method']:'';
		
		ob_start ();
		?>
        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
        	<th scope="row" class="titledesc"><label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
				<?php echo $this->get_tooltip_html( $data ); ?>
			</th>
        	<td class="forminp">
        		<fieldset>
        			<legend class="screen-reader-text">
        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
        			</legend>
        			
        			<div style="display:flex;flex-direction:row;">
            			<select class="select <?php echo esc_attr( $data['class'] ); ?>" name="<?php echo esc_attr( $field ); ?>-zone" id="<?php echo esc_attr( $field ); ?>-zone" style="<?php echo esc_attr( $data['css'] ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?>>
    						
    					</select>
    					<select class="select <?php echo esc_attr( $data['class'] ); ?>" name="<?php echo esc_attr( $field ); ?>-method" id="<?php echo esc_attr( $field ); ?>-method" style="margin-left:10px;<?php echo esc_attr( $data['css'] ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?>>
    						
    					</select>
					</div>
					<script type="text/javascript">
						(function($){
							var zones = <?php echo json_encode($zoneArray);?>;
							var zoneOptions = '';
							for(var index in zones){
								zoneOptions+='<option value="'+index+'" '+('<?php echo $zone_id?>'==index?'selected':'')+'>'+zones[index].title+'</option>';
							}
							$('#<?php echo esc_attr( $field ); ?>-zone').html(zoneOptions);

							$('#<?php echo esc_attr( $field ); ?>-zone').change(function(){
								var methodOptions = '';
								var zone_id = $(this).val();
								for(var index in zones[zone_id].shipping_methods){
									var method_title = zones[zone_id].shipping_methods[index];
									methodOptions+='<option value="'+index+'" '+('<?php echo $shipping_method?>'==index?'selected':'')+'>'+method_title+'</option>';
								}
								
								$('#<?php echo esc_attr( $field ); ?>-method').html(methodOptions);
							});

							$('#<?php echo esc_attr( $field ); ?>-zone').change();
						})(jQuery);
        			</script>
					<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
        	</td>
        </tr>
        <?php
		return ob_get_clean ();
	}
	
	public function validate_shipping_method_field($key) {
		$field = $this->get_field_key ( $key );
		     
	    return array(
	        'zone'=>isset($_POST [$field.'-zone'])?absint($_POST [$field.'-zone']):0,
	        'method'=>isset($_POST [$field.'-method'])?absint($_POST [$field.'-method']):0,
	    );
	}
}

return WRest_Add_On_Shipping_SC::instance();
?>