<?php 
class WRest_WC_Payment_Gateway_Alipay extends Abstract_WRest_WC_Payment_Gateway{
	private static $_instance;
	
	public static function instance(){
		if(!self::$_instance){
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	protected function __construct(){
		$this->id = strtolower(get_called_class());
		$this->supports[]='refunds';
		$api = WRest_Add_On_WC_Payment_Gateway_Alipay::instance();
		$this->icon = $api->domain_url. '/assets/images/alipay.png';
		
		$this->method_title='小程序 - 支付宝';
		
		$this->init_form_fields ();
		$this->init_settings ();
		
		$this->title = $this->get_option ( 'title' );
		$this->description = $this->get_option ( 'description' );
		$this->instructions  = $this->get_option( 'instructions');
		
		add_action ( 'woocommerce_update_options_payment_gateways_' .$this->id, array ($this,'process_admin_options') );
		add_action ( 'woocommerce_update_options_payment_gateways', array ($this,'process_admin_options') );
		add_action ( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
		add_action ( 'woocommerce_thankyou_'.$this->id, array( $this, 'thankyou_page' ) );
		//add_action ( 'woocommerce_receipt_'.$this->id, array ($this,'woocommerce_receipt') ,10,1);
		add_action('woocommerce_order_item_add_line_buttons', array($this,'order_item_add_line_buttons'),10,1);
	}
	
	function init_form_fields() {
		$this->form_fields = array (
				'enabled' => array (
						'title' => __('Enable/Disable','woocommerce'),
						'type' => 'checkbox',
						'default' => 'yes'
				),
				'title' => array (
						'title' => __('Title','woocommerce'),
						'type' => 'text',
						'default' =>  '支付宝',
						'css' => 'width:400px'
				),
				'description' => array (
						'title' => __('Description','woocommerce'),
						'type' => 'textarea',
						'css' => 'width:400px',
				),
				'instructions' => array(
						'title'       => __( 'Instructions', 'woocommerce' ),
						'type'        => 'textarea',
						'css' => 'width:400px',
						'description' => __( 'Instructions that will be added to the thank you page.', 'woocommerce' ),
						'default'     => ''
				),
				'partner_code' => array (
						'title' => '商户号',
						'type' => 'text',
						'css' => 'width:400px'
				),
				'credential_code' => array (
						'title' => '支付密钥',
						'type' => 'password',
						'css' => 'width:400px'
				),
				'prefix' => array (
						'title' => '订单号前缀',
						'description'=>'多个网站使用同一个支付宝账户时，避免订单号冲突。',
						'type' => 'text',
						'css' => 'width:400px',
						'default'=>'wc_',
				)
		);
	}
	
	public function process_payment_query(&$order_id=null,&$transaction_id=null,&$total_fee=null){
		$api = $this;
		$parameter = array (
				'service' => 'single_trade_query',
				'partner' =>$api->get_option('partner_code'),
				'_input_charset' => 'utf-8'
		);
		
		if($order_id){
			$parameter['out_trade_no'] = $this->get_out_trade_order_id($order_id);
		}
		
		if($transaction_id){
			$parameter['trade_no'] = $transaction_id;
		}
		
		$parameter['sign_type'] = 'MD5';
		$parameter['sign'] = $api->generate_pay_sign($parameter);
		
		$response_xml = WRest_Helper_Http::http_get('https://mapi.alipay.com/gateway.do?'.http_build_query($parameter),true);
		$response = WRest_Helper_String::xml_to_obj($response_xml);
		
		if(!$response||$response['is_success']!='T'){
			return false;
		}
		
		if($response['response']['trade']['trade_status']!='TRADE_SUCCESS'){
			return false;
		}
		$total_fee = $response['response']['trade']['total_fee'];
		$transaction_id = $response['response']['trade']['trade_no'];
		$order_id = $api->get_order_id_form_out_trade_order_id($response['response']['trade']['out_trade_no']);
		return $response['response']['trade'];
	}
	
	public function process_refund( $order_id, $amount = null, $reason = ''){
	    return new WP_Error('notice','请刷新页面后重试!');
	}
	
	
	/**
	 * 
	 * @param WC_Order $wc_order
	 */
	public function order_item_add_line_buttons($wc_order){
	    if($wc_order->get_payment_method()!=$this->id||! current_user_can( 'edit_shop_orders' ) ){
	        return;
	    }
	    
	    $order_id= $wc_order->get_id();
	    ?>
		<form id="form-wrestAlipayView-refund" action="<?php echo admin_url('/wp-json/payment/v1/alipay/refund')?>" method="post">
			<input type="hidden" name="order_id" value="<?php echo $order_id?>"/>
			<input type="hidden" name="amount"  id="form-wrestAlipayView-amount"/>
			<input type="hidden" name="reason" id="form-wrestAlipayView-reason"/>
		</form>
		<script type="text/javascript">
			var onAlipayViewLoad = function($){
				var $btn_redund=$('.refund-actions button.do-api-refund');
				if($btn_redund.length>0){
					var html = $btn_redund.html();
					$btn_redund.remove();
					$('.refund-actions').prepend('<button type="button" onclick="window.wrestAlipayView.refund(<?php print $order_id;?>);" class="button button-primary">'+html+'</button>');
				}
				
				window.wrestAlipayView =window.wrestAlipayView||{};
				window.wrestAlipayView.block=function(){
					$( '#woocommerce-order-items' ).block({
						message: null,
						overlayCSS: {
							background: '#fff',
							opacity: 0.6
						}
					});
				}

				window.wrestAlipayView.unblock=function(){
					$( '#woocommerce-order-items' ).unblock();
				}

				window.wrestAlipayView.refund=function(order_id){
					if ( window.confirm( woocommerce_admin_meta_boxes.i18n_do_refund ) ) {
						var refund_amount = $( 'input#refund_amount' ).val();
						var refund_reason = $( 'input#refund_reason' ).val();

						// Get line item refunds
						var line_item_qtys       = {};
						var line_item_totals     = {};
						var line_item_tax_totals = {};

						$( '.refund input.refund_order_item_qty' ).each(function( index, item ) {
							if ( $( item ).closest( 'tr' ).data( 'order_item_id' ) ) {
								if ( item.value ) {
									line_item_qtys[ $( item ).closest( 'tr' ).data( 'order_item_id' ) ] = item.value;
								}
							}
						});

						$( '.refund input.refund_line_total' ).each(function( index, item ) {
							if ( $( item ).closest( 'tr' ).data( 'order_item_id' ) ) {
								line_item_totals[ $( item ).closest( 'tr' ).data( 'order_item_id' ) ] = accounting.unformat( item.value, woocommerce_admin.mon_decimal_point );
							}
						});

						$( '.refund input.refund_line_tax' ).each(function( index, item ) {
							if ( $( item ).closest( 'tr' ).data( 'order_item_id' ) ) {
								var tax_id = $( item ).data( 'tax_id' );

								if ( ! line_item_tax_totals[ $( item ).closest( 'tr' ).data( 'order_item_id' ) ] ) {
									line_item_tax_totals[ $( item ).closest( 'tr' ).data( 'order_item_id' ) ] = {};
								}

								line_item_tax_totals[ $( item ).closest( 'tr' ).data( 'order_item_id' ) ][ tax_id ] = accounting.unformat( item.value, woocommerce_admin.mon_decimal_point );
							}
						});
						window.wrestAlipayView.block();
						var data = {
							action:                 'woocommerce_refund_line_items',
							order_id:               woocommerce_admin_meta_boxes.post_id,
							refund_amount:          refund_amount,
							refund_reason:          refund_reason,
							line_item_qtys:         JSON.stringify( line_item_qtys, null, '' ),
							line_item_totals:       JSON.stringify( line_item_totals, null, '' ),
							line_item_tax_totals:   JSON.stringify( line_item_tax_totals, null, '' ),
							api_refund:             $( this ).is( '.do-api-refund' ),
							restock_refunded_items: $( '#restock_refunded_items:checked' ).size() ? 'true' : 'false',
							security:               woocommerce_admin_meta_boxes.order_item_nonce
						};

						$.post( woocommerce_admin_meta_boxes.ajax_url, data, function( response ) {
							if ( true === response.success ) {
								
								var refund_amount = $( 'input#refund_amount' ).val();
								var refund_reason = $( 'input#refund_reason' ).val();
		
								$('#form-wrestAlipayView-amount').val(refund_amount);
								$('#form-wrestAlipayView-reason').val(refund_reason);
								//window.wrestAlipayView.block();
								$('#form-wrestAlipayView-refund').submit();
								
							} else {
								window.alert( response.data.error );
								window.wrestAlipayView.unblock();
							}
						});
					} else {
						window.wrestAlipayView.unblock();
					}
				};

				 
			};
			onAlipayViewLoad(jQuery);
			 document.addEventListener('resume', function(event) {
				 onAlipayViewLoad(jQuery);
			});
		</script>
		<?php 
	}
	
	public function process_payment($order_id){
	    $order = wc_get_order($order_id);
	    if(!$order||!$order->needs_payment()){
	        return array(
	            'result'=>'success',
	            'order_id'=>$order_id,
	            'complete'=>true
	        );
	    }
	    
	    $parameter = array (
	        'partner' =>$this->get_option('partner_code'),
	        'seller_id' =>$this->get_option('partner_code'),
	        'payment_type'=>'1',
	        'notify_url' => home_url('/wp-json/payment/v1/alipay/notify'),
	        'return_url' => home_url('/wp-json/payment/v1/alipay/back'),
	        'out_trade_no' => $this->generate_out_trade_order_id($order),
	        'subject' => $this->get_order_title($order),
	        '_input_charset' => 'utf-8',
	        'total_fee'=>round($order->get_total(),2),
	        'service'=>'alipay.wap.create.direct.pay.by.user',
	        'app_pay'=>'Y'
	    );
	    
	    $parameter['sign'] = $this->generate_pay_sign($parameter);
	    $parameter['sign_type'] = 'MD5';
	    
	    return array(
	        'result'=>'success',
	        'order_id'=>$order->get_id(),
	        'url_orderquery'=>home_url('/wp-json/payment/v1/alipay/query?id='.$order->get_id()),
	        'url_paylink'=>'https://mapi.alipay.com/gateway.do?'.http_build_query($parameter),
	        'redirect'=>'https://mapi.alipay.com/gateway.do?'.http_build_query($parameter),
	    );
	}
	
	public function generate_pay_sign($parameter){
	    ksort($parameter);
	    reset($parameter);
	
	    $builder = '';
	    foreach ($parameter as $key=>$val){
	        if($key==='sign'||$key==='sign_type'||$val===''||is_array($val)){
	            continue;
	        }
	
	        if($builder){
	            $builder.='&';
	        }
	        $builder.="{$key}={$val}";
	    }
	     
	    return md5($builder .$this->get_option('credential_code') );
	}
}
?>