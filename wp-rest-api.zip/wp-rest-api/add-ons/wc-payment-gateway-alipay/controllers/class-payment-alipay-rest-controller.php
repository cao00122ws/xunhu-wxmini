<?php
if (! defined ( 'ABSPATH' )) {
	exit ();
}

class WRest_Payment_Alipay_Rest_Controller extends Abstract_WRest_Controller {
	public function __construct() {
		$this->rest_base = 'alipay';
	}
	public function register_routes() {
		register_rest_route ( $this->namespace, "/{$this->rest_base}/notify", array (
				array (
						'methods' => WP_REST_Server::ALLMETHODS,
						'callback' => array ($this,'notify')
				)
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/query", array (
		    array (
		    		'methods' => WP_REST_Server::ALLMETHODS,
		        	'callback' => array ($this,'query')
		    )
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/back", array (
				array (
						'methods' => WP_REST_Server::ALLMETHODS,
						'callback' => array ($this,'back')
				)
		) );

		register_rest_route ( $this->namespace, "/{$this->rest_base}/refund", array (
		    array (
		        'methods' => WP_REST_Server::ALLMETHODS,
		        'callback' => array ($this,'refund')
		    )
		) );
	}

	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function refund($request){
	    $order_id = $request->get_param('order_id');
	    $amount =  round($request->get_param('amount'),2);
	    $reason =  wc_clean($request->get_param('reason'));
	    
	    if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_die( -1 );
		}
	  
	    $order = wc_get_order($order_id);
	    if(!$order){
	        wp_die('订单信息异常！');
	    }
	    
	    
	    $total = $order->get_total();
	    if($amount<=0||$amount>$total){
	       wp_die('订单退款金额异常！');
	    }
	    $api = WRest_WC_Payment_Gateway_Alipay::instance();
	    $transaction_id=$order->get_transaction_id();
	    
	    // 批次号，必填，格式：当天日期[8位]+序列号[3至24位]，如：201603081000001
	    
	    $batch_no = date_i18n('Ymdhis').substr(floor(microtime()*1000),0,1).rand(0,9);
	    // 退款笔数，必填，参数detail_data的值中，“#”字符出现的数量加1，最大支持1000笔（即“#”字符出现的数量999个）
	    
	    $batch_num = 1;
	    $reason = str_replace('^', '', $reason);
	    $reason = mb_strimwidth($reason, 0, 64,'...','utf-8');
	    // 退款详细数据，必填，格式（支付宝交易号^退款金额^备注），多笔请用#隔开
	    $detail_data = "{$transaction_id}^{$amount}^{$reason}";
	    $parameter = array (
	        "service" => 'refund_fastpay_by_platform_pwd',
	        "partner" => $api->get_option('partner_code'),
	        //"notify_url" => '',
	        "seller_user_id" => $api->get_option('partner_code'),
	        "refund_date" => date_i18n('Y-m-d H:i:s'),
	        "batch_no" => $batch_no,
	        "batch_num" => $batch_num,
	        "detail_data" => $detail_data,
	        "_input_charset" => 'utf-8'
	    );
	    
	    $parameter['sign']=$api->generate_pay_sign($parameter);
	    wp_redirect('https://mapi.alipay.com/gateway.do?'.http_build_query($parameter));
	    exit;
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function back($request){
		$api = WRest_WC_Payment_Gateway_Alipay::instance();
		
		$request = stripslashes_deep($_GET);
		if(!isset($request['sign'])||$request['sign']!=$api->generate_pay_sign($request)){
			wp_die('invalid sign!');
		}
		if($request['trade_status']!='TRADE_FINISHED'&&$request['trade_status']!= 'TRADE_SUCCESS'){
			wp_die('invalid request!');
		}
		
		try{
			$transaction_id = $request['trade_no'];
			$order_id = null;
			$response = $api->process_payment_query($order_id,$transaction_id);
			if(!$response){
				wp_die('order not paid!');
				exit;
			}
			
			$out_trade_no = $response['out_trade_no'];
			$order = wc_get_order($api->get_order_id_form_out_trade_order_id($out_trade_no));
			if(!$order){
				wp_die('order is not found!');
				exit;
			}
			
// 			if(round($order->get_total(),2)!=round($response['total_fee'],2)){
// 				wp_die('订单信息金额无法匹配！');
// 			}
			
			if(!$order->needs_payment()){
				wp_redirect($api->get_return_url($order));
				exit;
			}
			
			$order->payment_complete($request['trade_no']);
			
			wp_redirect($api->get_return_url($order));
			exit;
		}catch (Exception $e){
			wp_die($e->getMessage());
		}
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function query($request){
	    $order_id = absint($request->get_param('id'));
	    $order = wc_get_order($order_id);
	    if(!$order){
	        return new WP_REST_Response(array(
	            'paid'=>'N',
	            'order_id'=>$order_id
	        ));
	    }
	    
	    if(!$order->needs_payment()){
	        return new WP_REST_Response(array(
	            'paid'=>'Y',
	            'order_id'=>$order_id
	        ));
	    }
	    $api = WRest_WC_Payment_Gateway_Alipay::instance();
	    try{
	    	$order_id = $order->get_id();
	    	$transaction_id = null;
	    	$response = $api->process_payment_query($order_id,$transaction_id);
	        if(!$response){
	            return new WP_REST_Response(array(
	                'paid'=>'N',
	            'order_id'=>$order_id
	            ));
	        }
	         
// 	        if(round($order->get_total(),2)!=round($response['total_fee'],2)){
// 	            return new WP_Error('inner-error','订单信息金额无法匹配！',array('status'=>500));
// 	        }
	        
	        $order->payment_complete($response['trade_no']);
	        return new WP_REST_Response(array(
	            'paid'=>'Y',
	            'order_id'=>$order_id
	        ));
	    }catch (Exception $e){
	        return new WP_Error('inner-error','系统内部异常！',array('status'=>500));
	    }
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function notify($request){
	    $api = WRest_WC_Payment_Gateway_Alipay::instance();
	    
	    $request = stripslashes_deep($_POST);
	    if(!isset($request['sign'])||$request['sign']!=$api->generate_pay_sign($request)){
	        $this->_response_notify('invalid sign!');
	        exit;
	    }
	    if($request['trade_status']!='TRADE_FINISHED'&&$request['trade_status']!= 'TRADE_SUCCESS'){
	    	$this->_response_notify('invalid request!');
	    	exit;
	    }
	    
	    try{
	    	$transaction_id = $request['trade_no'];
	    	$order_id = null;
	    	$response = $api->process_payment_query($order_id,$transaction_id);
	        if(!$response){
	            $this->_response_notify('order not paid!');
	            exit;
	        }
	        
	        $out_trade_no = $response['out_trade_no'];
	        $order = wc_get_order($api->get_order_id_form_out_trade_order_id($out_trade_no));
	        if(!$order){
	            $this->_response_notify('order is not found!');
	            exit;
	        }
	        
// 	        if(round($order->get_total(),2)!=round($response['total_fee'],2)){
// 	            return new WP_Error('inner-error','订单信息金额无法匹配！',array('status'=>500));
// 	        }
	        
	        if(!$order->needs_payment()){
	            $this->_response_notify();
	            exit;
	        }
	         
	        $order->payment_complete($request['trade_no']);
	         
	        $this->_response_notify();
	        exit;
	    }catch (Exception $e){
	        $this->_response_notify($e->getMessage());
	        exit;
	    }
	}
	
	
	private function _response_notify($errmsg='success'){
		if($errmsg!='success'){
			WRest_Log::error($errmsg);
		}
	    echo $errmsg;
	    exit;
	}
	
}