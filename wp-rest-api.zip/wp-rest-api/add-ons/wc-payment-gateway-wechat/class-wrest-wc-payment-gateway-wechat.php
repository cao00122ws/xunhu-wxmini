<?php 
class WRest_WC_Payment_Gateway_Wechat extends Abstract_WRest_WC_Payment_Gateway{
	private static $_instance;
	
	public static function instance(){
		if(!self::$_instance){
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	protected function __construct(){
		$this->id = strtolower(get_called_class());
		$this->supports[]='refunds';
		$api = WRest_Add_On_WC_Payment_Gateway_Wechat::instance();
		$this->icon = $api->domain_url. '/assets/images/wechat.png';
		
		$this->method_title='小程序 - 微信支付';
		
		$this->init_form_fields ();
		$this->init_settings ();
		
		$this->title = $this->get_option ( 'title' );
		$this->description = $this->get_option ( 'description' );
		$this->instructions  = $this->get_option( 'instructions');
		
		add_action ( 'woocommerce_update_options_payment_gateways_' .$this->id, array ($this,'process_admin_options') );
		add_action ( 'woocommerce_update_options_payment_gateways', array ($this,'process_admin_options') );
		add_action ( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
		add_action ( 'woocommerce_thankyou_'.$this->id, array( $this, 'thankyou_page' ) );
		//add_action ( 'woocommerce_receipt_'.$this->id, array ($this,'woocommerce_receipt') ,10,1);
	}
	
	function init_form_fields() {
	    $api = WRest_Add_On_WC_Payment_Gateway_Wechat::instance();
		$this->form_fields = array (
				'enabled' => array (
						'title' => __('Enable/Disable','woocommerce'),
						'type' => 'checkbox',
						'default' => 'yes'
				),
				'title' => array (
						'title' => __('Title','woocommerce'),
						'type' => 'text',
						'default' =>  '微信支付',
						'css' => 'width:400px'
				),
				'description' => array (
						'title' => __('Description','woocommerce'),
						'type' => 'textarea',
						'css' => 'width:400px',
				),
				'instructions' => array(
						'title'       => __( 'Instructions', 'woocommerce' ),
						'type'        => 'textarea',
						'css' => 'width:400px',
						'description' => __( 'Instructions that will be added to the thank you page.', 'woocommerce' ),
						'default'     => ''
				),
				'partner_code' => array (
						'title' => '微信支付商户号',
						'type' => 'text',
						'css' => 'width:400px'
				),
				'credential_code' => array (
						'title' => '微信支付商户密钥',
						'type' => 'password',
						'css' => 'width:400px',
				        'description'=>"注意：退款功能需要上传证书到<code>{$api->domain_dir}/cert/</code>"
				),
				'prefix' => array (
						'title' => '订单号前缀',
						'description'=>'多个网站使用同一个微信支付账户时，避免订单号冲突。',
						'type' => 'text',
						'css' => 'width:400px',
						'default'=>'wc_',
				)
		);
	}
	
    public function process_refund( $order_id, $amount = null, $reason = ''){
        $wc_order = wc_get_order ($order_id );
        if(!$wc_order){
            return new WP_Error( 'invalid_order', __('Wrong Order') );
        }
    
        $total = $wc_order->get_total ();
        if($amount<=0||$amount>$total){
            return new WP_Error( 'invalid_order',__('Invalid Amount ' ) );
        }
        
        $total_fee = $wc_order->get_total();
        if(in_array($wc_order->get_currency(), apply_filters('wrest_currency_round', array('JPY','KRW')))){
            $total_fee = round($total_fee);
        }else{
            $total_fee = round($total_fee*100);
        }
        
        if(in_array($wc_order->get_currency(), apply_filters('wrest_currency_round', array('JPY','KRW')))){
            $amount = round($amount);
        }else{
            $amount = round($amount*100);
        }
        
        $main = WRest_Settings_Default_Basic_Default::instance();
        try {
           $request = array(
               'appid'=>$main->get_option('appid'),
			   'mch_id'=>$this->get_option('partner_code'),
               'nonce_str'=>str_shuffle(time()),
               'transaction_id'=>$wc_order->get_transaction_id(),
               'out_refund_no'=>$this->generate_refund_order_id($wc_order),
               'total_fee'=>$total_fee,
               'refund_fee'=>$amount
           );
           
           $api = WRest_Add_On_WC_Payment_Gateway_Wechat::instance();
           if(!file_exists($api->domain_dir.'/cert/apiclient_cert.pem')
               ||!file_exists($api->domain_dir.'/cert/apiclient_key.pem')){
                   return new WP_Error( 'invalid_order','系统没安装证书，无法退款！' );
           }
           
           $url = 'https://api.mch.weixin.qq.com/secapi/pay/refund';
           $request['sign'] = $this->generate_pay_sign($request);
          
           $curl = curl_init();
           curl_setopt($curl,CURLOPT_SSLCERTTYPE,'PEM');
           curl_setopt($curl,CURLOPT_SSLCERT, $api->domain_dir.'/cert/apiclient_cert.pem');
           curl_setopt($curl,CURLOPT_SSLKEYTYPE,'PEM');
           curl_setopt($curl,CURLOPT_SSLKEY, $api->domain_dir.'/cert/apiclient_key.pem');
           
           $responseTxt = WRest_Helper_Http::http_post($url,WRest_Helper_String::obj_to_xml($request),false,$curl);
           $response = WRest_Helper_String::xml_to_obj($responseTxt,true);
           if(!$response){
               throw new Exception('网络异常:'.$responseTxt);
           }
           if($response['return_code']!='SUCCESS'){
               throw new Exception($response['return_msg']);
           }
           
           if($response['result_code']!='SUCCESS'){
               throw new Exception($response['err_code_des']);
           }
        }catch(Exception $e){
            return new WP_Error( 'refuse_error', $e->getMessage());
        }
         
        return true;
    }
	
	public function process_payment_query(&$order_id=null,&$transaction_id=null,&$total_fee=null){
		$api = $this;
		$main = WRest_Settings_Default_Basic_Default::instance();
		$request = array(
				'appid'=>$main->get_option('appid'),
				'mch_id'=>$api->get_option('partner_code'),
				'nonce_str'=>str_shuffle(time()),
				'sign_type'=>'MD5'
		);
		
		if($order_id){
			$request['out_trade_no']=$this->get_out_trade_order_id($order_id);
		}
		
		if($transaction_id){
			$request['transaction_id']=$transaction_id;
		}
		
		$request['sign'] = $api->generate_pay_sign($request);
		$xml = WRest_Helper_String::obj_to_xml($request);
		$response_xml = WRest_Helper_Http::http_post('https://api.mch.weixin.qq.com/pay/orderquery',$xml);
		$response = WRest_Helper_String::xml_to_obj($response_xml,true);
		
		if(!$response||$response['return_code']!='SUCCESS'){
			return false;
		}
		
		if($response['result_code']!='SUCCESS'){
			return false;
		}
		
		if($response['trade_state']!='SUCCESS'){
			return false;
		}
		
		$total_fee = $response['total_fee'];
		$order_id = $api->get_order_id_form_out_trade_order_id($response['out_trade_no']);
		$transaction_id = $response['transaction_id'];
		return $response;
	}
	
	public function process_payment($order_id){
		$order = wc_get_order($order_id);
		if(!$order||!$order->needs_payment()){
			return array(
					'result'=>'success',
			        'order_id'=>$order_id,
					'complete'=>true
			);
		}
	   global $current_wrest_user;
		if(!$current_wrest_user){
		    $current_wrest_user= new WRest_User(get_current_user_id());
		}
		
		if($order->get_customer_id()!=get_current_user_id()
		    || !$current_wrest_user->is_load()
		    ||empty($current_wrest_user->openid)
		    ||$order->get_customer_id()!=$current_wrest_user->user_ID){
			throw new Exception('用户登录信息异常！(请尝试重新登录)');
		}
		
		$total_fee = $order->get_total();
		if(in_array($order->get_currency(), apply_filters('wrest_currency_round', array('JPY','KRW')))){
		    $total_fee = round($total_fee);
		}else{
		    $total_fee = round($total_fee*100);
		}
		
		$main = WRest_Settings_Default_Basic_Default::instance();
		$request = array(
				'appid'=>$main->get_option('appid'),
				'mch_id'=>$this->get_option('partner_code'),
				'nonce_str'=>str_shuffle(time()),
				'sign_type'=>'MD5',
				'body'=>$this->get_order_title($order),
				'out_trade_no'=>$this->generate_out_trade_order_id($order),
				'fee_type'=>$order->get_currency(),
				'total_fee'=>$total_fee,
				'spbill_create_ip'=>WRest_Helper_Http::get_client_ip(),
				'time_start'=>date_i18n('YmdHis'),
				'time_expire'=>date('YmdHis',current_time( 'timestamp')+15*60),
				'notify_url'=>home_url('/wp-json/payment/v1/wechat/notify'),
				'trade_type'=>'JSAPI',
				'openid'=>$current_wrest_user->get_openid(),
				'receipt'=>'Y'
		);
		
		$request['sign'] = $this->generate_pay_sign($request);
		
		$xml = WRest_Helper_String::obj_to_xml($request);
		$response_html = WRest_Helper_Http::http_post('https://api.mch.weixin.qq.com/pay/unifiedorder',$xml);
		$response = WRest_Helper_String::xml_to_obj($response_html,true);
		if(!$response||!is_array($response)){
			throw new Exception('网络异常，请重试！');
		}
		
		if($response['return_code']!='SUCCESS'){
			throw new Exception($response['return_msg']);
		}
		
		if($response['result_code']!='SUCCESS'){
			throw new Exception($response['err_code_des']);
		}
		
		$prepay_id = $response['prepay_id'];
		do_action('wrest_wc_payment_wechat_perpay_id',$response,$request,$order);
		
		$jsapi = array(
				'timeStamp'=>time(),
				'nonceStr'=>str_shuffle(time()),
				'package'=>"prepay_id={$prepay_id}",
				'signType'=>'MD5'
		);
		$main = WRest_Settings_Default_Basic_Default::instance();
		$jsapi['paySign'] = $this->generate_pay_sign(array_merge($jsapi,array(
				'appId'=>$main->get_option('appid')
		)));
		
		return array(
				'result'=>'success',
				'jsapi'=>$jsapi,
		        'order_id'=>$order->get_id(),
		        'url_orderquery'=>home_url('/wp-json/payment/v1/wechat/query?id='.$order->get_id())
		);
	}
	
	public function generate_pay_sign($request){
		ksort($request);
		reset($request);
		$str = '';
		foreach ($request as $k => $v)
		{
			if(!is_null($v)&&$v!==''&&$k!='sign'&&!is_array($v)){
				if($str){
					$str.='&';
				}
				$str.="{$k}={$v}";
			}
		}
		
		$str .= "&key=".$this->get_option('credential_code');
	
		return strtoupper(md5($str));
	}
}
?>