<?php
if (! defined ( 'ABSPATH' )) {
	exit ();
}

class WRest_Payment_Wechat_Rest_Controller extends Abstract_WRest_Controller {
	public function __construct() {
		$this->rest_base = 'wechat';
	}
	public function register_routes() {
		register_rest_route ( $this->namespace, "/{$this->rest_base}/notify", array (
				array (
						'methods' => WP_REST_Server::ALLMETHODS,
						'callback' => array ($this,'notify')
				)
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/query", array (
		    array (
		    		'methods' => WP_REST_Server::ALLMETHODS,
		        	'callback' => array ($this,'query')
		    )
		) );
	}

	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function query($request){
	    $order_id = absint($request->get_param('id'));
	    $order = wc_get_order($order_id);
	    if(!$order){
	        return new WP_REST_Response(array(
	            'paid'=>'N',
	            'order_id'=>$order_id
	        ));
	    }
	    
	    if(!$order->needs_payment()){
	        return new WP_REST_Response(array(
	            'paid'=>'Y',
	            'order_id'=>$order_id
	        ));
	    }
	    $api = WRest_WC_Payment_Gateway_Wechat::instance();
	    try{
	    	$order_id = $order->get_id();
	    	$transaction_id = null;
	    	$response = $api->process_payment_query($order_id,$transaction_id);
	        if(!$response){
	            return new WP_REST_Response(array(
	                'paid'=>'N',
	               'order_id'=>$order_id
	            ));
	        }
	        
            $total_fee = $order->get_total();
            if(in_array($order->get_currency(), apply_filters('wrest_currency_round', array('JPY','KRW')))){
	            $total_fee = round($total_fee);
	        }else{
	            $total_fee = round($total_fee*100);
	        }
	        
// 	        if($total_fee!=$response['total_fee']){
// 	            return new WP_Error('inner-error','订单信息金额无法匹配！',array('status'=>500));
// 	        }
	        
	        $order->payment_complete($response['transaction_id']);
	        return new WP_REST_Response(array(
	            'paid'=>'Y',
	            'order_id'=>$order_id
	        ));
	    }catch (Exception $e){
	        return new WP_Error('inner-error','系统内部异常！',array('status'=>500));
	    }
	    
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function notify($request){
	    $api = WRest_WC_Payment_Gateway_Wechat::instance();
	    $xml =isset($GLOBALS['HTTP_RAW_POST_DATA'])?$GLOBALS['HTTP_RAW_POST_DATA']:'';
	    if(empty($xml)){
	        $xml = file_get_contents("php://input");
	    }
	    
	    if(empty($xml)){
	        $this->_response_notify('invalid request!');
	        exit;
	    }
	  
	    $request = WRest_Helper_String::xml_to_obj($xml,true);
	    
	    if(!isset($request['sign'])||$request['sign']!=$api->generate_pay_sign($request)){
	        $this->_response_notify('invalid sign!');
	        exit;
	    }
	    
	    if($request['return_code']!='SUCCESS'){
	        $this->_response_notify($request['return_msg']);
	        exit;
	    }
	    
	    if($request['result_code']!='SUCCESS'){
	        $this->_response_notify($request['err_code_des']);
	        exit;
	    }
	    try{
			$order_id = null;
			$transaction_id = $request['transaction_id'];
			$response = $api->process_payment_query($order_id,$transaction_id);
	        if(!$response){
	            $this->_response_notify('order not paid!');
	            exit;
	        }
	        $out_trade_no = $response['out_trade_no'];
	        $order = wc_get_order($api->get_order_id_form_out_trade_order_id($out_trade_no));
	        if(!$order){
	            $this->_response_notify('order is not found!');
	            exit;
	        }
	        $total_fee = $order->get_total();
	        if(in_array($order->get_currency(), apply_filters('wrest_currency_round', array('JPY','KRW')))){
	            $total_fee = round($total_fee);
	        }else{
	            $total_fee = round($total_fee*100);
	        }
// 	        if($total_fee!=$response['total_fee']){
// 	            return new WP_Error('inner-error','订单信息金额无法匹配！',array('status'=>500));
// 	        }
	        if(!$order->needs_payment()){
	            $this->_response_notify();
	            exit;
	        }
	         
	        $order->payment_complete($request['transaction_id']);
	         
	        $this->_response_notify();
	        exit;
	    }catch (Exception $e){
	        $this->_response_notify($e->getMessage());
	        exit;
	    }
	}
	
	private function _response_notify($errmsg='OK'){
		if($errmsg!='OK'){
			WRest_Log::error($errmsg);
		}
	    ?>
	    <xml>
          <return_code><![CDATA[<?php echo $errmsg=='OK'?'SUCCESS':'FAIL' ?>]]></return_code>
          <return_msg><![CDATA[<?php echo $errmsg;?>]]></return_msg>
        </xml>
	    <?php
	    exit;
	}
	
}