<?php
if (! defined ( 'ABSPATH' )) {
	exit ();
}

class WRest_Payment_Wepayez_Alipay_Rest_Controller extends Abstract_WRest_Controller {
	public function __construct() {
		$this->rest_base = 'wepayez/alipay';
	}
	public function register_routes() {
		register_rest_route ( $this->namespace, "/{$this->rest_base}/notify", array (
				array (
						'methods' => WP_REST_Server::ALLMETHODS,
						'callback' => array ($this,'notify')
				)
		) );
		register_rest_route ( $this->namespace, "/{$this->rest_base}/back", array (
		    array (
		        'methods' => WP_REST_Server::ALLMETHODS,
		        'callback' => array ($this,'back')
		    )
		));
		register_rest_route ( $this->namespace, "/{$this->rest_base}/query", array (
		    array (
		    		'methods' => WP_REST_Server::ALLMETHODS,
		        	'callback' => array ($this,'query')
		    )
		));
	}

	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function back($request){
	    $res = shortcode_atts(array(
	        'id'=>null,
	        'notice_str'=>null,
	        'sign'=>null
	    ), $request->get_params());
	    $api = WRest_WC_Payment_Gateway_Wepayez_Alipay::instance();
	    if($res['sign']!=$api->generate_sign($res)){
	        wp_die('invalid order');
	    }
	    
	    $wc_order_id = absint($res['id']);
	    $wc_order = wc_get_order($wc_order_id);
	    if(!$wc_order){
	        wp_die('invalid order');
	    }
	    
	    try{
	        $transaction_id = null;
	        $order_id = $wc_order->get_id();
	        $response = $api->process_payment_query($order_id,$transaction_id);
	        if(!$response){
	            wp_die('order not paid!');
	            exit;
	        }
	        	
// 	        if(round($wc_order->get_total()*100)!=round($response['total_fee'])){
// 	            wp_die('订单信息金额无法匹配！');
// 	        }
	        	
	        if(!$wc_order->needs_payment()){
	            wp_redirect($api->get_return_url($wc_order));
	            exit;
	        }
	        	
	        $wc_order->payment_complete($request['trade_no']);
	        	
	        wp_redirect($api->get_return_url($wc_order));
	        exit;
	    }catch (Exception $e){
	        wp_die($e->getMessage());
	    }
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function query($request){
	    $order_id = absint($request->get_param('id'));
	    $order = wc_get_order($order_id);
	    if(!$order){
	        return new WP_REST_Response(array(
	            'paid'=>'N',
	            'order_id'=>$order_id
	        ));
	    }
	    
	    if(!$order->needs_payment()){
	        return new WP_REST_Response(array(
	            'paid'=>'Y',
	            'order_id'=>$order_id
	        ));
	    }
	    
	    $api = WRest_WC_Payment_Gateway_Wepayez_Alipay::instance();
	    try{
	    	$order_id = $order->get_id();
	    	$transaction_id = null;
	    	$response = $api->process_payment_query($order_id,$transaction_id);
	        if(!$response){
	            return new WP_REST_Response(array(
	                'paid'=>'N',
	                'order_id'=>$order_id
	            ));
	        }
	         
// 	        if(round($order->get_total()*100)!=$response['total_fee']){
// 	            return new WP_Error('inner-error','订单信息金额无法匹配！',array('status'=>500));
// 	        }
	        
	        $order->payment_complete($response['order_id']);
	        return new WP_REST_Response(array(
	            'paid'=>'Y',
	            'order_id'=>$order_id
	        ));
	    }catch (Exception $e){
	        return new WP_Error('inner-error','系统内部异常！',array('status'=>500));
	    }
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function notify($res){
	    $api = WRest_WC_Payment_Gateway_Wepayez_Alipay::instance();
	    $json =isset($GLOBALS['HTTP_RAW_POST_DATA'])?$GLOBALS['HTTP_RAW_POST_DATA']:'';
	    if(empty($json)){
	        $json = file_get_contents("php://input");
	    }
	    
	    if(empty($json)){
	        throw new Exception('invalid request');
	    }

	    $request = WRest_Helper_String::xml_to_obj($json,true);
	    if(!$request){
	        return new WP_Error('invalid-request','invalid request!',array('status'=>500));
	    }
	    
	    $response = $api->validate_callback_data($request);
	    $order = wc_get_order($api->get_order_id_form_out_trade_order_id($response['out_trade_no']));
	    if(!$order){
	        return new WP_Error('inner-error','invalid order！',array('status'=>500));
	    }
	    
// 	    if(round($order->get_total()*100)!=$response['total_fee']){
//             return new WP_Error('inner-error','订单信息金额无法匹配！',array('status'=>500));
//         }
	        
	    if("{$response['pay_result']}"==='0'){
	        try {
	            if(!$order->needs_payment()){
	                echo 'success';
	                exit;
	            }
	    
	            $order->payment_complete($response['transaction_id']);
	        } catch (Exception $e) {
	            wc_get_logger()->error($e->getMessage());
	            echo 'faiture';
	            exit;
	        }
	    }
	   
	    echo 'success';
	    exit;
	}
}