<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
   
/**
 * @author rain
 *
 */
class WRest_Add_On_WC_Payment_Gateway_Wepayez_Alipay extends Abstract_WRest_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WRest_Add_On_Payjs
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WRest_Add_On_WC_Payment_Gateway_Wepayez_Alipay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wrest_add_on_wc_payment_gateway_wepayez_alipay';
        $this->title='Wepayez - 支付宝';
        $this->description='微信小程序 - 支付宝';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author='迅虎网络';
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WRest_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WRest_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>'设置',
                'url'=>admin_url("admin.php?page=wc-settings&tab=checkout&section=wrest_wc_payment_gateway_wepayez_alipay")
            )
        );
    }

    public function on_load(){
        add_action('wrest_payment_area_requires', array($this,'wrest_payment_area_requires'),10);
    	add_filter('wrest_payment_controllers', array($this,'wrest_payment_controllers'),10,1);
    }
    
    public function wrest_payment_controllers($controllers){
    	$controllers[]=new WRest_Payment_Wepayez_Alipay_Rest_Controller();
    	return $controllers;
    }
    
    public function wrest_payment_area_requires(){
        require_once 'controllers/class-payment-alipay-rest-controller.php';
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WRest_Add_Ons::on_init()
     */
    public function on_init(){
    	add_filter ( 'woocommerce_payment_gateways', function($gateways){
    	    if(is_admin()||(defined('REST_REQUEST')&&REST_REQUEST)){
    			require_once 'class-wrest-wc-payment-gateway-alipay.php';
    			$gateways[]=WRest_WC_Payment_Gateway_Wepayez_Alipay::instance();
    		}
    		return $gateways;
    	} );
	
		add_action( 'rest_api_init', function(){
			require_once 'class-wrest-wc-payment-gateway-alipay.php';
		} );
    }
}

return WRest_Add_On_WC_Payment_Gateway_Wepayez_Alipay::instance();
?>