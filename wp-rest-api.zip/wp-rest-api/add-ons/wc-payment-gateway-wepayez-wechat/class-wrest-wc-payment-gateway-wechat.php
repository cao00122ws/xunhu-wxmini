<?php 
class WRest_WC_Payment_Gateway_Wepayez_Wechat extends Abstract_WRest_WC_Payment_Gateway{
	private static $_instance;
	
	public static function instance(){
		if(!self::$_instance){
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	protected function __construct(){
		$this->id = strtolower(get_called_class());
		$this->supports[]='refunds';
		$api = WRest_Add_On_WC_Payment_Gateway_Wepayez_Wechat::instance();
		$this->icon = $api->domain_url. '/assets/images/wechat.png';
		
		$this->method_title='小程序 - Wepayez 微信支付';
		
		$this->init_form_fields ();
		$this->init_settings ();
		
		$this->title = $this->get_option ( 'title' );
		$this->description = $this->get_option ( 'description' );
		$this->instructions  = $this->get_option( 'instructions');
		
		add_action ( 'woocommerce_update_options_payment_gateways_' .$this->id, array ($this,'process_admin_options') );
		add_action ( 'woocommerce_update_options_payment_gateways', array ($this,'process_admin_options') );
		add_action ( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
		add_action ( 'woocommerce_thankyou_'.$this->id, array( $this, 'thankyou_page' ) );
		//add_action ( 'woocommerce_receipt_'.$this->id, array ($this,'woocommerce_receipt') ,10,1);
	}
	
	function init_form_fields() {
		$this->form_fields = array (
				'enabled' => array (
						'title' => __('Enable/Disable','woocommerce'),
						'type' => 'checkbox',
						'default' => 'yes'
				),
				'title' => array (
						'title' => __('Title','woocommerce'),
						'type' => 'text',
						'default' => '微信支付(全球)',
						'css' => 'width:400px'
				),
				'description' => array (
						'title' => __('Description','woocommerce'),
						'type' => 'textarea',
						'css' => 'width:400px',
				),
				'instructions' => array(
						'title'       => __( 'Instructions', 'woocommerce' ),
						'type'        => 'textarea',
						'css' => 'width:400px',
						'description' => __( 'Instructions that will be added to the thank you page.', 'woocommerce' ),
						'default'     => ''
				),
				'partner_code' => array (
						'title' => '商户编码',
						'type' => 'text',
						'css' => 'width:400px'
				),
				'credential_code' => array (
						'title' => '签名密钥',
						'type' => 'password',
						'css' => 'width:400px'
				),
				'prefix' => array (
						'title' => '订单号前缀',
						'description'=>'多个网站使用同一个微信支付账户时，避免订单号冲突。',
						'type' => 'text',
						'css' => 'width:400px',
						'default'=>'wc_',
				)
		);
	}
	
    public function process_refund( $order_id, $amount = null, $reason = ''){
	    $wc_order = wc_get_order ($order_id );
	    if(!$wc_order){
	        return new WP_Error( 'invalid_order', __('Wrong Order') );
	    }
	
	    $total = $wc_order->get_total ();
	    if($amount<=0||$amount>$total){
	        return new WP_Error( 'invalid_order',__('Invalid Amount ' ) );
	    }
	    if(in_array($wc_order->get_currency(), apply_filters('wrest_currency_round', array('JPY','KRW')))){
	        $total = round($total);
	        $amount = round($amount);
	    }else{
	        $total = round($total*100);
	        $amount = round($amount*100);
	    }
	    
	    $qty = $wc_order->get_total_qty_refunded();
		$request=array(
		    'service'=>'unified.trade.refund',
		    'mch_id'=>$this->get_option('partner_code'),
		    'out_trade_no'=>$this->get_out_trade_order_id($wc_order),
		    'out_refund_no'=>"{$order_id}D{$qty}",
		    'total_fee'=>$total,
		    'refund_fee'=>$amount,
		    'op_user_id'=>$this->get_option('partner_code'),
		    'nonce_str'=>str_shuffle(time())
		);
		
		$request['sign']=$this->generate_sign($request);
		try {
		    $request['sign']=$this->generate_sign($request);
		    $response = WRest_Helper_Http::http_post('https://pay.wepayez.com/pay/gateway', WRest_Helper_String::obj_to_xml($request));
		    
		    $result = WRest_Helper_String::xml_to_obj($response);
		    if(!$result){
		        throw new Exception('invalid callback data:'.$response);
		    }
		    	
		    $response = $this->validate_callback_data($result);
		    if(!empty($response['refund_id'])){
		        return true;
		    }
		    
		} catch (Exception $e) {
		    wc_get_logger()->error($e->getMessage());
		  
		    return new WP_Error( 'refuse_error', $e->getMessage());
		}
	     
	    return true;
	}
	
	public function process_payment_query(&$order_id=null,&$transaction_id=null,&$total_fee=null){
        if(!$order_id){
            throw new Exception('invalid order_id for query');
        }
	     
        $partner_code = $this->get_option('partner_code');
        $credential_code = $this->get_option('credential_code');
        $new_order_id = $this->get_out_trade_order_id($order_id);
        
        $request=array(
            'service'=>'unified.trade.query',
            'mch_id'=>$this->get_option('partner_code'),
            'out_trade_no'=>$new_order_id,
            'transaction_id'=>$transaction_id,
            'nonce_str'=>str_shuffle(time())
        );
        
        $request['sign']=$this->generate_sign($request);
        $response = WRest_Helper_Http::http_post('https://pay.wepayez.com/pay/gateway', WRest_Helper_String::obj_to_xml($request));
    
        $result = WRest_Helper_String::xml_to_obj($response);
        if(!$result){
            throw new Exception('invalid callback data:'.$response);
        }
         
        $response = $this->validate_callback_data($result);
        if(!empty($response['refund_id'])){
            return true;
        }
        if($response['trade_state']!='SUCCESS'){
            return $response;
        }
        
        return false;
	}
	
	public function process_payment($order_id){
		$order = wc_get_order($order_id);
		if(!$order||!$order->needs_payment()){
			return array(
					'result'=>'success',
			        'order_id'=>$order_id,
					'complete'=>true
			);
		}
		
		global $current_wrest_user;
		if(!$current_wrest_user){
		    $current_wrest_user= new WRest_User(get_current_user_id());
		}
		
		if($order->get_customer_id()!=get_current_user_id()
		    || !$current_wrest_user->is_load()
		    ||empty($current_wrest_user->openid)
		    ||$order->get_customer_id()!=$current_wrest_user->user_ID){
			throw new Exception('用户登录信息异常！(请尝试重新登录)');
		}
		$main = WRest_Settings_Default_Basic_Default::instance();
		
		$appid = $main->get_option('appid');
		$startTime = date_i18n('YmdHis' );
		$expiredTime = date('YmdHis',current_time( 'timestamp' )+15*60);
		
	    if(in_array($order->get_currency(), apply_filters('wrest_currency_round', array('JPY','KRW')))){
		    $total_fee = round($order->get_total());
		}else{
		    $total_fee = round($order->get_total()*100);
		}
		
		$request = array(
		    'service'=>'pay.weixin.jspay',
            'mch_id'=>$this->get_option('partner_code'),
            'out_trade_no'=>$this->generate_out_trade_order_id($order),
            'body'=>$this->get_order_title($order),
            'total_fee'=>$total_fee,
            'mch_create_ip'=>WRest_Helper_Http::get_client_ip(),
            'notify_url'=>home_url('/wp-json/payment/v1/wepayez/wechat/notify'),
            'sub_openid'=>$current_wrest_user->openid,
            'sub_appid'=>$appid,
            'is_raw'=>1,
            'time_start'=>$startTime,
            'fee_type'=>$order->get_currency(),
            'time_expire'=>$expiredTime,
            'nonce_str'=>str_shuffle(time())
		);
		
		$request['sign']=$this->generate_sign($request);
		$response = WRest_Helper_Http::http_post('https://pay.wepayez.com/pay/gateway', WRest_Helper_String::obj_to_xml($request));
		
		$result = WRest_Helper_String::xml_to_obj($response);
		if(!$result){
		    throw new Exception('invalid callback data:'.$response);
		}
		 
		$response = $this->validate_callback_data($result);
	
		return array(
				'result'=>'success',
				'jsapi'=>is_array($response['pay_info'])?$response['pay_info']:json_decode($response['pay_info'],true),
		        'order_id'=>$order->get_id(),
		        'url_orderquery'=>home_url('/wp-json/payment/v1/wepayez/wechat/query?id='.$order->get_id())
		);
	}
	
	public function validate_callback_data($response){
	    $sign = $this->generate_sign($response);
	    if(!isset($response['sign'])){
	        throw new Exception(json_encode($response));
	    }
	    if($sign!=$response['sign']){
	        throw new Exception('invalid sign');
	    }
	
	    if("{$response['status']}"!=='0'){
	        throw new Exception("connect failed!errmsg:{$response['message']}");
	    }
	
	    if("{$response['result_code']}"!=='0'){
	        throw new Exception("request failed!errcode:{$response['err_code']},errmsg:{$response['err_msg']}");
	    }
	     
	    return $response;
	}
	
	public function generate_sign(array $array){
	    ksort($array);
	    reset($array);
	
	    $index=0;
	    $string='';
	    foreach ($array as $key=>$val){
	        if($key=='sign'||$val===''||is_null($val)){
	            continue;
	        }
	
	        if($index++!=0){
	            $string.='&';
	        }
	        $string.="{$key}={$val}";
	    }
	
	    $string.="&key=".$this->get_option('credential_code');
	    return strtoupper(md5($string));
	}
}
?>