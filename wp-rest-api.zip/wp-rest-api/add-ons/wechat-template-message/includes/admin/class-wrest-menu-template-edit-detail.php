<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WRest_Template_Edit_Detail{
    /**
     * @var WRest_Wechat_Template_Message
     */
    private $template;
    
    public function __construct($id=0){
        $this->template = new WRest_Wechat_Template_Message($id);
    }
   
	public function view() {
	    if(!$this->template->is_load()){
	        ?><script type="text/javascript">
			location.href="<?php echo admin_url('admin.php?page=wrest_page_default&section=add_ons_menu_email_edit')?>";
			</script> <?php 
	        return;
	    }
	    
	    if(isset($_POST['notice'])){
	        try {
	            if(wp_verify_nonce($_POST['notice'], WRest::instance()->session->get_notice('admin:form:wechat_template_edit',true))){        
	                $error =$this->template->update(array(
	                   'enabled'=>isset($_POST['enabled'])&& $_POST['enabled']=='yes'?1:0,
	                   'recipients'=>explode(';', $_POST['recipients']),
	                   'tid'=>$_POST['tid']
	               ));
	               
	               if(!WRest_Error::is_valid($error)){
	                   throw new Exception($error->errmsg);
	               }
	               
	               $this->template = new WRest_Wechat_Template_Message($this->template->template_id);
	               ?>
	               <div id="message" class="success notice notice-success is-dismissible">
               		<p><?php echo __('Data saved successfully!',WC_SINIC);?></p>
               		<button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php print __('Ignore')?></span></button>
               		</div>
	               <?php 
	            }else{
	                throw new Exception(WRest_Error::err_code(701)->errmsg);
	            }
	        } catch (Exception $e) {
	            ?><div id="message" class="error notice notice-error is-dismissible">
	            <p>
	            <?php echo $e->getMessage();?>
        		</p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php print __('Ignore')?></span></button></div>
	            <?php 
	        }	            
	   }
        ?>
        
         <form method="post" id="mainform" action="" enctype="multipart/form-data">
			<h2><?php echo $this->template->system_name?></h2>

			<p><?php echo $this->template->description?></p>

			<table class="form-table">
				<tbody>
				<tr valign="top">
        			<th scope="row" class="titledesc">
        				<label for="enabled"><?php echo __('Enabled/Disabled',WC_SINIC)?></label>
        			</th>
        			<td class="forminp">
        				<fieldset>
        					<legend class="screen-reader-text"><span><?php echo __('Enabled/Disabled',WC_SINIC)?></span></legend>
        					<label>
        					<input type="checkbox" name="enabled" id="enabled" value="yes" <?php echo $this->template->enabled?"checked":"";?>> <?php echo __('Enable this msg',WC_SINIC)?>
        					</label><br>
        				</fieldset>
        			</td>
        		</tr>
        		<tr valign="top">
        			<th scope="row" class="titledesc">
        				<label for="no"><?php echo __('NO.',WC_SINIC)?></label>
        			</th>
        			<td class="forminp">
        				<fieldset>
        					<legend class="screen-reader-text"><span><?php echo __('NO.',WC_SINIC)?></span></legend>
        					<label>
        					<input style="width:400px;" class="input-text regular-input" type="text" name="no" id="no" readonly value="<?php echo esc_attr($this->template->template_id); ?>" />
        					</label><br>
        				</fieldset>
        			</td>
        		</tr>
        		<tr valign="top">
        			<th scope="row" class="titledesc">
        				<label for="tname"><?php echo __('Template Name',WC_SINIC)?></label>
        			</th>
        			<td class="forminp">
        				<fieldset>
        					<legend class="screen-reader-text"><span><?php echo __('Template Name',WC_SINIC)?></span></legend>
        					<label>
        					<input style="width:400px;" class="input-text regular-input" name="tname" id="tname"  type="text" readonly value="<?php echo esc_attr($this->template->tname); ?>" />
        					</label><br>
        				</fieldset>
        			</td>
        		</tr>
        		
        		<tr valign="top">
        			<th scope="row" class="titledesc">
        				<label for="tid"><?php echo __('Template ID',WC_SINIC)?></label>
        			</th>
        			<td class="forminp">
        				<fieldset>
        					<legend class="screen-reader-text"><span><?php echo __('Template ID',WC_SINIC)?></span></legend>
        					<label>
        					<input style="width:400px;" class="input-text regular-input" type="text" name="tid" id="tid" value="<?php echo esc_attr($this->template->tid); ?>" />
        					</label><br>
        				</fieldset>
        			</td>
        		</tr>
        		
				<tr valign="top">
        			<th scope="row" class="titledesc">
        				<span class="wrest-help-tip"></span>				
        				<label for="recipients"><?php echo __('Recipients',WC_SINIC)?></label>
        			</th>
        			<td class="forminp">
        				<fieldset>
        					<legend class="screen-reader-text"><span><?php echo __('Recipients',WC_SINIC)?></span></legend>
        					<input style="width:400px;" class="input-text regular-input" type="text" name="recipients" id="recipients" value="<?php echo $this->template->recipients&&is_array($this->template->recipients)?join(';', $this->template->recipients):null; ?>" />
        					<div class="description">多个收件人<code>;</code>分隔(其中：{wechat:admin}：管理员微信,{wechat:customer}:用户微信)</div>
        				</fieldset>
        			</td>
        		</tr>
        		
				</tbody>
				</table>
					<div id="template">
						<div class="template template_html">
    						<h4><?php echo __('Template',WC_SINIC)?></h4>
    						
    						<p><?php echo sprintf(__('Copy %s to your theme folder:%s.',WC_SINIC),"<code>templates/wechat-templates/{$this->template->template_id}.php</code>","<code>[theme]/wc-china-checkout/wechat-templates/{$this->template->template_id}.php</code>")?></p>
    					</div>
					</div>
				<p class="submit">
				<input type="hidden" name="notice" value="<?php print wp_create_nonce ( WRest::instance()->session->get_notice('admin:form:wechat_template_edit'));?>"/>
				<input class="button-primary wrest-save-button" type="submit" value="<?php echo __('Save change',WC_SINIC)?>">
				</p>
			</form>  
		<?php
	}
}
