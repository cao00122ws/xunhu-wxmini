<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WRest_Template_Edit_List {

	public function view() {
		$api =WRest_Add_On_Wechat_Template_Message::instance();
        ?>
		<div class="wrap">
    		<h2>模板消息 <button class="button button-primary" id="btn-wrest-import-msg-tpl">一键重置</button></h2>
       		<?php
       		$table = new WRest_Template_List_Table();
       		$table->views();
       		$table->prepare_items();
       		?>
       		
        	<form method="GET" id="form-wrest-tpls">
        	   <input type="hidden" name="page" value="<?php echo WRest_Admin::instance()->get_current_page()->get_page_id()?>"/>
               <input type="hidden" name="section" value="<?php echo WRest_Admin::instance()->get_current_menu()->id?>"/>
               <input type="hidden" name="tab" value="<?php echo WRest_Admin::instance()->get_current_submenu()->id?>"/>
           		<div class="order-list" id="wrest-order-list">
           		<?php $table->display(); ?>
           		</div>
        	</form>
        	<script type="text/javascript">
				(function($){
					$('#btn-wrest-import-msg-tpl').click(function(){
						var data={
                        	
                        };
						$.ajax({
							url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_{$api->id}",'tab'=>'import_wechat_templates'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							beforeSend:function(){
								$('#form-wrest-tpls').loading();
							},
							complete:function(){
								$('#form-wrest-tpls').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert( e.errmsg );
									return;
								}

								location.reload();
							},
							error:function(e){
								console.error(e.responseText);
								alert('网络异常，请重试!' );
							}
						});
					});

					$('.wrest-tpl-status').click(function(){
						var tid = $(this).data('tid');

						var enabled = $(this).attr('checked');
						var data={
	                        tid:tid,
	                        enabled:enabled?'yes':'no'	
                        };
						$.ajax({
							url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_{$api->id}",'tab'=>'change_tpl_status'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							beforeSend:function(){
								$('#wrest-order-list').loading();
							},
							complete:function(){
								$('#wrest-order-list').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert( e.errmsg );
									return;
								}
							},
							error:function(e){
								console.error(e.responseText);
								alert('网络异常，请重试!' );
							}
						});
					});
				})(jQuery);
        	</script>
    	</div>
    	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WRest_Template_List_Table extends WP_List_Table {

    /**
     * @param WRest_Menu_Order_Default_Settings $api
     * @param array $args
     * @since 1.0.0
     */
    public function __construct( $args = array() ) {
        parent::__construct( $args );
        
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'system_name');
    }

    function prepare_items() {
        $api = WRest_Add_On_Wechat_Template_Message::instance();
        
        $templates = array();
        foreach ($api->get_comment_templates() as $tid=>$settings){
            $settings['tid'] = $tid;
            $settings['item'] = new WRest_Wechat_Template_Message($tid);
            $templates[] = $settings;
        }
        
        $this->set_pagination_args( array(
            'total_items' => count($templates),
            'total_pages' => 1,
            'per_page' => count($templates)
        ));

        $this->items = $templates;
    }

    function get_columns() {
        return array(
            'tid'               => '#',
            'title'             => '模板名称',
            'to'                => '接收者',
            'templates'         => '参数列表',
            'template_id'       => '模板ID',
            'status'            => '状态',
        );
    }

    public function column_tid($item){
        ?><code><?php echo $item['tid'];?></code><?php
    }
        
	public function column_title($item){
	     echo $item['title'];
    }
    
    public function column_to($item){
        if(!$item['item']->is_load()){
            ?><span>--</span><?php
        }else{
            ?><span><?php echo $item['item']->get_to_name();?></span><?php
        }
    }
    
    public function column_template_id($item){
        if(!$item['item']->is_load()){
            ?><span style="color:red;">缺失</span><?php
            }else{
            ?><span><?php echo $item['item']->template_id;?></span><?php
        }
    }
    
    public function column_status($item){
        if(!$item['item']->is_load()){
            ?><span>--</span><?php
            }else{
            ?><span> <label><input class="wrest-tpl-status" data-tid="<?php echo esc_attr($item['tid'])?>" type="checkbox" <?php echo $item['item']->status=='publish'?'checked':'';?>/> 启用</label> </span><?php
        }
    }
    public function column_templates($item){
        if(!$item['item']->is_load()){
            ?><span>--</span><?php
        }else{
            ?><span><?php 
            if($item['item']->keyword_list){
                $index = 0;
                foreach ($item['item']->keyword_list as $template){
                    if($index++!=0){
                        echo "，";
                    }
                    echo $template;
                }
            }
            ?></span><?php
        }
    }
   
    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();
    
        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }
    
            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }
    
            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';
    
            $attributes = "class='$classes' $data";
    
            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            }  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }
    
    
	function no_items() {
		?>抱歉，未发现任何模板消息!<?php 
	}
}
