<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
 
class WRest_Menu_Email_Edit_Settings extends Abstract_WRest_Settings {
    /**
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='page_msgser_settings_wechat_template';
        $this->title='模板消息';
    }

    public function admin_form_start(){}
     
    public function admin_options(){
        $id  = isset($_GET['id'])?$_GET['id']:null; 
        $api = WRest_Settings_Default_Basic_Default::instance();
        $appid = $api->get_option('appid');
        $appsecret = $api->get_option('appsecret');
        if(empty($appid)||empty($appsecret)){
            ?>
            <div id="message" class="error notice notice-error is-dismissible">
           		<p>请<a href="<?php echo admin_url('admin.php?page=wrest_page_default&section=menu_default_basic&sub=settings_default_basic_default')?>" target="_blank">完善APPID和APPSECRET</a>后再继续操作!</p>
           		<button type="button" class="notice-dismiss"><span class="screen-reader-text">忽略此通知。</span></button>
   			</div>
            <?php 
            return;
        }
        if (isset($_REQUEST['view'])&&$_REQUEST['view']=='edit' ) {
            require_once 'class-wrest-menu-template-edit-detail.php';
            $api = new WRest_Template_Edit_Detail($id);
    		$api->view();
        } else {
            require_once 'class-wrest-menu-template-edit-list.php';
            $api = new WRest_Template_Edit_List();
		    $api->view();
        }
	}
	
    public function admin_form_end(){} 
}


?>