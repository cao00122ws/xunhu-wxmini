<?php
class WRest_Wechat_Form_Id extends WRest_Object{
	public $fid;
	public $form_id;
	public $user_ID;
	public $type;
	public $has_times;
	public $created_time;
	
	public function is_auto_increment(){
		return false;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'fid';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_wechat_form_id';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
			'fid'=>0,
		    'user_ID'=>null,
		    'form_id'=>null,
		    'type'=>null,
			'has_times'=>1,
		    'created_time'=>0
		);
	}
	
	public static function get_active_form_id($user_ID){
	    if(!$user_ID){
	        return WRest_Error::err_code(404);
	    }
	    global $wpdb;
	    $now = current_time( 'timestamp')-7*24*60*60;
	    $form_id_obj = $wpdb->get_row(
        	        "select *
        	         from {$wpdb->prefix}wrest_wechat_form_id
        	         where has_times>=1
        	               and user_ID={$user_ID}
        	               and created_time>={$now}
        	         order by created_time asc
        	         limit 1;");
	    $formId = new WRest_Wechat_Form_Id($form_id_obj);
	    if($formId->is_load()){
	        $form_id = $formId->form_id;
	        $error=null;
	        if($formId->has_times<=1||$formId->created_time<=$now){
	           $error =  $formId->remove();
	        }else{ 
	            $error =   $formId->update(array(
	                'has_times'=>--$formId->has_times
	            ));
	        }
	        
	        if(!WRest_Error::is_valid($error)){
	            return $error;
	        }
	        
	        return $form_id;
	    }
	    return WRest_Error::err_code(404);
	    
	}
}

class WRest_Wechat_Form_Id_Model extends Abstract_WRest_Schema{
	/**
	 * {@inheritDoc}
	 * @see Abstract_XH_Model_Api::init()
	 */
	public function init()
	{
		$collate=$this->get_collate();
		global $wpdb;
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_wechat_form_id` (
					`fid` varchar(32) NOT NULL,
					`form_id` varchar(512) NULL DEFAULT NULL,
					`type` varchar(16) NOT NULL DEFAULT 'formid',
					`user_ID` int(11) NULL,
					`has_times` int(11) NOT NULL DEFAULT 1,
					`created_time` int(11) NOT NULL DEFAULT 0,
					PRIMARY KEY (`fid`)
				)
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
		
	}
}