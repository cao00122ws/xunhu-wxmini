<?php
class WRest_Wechat_Template_Message extends WRest_Object{
	public $tid;
	public $title;
	public $keyword_list;
	public $to;
	public $template_id;
	public $status;
	
	public function is_auto_increment(){
		return false;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'tid';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_wechat_template_message';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
			'tid'=>0,
		    'template_id'=>null,
			'title'=>null,
			'keyword_list'=>array(),
		    'to'=>array(),
		    'status'=>'draft'
		);
	}
	
	public function get_status_html(){
	    switch ($this->status){
	        case 'draft':
	            return '<span>禁用</span>';
	        case 'publish':
	            return '<span style="color:green;">正常</span>';
	        default:
	            return $this->status;
	    }
	}
	
	public function get_to_name(){
	    switch ($this->to){
	        case 'customer':
	            return '<b style="color:green;">顾客</b>';
	        case 'shopmanager':
	            return '<b style="color:#222;">店主</b>';
	        default:
	            return $this->to;
	    }
	}
}

class WRest_Wechat_Template_Message_Model extends Abstract_WRest_Schema{
	/**
	 * {@inheritDoc}
	 * @see Abstract_XH_Model_Api::init()
	 */
	public function init()
	{
		$collate=$this->get_collate();
		global $wpdb;
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_wechat_template_message` (
					`tid` varchar(32) NOT NULL,
					`title` varchar(128) NULL DEFAULT NULL,
					`keyword_list` TEXT NULL DEFAULT NULL,
					`template_id` varchar(512) NULL DEFAULT NULL,
					`to` varchar(32) NOT NULL,
					`status` varchar(16) NOT NULL DEFAULT 'publish',
					PRIMARY KEY (`tid`)
				)
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
		
	}
}