<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
   
/**
 * @author rain
 *
 */
class WRest_Add_On_Wechat_Template_Message extends Abstract_WRest_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WRest_Add_On_Wechat_Template_Message
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    public $templates=array(
        'AT0229'=>array(
            'title'=>'下单成功通知',
            'description'=>'顾客订单支付成功候，将推送此条信息给顾客',
            'keyword_list'=>array(
                2,86,81,16,17,18
            )
        ),
        'AT0007'=>array(
            'title'=>'(虚拟商品)订单发货提醒(1)',
            'description'=>'(虚拟商品)订单状态为<code>已发货</code>时，',
            'keyword_list'=>array(
                7,3,34,19,96,108
            )
        ),
        'AT0105'=>array(
            'title'=>'(快递物流)订单发货提醒(2)',
            'keyword_list'=>array(
                8,3,1,2,6,13,12
            )
        ),
        'AT1977'=>array(
            'title'=>'审批评论提醒',
            'keyword_list'=>array(
                2,3
            )
        )
    );
    
    public function get_comment_templates(){
        return apply_filters("wrest_comment_templates",$this->templates);
    }
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WRest_Add_On_Wechat_Template_Message
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wrest_add_on_wechat_template_message';
        $this->title='微信模板消息';
        $this->description='支持向客户推送订单、评论相关的模板消息。';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author='迅虎网络';
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WRest_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WRest_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>'设置',
                'url'=>admin_url("admin.php?page=wrest_page_default&section=menu_default_basic&sub=page_msgser_settings_wechat_template")
            )
        );
    }

    public function on_load(){
        require_once 'includes/class-wrest-wechat-template-message.php';
        require_once 'includes/class-wrest-wechat-form-id.php';
        
        add_filter('xunhuweb_tpl', array($this,'xunhuweb_tpl'),10,3);
        
        add_action('woocommerce_payment_complete',array($this,'woocommerce_payment_complete'),5,1);
        add_action('woocommerce_order_status_completed',array($this,'woocommerce_order_status_completed'),5,2);
        add_action('wp_set_comment_status', array($this,'wp_set_comment_status'),10,2);
    }
    
    public static function wp_set_comment_status($comment_ID,$comment_status){
        switch ($comment_status){
            case 'approve':
            case 'hold': 
                if(defined('xunhuweb_tpl_comment_'.$comment_status)){
                    return;
                }
                
                define('xunhuweb_tpl_comment_'.$comment_status,1);
                if(get_comment_meta($comment_ID,'_wrest_tpl_has_'.$comment_status,true)=='yes'){
                    return;
                }
                
                $message = apply_filters('xunhuweb_tpl', array(
                    'openid'=>null,
                    'weapp_template_msg'=>null,
                    'mp_template_msg'=>null
                ),'comment_'.$comment_status,array(
                    $comment_ID,
                    $comment_status
                ));
                
                 $response = $this->sendTemplate($message);
                if(!$response instanceof WRest_Error){
                update_comment_meta($comment_ID,'_wrest_tpl_has_'.$comment_status,'yes');
                }
                break;
        }
    }
    
    /**
     * @param integer $wc_order_id
     * @param WC_Order $wc_order
     */
    public static function woocommerce_order_status_completed($wc_order_id,$wc_order){
        if(defined('xunhuweb_tpl_wc_status_completed')){
            return;
        }
        
        define('xunhuweb_tpl_wc_status_completed',1);
        if(get_post_meta($wc_order_id,'_wrest_tpl_has_completed_',true)=='yes'){
            return;
        }
        
        $message = apply_filters('xunhuweb_tpl', array(
            'openid'=>null,
            'weapp_template_msg'=>null,
            'mp_template_msg'=>null
        ),'wc_status_completed',array(
            $wc_order
        ));
        
        $response = $this->sendTemplate($message);
        if(!$response instanceof WRest_Error){
            update_post_meta($wc_order_id,'_wrest_tpl_has_completed_','yes');
        }
    }
    
    public function woocommerce_payment_complete($wc_order_id){
        $wc_order = wc_get_order($wc_order_id);
        if(!$wc_order){
            return;
        }
    
        if(defined('xunhuweb_tpl_wc_payment_complete')){
            return;
        }
        define('xunhuweb_tpl_wc_payment_complete',1);
        
        if(get_post_meta($wc_order_id,'_wrest_tpl_has_payment_complete_',true)=='yes'){
            return;
        }
        
        $message = apply_filters('xunhuweb_tpl', array(
            'openid'=>null,
            'weapp_template_msg'=>null,
            'mp_template_msg'=>null
        ),'wc_payment_complete',array(
            $wc_order
        ));
    
        if(
            ((!isset($message['weapp_template_msg'])||!$message['weapp_template_msg'])
                &&(!isset($message['mp_template_msg'])||!$message['mp_template_msg']))
            ||empty($message['openid'])
            ){
            return;
        }
    
        $response = $this->sendTemplate($message);
        if(!$response instanceof WRest_Error){
            update_post_meta($wc_order_id,'_wrest_tpl_has_payment_complete_','yes');
        }
    }
    
    private function sendTemplate($message){
        if(
            ((!isset($message['weapp_template_msg'])||!$message['weapp_template_msg'])
                &&(!isset($message['mp_template_msg'])||!$message['mp_template_msg']))
            ||empty($message['openid'])
            ){
            return;
        }
    
        require_once WREST_DIR.'/includes/class-xh-wechat-api.php';
        $api = WRest_Settings_Default_Basic_Default::instance();
        $appid = $api->get_option('appid');
        $appsecret = $api->get_option('appsecret');
        $api = new WRest_Wechat_Api($appid,$appsecret);
    
        $api->sendTemplate($message['openid'],$message['weapp_template_msg'],$message['mp_template_msg']);
    }
    
    /**
     * @param array $message
     * @param string $tag
     * @param array $args
     */
    public  function xunhuweb_tpl($message,$tag,$args){
        switch ($tag){
            case 'comment_approve':
            case 'comment_onhold':
                $comment_ID = $args[0];
                $comment_status = $args[1];
                $comment = get_comment($comment_ID);
                if(!$comment){
                    return $message;
                }
                $post = get_post($comment->comment_post_ID);
                if(!$post){
                    return $message;
                }
                $customer_id = $comment->user_id;
                if(!$customer_id){
                    return $message;
                }
                
                if(empty($message['openid'])){
                    $wrest_user = new WRest_User($customer_id);
                    if($wrest_user->is_load()){
                        $message['openid'] = $wrest_user->openid;
                    }
                }
                
                $form_id = WRest_Wechat_Form_Id::get_active_form_id($customer_id);
                if($form_id instanceof WRest_Error){
                    return $message;
                }
                
                $tpl = new WRest_Wechat_Template_Message('AT1977');
                if(!$tpl->is_load()||$tpl->status!='publish'){
                    return $message;
                }
                $page ='pages/index/index';
                 switch ($post){
                     case 'post':
                         $page = "pages/article/detail/index?id={$post->ID}";
                         break;
                     case 'page':
                         $page = "pages/web-view/index?id=".urlencode(get_permalink($post->ID));
                         break;
                     case 'product':
                     case 'product_variation':
                         $page = "package_a/pages/product/detail/index?id={$post->ID}";
                         break;
                 }
                 $result = '未知';
                switch ($comment_status){
                    case 'approve':
                        $result='审核通过';
                        break;
                    case 'onhold':
                        $result='被驳回';
                        break;
                }
                
                $message['weapp_template_msg']=array(
                    'template_id'=>$tpl->template_id,
                    'page'=>$page,
                    'form_id'=>$form_id,
                    'data'=>array(
                        "keyword1"=>[
                            "value"=> $result
                        ],
                        "keyword2"=> [
                            "value"=>  $comment->comment_content,
                        ]
                    ),
                    'emphasis_keyword'=>"keyword1.DATA"
                );
                break;
            case 'wc_status_completed':
                $wc_order = $args[0];
                if(!$wc_order instanceof WC_Order){
                    return $message;
                }
                $customer_id = $wc_order->get_customer_id();
                if(!$customer_id){
                    return $message;
                }
                
                if(empty($message['openid'])){
                    $wrest_user = new WRest_User($customer_id);
                    if($wrest_user->is_load()){
                        $message['openid'] = $wrest_user->openid;
                    }
                }
                
                $form_id = WRest_Wechat_Form_Id::get_active_form_id($customer_id);
                if($form_id instanceof WRest_Error){
                    return $message;
                }
                
                $orderApi = WRest::instance()->get_product_api()->get_order($wc_order);
                $shipping = $orderApi->get_shipping();
                if($shipping){
                    $tpl = new WRest_Wechat_Template_Message('AT0105');
                    if(!$tpl->is_load()||$tpl->status!='publish'){
                        return $message;
                    }
                     
                    $message['weapp_template_msg']=array(
                        'template_id'=>$tpl->template_id,
                        'page'=>"package_a/pages/order/detail/index?id={$wc_order->get_id()}",
                        'form_id'=>$form_id,
                        'data'=>array(
                            "keyword1"=>[
                                "value"=> $wc_order->get_id()
                            ],
                            "keyword2"=> [
                                "value"=>date_i18n('Y-m-d H:i'),
                            ],
                            "keyword3"=> [
                                "value"=> isset($shipping['company'])?$shipping['company']:'待定'
                            ],
                            "keyword4"=> [
                                "value"=> isset($shipping['shipping_no'])?$shipping['shipping_no']:'待定'
                            ],
                            "keyword5"=> [
                                "value"=> $this->get_order_item_detail($wc_order)
                            ],
                            "keyword6"=> [
                                "value"=> $this->get_order_shipping_detail($wc_order)
                            ],
                            "keyword7"=> [
                                "value"=> '收货后，别忘了回来给个好评哦！'
                            ]
                        ),
                        'emphasis_keyword'=>"keyword1.DATA"
                     );
                }else{
                    $tpl = new WRest_Wechat_Template_Message('AT0007');
                    if(!$tpl->is_load()||$tpl->status!='publish'){
                        return $message;
                    }
                     
                    $message['weapp_template_msg']=array(
                        'template_id'=>$tpl->template_id,
                        'page'=>"package_a/pages/order/detail/index?id={$wc_order->get_id()}",
                        'form_id'=>$form_id,
                        'data'=>array(
                            "keyword1"=>[
                                "value"=> $wc_order->get_id()
                            ],
                            "keyword2"=> [
                                "value"=>date_i18n('Y-m-d H:i'),
                            ],
                            "keyword3"=> [
                                "value"=> $wc_order->get_shipping_method()
                            ],
                            "keyword4"=> [
                                "value"=> $this->get_order_shipping_detail($wc_order)
                            ],
                            "keyword5"=> [
                                "value"=> $this->get_order_item_detail($wc_order)
                            ],
                            "keyword6"=> [
                                "value"=> '收货后，别忘了回来给个好评哦！'
                            ]
                        ),
                        'emphasis_keyword'=>"keyword1.DATA"
                      );
                }
                
                
                break;
            /**
             * 顾客完成支付
             */
            case 'wc_payment_complete':
                $wc_order = $args[0];
                if(!$wc_order instanceof WC_Order){
                    return $message;
                }
                $customer_id = $wc_order->get_customer_id();
                if(!$customer_id){
                    return $message;
                }
                
                if(empty($message['openid'])){
                    $wrest_user = new WRest_User($customer_id);
                    if($wrest_user->is_load()){
                        $message['openid'] = $wrest_user->openid;
                    }
                }
                
                $form_id = WRest_Wechat_Form_Id::get_active_form_id($customer_id);
                if($form_id instanceof WRest_Error){
                    return $message;
                }
                
                $tpl = new WRest_Wechat_Template_Message('AT0229');
                if(!$tpl->is_load()||$tpl->status!='publish'){
                    return $message;
                }
                
                $message['weapp_template_msg']=array(
                    'template_id'=>$tpl->template_id,
                    'page'=>"package_a/pages/order/detail/index?id={$wc_order->get_id()}",
                    'form_id'=>$form_id,
                    'data'=>array(
                        "keyword1"=>[
                            "value"=> $wc_order->get_id()
                        ],
                        "keyword2"=> [
                            "value"=> $wc_order->get_payment_method_title(),
                        ],
                        "keyword3"=> [
                            "value"=> html_entity_decode(get_woocommerce_currency_symbol($wc_order->get_currency())).$wc_order->get_total()
                        ],
                        "keyword4"=> [
                            "value"=> $this->get_order_item_detail($wc_order)
                        ],
                        "keyword5"=> [
                            "value"=> $this->get_order_shipping_detail($wc_order)
                        ],
                        "keyword6"=> [
                            "value"=> '如未及时发货，请在线联系客服！'
                        ]
                    ),
                    'emphasis_keyword'=>"keyword1.DATA"
                );
                break;
        }
        
        return $message;
    }
    /**
     * @param WC_Order $wc_order
     */
    private function get_order_shipping_detail($wc_order){
        if($wc_order->has_shipping_address()){
            $address = '';
            
            $address = apply_filters( 'woocommerce_order_formatted_shipping_address', $wc_order->get_address( 'shipping' ), $wc_order );
            $address = WC()->countries->get_formatted_address( $address,"\r\n" );
    
    		return $address ? html_entity_decode(esc_html($address)) : '暂无';
        }
        
        $address = apply_filters( 'woocommerce_order_formatted_billing_address', $wc_order->get_address( 'billing' ), $wc_order );
        $address = WC()->countries->get_formatted_address( $address ,"\r\n" );
        
        return $address ? html_entity_decode(esc_html($address)) : '暂无';
    }
    
    /**
     * @param WC_Order $wc_order
     */
    private function get_order_item_detail($wc_order){
        $items_str = '';
        $orderItems = $wc_order->get_items('line_item');
        if ($orderItems) {
            $index = 0;
            foreach ($orderItems as $item_id => $item) {
                if($index++!=0){
                    $items_str.="\r\n";
                }
        
                //$item instanceof WC_Order_Item_Product;
                $items_str.=$item->get_name().' x'. $item->get_quantity();
            }
        }
        return $items_str;
    }
    
    
    public function on_install(){
        $model = new WRest_Wechat_Template_Message_Model();
        $model->init();
        
        $model = new WRest_Wechat_Form_Id_Model();
        $model->init();
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WRest_Add_Ons::on_init()
     */
    public function on_init(){
        require_once 'includes/admin/class-wrest-menu-template-edit.php';
        add_filter('wrest_admin_menu_menu_default_basic', function($menus){
            $menus[]=WRest_Menu_Email_Edit_Settings::instance();
            return $menus;
        },10,1);
        add_action('wrest_collection_form_id', array($this,'collection_form_id'),10,1);
        add_action('wrest_wc_payment_wechat_perpay_id', array($this,'wc_payment_wechat_perpay_id'),10,3);
    }
    
    public function get_shopmanager(){
        global $wpdb;
        $query = $wpdb->get_row(
            "select *
             from {$wpdb->prefix}wrest_user
             where role='shopmanager'
             limit 1;");
        return new WRest_User($query);
    }
    
    public function wc_payment_wechat_perpay_id($response,$request,$order){
        if(!$response||!is_array($response)||!isset($response['prepay_id'])){
            return;
        }
        $prepay_id = $response['prepay_id'];
        $fid = md5($prepay_id);
        $dom = new WRest_Wechat_Form_Id($fid);
        if(!$dom->is_load()){
            $dom->fid = $fid;
            $dom->form_id = $prepay_id;
            $dom->user_ID = get_current_user_id();
            $dom->created_time = current_time( 'timestamp');
            $dom->has_times = 3;
            $dom->type='prepayid';
            $dom->insert();
        }
    }
    
    public function on_cron(){
        //移除过期的formid
        global $wpdb;
        $now = current_time( 'timestamp')-7*24*60*60;
        $wpdb->query("delete from {$wpdb->prefix}wrest_wechat_form_id where has_times=0 or created_time<{$now};");
    }
    
    /**
     * 
     * @param WP_REST_Request $request
     */
    public function collection_form_id($request){
        $formIds = $request->get_param('formIds');
        if($formIds){
            $formIds = json_decode(wp_unslash($formIds),true);
        }
        
        if($formIds&&count($formIds)&&is_user_logged_in()){
            foreach ($formIds as $form_id=>$created_time){
                $fid = md5($form_id);
                $dom = new WRest_Wechat_Form_Id($fid);
                if(!$dom->is_load()){
                    $dom->fid = $fid;
                    $dom->user_ID = get_current_user_id();
                    $dom->form_id = $form_id;
                    $dom->created_time = absint($created_time);
                    $dom->has_times = 1;
                    $dom->type='formid';
                    $dom->insert();
                }
            }
        
        }
    }
    
    public function do_ajax(){
        $action = "wrest_{$this->id}";
        $request=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            'tab'=>null,
            $action=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));
         
        if ( ! current_user_can( 'manage_options') ){
            return;
        }
         
        if(!WRest::instance()->WP->ajax_validate($request, $request['hash'],true)){
            echo WRest_Error::err_code(701)->to_json();
            exit;
        }
        
        switch ($request['tab']){
            
			case 'import_wechat_templates':
			    require_once WREST_DIR.'/includes/class-xh-wechat-api.php';
			    
			    $api = WRest_Settings_Default_Basic_Default::instance();
			    $wechatApi = new WRest_Wechat_Api($api->get_option('appid'), $api->get_option('appsecret'));
		
			    $template_list = $wechatApi->getTemplateList();
			    if($template_list instanceof WRest_Error){
			        $template_list->output();
			        exit;
			    }
			   
			    foreach ($template_list as $tpl_id=>$tpl){
			        $response = $wechatApi->deleteTemplate($tpl_id);
			        if($response instanceof WRest_Error){
			            $response->output();
			            exit;
			        }
			    }
			   // $tem
			   foreach ($this->get_comment_templates() as $tid=>$settings){
                    $template = $wechatApi->getTemplate($tid);
                    if($template instanceof WRest_Error){
                       $template->output();
                       exit;
                    }
                    
                    $tpl = new WRest_Wechat_Template_Message($tid);
                    
                    $response = $wechatApi->addTemplate($tid,$settings['keyword_list']);
                    if($response instanceof WRest_Error){
                       $response->output();
                       exit;
                    }
                    $template_id = $response['template_id'];
                        
                    $keyword_list = array();
                    $keywords=array();
                    if(isset($template['keyword_list'])&&$template['keyword_list']){
                       foreach ($template['keyword_list'] as $keyword){
                           $keyword_list[$keyword['keyword_id']] =$keyword;
                       }
                       
                       foreach ($settings['keyword_list'] as $kid){
                           $keywords[$kid]=isset($keyword_list[$kid]['name'])?$keyword_list[$kid]['name']:'未知';
                       }
                    }
			      
			       if(!$tpl->is_load()){
			           $tpl->template_id = $template_id;
			           $tpl->keyword_list=$keywords;
			           $tpl->title = $template['title'];
			           $tpl->status ='publish';
			           $tpl->to = 'customer';
			           $tpl->tid = $tid;
			           $error = $tpl->insert();
			       }else{
			           $error = $tpl->update(array(
			               'template_id'=>$template_id,
			               'keyword_list'=>$keywords,
			               'title'=>$template['title'],
			               'to'=>'customer'
			           ));
			       }
			       if(!WRest_Error::is_valid($error)){
			           $error->output();
			       }
			   }
			   
			   WRest_Error::success()->output();
			   exit;
			case 'change_tpl_status':
			    $tpl = new WRest_Wechat_Template_Message(isset($_REQUEST['tid'])?sanitize_text_field(stripslashes($_REQUEST['tid'])):'');
			    if(!$tpl->is_load()){
			        WRest_Error::err_code(404)->output();
			        exit;
			    }
			    
			    $tpl->update(array(
			        'status'=> isset($_REQUEST['enabled'])&&$_REQUEST['enabled']=='yes'?'publish':'draft'
			    ))->output(); 
			    exit;
        }
    }
}

return WRest_Add_On_Wechat_Template_Message::instance();
?>