var langList = 
[
	{name:'zh-cn',	charset:'UTF-8'}
];

var skinList = 
[
	{ name: 'twoer', charset: 'UTF-8' }
];