(function($){
	$.fn.formScale=function (onchange) {
        return this.each(function (i,element) {
            var $dom = $(element);
            $dom.find('.jquery-view-btn').each(function(){
            	this.onmousedown=function(e){
                	var btn = this;
                	var $step = $(btn).siblings('.jquery-view-step');
                	var x=(e||window.event).clientX;
    				var l=btn.offsetLeft;
    				var $bar = $(btn).parent('.jquery-view');
    				var max=$bar[0].offsetWidth;
    				
    				document.onmousemove=function (e){
    					var thisX=(e||window.event).clientX;
    					
    					var to=Math.min(max,Math.max(-2,l+(thisX-x)));
    					
    					to = Math.max(0,to);
    					btn.style.left=to+'px';
    					$step.css('width',to+'px');
    					if(onchange){
    						onchange(to/(max*1.0))
    					}
    					
    					document.onmouseup=function (e){
        					document.onmousemove=null;
        				};
    				};
                };
            });
            
        });
    }
})(jQuery);