<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
 
abstract class Abstract_WRest_Area{
    public $namespace;
    
    /**
     * @return Abstract_WRest_Controller[]
     */
    abstract function controllers();
    
    public function requires(){
       
    }
}