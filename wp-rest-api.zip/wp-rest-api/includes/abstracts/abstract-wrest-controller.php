<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
 
abstract class Abstract_WRest_Controller extends WP_REST_Controller{
	public function get_namespace(){
		return $this->namespace;
	}
	
	public function get_rest_base(){
		return $this->rest_base;
	}
    /**
     * 
     * @param Abstract_WRest_Area $area
     */
   public function set_area($area){
       $this->namespace = $area->namespace;       
       return $this;
   }
   
   /**
    * 
    * @param WP_REST_Request $request
    */
   public function get_private_items_permissions_check($request){
       if(!is_user_logged_in()){
           return new WP_Error(401,'Unauthorized',array('status'=>401));
       }

       return true;
   }
   
   public function get_version($request){
       return WRest::instance()->WP->get_version($request);
   }
}