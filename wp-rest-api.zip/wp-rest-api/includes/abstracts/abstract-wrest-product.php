<?php

abstract class Abstract_WRest_Order{
    public static function get_status_group($counts){
        $status_Api = WRest_Menu_Default_Order::instance();
    
        //待支付
        $wrest_pending = apply_filters('wrest_order_status_group_pending', array(
            $status_Api->get_status_name('wc-pending','full'),
            $status_Api->get_status_name('wc-on-hold','full'),
        ));
    
        //配送中
        $wrest_shipping =  apply_filters('wrest_order_status_group_shipping', array(
            $status_Api->get_status_name('wc-processing','full'),
            $status_Api->get_status_name('wc-shiped','full'),
        ));
    
        //已完成
        $wrest_completed =  apply_filters('wrest_order_status_group_completed', array(
            $status_Api->get_status_name('wc-completed','full')
        ));
    
        //退款
        $wrest_refund =  apply_filters('wrest_order_status_group_refund', array(
            $status_Api->get_status_name('wc-refunding','full'),
            $status_Api->get_status_name('wc-refund-failed','full'),
            $status_Api->get_status_name('wc-refund-hold','full'),
            $status_Api->get_status_name('wc-refunded','full'),
            $status_Api->get_status_name('wc-cancelled','full'),
        ));
    
        return array(
            'wrest-pending'=> array(
                'status'=>'wrest-pending',
                'label'=>'待支付',
                'count'=>self::get_order_status_list_count($wrest_pending,$counts),
                'sub'=>$wrest_pending
            ),
            'wrest-shipping'=> array(
                'status'=>'wrest-shipping',
                'label'=>'配送中',
                'count'=>self::get_order_status_list_count($wrest_shipping,$counts),
                'sub'=>$wrest_shipping
            ),
            'wrest-completed'=> array(
                'status'=>'wrest-completed',
                'label'=>'已完成',
                'count'=>self::get_order_status_list_count($wrest_completed,$counts),
                'sub'=>$wrest_completed
            ),
            'wrest-cancel-refund'=> array(
                'status'=>'wrest-cancel-refund',
                'label'=>'取消/退款',
                'count'=>self::get_order_status_list_count($wrest_refund,$counts),
                'sub'=>$wrest_refund
            )
        );
    }
    
    private static function get_order_status_list_count($status_list,$counts=null){
        $total = 0;
        foreach ($status_list as $status){
            if($counts&&isset($counts[$status])){
                $total+=absint($counts[$status]);
            }
        }
    
        return $total;
    }
    
    public static function get_status_wait_received(){
        $status_api = WRest_Menu_Default_Order::instance();
        $status_shiped = $status_api->get_status_name('wc-shiped');
        return apply_filters('wrest_orderstatus_wait_received', array(
            $status_shiped
        ));
    }
    
    /**
     *
     * @var WC_Order
     */
    protected $order;

    abstract function __construct($post_ID_or_order);

    public function is_load()
    {
        return $this->get_order();
    }

    abstract function permission_check();

    /**
     * 检查是否支付成功
     */
    abstract function process_payment_check();

    /**
     *
     * @return WC_Order
     */
    public function get_order()
    {
        return $this->order;
    }

    /**
     *
     * @return WC_Order
     */
    abstract function to_simple($version);

    /**
     *
     * @return WC_Order
     */
    abstract function to_detail($version);

    abstract function has_shipping();

    abstract function get_shipping();
}

abstract class Abstract_WRest_Product
{
    public static function to_list_mode($modal,$products){
        if(!$products){return null;}
        switch ($modal){
            default:
            case 'detail':
            case 'big':
                $results = array();
                foreach ($products as $product){
                    $results[]=array(
                        'modal'=>$modal,
                        'item'=>$product
                    );
                }
                return $results;
            case 'swip':
                $results = array();
                $results[]=array(
                    'modal'=>$modal,
                    'items'=>$products
                );
                return $results;
            case 'small':
                $results = array();
                for($index=0;$index<count($products);$index++){
                    if($index%2==0){
                        $config_item = array(
                            'modal'=>$modal
                        );
                        $config_item['left']=$products[$index];
                        $config_item['right'] = null;
                    }else if($index%2==1){
                        $config_item['right']=$products[$index];
                        $results[] = $config_item;
                        $config_item = null;
                    }
                }
                if($config_item){
                	$results[]=$config_item;
                }
                return $results;
            case '1big2small':
                $results = array();
                $config_item=null;
                for($index=0;$index<count($products);$index++){
                    if($index%3==0){
                        $config_item = array();
                        $config_item['modal'] = 'big';
                        $config_item['item'] = $products[$index];
                        $results[] = $config_item;
                        $config_item=null;
                    }else if(($index+2)%3==0){
                        $config_item = array();
                        $config_item['modal'] = 'small';
                        $config_item['left']=$products[$index];
                        $config_item['right'] = null;
                    }else if(($index+2)%3==1){
                        $config_item['modal'] = 'small';
                        $config_item['right']=$products[$index];
                        $results[] = $config_item;
                        $config_item = null;
                    }
                }
    
                if($config_item){
                    $results[] = $config_item;
                }
    
                return $results;
            case 'oneline3':
                $results = array();
                $config_item = null;
    
                for($index=0;$index<count($products);$index++){
                    if($index%3==0){
                        $config_item = array(
                            'modal'=>$modal
                        );
                        $config_item['left']=$products[$index];
                        $config_item['middle'] = null;
                        $config_item['right'] = null;
                    }else if($index%3==1){
                        $config_item['middle']=$products[$index];
                    }else if($index%3==2){
                        $config_item['right']=$products[$index];
                        $results[] = $config_item;
                        $config_item = null;
                    }
                }
    
                if($config_item){
                    $results[] = $config_item;
                }
                return $results;
        }
    }
    
    /**
     *
     * @var WC_Product
     */
    protected $product;

    abstract function __construct($post_ID_or_product);

    public function is_load()
    {
        return $this->get_product();
    }

    /**
     *
     * @return WC_Product
     */
    public function get_product()
    {
        return $this->product;
    }
    public function get_available_variations(){
    	return null;
    }
    /**
     *
     * @param WRest_Version $version            
     * @param string $image_size            
     */
    abstract function to_simple($version, $image_size = null);

    abstract function to_detail($version);

    public static function get_post_thumbnail($id, $size = 'thumbnail')
    {
        $post_thumbnail_id = get_post_thumbnail_id($id);
        return $post_thumbnail_id ? self::get_the_image($post_thumbnail_id, $size) : null;
    }

    public static function get_the_image($id, $size = 'thumbnail')
    {
        $image = wp_get_attachment_image_src($id, $size);
        if ($image && count($image) >= 3) {
            return array(
                'url' => $image[0],
                'width' => $image[1],
                'height' => $image[2]
            );
        }
        
        return null;
    }
}

abstract class Abstract_WRest_Doamin
{

    public $post_type;

    public $cat_type;

    public $tag_type;

    public $order_type;

    abstract function html_status_to_wc_status($html_status);

    abstract function wc_status_to_html_status($wc_status);

    abstract function get_order_statuses();

    public function cancel_order($version, $order_ID){}
    public function pre_refund_order($version, $order_ID){}
    public function pre_refund_order_m($version, $request){}
    public function refund_order($version, $request){}
    public function received_order($version, $order_ID){}
    
    
    public function get_user_order_counts($user_ID=null){
       return array();
    }
    
    public function clear_user_order_counts($user_ID=null){
       
    }
    /**
     *
     * @param int $order_ID            
     * @return Abstract_WRest_Order
     */
    abstract function get_order($order_ID);

    /**
     *
     * @param int|WP_Post|WC_Product $post_ID            
     * @return Abstract_WRest_Product
     */
    abstract function get_product($post_ID);

    /**
     *
     * @param WP_REST_Request $request            
     * @return WP_REST_Response
     */
    abstract function add_to_cart($version, $request);
    abstract function clear_cart($version, $request);
    abstract function cart_add_coupon($version, $coupon_code);

    abstract function cart_remove_coupon($version, $coupon_code);

    /**
     *
     * @param WRest_Version $version            
     * @param WP_REST_Request $request            
     * @return WP_REST_Response
     */
    abstract function cart_set_quantity($version, $request);

    /**
     *
     * @param WRest_Version $version            
     * @param WP_REST_Request $request            
     * @return WP_REST_Response
     */
    abstract function cart_remove_item($version, $request);



    public static function format_price($price){
        if(!$price||!is_numeric($price)){
            return $price;
        }
        global $decimals,$decimal_separator,$thousand_separator;
    
        if(is_null($decimals)){
            $decimals =  wc_get_price_decimals();
        }
        if(is_null($decimal_separator)){
            $decimal_separator = wc_get_price_decimal_separator();
        }
        if(is_null($thousand_separator)){
            $thousand_separator = wc_get_price_thousand_separator();
        }
                     
        return apply_filters( 'formatted_woocommerce_price', number_format( $price, $decimals, $decimal_separator, $thousand_separator ), $price, $decimals, $decimal_separator, $thousand_separator );
    }
    
    /**
     *
     * @return WP_REST_Response
     */
    abstract function get_cart($version, $args = array());

    abstract function remove_address($address_id);
    
    abstract function confirm_address($address_id);
    
    abstract function get_address_list();
    /**
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    abstract function save_address($request);

    abstract function get_currency_symbol();
    
    abstract function get_address_detail($address_id);
    
    abstract function get_address();
    abstract function pre_process_checkout($version, $request);
    /**
     *
     * @param WP_REST_Request $request            
     * @return WP_REST_Response
     */
    abstract function process_checkout($version, $request);

    /**
     *
     * @param WP_REST_Request $request            
     * @return array
     */
    abstract function process_re_checkout($version, $request);
    abstract function get_cart_coupons();
    public function get_product_list($version,$config,$image_size = 'single',$mode=ARRAY_N){
    	return array(
    			'items'=>null,
    			'total_count'=>0
    	);
    }

    /**
     *
     * @param WP_REST_Request $request            
     * @return WP_REST_Response
     */
    abstract function cart_update_payment_method($version, $request);

    /**
     *
     * @param WP_REST_Request $request            
     * @return WP_REST_Response
     */
    abstract function cart_update_shipping_method($version, $request);

    /**
     *
     * @param WP_Term $term            
     */
    abstract function get_cat_thumb_url($term);
    
    public function sanitize_keywords($keyword){
        if(empty($keyword)){return $keyword;}
        $keyword = urldecode( stripslashes($keyword) );
        
        $keyword = WRest_Helper_String::remove_emoji(trim(wc_clean($keyword)));
        if(empty($keyword)&&mb_strlen($keyword,'utf-8')<2){
            return null;
        }
        
        global $wpdb;
        return $wpdb->esc_like(mb_strimwidth($keyword, 0, 32,'','utf-8'));
    }
    /**
     * 
     * @param WP_REST_Request $request
     */
    public function process_product_search($request,$version){
    	return new WP_REST_Response(array(
    			'items'=>null,
    			'pageIndex'=>1,
    			'pageSize'=>30,
    			'totalCount'=>0,
    			'totalPage'=>0
    	));
    }
    
    public function get_product_sorts()
    {
        $sorts = array(
            array(
                'title' => '综合排序',
                'call' => function (&$args) {}
            ),
            array(
                'title' => '最新发布',
                'call' => function (&$args) {
                    $args['sort'] = 'publish_date_desc';
                }
            ),
            array(
                'title' => '销量最多',
                'call' => function (&$args) {
                    $args['sort'] = 'sale_qty_desc';
                }
            ),
            array(
                'title' => '价格由低到高',
                'call' => function (&$args) {
                    $args['sort'] = 'price_asc';
                }
            ),
            array(
                'title' => '价格由高到低',
                'call' => function (&$args) {
                    $args['sort'] = 'price_desc';
                }
            ),
            array(
                'title' => '评分由高到低',
                'call' => function (&$args) {
                    $args['sort'] = 'average_rating_desc';
                }
            ),
            array(
                'title' => '评分由低到高',
                'call' => function (&$args) {
                    $args['sort'] = 'average_rating_asc';
                }
            )
        );
        
        return apply_filters('wrest_pro_search_sorts', $sorts);
    }

    /**
     * 
     * @param WRest_Version $version
     * @return array
     */
    public function get_product_filters($version)
    {
    	$api = WRest::instance()->get_product_api();
        global $wpdb;

        $symbol = $api->get_currency_symbol();
        $filters = array(
            '__price__' => array(
                'title' => "价格区间({$symbol})",
                'type' => 'slider',
                'low_txt' => '最低价',
                'heigh_txt' => '最高价',
                'max' => 99999,
                'min' => 0,
                'call' => function (&$args, $key, $request,$setting=null) {
                    if(!$request||!is_array($request)||count($request)==0){
                        return;
                    }
                    
                    if (! isset($args['meta_query'])) {
                        $args['meta_query'] = array();
                    }
                    
                    $query = array(
                        'relation' => 'AND'
                    );
                    
                    $low = isset($request['low'])?round($request['low'],2):0;
                    if ($low) {
                        $query[] = array(
                            'key' => '_price', // (字符串) - 自定义字段的键
                            'value' => $low, // (字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
                            'type' => 'DECIMAL', // (字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为 'CHAR'
                            'compare' => '>='
                        ) ;
                    }
                    
                    $top = isset($request['top'])?round($request['top'],2):0;
                    if ($top) {
                        $query[] = array(
                            'key' => '_price', // (字符串) - 自定义字段的键
                            'value' => $top, // (字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
                            'type' => 'DECIMAL', // (字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为 'CHAR'
                            'compare' => '<='
                        );
                    }
                    $args['meta_query'][] = $query;
                }
            )
        );
        
        
        $attributes = WRest_Cache_Helper::get("attributes:{$version->get_version_code()}", 'wrest::product::filter');
        if(!$attributes){
            $attributes=array();
            
            $attribute_taxonomies = wc_get_attribute_taxonomies();

            if($attribute_taxonomies){
                foreach ($attribute_taxonomies as $key=>$tax){
                    $taxonomy = wc_attribute_taxonomy_name( $tax->attribute_name );

                    if ( taxonomy_exists( $taxonomy ) ) {

                        $terms = get_terms( array(
                            'taxonomy'=>$taxonomy,
                            'hide_empty'=>false
                        ));

                        if(!is_wp_error($terms)&&count($terms)>0){
                            $attributes[$taxonomy ]=array(
                                'label'=> html_entity_decode($tax->attribute_label),
                                'options'=>array()
                            );
                            foreach ($terms as $term){
                                $attributes[$taxonomy]['options'][$term->term_id]=html_entity_decode($term->name);
                            }
                        }
                    }
                }
            }
            
            WRest_Cache_Helper::set("attributes:{$version->get_version_code()}", $attributes, 'wrest::product::filter',60*60*24);
        }
        
        if ($attributes) {
            foreach ($attributes as $taxonomy => $taxonomyObj) {
        		$filters[$taxonomy] = array(
    				'title' => $taxonomyObj['label'],
    				'attribute_name'=>$taxonomy,
    				'type' => 'mult-select',
    				'options' => $taxonomyObj['options'],
    				'call' => function (&$args, $key, $request,$setting) {
        				if(!$request||!is_array($request)||count($request)==0){
        				    return;
        				}
        				if(!isset($args['tax_query'])){
        				    $args['tax_query']=array();
        				}
        				
        				$query = array(
        				    'relation'=>'AND'
        				);
        				
        				$cat_ids = array();
    				    foreach ($request as $tid=>$val){
    				        $tid = absint($tid);
    				        if($tid){
    				            $cat_ids[]=$tid;
    				        }
    				    }
        				
        				$query[] = array(
        				    'taxonomy' => $key,
        				    'field'    => 'term_id',
        				    'terms'    => array_unique($cat_ids,SORT_NUMERIC),
        				);
        				
        				$args['tax_query'][]=$query;
        				return $args;
        			}
            	);
            }
        }
        
        return apply_filters('wrest_pro_search_filters', $filters);
    }

    public function get_product_cats($version,$taxonomys =array(),$includes = array(),$three = false)
    {
        $key = '';
        if($taxonomys){
            foreach ($taxonomys as $t){
                $key.=':'.$t;
            }
        }
        
        if($includes){
            foreach ($includes as $id){
                $key.=':'.$id;
            }
        }
        $key = 'cats:'.md5($key);
        $cats = WRest_Cache_Helper::get($key, 'wrest::product::filter');
        if (!$cats) {
            $cats = $cats1 = array();
            
            $api = WRest::instance()->get_product_api();
            $args = array(
                'meta_query'=>array(
                    array(
                        'relation'=>'OR',
                        array(
                            'key' => '__wrest_disable__', //(字符串) - 自定义字段的键
                            'compare' => 'NOT EXISTS'
                        ),
                        array(
                            'key' => '__wrest_disable__', //(字符串) - 自定义字段的键
                            'value' =>'yes', //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
                            'type' => 'CHAR', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
                            'compare' => '!=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
                        ),
                    )
                )
            );
            if(is_array($taxonomys)&&count($taxonomys)){
                $args['taxonomy'] = $taxonomys;
            }
             
            if($includes&&count($includes)){
                $args['include'] =$includes;
                $args['orderby'] ='include';
            }
            
            $cat_query = new WP_Term_Query();
            $cat_query->query($args);
            $icon = new WRest_Menu_Store_Icon($version);
            $icon_none_cat_icon = $icon->get_option('none_cat_icon');
            if(!$icon_none_cat_icon||!is_array($icon_none_cat_icon)){
                $icon_none_cat_icon = null;
            }

            if ( $cat_query->terms && count($cat_query->terms)) {
                foreach ($cat_query->terms as $level1) {
                    if ($level1->parent === 0) {
                        $r1 = array(
                            'term_id' => $level1->term_id,
                            'name' => $level1->name,
                            'children' => null,
                            'children1'=>null
                        );
                         
                        foreach ($cat_query->terms as $level2) {
                            if ($level2->parent == $level1->term_id) {
                                $icon = $this->get_cat_thumb_url($level2);
                                if(empty($icon)&&$icon_none_cat_icon){
                                    $icon = $icon_none_cat_icon['url'];
                                }
                                $r2 = array(
                                    'term_id' => $level2->term_id,
                                    'name' => $level2->name,
                                    'icon' => $icon,
                                    'children' => null,
                                    'children1'=>null,
                                );


                                if($three){
                                    foreach ($cat_query->terms as $level3){
                                        if($level3->parent ==$level2->term_id){
                                            $icon = $this->get_cat_thumb_url($level3);
                                            if(empty($icon)&&$icon_none_cat_icon){
                                                $icon = $icon_none_cat_icon['url'];
                                            }
                                            $r3 = array(
                                                'term_id' => $level3->term_id,
                                                'name' => $level3->name,
                                                'icon' => $icon,
                                                'children' => null,
                                                'children1'=>null,
                                            );

                                            if (! ($r2['children'])) {
                                                $r2['children'] = array();
                                            }
                                            if (! ($r2['children1'])) {
                                                $r2['children1'] = array();
                                            }

                                            $r2['children'][$level3->term_id] = $r3;
                                            $r2['children1'][] = $r3;
                                        }
                                    }
                                }

                                if (! ($r1['children'])) {
                                    $r1['children'] = array();
                                }
                                if (! ($r1['children1'])) {
                                    $r1['children1'] = array();
                                }
                                $r1['children'][$level2->term_id] = $r2;
                                $r1['children1'][] = $r2;
                            }
                        }
            
                        $r1['children_count'] = isset($r1['children1']) ? count($r1['children1']) : 0;
                         
                        $cats[$level1->term_id] = $r1;
            
                        $cats1[]=$r1;
                    }
                }
            }
            
            $cats = array(
                'current_cat_id' => 0,
                'current_index'=>0,
                'items' => $cats,
                'items1' => $cats1,
                'is_mult_cats' => true
            );
            
            WRest_Cache_Helper::set($key, $cats, 'wrest::product::filter');
        }
        
        
        return apply_filters('wrest_pro_search_cats', $cats);
    }
}
 