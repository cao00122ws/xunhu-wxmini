<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
 
abstract class Abstract_WRest_View{
    /**
     * @return Abstract_WRest_Template[]
     */
   protected abstract function templates();
   
    public function view()
    {
        $config = array(
            
        );
        
        $templates = $this->templates();
        ksort($templates);
        reset($templates);
        foreach ($templates as $sort=>$template){
            $config[] = $template->config();
        }
        
        unset($templates);
        return $config;
    }
}