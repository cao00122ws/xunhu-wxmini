<?php
abstract class Abstract_WRest_WC_Payment_Gateway extends WC_Payment_Gateway{
    public $instructions;
    
	const ORDER_SN='__wrest_order_sn__';
	
	/**
	 * 
	 * @param WC_Order $wc_order
	 */
	abstract function process_payment_query(&$order_id=null,&$transaction_id=null,&$total_fee=null);
	
	/**
	 * 
	 * @param WC_Order $wc_order
	 */
	public function generate_out_trade_order_id($wc_order){
	    if($wc_order instanceof WC_Order){
	        $wc_order = $wc_order->get_id();
	    }
	    
	    update_post_meta($wc_order, self::ORDER_SN, $this->get_option('prefix').date_i18n('ymdHis').$wc_order);
	    return $this->get_out_trade_order_id($wc_order);
	}
	
	public function generate_refund_order_id($wc_order){
	    if($wc_order instanceof WC_Order){
	        $wc_order = $wc_order->get_id();
	    }
	    
	    return 'f'.date_i18n('Ymdhis').$wc_order;
	}
	
	public function get_order_id_form_out_trade_order_id($out_trade_order_id){
	    return absint(substr($out_trade_order_id,strlen($this->get_option('prefix').date_i18n('ymdHis'))));
	}
	
	/**
	 * @param WC_Order $wc_order
	 */
	public function get_out_trade_order_id($wc_order){
	    if($wc_order instanceof WC_Order){
	        $wc_order = $wc_order->get_id();
	    }
	    
	    return (string)get_post_meta($wc_order,self::ORDER_SN,true);
	}
	
	/**
	 * @param WC_Order $wc_order
	 */
	public function get_order_title($wc_order){
	    return apply_filters('wrest-wcorder-title', mb_strimwidth(get_bloginfo('name')."-{$wc_order->get_id()}", 0,64,'...','utf-8'),$wc_order);
	}
	

	/**
	 * Output for the order received page.
	 */
	public function thankyou_page() {
	    if ( $this->instructions ) {
	        echo wpautop( wptexturize( $this->instructions ) );
	    }
	}
	
	/**
	 * Add content to the WC emails.
	 *
	 * @access public
	 * @param WC_Order $order
	 * @param bool $sent_to_admin
	 * @param bool $plain_text
	 */
	public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
	    $method = method_exists($order ,'get_payment_method')?$order->get_payment_method():$order->payment_method;
	    if ( $this->instructions && ! $sent_to_admin && $this->id === $method ) {
	        echo wpautop( wptexturize( $this->instructions ) ) . PHP_EOL;
	    }
	}
}