<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

abstract class Abdtract_WRest_XCX_Setting_Menu extends Abstract_WRest_Settings_Menu{
    private $_configs = array();
    /**
     * @var WRest_Template_Layout_Navbar[]
     */
    private $_navbars = array();
    
    /**
     * @var WRest_Template_Window
     */
    private $_headers = array();
    
    private $_bodys=array();
    private $_footer=array();
    private $_bg=array();
    /**
     * 标记是否处于编辑状态
     * @var boolean
     */
    public $enable_edit = true;
    
    abstract function get_template_type();
    
    public function get_current_navbar_tab(){
        return false;
    }

    public function isShowRightBar(){
        return true;
    }

    public function isShowRightBar_Home(){
        return false;
    }
    
    public function isShowRightBar_Cart(){
        return true;
    }
    
    public function requiredAuth($version){
         return $this->get_window_field($version, 'requiredAuth')=='yes';
    }
    
    public function navHide($version){
        return $this->get_window_field($version, 'navHide')=='yes';
    }

    /**
     * @param WRest_Version $version
     * @param string $fieldkey
     * @param string $default
     * @return mixed
     */
    public function get_window_field($version,$fieldkey,$default = null){
        return $this->get_window($version)->get_option($fieldkey,$default);
    }
    
    
    public function get_config($version){
        if(!isset($this->_configs[$version->id])){
            $this->_configs[$version->id] = $this->get_config_data($version);
        }
        
        return $this->_configs[$version->id];
    }
    /**
     * @param WRest_Version $version
     * @return WRest_Template_Layout_Navbar
     */
    public function get_navbar($version){
        if(!isset($this->_navbars[$version->id])){
            $this->_navbars[$version->id] = new WRest_Template_Navbar($version);
        }
    
        return $this->_navbars[$version->id];
    }
    public function save_config($version,$fields){
        return WRest_Version::save_config($this->id,$version,$fields);
    }
    
    /**
     * @param WRest_Version $version
     * @return Abstract_WRest_Template_Settings[]
     */
    public function get_body($version){
        if(!isset($this->_bodys[$version->id])){
            $config = $this->get_config($version);
            
            $body_config =  $config&&is_array($config)&&isset($config['body'])&&is_array($config['body'])?$config['body']:array();
            $this->_bodys[$version->id]=array();
            
            $index = 0;
            foreach ($body_config as $p=>$template){
                $class = $this->get_template_class(isset($template['type'])?$template['type']:null);
                if(!$class){continue;}
                $obj = new $class($version,$index++,$template);
                $this->_bodys[$version->id][]=$obj;
            }
        }
    
        $config_body = $this->_bodys[$version->id];
        if(!$config_body||!is_array($config_body)){
            $config_body = array();
        }
        
        return $config_body;
    }
    /**
     * @param WRest_Version $version
     * @return Abstract_WRest_Template_Settings
     */
    public function get_footer($version){
        if(!isset($this->_footer[$version->id])){
             $this->_footer[$version->id] = null;
             $config = $this->get_config($version);
             $footer_config = $config&&is_array($config)&&isset($config['footer'])&&is_array($config['footer'])?$config['footer']:array();       
             $class = $this->get_template_class(isset($footer_config['type'])?$footer_config['type']:null);
             if($class){
                $this->_footer[$version->id] = new $class($version,0,$footer_config);
             }
        }
    
        return $this->_footer[$version->id];
    }
    
    /**
     * @param WRest_Version $version
     * @return Abstract_WRest_Template_Settings
     */
    public function get_bg($version){
        if(!isset($this->_bg[$version->id])){
            $this->_bg[$version->id] = null;
            $config = $this->get_config($version);
            $footer_config = $config&&is_array($config)&&isset($config['bg'])&&is_array($config['bg'])?$config['bg']:array();
            $class = $this->get_template_class(isset($footer_config['type'])?$footer_config['type']:null);
            if($class){
                $this->_bg[$version->id] = new $class($version,0,$footer_config);
            }
        }
    
        return $this->_bg[$version->id];
    }
    
    public function get_option($key, $empty_value = null){
        throw new Exception('This method is deleted!');
    }
   
    public function has_templates(){
        return true;
    }
   
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function render_templates($request,$response = array()){
        do_action('wrest_page_init',$this);
        $theme_id = sanitize_text_field($request->get_param('theme'));
        $themes = WRest_Admin::instance()->get_themes($this->get_template_type());
        
        $version_id = absint(str_replace(array('.','v'), '', $request->get_param('version')));
        $version = new WRest_Version($version_id,true);
        if(!$version->is_load()){
            return new WP_Error('system','The request version is not found',array('status'=>404));
        }
        
        if($theme_id&&isset($themes[$theme_id])&&$this->get_template_type()=='index'){
            $version->content =json_encode(array(
				$this->id=>$themes[$theme_id]
			));
        }
        if(!$response||!is_array($response)){$response=array();}
        
        $response = array_merge($response,array(
            'templates'=>array(),
            'footer'=>null,
            'bg'=>null
        ));
        
        $templates = array();
        foreach ($this->get_body($version) as $subtemplate){
            $auth_type = $subtemplate->get_option('auth_type');
            if(!$auth_type){$auth_type='';}
            switch ($auth_type){
                default:
                    $subtemplate->to_json($templates,$request);
                    break;
                case 'before':
                    if(!is_user_logged_in()){
                        $subtemplate->to_json($templates,$request);
                    }
                    break;
                case 'after':
                    if(is_user_logged_in()){
                        $subtemplate->to_json($templates,$request);
                    }
                    break;
            }
            
        }
        
        $response['templates'] = $templates;
        
        $footer = $this->get_footer($version);
        if($footer){
            $auth_type = $footer->get_option('auth_type');
            if(!$auth_type){$auth_type='';}
            switch ($auth_type){
                default:
                    $footerConfig = array();
                    $footer->to_json($footerConfig,$request);
                    $response['footer'] = count($footerConfig)>0?$footerConfig[0]:null;
                    break;
                case 'before':
                    if(!is_user_logged_in()){
                        $footerConfig = array();
                        $footer->to_json($footerConfig,$request);
                        $response['footer'] = count($footerConfig)>0?$footerConfig[0]:null;
                    }
                    break;
                case 'after':
                    if(is_user_logged_in()){
                        $footerConfig = array();
                        $footer->to_json($footerConfig,$request);
                        $response['footer'] = count($footerConfig)>0?$footerConfig[0]:null;
                    }
                    break;
            }
        }
        
        $bg = $this->get_bg($version);
        if($bg){
            $auth_type = $bg->get_option('auth_type');
            if(!$auth_type){$auth_type='';}
            switch ($auth_type){
                default:
                    $bgConfig = array();
                    $bg->to_json($bgConfig,$request);
                    $response['bg'] = count($bgConfig)>0?$bgConfig[0]:null;
                    break;
                case 'before':
                    if(!is_user_logged_in()){
                        $bgConfig = array();
                        $bg->to_json($bgConfig,$request);
                        $response['bg'] = count($bgConfig)>0?$bgConfig[0]:null;
                    }
                    break;
                case 'after':
                    if(is_user_logged_in()){
                        $bgConfig = array();
                        $bg->to_json($bgConfig,$request);
                        $response['bg'] = count($bgConfig)>0?$bgConfig[0]:null;
                    }
                    break;
            }
        }
        
        global $authorize_controllers_registered;
        if($authorize_controllers_registered
            ||($this->requiredAuth($version)&&!is_user_logged_in())
            ||$this->get_template_type()=='login'//当前页面是登录页面
            ){
        	//标识页面需要获取用户code
        	$response['requiredAuth'] = true;
        }
        
        if(!isset($response['pageNavTitle'])){
        	$response['pageNavTitle'] = $this->get_window_field($version, 'navigationBarTitleText',get_bloginfo('name')); 
        }
        
        if(!isset($response['navHide'])){
            $response['navHide'] = $this->navHide($version);
        }
        
        return new WP_REST_Response($response);
    }
    
    /**
     * @param boolean $include_draft 包含草稿
     * @return array
     */
    public function get_config_data($version = null,&$version_obj=null){
        $version_obj=null;
        $fields = WRest_Version::get_config($this->id,$version,$version_obj);
       
        if(!$fields){return array();}
        return $fields;
    }
   
    public function admin_form_start(){}
    public function admin_form_end(){}
    
    public function get_template_class($type){
        if(!$type){return false;}
        $templates = $this->get_controllers(array());
        foreach ($templates as $key=>$group){
            if(!isset($group['components'])||!$group['components']){
                continue;
            }
            foreach ($group['components'] as $class=>$settings){
            	if(strcasecmp($class, $type)===0&&class_exists($class)){
                    return $class;
                }
            }
        }
        
        return false;
    }
    
    public function get_controllers($controllers = array()){
        return array_merge($controllers,array(
            'base'=>array(
                'title'=>'基础组件',
                'components'=>array(
                    'WRest_Template_Editor'=>array(
                        'title'=>'富文本'
                    ),
                	'WRest_Template_Graphic_Navigation'=>array(
                        'title'=>'图文导航'
                    ),
                    'WRest_Template_Picture_Advertisement'=>array(
                        'title'=>'图片/广告'
                    ),
                    'WRest_Template_MagicCube'=>array(
                        'title'=>'魔方'
                    ),
                    'WRest_Template_Canvas'=>array(
                        'title'=>'画板<span style="color:red;">NEW</span>'
                    ),
                    'WRest_Template_Link'=>array(
                        'title'=>'导航链接'
                    ),
                    'WRest_Template_Title'=>array(
                        'title'=>'标题'
                    ),
                    'WRest_Template_NavT'=>array(
                        'title'=>'标题(导航)'
                    ),
                    'WRest_Template_Video'=>array(
                        'title'=>'视频'
                    ),
                    'WRest_Template_Line'=>array(
                        'title'=>'辅助线'
                    ),
                    'WRest_Template_Blank'=>array(
                        'title'=>'辅助空白'
                    ),
                    'WRest_Template_Map'=>array(
                        'title'=>'地图<span style="color:red;">NEW</span>'
                    )
                )
            ),
            'product'=>array(
                'title'=>'数据',
                'components'=>array(
                    'WRest_Template_Category'=>array(
                        'title'=>'分类、标签聚合'
                    ),
                    'WRest_Template_Products'=>array(
                        'title'=>'商品区块'
                    ),
                    'WRest_Template_Product_List'=>array(
                        'title'=>'商品列表 '
                    ),
                    'WRest_Template_Search'=>array(
                        'title'=>'商品搜索'
                    ),
                    'WRest_Template_Posts'=>array(
                        'title'=>'资讯模块<span style="color:red;">NEW</span>'
                    ),
                )
            ),
        	'authorize' => array(
            		'title'=>'登录',
            		'components'=>array(
            				'WRest_Template_Authorize_Btn_Login'=>array(
            					'title'=>'微信登录'
            				)
            		)
            ),
            'other'=>array(
                'title'=>'其它',
                'components'=>array(
                    
//                     'WRest_Template_TabNav'=>array(
//                        'title'=>'Tab导航栏'
//                     ),
                   'WRest_Template_GZH'=>array(
                       'title'=>'关注公众号<span style="color:red;">NEW</span>'
                    ),
                    'WRest_Template_Dialog'=>array(
                       'title'=>'弹窗广告<span style="color:red;">NEW</span>'
                    ),
                    'WRest_Template_GG'=>array(
                       'title'=>'Banner广告<span style="color:red;">NEW</span>'
                    ),
                    'WRest_Template_License'=>array(
                        'title'=>'版权信息'
                    )
                )
            )
        ));
    }
    
	public function template_view($version_obj){
		$url = WRest_Admin::instance()->get_current_admin_url();
		?>
		<ul class="xh-m-table" id="container" style="max-width:1100px;min-height:300px;"></ul>
	
		<script type="text/javascript">
			(function($){
				window.templateView={
					page_index:1,
					loading:false,
					items:null,
					search:function(page_index){
						if(this.loading){return;}
						this.page_index = page_index;
						var params={
							pageIndex:page_index
						};
						jQuery.ajax({
				            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'templates','template_type'=>$this->get_template_type()),true,true)?>',
				            type: 'post',
				            timeout: 60 * 1000,
				            async: true,
				            cache: false,
				            data: params,
				            dataType: 'json',
				            beforeSend  : function (XMLHttpRequest) {
				                XMLHttpRequest.setRequestHeader("request_type","ajax");
				                $('#container').loading('show');
				            },
				            complete: function() {
				            	$('#container').loading('hide');
				            	window.templateView.loading=false;
				            },
				            success: function(m) {
				            	if(m.errcode!=0){
				            		$('#container').html('<li>'+m.errmsg+'</li>');
									return;
								}
	
								if(!m.data||!m.data.items||m.data.items.length==0){
									$('#container').html('<li><p>暂无模板内容...</p></li>');
									return;
								}

								var generate_html_item=function(data,index){
									var html='';
									html+='<li >';
									html+='<div style="width: 228px;">';
									html+='<div style="width: 228px;">';
									html+='<a href="'+data.preview_img+'" target="_blank"><img src="'+data.preview_img+'" style="width: 176px;" /></a>';
									html+='</div>';
									html+='<div><h5>'+data.title+'</h5></div>';
									html+='<form id="wrest-form-'+index+'" method="POST" action="<?php echo esc_attr($url);?>">';
									html+='<input type="hidden" name="wrest-template-fields" value="'+index+'" />';
									html+='<input type="hidden" name="wrest-template-type" value="<?php echo $this->get_template_type()?>" />';
									html+='<button type="button" style="margin-top:20px;" class="button" onclick="window.templateView.use(\''+index+'\');">立即使用</button></form>'; 
									html+='</div>';
									html+='</li>';
									return html;
								}
								
								window.templateView.items = m.data.items;
								var html='';
								
				            	for(var index in m.data.items){
					            	var data = m.data.items[index];
					            	html+=generate_html_item(data,index);
					            }
				            	 $('#container').html(html);	
				            },
				            error:function(e){
				            	$('#container').html('<tr><td><p style="color:red">网络异常，请重试！</p></td></tr>');
				            	console.error(e.responseText);
				            }
				         });
					},
					use:function(index){
						if(!this.items){return;}
						
						if(!confirm('当前操作会覆盖之前的设置，确认执行？')){return;}
					
						$('#wrest-form-'+index).submit();
					}
				};
				$(function(){
					window.templateView.search(1);
				});
			})(jQuery);
		</script>
		<?php 
	}
	
    public function app_view_window($version_obj,$config){
        ?>
        <div class="zent-design__item-list" style="min-height:0px;border-bottom:solid 1px #e5e5e5;" id="the-app-page">
			<?php 
			$this->get_window($version_obj)->render($this);
			?>
		</div>
        <?php 
    }
    

    /**
     * @param WRest_Version $version
     * @return WRest_Template_Layout_Navbar
     * @deprecated 3.3.0 Use WRest_Menu_Store_Theme
     */
    public function get_window($version){
        if(!isset($this->_headers[$version->id])){
            $config = $this->get_config($version);
            $this->_headers[$version->id] = new WRest_Template_Window($version,0,$config&&is_array($config)&&isset($config['window'])&&is_array($config['window'])?$config['window']:array());
        }
    
        return $this->_headers[$version->id];
    }
    
    public function app_view_body($version_obj,$config){
        $theme = new WRest_Menu_Store_Theme($version_obj);
        $backgroundColor =$theme->get_option('page_backgroundColor');
        
        $fields = $this->get_body($version_obj);
        $footer = $this->get_footer($version_obj);
        $bg = $this->get_bg($version_obj);
        ?>
        
        <div style="position:relative;min-height:0px;background-color:#<?php echo $backgroundColor;?>;z-index:-1;" class="zent-design__item-list" id="the-app-container">
			<ul id="the-app-body">
			<?php 
			    
        			foreach ($fields as $template){
        			    ?><li><?php $template->render($this);?></li> <?php 
        			} 
        			if(!count($fields)&&!$footer&&!$bg){
        			    ?><li id="app-body-pre" style="padding-top:100px;text-align:center;">
        			    	暂无预览信息 
        			    	<?php if($this->has_templates()){
        			    	    ?><a href="<?php echo admin_url('admin.php?page=wrest_page_default&section=menu_store_settings&template=1&sub='.$this->id)?>">导入主题</a><?php 
        			    	}?>
        			    	
        			    </li><?php 
        			}
			?></ul>
		</div>
		<div style="min-height:0px;background-color:#<?php echo $backgroundColor;?>;margin-bottom:97px;" class="zent-design__item-list" >
			<ul id="the-app-footer">
			<?php 
			
			if ($footer){
			    ?><li><?php $footer->render($this);?></li> <?php 
			} 
			?></ul>
		</div>
		<div style="min-height:0px;background-color:#<?php echo $backgroundColor;?>;bottom: 52px;width: 320px;position: absolute;" class="zent-design__item-list" >
			<ul id="the-app-bg">
			<?php 
			
			if ($bg){
			    ?><li><?php $bg->render($this);?></li> <?php 
			} 
			?></ul>
		</div>
		<?php 
		if($this->enable_edit){
		    ?>
		    <script type="text/javascript">
    			(function($){
    			    $('#the-app-body').sortable({
                		cancel:'.page-section-not-sortable',
                		handle:'.zent-design-preview-controller',
    					cursor:'move',
    					tolerance: "pointer",
    			        placeholder: "field-drop-zone"
    			    });
    			})(jQuery);
    		</script>
		    <?php 
		}
    }
    
    public function app_view_content($version_obj,$config){
        if($this->get_current_navbar_tab()){
            
            $navbar = new WRest_Template_Navbar($version_obj);
            
            if($navbar->get_option('position','bottom')=='bottom'){
                ?>
                <style type="text/css">
                .navbar-menu{
                	position: absolute;
                    bottom: 0;
                }
                </style>
                <?php 
                $this->app_view_body($version_obj, $config);
                $this->app_view_navbar($version_obj, $config);
            }else{
                $this->app_view_navbar($version_obj, $config);
                $this->app_view_body($version_obj, $config);
            }
        }else{
            $this->app_view_body($version_obj, $config);
        }
    }
    
    public function app_view_navbar($version_obj,$config){
        if($this->get_current_navbar_tab()){ 
            ?>
			<div style="padding-bottom: 0px;min-height:0px;" class="zent-design__item-list navbar-menu" id="the-app-navbar">
    		<?php 
			$this->get_navbar($version_obj)->render($this);
			?>
			</div><?php
        }
    }
    
    public function app_view_controls($version_obj,$config){
        ?>
         <div class="zent-design__add zent-design__add--grouped">
        	<div class="zent-design-editor-add-component zent-design-editor-add-component--grouped" >
        		<?php 
        		foreach ($this->get_controllers() as $group_key=>$group){
        		    $visiable = false;
        		    foreach ($group['components'] as $ckey=>$component){
        		        if(!isset($component['hidden'])||!$component['hidden']){
        		            $visiable = true;
        		            break;
        		        }
        		    }
        		    if(!$visiable){continue;}
        		    ?>
        		    <div class="zent-design-editor-add-component__grouped">
            			<p class="zent-design-editor-add-component__grouped-title"><?php echo $group['title']?></p>
            			<div class="zent-design-editor-add-component__grouped-list">
            				<?php if($group['components']){
            				    foreach ($group['components'] as $ckey=>$component){
            				        if(isset($component['hidden'])&&$component['hidden']){continue;}
            				        ?>
            				        <div class="zent-popover-wrapper zent-pop-wrapper zent-design-editor-add-component-btn-wrapper zent-design-editor-add-component__grouped-btn-wrapper" style="display: inline-block;">
                    					<a class="zent-design-editor-add-component__grouped-btn"  onclick="window.templateView.add_template('<?php echo esc_attr($ckey);?>')"><?php echo $component['title']?></a>
                    				</div>
            				        <?php 
            				    }
            				}?>
            			</div>
        			</div>
        		    <?php 
        		}
        		?>
        	</div>
        </div>
        <script type="text/javascript">
			(function($){
				window.templateView.add_template = function(template_id){
					if(this.loading){return;}
					this.loading = true;

					var request={};
					request.template_id = template_id;
					request.version = window.templateView.version;
					jQuery.ajax({
			            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'add_template','id'=>$this->id),true,true)?>',
			            type: 'post',
			            timeout: 60 * 1000,
			            async: true,
			            cache: false,
			            data: request,
			            dataType: 'json',
			            beforeSend : function (XMLHttpRequest) {
			                XMLHttpRequest.setRequestHeader("request_type","ajax");
			                $('#the-app-body').loading('show');
			            },
			            complete: function() {
			            	$('#the-app-body').loading('hide');
			            	window.templateView.loading=false;
			            },
			            success: function(m) {
			            	if(m.errcode!=0){
			            		alert(m.errmsg);
								return;
							}
							var $pre = $('#app-body-pre');
							if($pre.length>0){$pre.remove();}
			            	switch(m.data.group){
    			            	case 'body':
    			            		$('#the-app-'+m.data.group).append('<li>'+m.data.html+'</li>');
    			            		break;
    			            	case 'footer':
    			            	case 'bg':
        			            default:
    			            		$('#the-app-'+m.data.group).html('<li>'+m.data.html+'</li>');
    			            		break;
			            	}
			            	
			            	window.templateView.controlEvent();
			            },
			            error:function(e){
			            	alert('网络异常，请重试！');
			            	console.error(e.responseText);
			            }
			         });
				};
			})(jQuery);
		</script>    
        <?php 
    }
    public function app_view_scripts_header($version_obj,$config){
        ?>
         <script type="text/javascript">
         	(function($){
          		window.templateView=window.templateView||{};
          		window.templateView.version = <?php echo $version_obj->id?>;
              	window.templateView.loading = false;
              	window.templateView.submit = function(request,call){
					if(this.loading){return;}
					this.loading = true;

					var configs={
						window:{},
						body:[],
						footer:{},
						bg:{}
					};
				
					$('#the-app-page .zent-design-preview-item').each(function(){
						var view_id = $(this).attr('id');
						if(!window[view_id]){
							return;
						}

						configs.window = window[view_id].config();
						return false;
					});
					
					$('#the-app-body .zent-design-preview-item').each(function(){
						var view_id = $(this).attr('id');
						if(!window[view_id]){
							return;
						}
						
						configs.body.push(window[view_id].config());
					});
					
					$('#the-app-footer .zent-design-preview-item').each(function(){
						var view_id = $(this).attr('id');
						if(!window[view_id]){
							return;
						}
						
						configs.footer = window[view_id].config();
					});
					
					$('#the-app-bg .zent-design-preview-item').each(function(){
						var view_id = $(this).attr('id');
						if(!window[view_id]){
							return;
						}
						
						configs.bg = window[view_id].config();
					});
					
					<?php if($this->get_template_type()=='layout'){
					    ?>
					    $('#the-app-navbar .zent-design-preview-item').each(function(){
							var view_id = $(this).attr('id');
							if(!window[view_id]){
								return;
							}
							
							configs.navbar = window[view_id].config();
						});			    
                    <?php 
					}?>
					
					
					request.id='<?php echo $this->id;?>';
					request.version = window.templateView.version;
					request.fields = JSON.stringify(configs);
					
					jQuery.ajax({
			            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'save_template'),true,true)?>',
			            type: 'post',
			            timeout: 60 * 1000,
			            async: true,
			            cache: false,
			            data: request,
			            dataType: 'json',
			            beforeSend  : function (XMLHttpRequest) {
			                XMLHttpRequest.setRequestHeader("request_type","ajax");
			                $('#app-container').loading('show');
			            },
			            complete: function() {
			            	$('#app-container').loading('hide');
			            	window.templateView.loading=false;
			            },
			            success: function(m) {
			            	if(m.errcode!=0){
			            		alert(m.errmsg);
								return;
							}

			            	call(m);
			            },
			            error:function(e){
			            	alert('网络异常，请重试！');
			            	console.error(e.responseText);
			            }
			         });
				};

      		})(jQuery);
		  </script>
        <?php 
    }
    
    public function app_view_scripts_footer($version_obj,$config){
        ?>
        <script type="text/javascript">
			(function($){
				window.templateView.controlEvent();
			})(jQuery);
		</script>
        <?php 
    }
        
    public function app_view_actions($version_obj,$config){
        ?>
        <div class="save">
			<div class="inner">
				<?php if($this->has_templates()){
				    ?>
				    <a href="<?php echo admin_url("admin.php?page=wrest_page_default&section=menu_store_settings&sub={$this->id}&template=1")?>" target="_blank" class="zent-btn-primary zent-btn">从模版导入</a>
				    <?php 
				}?>
				
				<button type="button" class="zent-btn-danger zent-btn" id="btn-save-app"><span>保存修改</span></button>  
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				$('#btn-save-app').click(function(){
					window.templateView.submit({
						'key':'publish'
					},function(m){
						window.templateView.load();
					})
                });
				$('#btn-push-app').click(function(){
					window.templateView.submit({
						'key':'publish'
					},function(m){
						window.templateView.load();
						location.href='<?php echo admin_url('admin.php?page=wrest_page_store_push&section=menu_store_publish&sub=menu_shop_publish')?>';
					})
                });
			})(jQuery);
		</script>
        <?php 
    }
    
	public function app_view($version=null){
	    do_action('wrest_page_init',$this);
	    $version_obj=null;
	    $config =$this->get_config_data($version,$version_obj);
	    if(!$version_obj){
	        $this->errors[]='数据加载异常，请刷新页面重试！';
	        $this->display_errors();
	        return;
	    }
	   ?>
        <div class="edit-showcase-design-page">
           <div class="edit-showcase-design-page__design-editor">
            	<div class="zent-design wsc-design" style="padding-bottom: 0px;;">
            		<div class="zent-design-preview">
            			<?php 
            			     $this->app_view_scripts_header($version_obj,$config);
            			     $this->app_view_window($version_obj,$config);
            			     ?><div style="position:relative;height: 100%;min-height:200px;z-index:-1;"><?php 
            			     $this->app_view_content($version_obj,$config);
            			     ?></div><?php 
            			     if($this->enable_edit){
            			         $this->app_view_controls($version_obj,$config);
            			     }
            			     $this->app_view_scripts_footer($version_obj,$config);
            			 ?>
            		</div>
            	</div>
            </div>
			
			<?php if($this->enable_edit){
			    $this->app_view_actions($version_obj,$config);
			}?>
			
		</div>	
    	<?php 
    }
    
    public function admin_options_header(){
    	?>
        <link rel="stylesheet" href="<?php echo WREST_URL?>/assets/css/common.css">
        <link rel="stylesheet" href="<?php echo WREST_URL?>/assets/css/app.css">
        <link rel="stylesheet" href="<?php echo WREST_URL?>/assets/css/app-nav.css">
        <link rel="stylesheet" href="<?php echo WREST_URL?>/assets/css/reset.css">
        <link rel="stylesheet" type="text/css" href="<?php echo WREST_URL?>/assets/slick/slick.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo WREST_URL?>/assets/slick/slick-theme.css"/>
        <link rel="stylesheet" href="<?php echo WREST_URL?>/assets/colpick/css/colpick.css">
        
        <script type="application/javascript" src="<?php echo WREST_URL?>/assets/colpick/js/colpick.js"></script>
        <script type="text/javascript" src="<?php echo WREST_URL?>/assets/slick/slick.min.js"></script>
       
        <?php 
        if(!defined('xunhuweb_ueditor_scripts')){
        	define('xunhuweb_ueditor_scripts', 1);
        	?>
        	 <script type="text/javascript">
	        	window.UEDITOR_SERVER_URL ='<?php echo WRest::instance()->ajax_url(array('action'=>'wrest_ueditor'),true,true)?>';
			</script>
	        <script type="text/javascript" src="<?php echo WREST_URL?>/assets/ueditor/ueditor.config.js"></script>
	        <script type="text/javascript" src="<?php echo WREST_URL?>/assets/ueditor/ueditor.all.js"></script>
        	<?php 
        }
        $api = WRest_Settings_Default_Basic_Default::instance();
        $mapkey = $api->get_option('txmapkey');
    	if(!defined('xunhuweb_txmap_scripts')){
    	    define('xunhuweb_txmap_scripts', 1);
    	    ?>
    	    <script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key=<?php echo $mapkey?>"></script>
    	    <?php 
    	}
    }
  
    public function process_admin_header(&$version_obj=null,$receive_post = false){
        $fields = $this->get_config_data(null,$version_obj);
        if(!$version_obj){
            ?><script type="text/javascript">
            	confirm('请新增一个版本号后，再回来操作！');
				location.href="<?php echo admin_url('admin.php?page=wrest_page_store&section=menu_store_publish')?>";
            </script><?php 
            return;
        } 
        
        if(isset($_POST['wrest-template-fields'])&&isset($_POST['wrest-template-type'])){
            $index = sanitize_text_field($_POST['wrest-template-fields']);
            $type = sanitize_text_field($_POST['wrest-template-type']);
        
            $themes = WRest_Admin::instance()->get_themes($type);
            $postConfig = isset($themes[$index])?$themes[$index]:null;
            if($postConfig&&is_array($postConfig)&&$version_obj){
                $error = WRest_Version::save_config($this->id,$version_obj,$postConfig);
                if(!WRest_Error::is_valid($error)){
                    $this->errors[]=$error->errmsg;
                }else{
                    $fields = $this->get_config_data(null,$version_obj);
                }
            }
        }
        
        $this->admin_options_header();
        $this->display_errors();
        return $fields;
    }
    
    public function admin_options(){
        $version_obj = null;
        $fields = $this->process_admin_header($version_obj,true);
        if(!$version_obj){return;}
       ?>
        <div class="container">
            <div id="app-third-sidebar" class="js-app-third-sidebar">
                <div class="zent-breadcrumb">
                    <a href="#">店铺页面</a>
                    <span>
                        <?php echo $this->title;?> 
                    </span>
                    <span>
                        <?php echo $version_obj->get_version_code();?> 
                    </span>
                </div> 
            </div>
	           
            <?php 
                if($this->has_templates()&&count($fields)<=1||(isset($_REQUEST['template'])&&$_REQUEST['template']=='1')){
                    $this->template_view($version_obj);
                }else{
                    $this->admin_options_content($version_obj);
                }
    	    ?>
        </div>
    	<?php 
    }
    
    /**
     * 
     * @param WRest_Version $version_obj
     */
    public function admin_options_content($version_obj,$editCall=null){
        $ratio = 0.5;
        require_once WREST_DIR.'/includes/miniprogram/abstract.php';
        require_once WREST_DIR.'/includes/miniprogram/theme.wxss.php';
        $theme = new WRest_Menu_Store_Theme($version_obj);
        $wxss = new WRest_Mini_App_Theme_WXSS(array(
            'width'=>320,
            'ratio'=>$ratio,
            'page'=>'.zent-design-preview',
            'view'=>'.zent-design-preview',
            'image'=>'.image',
            'text'=>''
        ));
         
        ?>
		<style type="text/css">
        <?php echo str_replace('rpx', 'px', $wxss->render($version_obj));?>
        </style>
        <script type="text/javascript">
			window.__config__={
				theme_size:<?php echo $theme->get_option('size')*$ratio;?>
			};
		</script>
    	<div id="app-container">
    		<div class="app">
               <div class="app-inner clearfix">
                  <div class="app-init-container" style="display:flex;flex-direction:row;justify-content:flex-start;">
                  	<div style="display:flex;flex-direction:column;">
                      	<div class="xh-column xh-w xh-mB30" id="app-dialog" style="min-width:320px;<?php echo !$this->enable_edit?'display:none;':''?>"></div>
                        <div class="app__content" id="app-content" style="min-width:320px;min-height:600px"></div> 
                  	</div>
             		 
             		<?php if($editCall){
             		    call_user_func_array($editCall, array($this,$version_obj));
             		}?>                 
             	</div>
                <div class="notify-bar js-notify animated hinge hide"></div>
               </div>
            </div>
    	</div>
    	<script type="text/javascript">
          	jQuery(function($){
          		window.templateView=window.templateView||{};
              	window.templateView.loading = false;
                window.templateView.load = function(){
					if(window.templateView.loading){return;}
					window.templateView.loading = true;

					var request={
						version:$('#wrest-version').val(),
						enable_edit:'<?php echo $this->enable_edit?'yes':'no'?>'
    				};
					
					jQuery.ajax({
			            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'load_template','id'=>$this->id),true,true)?>',
			            type: 'post',
			            timeout: 60 * 1000,
			            async: true,
			            cache: false,
			            data: request,
			            dataType: 'json',
			            beforeSend  : function (XMLHttpRequest) {
			                XMLHttpRequest.setRequestHeader("request_type","ajax");
			                $('#app-content').loading('show');
			            },
			            complete: function() {
			            	$('#app-content').loading('hide');
			            	window.templateView.loading=false;
			            },
			            success: function(m) {
			            	if(m.errcode!=0){
			            		alert(m.errmsg);
								return;
							}

			            	$('#app-content').html(m.data);
			            	window.templateView.controlEvent();
			            },
			            error:function(e){
			            	alert('网络异常，请重试！');
			            	console.error(e.responseText);
			            }
			         });
				};


				window.templateView.controlEvent = function(){
					<?php if($this->enable_edit){
					    ?>
					    $('.zent-design-preview-controller').not('.wrest-event-binded').addClass('wrest-event-binded').click(function(){
		        			//显示高亮虚线
		        			$('.zent-design-preview-controller').removeClass('zent-design-preview-controller--highlight').removeClass('zent-design-preview-controller--selected');
		        			$(this).addClass('zent-design-preview-controller--selected').addClass('zent-design-preview-controller--highlight');
		        
		        			//影藏已显示编辑区域
		        			$('.zent-design-editor-item').css('display','none');
		        			//显示当前编辑区域
		        			$(this).siblings('.zent-design-editor-item').fadeIn();
		        		}).first().click();
					    <?php 
					}?>
					
	        		
					$(document).trigger('on_wrest_app_ready');
				};
				
              	window.templateView.load(); 

              	$('#wrest-version').change(function(){
              		window.templateView.load();
                });
            });
        </script>
    	<?php 
    }
}