<?php

abstract class Abdtract_WRest_Setting_Layout extends Abstract_WRest_Settings_Menu{
    /**
     * @var WRest_Version
     */
    protected $version;
    protected function __construct($version=null){
        if(!$version){
            $version = WRest_Version::get_newest_version();
        }
        $this->version = $version;
    }
    
    public function process_admin_options() {
        $version = $this->version;
        if(!$version||!$version->is_load()){
            $this->errors[]="版本信息加载异常!";
        }else{
            $this->validate_settings_fields ();
            do_action('wrest_process_admin_options_validate_'.$this->id);
        }
        
        if (count ( $this->errors ) > 0) {
            $this->display_errors ();
            return false;
        } else {
            WRest_Version::save_config($this->id,$version,$this->sanitized_fields);
            $this->init_settings ();
            do_action('wrest_refresh_config',$version);
            $this->display_success();
            return true;
        }
    }
    
    public function init_settings() {
        $this->settings = WRest_Version::get_config($this->id,null,$this->version);
    
        if (! $this->settings || ! is_array ( $this->settings )) {
            	
            $this->settings = array ();
            	
            // If there are no settings defined, load defaults.
            $form_fields = $this->get_form_fields ();
            if ($form_fields) {
    
                foreach ( $form_fields as $k => $v ) {
                    $this->settings [$k] = isset ( $v ['default'] ) ? $v ['default'] : '';
                }
            }
        }
    
        if (! empty ( $this->settings ) && is_array ( $this->settings )) {
            $this->settings = array_map ( array (
                $this,
                'format_settings'
            ), $this->settings );
            $this->enabled = isset ( $this->settings ['enabled'] ) && $this->settings ['enabled'] == 'yes' ? 'yes' : 'no';
        }
    }
    
    public function admin_form_start(){}
     
    public function admin_options(){
        $page = $this->get_page_review();
        $page->enable_edit = false;
        
        if(!$this->version){return;}
        
        $fields = $page->process_admin_header($this->version,false);
       
        ?>
        <div class="container">
            <div id="app-third-sidebar" class="js-app-third-sidebar">
                <div class="zent-breadcrumb">
                    <a href="#">店铺设置</a>
                    <span>
                        <?php echo $this->title;?> 
                    </span>
                    <span> <?php echo $this->version->get_version_code();?> </span>
                </div> 
            </div>
	           
            <?php 
             $page->admin_options_content($this->version,array($this,'admin_options_edit'));
    	    ?>
        </div>
    	<?php 
	}
	
	/**
	 * 
	 * @param Abstract_WRest_Settings_Menu $page
	 * @param WRest_Version $version
	 */
	public function admin_options_edit($page, $version)
	{
	
	    ?>
       <div style="margin-left:20px;">
          <?php 
          parent::admin_form_start();
          
          $title = $this->title;
          if(!empty($this->menu_title)){
              $title = $this->menu_title;
          }
          ?>
  	      <style type="text/css">
              .form-table tr{display:block;}
          </style>
          <h3><?php echo ( ! empty( $title ) ) ? $title : __( 'Settings') ; ?></h3>
          <?php echo ( ! empty( $this->description ) ) ? wpautop( $this->description ) : ''; ?>
          
          <?php do_action('wrest_admin_options_header_'.$this->id)?>
          <input type="hidden" name="__current_version__" value="<?php echo $version->id?>" />
          <input type="hidden" name="action" value="<?php print esc_attr($this->id)?>"/>
          <table class="form-table">
  			<?php $this->generate_settings_html(); ?>
  		</table>
  		<?php parent::admin_form_end();?>
       </div>
       <?php 
    }
	
    public function admin_form_end(){} 
    
    /**
     * @return Abdtract_WRest_XCX_Setting_Menu
     */
    public function get_page_review()
    {
        return WRest_Menu_Store_Index::instance();
    } 
    
    public function generate_color_html($key, $data) {
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'css' => '',
            'placeholder' => '',
            'type' => 'text',
            'desc_tip' => false,
            'description' => '',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $color = $this->get_option($key);
        ob_start ();
        ?>
        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
        	<th scope="row" class="titledesc">
        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
        		<?php echo $this->get_tooltip_html( $data ); ?>
        	</th>
        	<td class="forminp">
        		<fieldset>
        			<legend class="screen-reader-text">
        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
        			</legend>
        			<?php $this->generate_color_panel($field,$color,$data['default']);?>
					
        			<?php echo $this->get_description_html( $data ); ?>
        		</fieldset>
        		
        	</td>
        </tr>
        <?php
		
		return ob_get_clean ();
	}
	
	private function generate_color_panel($field,$color,$default=null){
	    ?>
	    <div class="zent-input-wrapper" style="display:inline-block;">
			<div class="zent-color-picker" tabindex="0">
				<div id="<?php echo $field?>-picker" data-float="1" class="zent-color-picker__text" style="background-color: #<?php echo esc_attr($color)?>;"></div>
			</div>	
			<input type="text" name="<?php echo $field;?>" id="<?php echo $field;?>" value="<?php echo esc_attr($color)?>" style="width:60px;"/>
			<a href="javascript:void(0);" id="<?php echo $field?>-reset">重置</a>
		</div>
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field?>-reset').click(function(){
					var hex = '<?php echo $default;?>';
					$('#<?php echo $field;?>').val(hex);
					$('#<?php echo $field?>-picker').css('background-color','#'+hex).colpickSetColor(hex);
				});

				$('#<?php echo $field;?>').click(function(){
					var hex = $(this).val();
					
					$('#<?php echo $field;?>').val(hex);
					if(!hex){
						$('#<?php echo $field?>-picker').css('background-color','#fff');
						return;
					}
					
					$('#<?php echo $field?>-picker').css('background-color','#'+hex).colpickSetColor(hex);
				});

				$('#<?php echo $field;?>').keyup(function(){
					window.<?php echo $field?>.set_value($(this).val());
				});
				
				window.<?php echo $field?>={
					timeout:null,
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field;?>').val(val);
						$('#<?php echo $field;?>').click();
					}
				};
				
				$('#<?php echo $field?>-picker').colpick({
				    layout:'full',
				    submit:0,
				    color:'<?php echo $color ?>',
				    colorScheme:'light',
				    onChange:function(hsb,hex,rgb,el,bySetColor) {
				    	$('#<?php echo $field;?>').val(hex);
						$('#<?php echo $field?>-picker').css('background-color','#'+hex);
				    }})
    				.keyup(function(){
    				    $(this).colpickSetColor(this.value);
    			    });
			})(jQuery);
		</script>
	    <?php 
	    
	}
	
	public function generate_image_html($key, $data) {
	    $field = $this->get_field_key ( $key );
	    $defaults = array (
	        'title' => '',
	        'disabled' => false,
	        'class' => '',
	        'css' => '',
	        'placeholder' => '',
	        'type' => 'text',
	        'desc_tip' => false,
	        'description' => '',
	        'custom_attributes' => array (),
	        'validate'=>function($key,$api){
	        $field = $api->get_field_key($key);
	        $data = isset($_POST[$field])?stripslashes($_POST[$field]):null;
	        return $data;
	        }
        );
	
	    $data = wp_parse_args ( $data, $defaults );
	    $config =  $this->get_option( $key );
	    if(!$config||!is_array($config)){
	        $config =array();
	    }
	    ob_start ();
	    ?>
	        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
	        	<th scope="row" class="titledesc">
	        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
	        		<?php echo $this->get_tooltip_html( $data ); ?>
	        	</th>
	        	<td class="forminp">
	        		<fieldset>
	        			<legend class="screen-reader-text">
	        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
	        			</legend>
	        			
						<img id="<?php echo esc_attr( $field ); ?>-img" style="max-width:100px;max-height:100px;background:#f4f4f4;" src="<?php echo esc_attr(  isset($config['url'])? $config['url']:'' ); ?>">
						
						<input type="hidden" name="<?php echo esc_attr( $field ); ?>_url" id="<?php echo esc_attr( $field ); ?>_url" value="<?php echo esc_attr( isset($config['url'])? $config['url']:''); ?>" />
						<input type="hidden" name="<?php echo esc_attr( $field ); ?>_width" id="<?php echo esc_attr( $field ); ?>_width" value="<?php echo esc_attr(  isset($config['width'])?$config['width']:0 ); ?>" />
						<input type="hidden" name="<?php echo esc_attr( $field ); ?>_height" id="<?php echo esc_attr( $field ); ?>_height" value="<?php echo esc_attr(  isset($config['height'])?$config['height']:0 ); ?>" />
						
						<input type="button" class="button" id="btn-<?php echo esc_attr( $field ); ?>-upload-img" value="<?php echo __('Upload Image',WREST)?>" />
						<a href="javascript:void(0);" style="margin-left:5px;" id="btn-<?php echo esc_attr( $field ); ?>-remove"><?php echo __('Remove',WREST)?></a>
						<script type="text/javascript">
						(function($){
							$('#btn-<?php echo esc_attr( $field ); ?>-upload-img').click(function() {  
								window.__send_to_editor = window.send_to_editor;
								window.send_to_editor = function(html) {
									var $img = jQuery('img','<span>'+html+'</span>');
									if($img.length==0){
										alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
										return;
									}
									var url = $img.attr('src');
									var width = $img.attr('width');
									var height = $img.attr('height');

									if(!url){
										alert('图片路径信息获取失败！');
										return;
									}

									if(!width){
										alert('图片宽度信息获取失败！');
										return;
									}
									if(!height){
										alert('图片高度信息获取失败！');
										return;
									}
									$('#<?php echo esc_attr( $field ); ?>_url').val(url);
									$('#<?php echo esc_attr( $field ); ?>_width').val(width);
									$('#<?php echo esc_attr( $field ); ?>_height').val(height);
								    $('#<?php echo esc_attr( $field ); ?>-img').attr('src',url);
							    	window.send_to_editor = window.__send_to_editor;
							    }
							    
							    wp.media.editor.open();
							    return false;    
						    });   
						    
						    $('#btn-<?php echo esc_attr( $field ); ?>-remove').click(function(){
								if(confirm('<?php echo __('Are you sure?',WREST)?>')){
									$('#<?php echo esc_attr( $field ); ?>_url').val('');
									$('#<?php echo esc_attr( $field ); ?>_width').val('');
									$('#<?php echo esc_attr( $field ); ?>_height').val('');
									$('#<?php echo esc_attr( $field ); ?>-img').attr('src','');
								}
							});
						})(jQuery);
						</script>
	        			
	        			<?php echo $this->get_description_html( $data ); ?>
	        		</fieldset>
	        	</td>
	        </tr>
	        <?php
		return ob_get_clean ();
	}
	
	public function validate_image_field($key){
	    $field = $this->get_field_key($key);
	    return array(
	        'width'=>isset($_POST["{$field}_width"])?absint($_POST["{$field}_width"]):0,
	        'height'=>isset($_POST["{$field}_height"])?absint($_POST["{$field}_height"]):0,
	        'url'=>isset($_POST["{$field}_url"])?sanitize_text_field($_POST["{$field}_url"]):'',
	    );
	}
	
	public function validate_color_btn_field($key){
	   $field = $this->get_field_key($key);
	   return array(
	       'normal'=>isset($_POST["{$field}_normal"])?sanitize_text_field($_POST["{$field}_normal"]):'',
	       'press'=>isset($_POST["{$field}_press"])?sanitize_text_field($_POST["{$field}_press"]):'',
	       'disable'=>isset($_POST["{$field}_disable"])?sanitize_text_field($_POST["{$field}_disable"]):'',
	   );
	}
	
	public function generate_color_btn_html($key, $data) {
	    $field = $this->get_field_key ( $key );
	    $defaults = array (
	        'title' => '',
	        'disabled' => false,
	        'class' => '',
	        'css' => '',
	        'placeholder' => '',
	        'type' => 'text',
	        'desc_tip' => false,
	        'description' => '',
	        'custom_attributes' => array ()
	    );
	
	    $data = wp_parse_args ( $data, $defaults );
	    $colors = $this->get_option($key);
	    if(!$colors||!is_array($colors)){
	        $colors = array();
	    }
	    ob_start ();
	    ?>
        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
        	<th scope="row" class="titledesc">
        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
        		<?php echo $this->get_tooltip_html( $data ); ?>
        	</th>
        	<td class="forminp">
        		<fieldset>
        			<legend class="screen-reader-text">
        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
        			</legend>
        			
        			<div style="display:flex;flex-direction:row;">
            			<div>
                			<?php $this->generate_color_panel("{$field}_normal",isset($colors['normal'])?$colors['normal']:'',isset($data['default']['normal'])?$data['default']['normal']:'');?>
        					<p class="description">(Normal)</p>
            			</div>
            			
    					<div style="margin-left:15px;">
                			<?php $this->generate_color_panel("{$field}_press",isset($colors['press'])?$colors['press']:'',isset($data['default']['press'])?$data['default']['press']:'');?>
        					<p class="description">(Press 20%)</p>
            			</div>
            			
            			<div style="margin-left:15px;">
                			<?php $this->generate_color_panel("{$field}_disable",isset($colors['disable'])?$colors['disable']:'',isset($data['default']['disable'])?$data['default']['disable']:'');?>
        					<p class="description">(Disable 20%)</p>
            			</div>
        			</div>
        			<?php echo $this->get_description_html( $data ); ?>
        		</fieldset>
        	</td>
        </tr>
        <?php
		
		return ob_get_clean ();
	}
	
	public function validate_button_field($key){
	    $field = $this->get_field_key($key);
	    return array(
	        'bg'=>isset($_POST["{$field}_bg"])?sanitize_text_field($_POST["{$field}_bg"]):'',
	        'font'=>isset($_POST["{$field}_font"])?sanitize_text_field($_POST["{$field}_font"]):'',
	        'border'=>isset($_POST["{$field}_border"])?sanitize_text_field($_POST["{$field}_border"]):''
	    );
	}
	
	public function generate_button_html($key, $data) {
	    $field = $this->get_field_key ( $key );
	    $defaults = array (
	        'title' => '',
	        'disabled' => false,
	        'class' => '',
	        'css' => '',
	        'placeholder' => '',
	        'type' => 'text',
	        'desc_tip' => false,
	        'description' => '',
	        'custom_attributes' => array ()
	    );
	
	    $data = wp_parse_args ( $data, $defaults );
	    $colors = $this->get_option($key);
	    if(!$colors||!is_array($colors)){
	        $colors = array();
	    }
	    ob_start ();
	    ?>
	        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
	        	<th scope="row" class="titledesc">
	        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
	        		<?php echo $this->get_tooltip_html( $data ); ?>
	        	</th>
	        	<td class="forminp">
	        		<fieldset>
	        			<legend class="screen-reader-text">
	        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
	        			</legend>
	        			
	        			<div style="display:flex;flex-direction:row;">
                			<div>
	                			<?php $this->generate_color_panel("{$field}_font",isset($colors['font'])?$colors['font']:'',isset($data['default']['font'])?$data['default']['font']:'');?>
	        					<p class="description">文字颜色</p>
	            			</div>
	            			
	            			<div style="margin-left:15px;">
	                			<?php $this->generate_color_panel("{$field}_border",isset($colors['border'])?$colors['border']:'',isset($data['default']['border'])?$data['default']['border']:'');?>
	        					<p class="description">边框颜色</p>
	            			</div>
	            			
	            			<div>
	                			<?php $this->generate_color_panel("{$field}_bg",isset($colors['bg'])?$colors['bg']:'',isset($data['default']['bg'])?$data['default']['bg']:'');?>
	        					<p class="description">背景色</p>
	            			</div>
	        			</div>
	        			
	        			
	        			<?php echo $this->get_description_html( $data ); ?>
	        		</fieldset>
	        	</td>
	        </tr>
	        <?php
			
			return ob_get_clean ();
		}
	
	public function generate_border_html($key, $data) {
	    $field = $this->get_field_key ( $key );
	    $defaults = array (
	        'title' => '',
	        'disabled' => false,
	        'class' => '',
	        'css' => '',
	        'placeholder' => '',
	        'type' => 'border',
	        'desc_tip' => false,
	        'description' => '',
	        'custom_attributes' => array ()
	    );
	
	    $data = wp_parse_args ( $data, $defaults );
	    $config = $this->get_option($key);
	    if(!$config||!is_array($config)){
	        $config = array();
	    }
	    ob_start ();
	    ?>
        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
        	<th scope="row" class="titledesc">
        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
        		<?php echo $this->get_tooltip_html( $data ); ?>
        	</th>
        	<td class="forminp">
        		<fieldset>
        			<legend class="screen-reader-text">
        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
        			</legend>
        			
        			<div style="display:flex;flex-direction:row;">
            			<div>
                			<?php $this->generate_color_panel("{$field}_color",isset($config['color'])?$config['color']:'',isset($data['default']['color'])?$data['default']['color']:'');?>
        					<p class="description">边框颜色</p>
            			</div>
            			
    					<div style="margin-left:15px;">
                			<input class="wc_input_decimal input-text regular-input <?php echo esc_attr( $data['class'] ); ?>" type="tel" name="<?php echo "{$field}_size"; ?>" id="<?php echo "{$field}_size"; ?>" style="<?php echo esc_attr( $data['css'] ); ?>" value="<?php echo esc_attr( isset($config['size'])?$config['size']:'' ); ?>" placeholder="<?php echo esc_attr( $data['placeholder'] ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?> />
        					<p class="description">边框大小(rpx)</p>
            			</div>
            			
        			</div>
        			<?php echo $this->get_description_html( $data ); ?>
        		</fieldset>
        	</td>
        </tr>
        <?php
		
		return ob_get_clean ();
	}
	
    public function validate_border_field($key){
	   $field = $this->get_field_key($key);
	   return array(
	       'color'=>isset($_POST["{$field}_color"])?sanitize_text_field($_POST["{$field}_color"]):'',
	       'size'=>isset($_POST["{$field}_size"])?absint(sanitize_text_field($_POST["{$field}_size"])):2
	   );
	}
	
	public function validate_integer_field($key){
	    $text = $this->get_option ( $key );
	    $field = $this->get_field_key ( $key );
	    
	    if (isset ( $_POST [$field] )) {
	        $settings = $this->form_fields[$key];
	        if(isset($settings['ignore_kses_post'])&&$settings['ignore_kses_post']){
	            $text = !is_array( $_POST [$field])? ( trim ( stripslashes ( $_POST [$field] ) ) ): $_POST [$field];
	        }else{
	            $text =!is_array( $_POST [$field])? wp_kses_post ( trim ( stripslashes ( $_POST [$field] ) ) ): $_POST [$field];
	        }
	        	
	    }
	    
	    return absint($text);
	}
	
	public function generate_integer_html($key, $data) {
	    $field = $this->get_field_key ( $key );
	    $defaults = array (
	        'title' => '',
	        'disabled' => false,
	        'class' => '',
	        'css' => 'min-width:400px;',
	        'placeholder' => '',
	        'type' => 'integer',
	        'desc_tip' => false,
	        'description' => '',
	        'custom_attributes' => array ()
	    );
	
	    $data = wp_parse_args ( $data, $defaults );
	
	    ob_start ();
	    ?>
	        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
	        	<th scope="row" class="titledesc">
	        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
					<?php echo $this->get_tooltip_html( $data ); ?>
				</th>
	        	<td class="forminp">
	        		<fieldset>
	        			<legend class="screen-reader-text">
	        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
	        			</legend>
	        			<input class="input-text regular-input <?php echo esc_attr( $data['class'] ); ?>" type="tel" name="<?php echo esc_attr( $field ); ?>" id="<?php echo esc_attr( $field ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>" value="<?php echo esc_attr( $this->get_option( $key ) ); ?>" placeholder="<?php echo esc_attr( $data['placeholder'] ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?> autocomplete="off"  />
						<?php echo $this->get_description_html( $data ); ?>
					</fieldset>
	        	</td>
	        </tr>
	        <?php
			
			return ob_get_clean ();
		}
}