<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

/**
 * Social Admin
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Admin {
    /**
     * Wp menu key
     *  
     * @var string
     * @since  1.0.0
     */
    const menu_tag='wrest';
    
    /**
     * 实例
     * 
     * @var WRest_Admin
     */
    private static $_instance;
    
    /**
     * WRest_Admin Instance
     * 
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * hook admin menu actions
     * @since  1.0.0
     */
    private function __construct(){      
        $this->includes();
        $this->hooks();
    }
 
    /**
     * include menu files
     * @since  1.0.0
     */
    public function includes(){
        require_once 'abstracts/abstract-wrest-xcx-setting.php';
        require_once 'menus/class-wrest-page-default.php';
        require_once 'menus/class-wrest-page-store.php';
        require_once 'menus/class-wrest-page-add-ons.php';
        require_once 'menus/class-wrest-menu-default-basic.php';
        require_once 'menus/class-wrest-menu-add-ons-install.php';
        require_once 'menus/class-wrest-menu-add-ons-recommend.php';
        require_once 'class-wrest-meta-box-product-images.php';
        require_once 'abstracts/abstract-xh-view-layout.php';
    }
    
    /**
     * hooks
     * @since  1.0.0
     */
    public function hooks(){
        add_action( 'admin_menu', array( $this, 'admin_menu'),10);
        add_action( 'admin_head', array( $this, 'admin_head'),10 ); 
        add_action( 'admin_init', array( $this, 'admin_init'),10 );
      
        add_filter('wrest_ajax', function($actions){
            $actions['wrest_admin']=array(WRest_Admin::instance(),'do_ajax');
            return $actions;
        },10,1);
        
    }
    public function admin_init(){
    	$product_type = WRest::instance()->get_product_api()->post_type;
    	add_meta_box( 'wrest-product-content', '(小程序)图文介绍', 'WRest_Meta_Box_Product_Images::output',$product_type, 'advanced', 'high' );
    	add_meta_box( 'wrest-post-content','(小程序)图文介绍', 'WRest_Meta_Box_Product_Images::output','post', 'advanced', 'high' );
    	add_meta_box('wrest-metabox-product-vedio','(小程序)视频介绍',array($this,'meta_product_video'),$product_type,'side','default' );
    	add_action( 'save_post', array($this,'save_meta_product_video'),10,1 );
    	add_action( 'save_post', 'WRest_Meta_Box_Product_Images::save', 0, 2 );
    	add_action('woocommerce_product_options_inventory_product_data', __CLASS__.'::add_product_sale_qty_field',10);
    	add_action('woocommerce_product_options_pricing', __CLASS__.'::add_product_align_field',10);
        add_meta_box('wrest-metabox-article-products','(小程序)相关产品列表',array($this,'meta_article_products'),'post','advanced','default' );
        add_action( 'save_post', array($this,'save_meta_article_products'),10,1 );
        add_action( 'save_post', array($this,'save_meta_product_sale_qty'),10,1 );
        
        add_action('product_cat_edit_form_fields',array($this,'product_cat_edit_form_fields'),10,2);
        add_action('product_cat_add_form_fields',array($this,'product_cat_add_form_fields'),10,1);
        
        add_action('category_edit_form_fields',array($this,'product_cat_edit_form_fields'),10,2);
        add_action('category_add_form_fields',array($this,'product_cat_add_form_fields'),10,1);
        
        add_action( 'edited_product_cat', array( $this, 'product_cat_save_tax_meta' ), 10, 2 );
        add_action( 'create_product_cat', array( $this, 'product_cat_save_tax_meta' ), 10, 2 );
        
        add_action( 'edited_category', array( $this, 'product_cat_save_tax_meta' ), 10, 2 );
        add_action( 'create_category', array( $this, 'product_cat_save_tax_meta' ), 10, 2 );
        
        add_filter('manage_edit-comments_columns', __CLASS__.'::edit_comment_columns',10,1);
        add_action('manage_comments_custom_column', __CLASS__.'::manage_comments_custom_column',10,2);
        add_action('woocommerce_coupon_options', __CLASS__.'::woocommerce_coupon_options',10,2);
        add_action('woocommerce_coupon_options_save', __CLASS__.'::woocommerce_coupon_options_save',10,2);
        
        add_filter( 'post_row_actions', __CLASS__.'::dupe_link' , 99, 2 );
        add_filter('views_edit-shop_order', __CLASS__.'::views_edit_shop_order',11,1);
       
        if(function_exists('wc_get_order_types')){
            foreach ( wc_get_order_types( 'order-meta-boxes' ) as $type ) {
                add_meta_box( 'wrest-order-refund', "订单退款申请", __CLASS__.'::order_refund_html', $type, 'advanced', 'default' );
            }
        }
        
        add_action('woocommerce_admin_order_data_after_billing_address', __CLASS__.'::woocommerce_admin_order_data_after_billing_address',10,1);
    }


    /**
     *
     * @param WC_Order $order
     */
    public static function woocommerce_admin_order_data_after_billing_address($order){
        $has_idcard = class_exists('WC_Sinic')&&WC_Sinic::instance()->get_available_addon('wc_sinic_add_ons_idcard');
		if(!$has_idcard){
		    return;
		}
		$billing_idcard_username = get_post_meta($order->get_id(),'_billing_idcard_username',true);
		$billing_idcard_no = get_post_meta($order->get_id(),'_billing_idcard_no',true);
		  
    
        ?><p><b>身份认证信息：</b><?php echo $billing_idcard_username?> <?php echo $billing_idcard_no?> </p><?php
    }
    
    public static function order_refund_html($post){
        $upload_images = array();
        $uploads  =get_post_meta($post->ID,'__wres_refund_reason_uploads__',true);
        if($uploads){
            foreach ($uploads as $upload_id){
                $image = wp_get_attachment_image_src(absint($upload_id));
                if($image&&count($image)){
                    $upload_images[]=$image[0];
                }
            }
        }
        
        $refund_reason=get_post_meta($post->ID,'__wres_refund_reason__',true);
        $refund_reason_detail=get_post_meta($post->ID,'__wres_refund_reason_detail__',true);
  
        ?>
        <div class="add_note" >
			<p>
				<label for="wc_sinic_shipping_company"><b>退款原因：</b><?php echo $refund_reason;?></label>
				
			</p>
			<p>
				<label for="wc_sinic_shipping_no"><b>详细原因：</b><?php echo $refund_reason_detail;?></label>
				
			</p>
			<p>
				<?php foreach ($upload_images as $upload){
				    ?><a href="<?php echo $upload?>" target="_blank"><img alt="" src="<?php echo $upload?>"  style="width:80px;height:80px;margin:10px;"/> </a><?php 
				}?>
			</p>
		</div>
        <?php 
    }
    
    public static function views_edit_shop_order($status_list){
         
        $status_Api = WRest_Menu_Default_Order::instance();
        $new_status_list = array();
        foreach ($status_list as $status=>$txt){
            $config = $status_Api->reflect_status($status);
            $new_status_list[]=array(
                'name'=>$config?$config['name']:$status,
                'txt'=>$txt,
                'sort'=>$config&&isset($config['sort'])?absint($config['sort']):0
            );
        }
    
        usort($new_status_list, function($l,$r){
            return $l['sort']>$r['sort'];
        });
    
            $status_array = array();
            foreach ($new_status_list as $item){
                $status_array[$item['name']] = $item['txt'];
            }
             
            return $status_array;
    }
    
    public static function dupe_link($actions, $post){
        if ( !in_array($post->post_type, array('post','product','wrest_page')) ) {
            return $actions;
        }
    
        $scripts = '';
        if(!defined('wrest_sm_qrcode_scripts')){
            define('wrest_sm_qrcode_scripts', 1);
            ob_start();
            ?>
            	<div id="wrest-product-shar-dialog" style="display:none;">
               		<img alt="" src="" id="wrest-product-shar-dialog-qrcode" style="width:200px;height:200px;margin:auto;" title="预览"/>
        		</div>	
                <script type="text/javascript">
					(function($){
						if(!window.thickboxL10n){
							window.thickboxL10n = {"next":"\u4e0b\u4e00\u9875 >","prev":"< \u4e0a\u4e00\u9875","image":"\u56fe\u50cf","of":"\/","close":"\u5173\u95ed","noiframes":"\u8fd9\u4e2a\u529f\u80fd\u9700\u8981iframe\u7684\u652f\u6301\u3002\u60a8\u53ef\u80fd\u7981\u6b62\u4e86iframe\u7684\u663e\u793a\uff0c\u6216\u60a8\u7684\u6d4f\u89c8\u5668\u4e0d\u652f\u6301\u6b64\u529f\u80fd\u3002","loadingAnimation":"http:\/\/ranj.mabaodian.com\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
	        			}
						window.wrest_wc_product_share_qrcode =function(post_ID){
						    var data ={
						    	post_ID:post_ID
						    };

							$.ajax({
								url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_admin",'tab'=>'product_share_code'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:data,
								dataType:'json',
								beforeSend:function(){
									$('#wpcontent').loading();
								},
								complete:function(){
									$('#wpcontent').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert( e.errmsg );
										return;
									}
									
									$('#wrest-product-shar-dialog-qrcode').attr('src',e.data.qrcode);
									tb_show('小程序预览', '#TB_inline?inlineId=wrest-product-shar-dialog&height=250&width=250');
									jQuery('#TB_window').css({'height':'250px','width':'250px'});
								},
								error:function(e){
									console.error(e.responseText);
									alert('网络异常，请重试!' );
								}
							});
						}
					})(jQuery);
				</script>        
            <?php 
            $scripts = ob_get_clean();
        }
        
        $actions['wrest_share_code'] = $scripts.'<a href="javascript:void(0);" onclick="window.wrest_wc_product_share_qrcode('.$post->ID.')" title="小程序分享码"><img src="'.WREST_URL.'/assets/images/sm.png" style="width:22px;height:22px;"/></a>';
        
        return $actions;
    }
    public static function add_product_align_field(){
        global $post;
        $align = get_post_meta($post->ID,'__wrest_align__',true);
        woocommerce_wp_text_input(
            array(
                'id'                => '__wrest_align__',
                'value'             => $align,
                'label'             => '商品别名<span style="color:red;">NEW</span>',
                'type'              => 'text'
            )
        );
    }
    public static function add_product_sale_qty_field(){
        global $post;
        $sale_qty = get_post_meta($post->ID,'__wrest_sale_qty__',true);
        if(empty($sale_qty)&&$sale_qty!=='0'){
            $sale_qty = rand(20,200);
        }else{
            $sale_qty = absint($sale_qty);
        }
        
        wp_nonce_field( plugin_basename( __FILE__ ), '__wrest_sale_qty_hidden__' );
        woocommerce_wp_text_input(
            array(
                'id'                => '__wrest_sale_qty__',
                'value'             => $sale_qty,
                'label'             => '基础销量<span style="color:red;">NEW</span>',
                'desc_tip'          => true,
                'description'       => '商品销量基础值，显示销量在此基础上叠加实际销量',
                'type'              => 'number'
            )
        );

    }
    
    /**
     * @param integer $coupon_id
     * @param WC_Coupon $coupon
     */
    public static function woocommerce_coupon_options_save($coupon_id, $coupon ){
        // 首先，我们需要检查当前用户是否被授权做这个动作。
        if ( ! current_user_can( 'edit_post', $coupon_id ) ){
            return;
        }
        
        // 其次，我们需要检查，是否用户想改变这个值。
        if ( ! isset( $_POST['_wrest_public_hidden_'] ) || ! wp_verify_nonce( $_POST['_wrest_public_hidden_'], plugin_basename( __FILE__ ) ) ){
            return;
        }
        
    	update_post_meta($coupon_id, '_wrest_public_', isset( $_POST['_wrest_public_'])? wc_clean( $_POST['_wrest_public_'] ):'no');
    }
    
    /**
     * @param integer $coupon_id
     * @param WC_Coupon $coupon
     */
    public static function woocommerce_coupon_options($coupon_id, $coupon){
    	?>
    	<hr />
    	<?php
    	wp_nonce_field( plugin_basename( __FILE__ ), '_wrest_public_hidden_' );
    	$wrest_public =  get_post_meta($coupon->get_id(),'_wrest_public_',true);
    	woocommerce_wp_checkbox(
    			array(
    					'id'                => '_wrest_public_',
    					'type'				=>'checkbox',
    					'value'            => wc_bool_to_string( $wrest_public ),
    					'label'             => '开放优惠券<span style="color:red;">NEW</span>',
    					'description'       => '允许把优惠券显示在产品详情或其他页面，方便顾客领取。'
    			)
    	);
    }
    
    
    /**
     * @param int $term_id Term ID.
     * @param int $tt_id   Term taxonomy ID.
     */
    public function product_cat_save_tax_meta($term_id, $tt_id ){
        if ( ! current_user_can( 'edit_term',$term_id)  ){
            return;
        }
        
        if ( ! isset( $_POST['__wrest_enable_hidden__'] ) || ! wp_verify_nonce( $_POST['__wrest_enable_hidden__'], plugin_basename( __FILE__ ) ) ){
            return;
        }
        //刷新缓存
        WRest_Cache_Helper::clear('wrest::product::filter','cats');
        update_term_meta($term_id, '__wrest_disable__',  $_POST['__wrest_disable__']=='yes'?'yes':'no');
    }
    
    /**
     * @param WP_Taxonomy $taxonomy
     */
     public function product_cat_add_form_fields($taxonomy){
        $this->product_cat_edit_form_fields(null,$taxonomy);
    }
    
    /**
     * 
     * @param WP_Term $tag
     * @param WP_Taxonomy $taxonomy
     */
    public function product_cat_edit_form_fields($tag,$taxonomy){
        $enable = $tag?get_term_meta($tag->term_id,'__wrest_disable__',true):'no';
        wp_nonce_field( plugin_basename( __FILE__ ), '__wrest_enable_hidden__' );
        ?>
        <tr class="form-field term-description-wrap">
			<th scope="row"><label for="__wrest_disable__">小程序内不显示</label></th>
			<td><input name="__wrest_disable__" <?php echo $enable=='yes'?'checked':''?> id="__wrest_disable__" type="checkbox" value="yes" />
			<p class="description">在小程序内隐藏当前分类的显示</p></td>
		</tr>
        <?php 
    }
    
    public function meta_article_products(){
        global $post;
        $product_ids = get_post_meta($post->ID,'__wrest_post_products__',true);
        wp_nonce_field( plugin_basename( __FILE__ ), '__wrest_post_products_hidden__' );
        $api = WRest::instance()->get_product_api();
        $product_type = $api->post_type;
        ?>
        <div style="min-height:100px;">
            <select id="__wrest_post_products__" name="__wrest_post_products__[]" class="wrest-search" data-type="<?php echo $product_type;?>" data-val="<?php echo esc_attr($product_ids?json_encode($product_ids):'[]')?>" data-multiple="1" data-sortable="true" data-placeholder="产品ID或名称..." data-allow_clear="true">
                <?php
                if($product_ids&&is_array($product_ids)){
                    foreach($product_ids as $id){
                        $obj = $api->get_product($id)->to_simple(new WRest_Version());
                        if(!$obj){continue;}
                        ?>
                        <option selected value="<?php echo $obj['id']?>">
                            <?php echo $obj['title'];?>
                        </option>
                        <?php
                    }
                }
                ?>
            </select>

        </div>

        <script type="text/javascript">
            (function($){
                $(document).bind('wrest-on-select2-inited',function(){
                	$('#__wrest_post_products__').val(<?php echo $product_ids&&is_array($product_ids)?json_encode($product_ids):'[]';?>).trigger("change");
                });
            })(jQuery);
        </script>
        <?php
    }

    public function save_meta_product_sale_qty($post_ID){
        // 首先，我们需要检查当前用户是否被授权做这个动作。
        if ( ! current_user_can( 'edit_post', $post_ID ) ){
            return;
        }
        
        // 其次，我们需要检查，是否用户想改变这个值。
        if ( ! isset( $_POST['__wrest_sale_qty_hidden__'] ) || ! wp_verify_nonce( $_POST['__wrest_sale_qty_hidden__'], plugin_basename( __FILE__ ) ) ){
            return;
        }  
        
        $old_sale_qty = get_post_meta($post_ID,'__wrest_sale_qty__',true);
        $total_sales = get_post_meta($post_ID,'total_sales',true);
        $new_sale_qty = isset($_POST['__wrest_sale_qty__'])?absint($_POST['__wrest_sale_qty__']):rand(20,200);
        
        update_post_meta($post_ID, 'total_sales',(($total_sales-$old_sale_qty)<=0?0:($total_sales-$old_sale_qty))+$new_sale_qty );
        update_post_meta($post_ID, '__wrest_sale_qty__',$new_sale_qty );
        update_post_meta($post_ID, '__wrest_align__' , sanitize_text_field($_POST['__wrest_align__']));
    }
    
    public function save_meta_article_products($post_ID){
        // 首先，我们需要检查当前用户是否被授权做这个动作。
        if ( ! current_user_can( 'edit_post', $post_ID ) ){
            return;
        }

        // 其次，我们需要检查，是否用户想改变这个值。
        if ( ! isset( $_POST['__wrest_post_products_hidden__'] ) || ! wp_verify_nonce( $_POST['__wrest_post_products_hidden__'], plugin_basename( __FILE__ ) ) ){
            return;
        }
        
        $product_ids =  isset($_POST['__wrest_post_products__'])?$_POST['__wrest_post_products__']:array();
        if(!$product_ids||!is_array($product_ids)){
            $product_ids=array();
        }

        $new_vals=array();
        $api = WRest::instance()->get_product_api();
        foreach ($product_ids as $pid){
            if($api->get_product(absint($pid))->is_load()){
                $new_vals[]=absint($pid);
            }
        }

        update_post_meta($post_ID, '__wrest_post_products__', $new_vals);

    }


    public static function edit_comment_columns($columns){
        $columns['wrest_comment_pics'] = '图片';
        $columns['wrest_comment_rating'] = '星评';
        return $columns;
    }
    
    public static function manage_comments_custom_column($column_name, $comment_ID){
        switch ($column_name){
            case 'wrest_comment_pics':
                if(!defined('xunhuweb_js_lightbox')){
                    define('xunhuweb_js_lightbox', true);
                    ?>
                        <link href="<?php echo WREST_URL?>/assets/lightbox/css/lightbox.css" rel="stylesheet" />
                        <script src="<?php echo WREST_URL?>/assets/lightbox/js/lightbox.min.js"></script>	
                        <?php 
                    }
                    $imgs = WRest_Comment::get_comment_img_list($comment_ID);
                    if(!$imgs){break;}
                    ?>
                    <div id="comment-<?php echo $comment_ID?>-imgs" style="display:flex;flex-direction:row;overflow-x:auto;overflow-y:hidden;" >
                    	<?php 
                    	    foreach ($imgs as $img_id=>$imgurl){
                    	       ?>
                    	       <div id="wrest-comment-img-<?php echo $img_id?>" style="position:relative;width:80px;height:80px;">
                            		<a href="<?php echo $imgurl?>" data-lightbox="wrest-comment-img-<?php echo $comment_ID;?>"><img src="<?php echo $imgurl?>" style="width:80px;height:80px;"/></a>
                            		<img onclick="window.wrestCommentView.removeImg(<?php echo $img_id?>)" style="position:absolute;top:0px;right:0px;width:20px;height:20px;cursor:pointer;" src="<?php echo WREST_URL?>/assets/images/icon/delete.png" />
                            	</div>
                    	       <?php  
                    	    }
                    	?>
                    </div>
                    <?php
                    if(!defined('wrest_comment_view')){
                        define('wrest_comment_view', 1);
                        ?>
                        <script type="text/javascript">
                            (function($){
    							window.wrestCommentView={
    								removeImg:function(imgid){
    									if(!confirm('图片移除后无法恢复，确认执行？')){
    										return;
    									}
    		                            var data={
    	    		                            comment_ID:<?php echo $comment_ID;?>,
    	    		                            imgid:imgid
    		                            };
    									$.ajax({
    										url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_admin",'tab'=>'remove_comment_img'),true,true)?>',
    										type:'post',
    										timeout:60*1000,
    										async:true,
    										cache:false,
    										data:data,
    										dataType:'json',
    										beforeSend:function(){
    											$('#comment-<?php echo $comment_ID?>-imgs').loading();
    										},
    										complete:function(){
    											$('#comment-<?php echo $comment_ID?>-imgs').loading('hide');
    										},
    										success:function(e){
    											if(e.errcode!=0){
    												alert( e.errmsg );
    												return;
    											}

    											$('#wrest-comment-img-'+imgid).remove();
    										},
    										error:function(e){
    											console.error(e.responseText);
    											alert('网络异常，请重试!' );
    										}
    									});
    								}
    							};
                             })(jQuery);
                        </script>
                        <?php 
                    }
                    break;
                case 'wrest_comment_rating':
                    $rating = WRest_Comment::get_comment_rating($comment_ID);
                    if(!$rating){break;}
                    ?>
                    <div style="display:flex;flex-direction:row;" >
                    <?php for($index=0;$index<$rating;$index++){
                        ?><img src="<?php echo WREST_URL?>/assets/images/icon/order/star-ed3f14.png" style="width:20px;height:20px;" /><?php 
                    }?>
                    </div>
                    <?php 
                    break;
            }
        }
        
    
    public function save_meta_product_video($post_ID){
    	// 首先，我们需要检查当前用户是否被授权做这个动作。
    	if ( ! current_user_can( 'edit_post', $post_ID ) ){
    		return;
    	}
    	
    	// 其次，我们需要检查，是否用户想改变这个值。
    	if ( ! isset( $_POST['__wrest_preview_video_hidden__'] ) || ! wp_verify_nonce( $_POST['__wrest_preview_video_hidden__'], plugin_basename( __FILE__ ) ) ){
    		return;
    	}
    	update_post_meta($post_ID, '__wrest_preview_video__', sanitize_text_field( $_POST['__wrest_preview_video__'] ));
    	
    }
    
    public function meta_product_video(){
    	global $post;
    	$product_video_url = get_post_meta($post->ID,'__wrest_preview_video__',true);
    	wp_nonce_field( plugin_basename( __FILE__ ), '__wrest_preview_video_hidden__' );
    	?>
    		<input value="<?php echo $product_video_url;?>" type="hidden" name="__wrest_preview_video__" id="wrest-preview-video"/>
    		
    		<a href="javascript:void(0);" id="wrest-set-product-video">设置产品视频(MP4)</a>
    		
    		<div id="wrest-product-video-edit" >
    			<video id="wrest-product-video-view" src="" controls="controls" style="width:300px;height:150px;">
					您的浏览器不支持 video 标签。
				</video>
				<br/>
				<div><a href="javascript:void(0);" id="wrest-product-video-remove" style="margin-left:5px;">删除产品视频</a></div>
    		</div>
    		
    		<p>小程序-产品详情：点击第一张预览图时，会自动播放视频</p>
    		<script type="text/javascript">
    		(function($){
    			
        		var wrestPreviewVideoInit=function(){
					var url = $('#wrest-preview-video').val();
					if(url){
						$('#wrest-product-video-view').attr('src',url);
						$('#wrest-product-video-edit').css('display','inline');
						$('#wrest-set-product-video').css('display','none');
						return;
					}
					$('#wrest-product-video-view').attr('src','');
					$('#wrest-product-video-edit').css('display','none');
					$('#wrest-set-product-video').css('display','inline');
            	};
            	wrestPreviewVideoInit();
				$('#wrest-set-product-video').click(function() {  
					var send_attachment_bkp = wp.media.editor.send.attachment;
				    wp.media.editor.send.attachment = function(props, attachment) {
					    if(attachment.mime=="video/mp4"){
						    $('#wrest-preview-video').val(attachment.url);
						    wrestPreviewVideoInit();
						    wp.media.editor.send.attachment = send_attachment_bkp;
						    return;
					    }
				       alert('请选择MP4格式的视频文件！');
				    }
				    wp.media.editor.open();
				    return false;    
			    });   
			    $('#wrest-product-video-remove').click(function(){
			    	$('#wrest-preview-video').val('');
			    	wrestPreviewVideoInit();
				});
			})(jQuery);
			</script>
    	<?php 
    }
    
    public function get_themes($template_type){
        $themes =  apply_filters('wrest_themes', array(
           'default'=> require_once WREST_DIR.'/themes/theme-default.php',
           'wph-jrtj'=> require_once WREST_DIR.'/themes/theme-wph-jrtj.php',
           'wph-mz'=> require_once WREST_DIR.'/themes/theme-wph-mz.php',
           'wph-my'=> require_once WREST_DIR.'/themes/theme-wph-my.php',
           'wph-jd'=> require_once WREST_DIR.'/themes/theme-wph-jd.php',
           'wph-jj'=> require_once WREST_DIR.'/themes/theme-wph-jj.php',
           //'yz-my' => require_once WREST_DIR.'/themes/theme-yz-my.php',
        ));
        $results = array();
        foreach ($themes as $key=>$theme){
            if(isset($theme[$template_type])){
                $results[$key]=$theme[$template_type];
            }
        }
        return $results;
    }
    
    public function do_ajax(){
        if ( ! current_user_can( 'manage_options') ){
    		return;
    	}
	    $action ='wrest_admin';
	    $request=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
	        'hash'=>null
        ), stripslashes_deep($_REQUEST));
	    do_action('wrest_admin_ajax_init');
	    if($request['tab']=='templates'){
	        $request['template_type'] = $_REQUEST['template_type'];
	    }
	    
	    if($request['tab']=='add_template'||$request['tab']=='load_template'){
	        $request['id'] = $_REQUEST['id'];
	    }
	    
	    if($request['tab']=='load_products'||$request['tab']=='load_posts'){
	    	$request['version'] = $_REQUEST['version'];
	    }
	    if($request['tab']=='save_theme'){
	        $request['version_id'] = absint($_REQUEST['version_id']);
	    }
	    
	    if($request['tab']=='export'){
	        $request['version_id'] = absint($_REQUEST['version_id']);
	    }
	    if($request['tab']=='create_post_item'){
	        $request['post_type'] = sanitize_text_field($_REQUEST['post_type']);
	    }
	    if(!WRest::instance()->WP->ajax_validate($request,$request['hash'],true)){
	        echo (WRest_Error::err_code(701)->to_json());
	        exit;
	    }
        
	    switch ($request['tab']){
	        case 'product_share_code':
	            $post_ID = isset($_REQUEST['post_ID'])?absint($_REQUEST['post_ID']):0;
	            $post = get_post($post_ID);
	            if(!$post){
	                WRest_Error::error_custom("页面信息加载异常！")->output();
	                exit;
	            }
	            
	            $api = WRest_Settings_Default_Basic_Default::instance();
	            $appid = $api->get_option('appid');
	            $appsecret = $api->get_option('appsecret');
	            require_once WREST_DIR.'/includes/class-xh-wechat-api.php';
	            $wechatApi = new WRest_Wechat_Api($appid,$appsecret);
	            
	            $page = '';
	            switch ($post->post_type){
	                case 'post':
	                    $page='/pages/article/detail/index';
	                    break;
	                case 'product':
	                    $page='/package_a/pages/product/detail/index';
	                    break;
	                case 'wrest_page':
	                    $page='/pages/page/index';
	                    break;
	                default:
	                    WRest_Error::error_custom("页面信息加载异常！")->output();
	                    exit;
	            }
	            
	            $qrcode = $wechatApi->get_smallprogram_qrcode($page,array(
	                'id'=>$post_ID
	            ));
	            if($qrcode instanceof WRest_Error){
	                $qrcode->output();exit;
	            }
	            WRest_Error::success(array(
	                'qrcode'=>$qrcode
	            ))->output();
	            exit;
	        case 'import':
	            if(!isset($_FILES["file"])||!isset($_REQUEST['version_id'])){exit;}
	            $version = new WRest_Version(absint($_REQUEST['version_id']));
	            if(!$version->is_load()){
	                WRest_Error::error_custom("版本信息加载异常！")->outpu();
	                exit;
	            }
	            
	            if (isset($_FILES ["file"] ["error"])&&$_FILES ["file"] ["error"]) {
	                echo  WRest_Error::error_custom( $_FILES ["file"] ["error"])->to_json();
	                exit;
	            }
	           
	            $config = @file_get_contents($_FILES["file"]["tmp_name"]);
	            @unlink($_FILES["file"]["tmp_name"]);
	            if(empty($config)){
	                echo  WRest_Error::error_custom("模板文件不能为空！")->to_json();
	                exit;
	            }
	            
	            $config = json_decode($config,true);
	            if(!$config||!is_array($config)){
	                echo  WRest_Error::error_custom("模板文件无法识别！")->to_json();
	                exit;
	            }
	            
	            echo $version->update(array(
	                'content'=>json_encode($config)
	            ))->to_json();
	            exit;
	            
	        case 'export':
	            $version = new WRest_Version($request['version_id']);
	            if(!$version->is_load()){
	                wp_die("版本信息加载异常！");
	            }
	            
	            $now = date_i18n('Ymdhis');
              
                header("Content-Type: application/octet-stream"); 
	            header ( "Content-Disposition: attachment; filename=theme-{$version->get_version_code()}-{$now}.json" );
	           
	            echo $version->content;
	            exit;
	                
	        case 'save_theme':
	            $version = new WRest_Version($request['version_id']);
	            if(!$version->is_load()){
	                echo (WRest_Error::error_custom("版本信息加载异常！")->to_json());
	                exit;
	            }
	            
	            $title = mb_strimwidth(stripslashes(sanitize_text_field($_REQUEST['title'])), 0, 128);
	            $content = json_decode(stripslashes_deep(sanitize_text_field($_REQUEST['content'])),true);
	            if(!$content||!is_array($content)){
	                echo (WRest_Error::error_custom("请求数据异常！")->to_json());
	                exit;
	            }
	            
	            if(empty($title)){
	                echo (WRest_Error::error_custom("主题标题不能为空！")->to_json());
	                exit;
	            }

	            if(isset($_REQUEST['tid'])){
    	            $request['tid'] = sanitize_text_field($_REQUEST['tid']);
    	            if($request['tid']){
    	                $theme = new WRest_Theme($request['tid']);
    	                if(!$theme->is_load()){
    	                    echo (WRest_Error::error_custom("主题信息加载异常！")->to_json());
    	                    exit;
    	                }
    	                
    	                echo $theme->update(array(
    	                    'title'=>$title,
    	                    'content'=>maybe_serialize($content)
    	                ))->to_json();
    	                exit;
    	            }
	            }
	            $theme = new WRest_Theme();
	            $theme->content = maybe_serialize($content);
	            $theme->title = $title;
	            $theme->tid = date_i18n('YmdHis');
	            $theme->is_system = 0;
	            echo $theme->insert()->to_json();
	            exit;
	    	case 'shop_publish':
	    		$request = shortcode_atts(array(
	    		     'id'=>null
	    		), stripslashes_deep($_REQUEST));
	    		$id = absint($request['id']);
	    		$wrest_version = new WRest_Version($id);
	    		if(!$wrest_version->is_load()){
	    			echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	    			exit;
	    		}
	    	
	    		require_once 'menus/class-wrest-menu-store-layout.php';
	    		require_once 'menus/class-wrest-menu-store-index.php';
	    		require_once 'menus/class-wrest-menu-store-login.php';
	    		
	    		require_once WREST_DIR.'/includes/miniprogram/abstract.php';
	    		require_once WREST_DIR.'/includes/miniprogram/abstract-tpl.php';
	    		require_once WREST_DIR.'/includes/miniprogram/app.json.php';
	    		require_once WREST_DIR.'/includes/miniprogram/app.js.php';
	    		require_once WREST_DIR.'/includes/miniprogram/theme.wxss.php';
	    		require_once WREST_DIR.'/includes/miniprogram/project.config.json.php';
	    		require_once WREST_DIR.'/includes/miniprogram/bg.wxml.php';
	    		require_once WREST_DIR.'/includes/miniprogram/footer.wxml.php';
	    		require_once WREST_DIR.'/includes/miniprogram/body.wxml.php';
	    		require_once WREST_DIR.'/includes/miniprogram/pages/page.wxml.php';
	    		require_once WREST_DIR.'/includes/miniprogram/pages/page.json.php';
	    		require_once WREST_DIR.'/includes/miniprogram/pages/page.wxss.php';
	    		
	    		require_once WREST_DIR.'/includes/miniprogram/pages/login/index.json.php';
	    		require_once WREST_DIR.'/includes/miniprogram/pages/login/index.wxml.php';
	    		require_once WREST_DIR.'/includes/miniprogram/hooks/package_a/checkout/address.php';
	    		require_once WREST_DIR.'/includes/miniprogram/hooks/package_a/order/address.php';
	    		
	    		require_once WREST_DIR.'/includes/miniprogram/hooks/package_a/order/list-item-btns.php';
	    		require_once WREST_DIR.'/includes/miniprogram/hooks/package_a/order/list-item-columns.php';
	    		
	    		require_once WREST_DIR.'/includes/miniprogram/hooks/package_a/product/add-to-cart-left.php';
	    		require_once WREST_DIR.'/includes/miniprogram/hooks/package_a/product/add-to-cart-right.php';
	    		try{
	    		    $configs = array(
	    		        new WRest_Mini_App_Json(),
    		    		new WRest_Mini_App_Js(),
	    		        new WRest_Mini_App_Theme_WXSS(),
	    		        new WRest_Mini_Project_Config_Json(),
	    		        new WRest_Mini_TPL_Bg_WXML(),
	    		        new WRest_Mini_TPL_Footer_WXML(),
	    		        new WRest_Mini_TPL_Body_WXML(),
	    		        
	    		        new WRest_Mini_Hooks_Package_A_Checkout_Address(),
	    		        new WRest_Mini_Hooks_Package_A_Order_List_Item_Btns(),
	    		        new WRest_Mini_Hooks_Package_A_Order_List_Item_Columns(),
	    		    	new WRest_Mini_Hooks_Package_A_Order_Address(),
	    		        new WRest_Mini_Hooks_Package_A_Product_Add_To_Cart_Left(),
	    		        new WRest_Mini_Hooks_Package_A_Product_Add_To_Cart_Right()
	    		    );
	    		    
	    		    $configs  = apply_filters('wrest_tpls', $configs);
	    		    
	    		    $index = WRest_Menu_Store_Index::instance();
	    		    $configs[]= new WRest_Mini_Pages_Page_WXML($index,"pages/index/index.wxml",array());
	    		    $configs[]= new WRest_Mini_Pages_Page_Json($index,"pages/index/index.json",array());
	    		    
	    		    //此处移到templates下
	    		    $configs[]= new WRest_Mini_Pages_Page_WXML($index,"templates/page/index.wxml",array());
	    		    $configs[]= new WRest_Mini_Pages_Page_Json($index,"pages/page/index.json",array());
	    		    
	    		    $configs[]= new WRest_Mini_Pages_Login_WXML();
	    		    $configs[]= new WRest_Mini_Pages_Login_Json();
	    		    
	    		    $cat = WRest_Menu_Store_Cat::instance();
	    		    $configs[]= new WRest_Mini_Pages_Page_WXML($cat,"pages/category/index.wxml",array());
	    		    $configs[]= new WRest_Mini_Pages_Page_Json($cat,"pages/category/index.json",array());
	    		    
	    		    $cat1 = WRest_Menu_Store_CatDetail::instance();
	    		    $configs[]= new WRest_Mini_Pages_Page_WXML($cat1,"templates/cat/index.wxml",array());
	    		    $configs[]= new WRest_Mini_Pages_Page_Json($cat1,"package_a/pages/category/index.json",array());
	    		    
	    		    $account = WRest_Menu_Store_Account::instance();
	    		    $configs[]= new WRest_Mini_Pages_Page_WXML($account,"pages/account/index.wxml",array());
	    		    $configs[]= new WRest_Mini_Pages_Page_Json($account,"pages/account/index.json",array());

	    		    require_once WREST_DIR.'/includes/miniprogram/plugin.php';
	    		    //清空plugins目录
	    		    if(!WRest::instance()->WP->removeDir(WREST_DIR.'/output/v2/plugins')){
	    		        throw new Exception("加载插件失败：插件目录删除失败(/output/v2/plugins)");
	    		    }
	    		    
	    		    
	    			foreach ($configs as $item){
	    			    $item->save($wrest_version);
	    			}
	    			
	    			$plugins = apply_filters('wrest_register_extends', array());
	    			foreach ($plugins as $plugin){
	    			    $plugin->save($wrest_version);
	    			}
	    			
	    		}catch (Exception $e){
	    			echo WRest_Error::error_custom($e->getMessage())->to_json();
	    			exit;
	    		}
	    		

	    		$file = $wrest_version->get_download_file();
	    		if(@file_exists($file)){
	    			if(!@unlink($file)){
	    				echo (WRest_Error::error_custom("历史版本文件删除失败！")->to_json());
	    				exit;
	    			}
	    		}
	    		
	    		try{
	    			require_once WREST_DIR."/includes/phpzip/Zip.php";
	    			$zip = new Zip();
	    			$zip->zip_start($file);
	    			$zip->basename(WREST_DIR.'/output/v2');
	    			$zip->zip_add(WREST_DIR.'/output/v2');
	    			$zip->zip_end();
	    		}
	    		catch(Exception $e){
	    			echo (WRest_Error::error_custom("文件打包时出现异常：".$e->getMessage())->to_json());
	    			exit;
	    		}
	    		
	    		$wrest_version->update(array(
	    		    'status'=>'publish'
	    		));
	    		
	    		echo (WRest_Error::success($wrest_version->get_download_url())->to_json());
	    		exit;
	    	case 'add_version':
	    	    $version = WRest_Version::get_newest_version();
	    	    
	    		$new_wrest_version = new WRest_Version();
	    		$new_wrest_version->content = $version?$version->content:null;
	    		$new_wrest_version->status ='draft';
	    		$new_wrest_version->created_time = current_time( 'timestamp');
	    		
	    		$error = $new_wrest_version->insert();
	    		if(!WRest_Error::is_valid($error)){
	    			echo $error->to_json();
	    			exit;
	    		}
	    		
	    		echo WRest_Error::success()->to_json();
	    		exit;
	    	case 'shop_version_remove':
	    		$request = shortcode_atts(array(
	    			'id'=>null
	    		), stripslashes_deep($_REQUEST));
	    		$id = absint($request['id']);
	    		$wrest_version = new WRest_Version($id);
	    		if(!$wrest_version->is_load()){
	    			echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	    			exit;
	    		}
	    		
	    		echo $wrest_version->remove()->to_json();
	    		exit;
	        case 'rebuild_shop_file':
	            $request = shortcode_atts(array(
	                'id'=>null
	            ), stripslashes_deep($_REQUEST));
	            $id = absint($request['id']);
	            $wrest_version = new WRest_Version($id);
	            if(!$wrest_version->is_load()){
	                echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	                exit;
	            }
	            
	            $file = $wrest_version->get_download_file();
	            if(@file_exists($file)){
	            	if(!@unlink($file)){
	            		echo (WRest_Error::error_custom("历史版本文件删除失败！")->to_json());
	            		exit;
	            	}
	            }
	            
	            try{
		            require_once WREST_DIR."/includes/phpzip/Zip.php";
		            $zip = new Zip();
		            $zip->zip_start($file);
		            $zip->zip_add(WREST_DIR.'/output/v2/');
		            $zip->zip_end();
	            	
	            }
	            catch(Exception $e){
	               echo (WRest_Error::error_custom("文件打包时出现异常：".$e->getMessage())->to_json());
	               exit;
	            }
	            
	            WRest_Error::success($wrest_version->get_download_url())->output();
	            exit;
	            
	        case 'remove_shop_file':
	            $request = shortcode_atts(array(
	                'id'=>null
	            ), stripslashes_deep($_REQUEST));
	            $id = absint($request['id']);
	            $wrest_version = new WRest_Version($id);
	            if(!$wrest_version->is_load()){
	                WRest_Error::error_custom("请求数据错误！")->output();
	                exit;
	            }
	          
	            $file = $wrest_version->get_download_file();
	            if(file_exists($file)){
	                if(!@unlink($file)){
	                    WRest_Error::error_custom("文件删除失败(可能没有足够权限或文件不存在)，请手动删除！")->output();
	                    exit;
	                }
	            }
	            
	            WRest_Error::success()->output();
	            exit;
	            
	        case 'templates':
	            WRest_Error::success(array(
	               'items'=>$this->get_themes($request['template_type'])
	            ))->output();
	            exit;
	        case 'load_posts':
	            $config = isset($_REQUEST['config'])&&$_REQUEST['config']?json_decode(stripslashes($_REQUEST['config']),true):array();
	            if(!$config||!is_array($config)){$config = array();}
	             
	            $request = shortcode_atts(array(
	                'version'=>null
	            ), stripslashes_deep($_REQUEST));
	             
	            $version = absint($request['version']);
	            $version_obj = new WRest_Version($version);
	            if(!$version_obj){
	                echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	                exit;
	            }
	            
	            //演示数据，不要加载那么多
                 if(!isset($config['posts_per_page'])||absint($config['posts_per_page'])>24){
                     $config['posts_per_page'] = 24;
                 }
                 
	            $items = WRest_Posts::get_posts($version_obj,$config);
	           
	            echo (WRest_Error::success($items)->to_json());
	            exit;
	        case 'load_products':
	            $config = isset($_REQUEST['config'])&&$_REQUEST['config']?json_decode(stripslashes($_REQUEST['config']),true):array();
	            if(!$config||!is_array($config)){$config = array();}
	            
	            $request = shortcode_atts(array(
	            	'version'=>null
	            ), stripslashes_deep($_REQUEST));
	            
	            $version = absint($request['version']);
	            $version_obj = new WRest_Version($version);
	            if(!$version_obj){
	            	echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	            	exit;
	            }
	            if(!isset($config['limit'])||absint($config['limit'])>24){
	                $config['limit'] = 24;
	            }
	            $api = WRest::instance()->get_product_api();
	            $query = $api->get_product_list($version_obj,$config);
	            $products = $query?$query['items']:array();
	            $items = array();
	            if($products&&count($products)>0){
	                foreach ($products as $product){
	                    $items[]=array(
	                    	'image'=>$product['image'],
	                        'name'=>$product['title'],
	                        'price_html'=>$product['price_html1']
	                    );
	                }
	            }
	            
	            echo (WRest_Error::success($items)->to_json());
	            exit;
	        case 'add_template':
	            $page = null;
	            if(is_numeric($request['id'])){
	                $post = get_post($request['id']);
	                if(!$post||$post->post_type!='wrest_page'){
	                    WRest_Error::error_custom("请求数据错误！")->output();
	                    exit;
	                }
	                require_once WREST_DIR.'/includes/shop/class-wrest-page-api.php';
	                $page = new WRest_Page_Content($post);
	            }else{
	                $page = WRest_Helper_Array::first_or_default(WRest_Menu_Shoppage_Settings::instance()->menus(),function($m,$id){
	                    return $m->id==$id;
	                },$request['id']);
	            }
                if(!$page){
                    echo (WRest_Error::error_custom("请求数据错误！")->to_json());
                    exit;
                }
	            
                $request = shortcode_atts(array(
                    'template_id'=>null,
                    'version'=>null
                ), stripslashes_deep($_REQUEST));
                
                $template_id = $request['template_id'];
                $version = absint($request['version']);
                $version_obj = new WRest_Version($version);
                if(!$version_obj){
                    WRest_Error::error_custom("请求数据错误！")->output();
                    exit;
                }
                
	            $class = $page->get_template_class($template_id);
	            if(!$class){
	                WRest_Error::error_custom("请求数据错误！")->output();
	                exit;
	            }
	            
	            ob_start();
	            $obj = new $class($version_obj,time(),array());
	            $obj->render($page);
	            WRest_Error::success(array(
	                'html'=>ob_get_clean(),
	                'group'=>$obj->group
	            ))->output();
	            exit;
	        case 'create_order_status_item':
	        	$html = WRest::instance()->WP->requires(WREST_DIR, 'wechat/order-status.php',array(
		        	'request'=>array(
		        	
	        		),
	        		'context'=>WRest_Helper::generate_unique_id()
	        	));
	        	
	        	WRest_Error::success($html)->output();
	        	exit;
	        case 'create_post_item':
	            $html = WRest::instance()->WP->requires(WREST_DIR, 'wechat/post-edit.php',array(
	                'request'=>array(
	                   'post_type'=>$request['post_type'],
	                   'label'=>isset($_REQUEST['label'])?sanitize_text_field($_REQUEST['label']):''
	                ),
	                'context'=>WRest_Helper::generate_unique_id()
	            ));
	             
	            WRest_Error::success($html)->output();
	            exit;
	        case 'create_navbar_menu':
	            $html = WRest::instance()->WP->requires(WREST_DIR, 'wechat/menu-edit.php',array(
	                    'request'=>array(),
	                    'context'=>WRest_Helper::generate_unique_id()
	            ));
	            
	            WRest_Error::success($html)->output();
	            exit;
	        case 'load_template':
	            $page = null;
	            if(is_numeric($request['id'])){
	                $post = get_post($request['id']);
	                if(!$post||$post->post_type!='wrest_page'){
	                    WRest_Error::error_custom("请求数据错误！")->output();
	                    exit;
	                }
	                require_once WREST_DIR.'/includes/shop/class-wrest-page-api.php';
	                $page = new WRest_Page_Content($post);
	            }else{
	                $page = WRest_Helper_Array::first_or_default(WRest_Menu_Shoppage_Settings::instance()->menus(),function($m,$id){
	                    return $m->id==$id;
	                },$request['id']);
	            }
	            
                if(!$page){
                    WRest_Error::error_custom("请求数据错误！")->output();
                    exit;
                }
                
                $request = shortcode_atts(array(
                    'version'=>null,
                    'enable_edit'=>'no'
                ), stripslashes_deep($_REQUEST));
                
                $page->enable_edit ='yes'==$request['enable_edit'];
             
                ob_start();
                $page->app_view($request['version']);
                $html = ob_get_clean();
                
                WRest_Error::success($html)->output();
                exit;
	        case 'save_template':
	            $request = shortcode_atts(array(
	               'key'=>null,
	               'fields'=>null,
	               'version'=>null,
	               'id'=>null
	            ), stripslashes_deep($_REQUEST));
	            
	           
	            $fields = json_decode($request['fields'],true);
	            if(!$fields||!is_array($fields)){
	                echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	                exit;
	            }
	           
	            if(!in_array($request['key'], array('load_config','publish'))){
	                echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	                exit;
	            }
	            
	            $page = null;
	            if(is_numeric($request['id'])){
	                $post = get_post($request['id']);
	                if(!$post||$post->post_type!='wrest_page'){
	                    WRest_Error::error_custom("请求数据错误！")->output();
	                    exit;
	                }
	                require_once WREST_DIR.'/includes/shop/class-wrest-page-api.php';
	                $page = new WRest_Page_Content($post);
	            }else{
	                $page = WRest_Helper_Array::first_or_default(WRest_Menu_Shoppage_Settings::instance()->menus(),function($m,$id){
	                    return $m->id==$id;
	                },$request['id']);
	            }
	               
	            if(!$page){
	                echo (WRest_Error::error_custom("请求数据错误！")->to_json());
	                exit;
	            }
	            
	            $error = $page->save_config($request['version'],$fields);
	            if(!WRest_Error::is_valid($error)){
	                echo $error->to_json();
	                exit;
	            }
	            
	            switch ($request['key']){
                    case 'load_config':
                    	echo WRest_Error::success(WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'load_config.js'),true,true))->to_json();
                    	exit;
                    case 'publish':
                        echo WRest_Error::success()->to_json();
	                    exit;
	            }
	           break;
	        case 'remove_comment_img':
	            $request = shortcode_atts(array(
	               'comment_ID'=>null,
	               'imgid'=>null
	            ), stripslashes_deep($_REQUEST));
	            
	            $comment_id = absint($request['comment_ID']);
	           $comment = get_comment($comment_id);
	           $imgid = absint($request['imgid']);
	           if(!$comment){
	               echo WRest_Error::err_code(404)->to_json();
	               exit;
	           }
	           
	           $imgs = get_comment_meta($comment->comment_ID, 'wrest_imgs', true);
	           if(!$imgs||!is_array($imgs)){
	               $imgs = array();
	           }
	           
	           $new_imgs = array();
	           foreach ($imgs as $id){
	              if($id!=$imgid) {
	                  $new_imgs[]=$id;
	              }
	           }
	           
	           update_comment_meta($comment->comment_ID, 'wrest_imgs',$new_imgs);
	           echo WRest_Error::success()->to_json();
	           exit;
           
	    }
    }
	
    /**
     * Reset default wp menu display
     * 
     * @since  1.0.0
     */
    public function admin_head(){
        global $submenu;
    
        if(isset( $submenu[self::menu_tag] ) 
           &&isset($submenu[self::menu_tag][0])
           &&isset($submenu[self::menu_tag][0][2])
           &&$submenu[self::menu_tag][0][2]==self::menu_tag){
            
            unset( $submenu[self::menu_tag][0] );
        }
    }
    
    /**
     * 获取注册的菜单
     * @return []Abstract_WRest_Settings_Page
     * @since 1.0.0
     */
    public function get_admin_pages(){
        return apply_filters('wrest_admin_pages', array(
           10=> WRest_Page_Default::instance(),
           50=> WRest_Page_Shop_Push::instance(),
           100=> WRest_Page_Add_Ons::instance()
        ));
    }
  
    
    /**
     * @return NULL|Abstract_WRest_Settings_Page
     * @since 1.0.0
     */
    public function get_current_page(){
        global $pagenow;
        if($pagenow!='admin.php'){
            return null;
        }
    
        $page_id = isset($_GET['page'])?$_GET['page']:null;
        return WRest_Helper_Array::first_or_default($this->get_admin_pages(),function($m,$pid){
            return $m->get_page_id()==$pid;
        },$page_id);
    }
    
    /**
     * @return NULL|Abstract_WRest_Settings_Menu
     * @since 1.0.0
     */
    public function get_current_menu(){
        $current_page = $this->get_current_page();
        if(!$current_page){
            return null;
        }
       
        return $current_page->get_current_menu();
    }
    
    /**
     * 获取当前设置地址
     * @since 1.0.0
     * @return string 
     */
    public function get_current_admin_url($params = array()){
        $page = $this->get_current_page();
        $menu = $this->get_current_menu();
        $submenu = $this->get_current_submenu();
        
        $query="admin.php";
        
        if($page){
            $query.="?page={$page->get_page_id()}";
            if($menu){
                $query .="&section={$menu->id}";
            }
            
            if($submenu){
                $query .="&sub={$submenu->id}";
            }
        }
        
        if(count($params)>0){
            $query.="&".http_build_query($params);
        }
        return admin_url($query);
    }
    
    /**
     * 
     * @return NULL|Abstract_WRest_Settings
     * @since 1.0.0
     */
    public function get_current_submenu(){
        $current_menu = $this->get_current_menu();
        if(!$current_menu){
            return null;
        }
       
        return $current_menu->get_submenu();
    }
    
    /**
     * Wp menus
     * @since  1.0.0
     */
    public function admin_menu(){
        if ( ! current_user_can( 'manage_options') ){
            return;
        }
        
        $menu_title = apply_filters('wrest_admin_menu_title','小程序');
        global $current_user;
        $pages = $this->get_admin_pages();
        ksort($pages);
        reset($pages);
        add_menu_page( $menu_title, $menu_title, 'read', self::menu_tag, null, null, '55.5' );
        foreach ($pages as $page){
            if(!$page||!$page instanceof Abstract_WRest_Settings_Page){
                continue;
            }
            
            $submenu = $page->menus();
            
            if( !$submenu||count($submenu)==0){continue;}
            add_submenu_page(
                self::menu_tag,
                $page->title,
                $page->title,
                'read',
                $page->get_page_id(),
                array($page,'render'));
        }     
    }
}