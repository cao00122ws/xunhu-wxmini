<?php
class WRest_Meta_Box_Product_Images{
	/**
	 * Output the metabox.
	 *
	 * @param WP_Post $post
	 */
	public static function output( $post ) {
		wp_nonce_field( plugin_basename( __FILE__ ), '__wrest_post_content_hidden__' );
		?>
		<style type="text/css">
			#wrest-product-content .inside {
			    margin: 0;
			    padding: 0;
			}
			
			#wrest-product-content .inside .add___wrest_post_content__s {
			    padding: 0 12px 12px;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container {
			    padding: 0 0 0 9px;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul {
			    margin: 0;
			    padding: 0;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul::after,
			#wrest-product-content .inside #__wrest_post_content___container ul::before {
			    content: ' ';
			    display: table;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul::after {
			    clear: both;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul li.add,
			#wrest-product-content .inside #__wrest_post_content___container ul li.image,
			#wrest-product-content .inside #__wrest_post_content___container ul li.wc-metabox-sortable-placeholder {
			    width: 80px;
			    float: left;
			    cursor: move;
			    border: 1px solid #d5d5d5;
			    margin: 9px 9px 0 0;
			    background: #f7f7f7;
			    border-radius: 2px;
			    position: relative;
			    box-sizing: border-box;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul li.add img,
			#wrest-product-content .inside #__wrest_post_content___container ul li.image img,
			#wrest-product-content .inside #__wrest_post_content___container ul li.wc-metabox-sortable-placeholder img {
			    width: 100%;
			    height: auto;
			    display: block;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul li.wc-metabox-sortable-placeholder {
			    border: 3px dashed #ddd;
			    position: relative;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul li.wc-metabox-sortable-placeholder::after {
			    font-family: Dashicons;
			    speak: none;
			    font-weight: 400;
			    font-variant: normal;
			    text-transform: none;
			    line-height: 1;
			    -webkit-font-smoothing: antialiased;
			    margin: 0;
			    text-indent: 0;
			    position: absolute;
			    top: 0;
			    left: 0;
			    width: 100%;
			    height: 100%;
			    text-align: center;
			    content: "ï…¡";
			    font-size: 2.618em;
			    line-height: 72px;
			    color: #ddd;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul ul.actions {
			    position: absolute;
			    top: -8px;
			    right: -8px;
			    padding: 2px;
			    display: none;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul ul.actions li {
			    float: right;
			    margin: 0 0 0 2px;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul ul.actions li a {
			    width: 1em;
			    height: 1em;
			    margin: 0;
			    height: 0;
			    display: block;
			    overflow: hidden;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul ul.actions li a.tips {
			    cursor: pointer;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul ul.actions li a.delete {
			    display: block;
			    text-indent: -9999px;
			    position: relative;
			    height: 1em;
			    width: 1em;
			    font-size: 1.4em;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul ul.actions li a.delete::before {
			    font-family: Dashicons;
			    speak: none;
			    font-weight: 400;
			    font-variant: normal;
			    text-transform: none;
			    line-height: 1;
			    -webkit-font-smoothing: antialiased;
			    margin: 0;
			    text-indent: 0;
			    position: absolute;
			    top: 0;
			    left: 0;
			    width: 100%;
			    height: 100%;
			    text-align: center;
			    content: "";
			    color: #999;
			    background: #fff;
			    border-radius: 50%;
			    height: 1em;
			    width: 1em;
			    line-height: 1em;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul ul.actions li a.delete:hover::before {
			    color: #a00;
			}
			
			#wrest-product-content .inside #__wrest_post_content___container ul li:hover ul.actions {
			    display: block;
			}
			#wrest-product-content .inside #__wrest_post_content___container .__wrest_post_content__s .image{width:320px;}
			</style>
			
		<div id="__wrest_post_content___container">
		<div style="margin-bottom:20px;">(小程序)产品图文介绍 - 请优先设置此项内容，异步加载节约流量，布局不容易混乱</div>
			<ul class="__wrest_post_content__s" style="width:320px;margin:0 auto;">
				<?php
				$__wrest_post_content__ = get_post_meta($post->ID,'_wrest_the_content_',true);
				$attachments = $__wrest_post_content__?explode(',', $__wrest_post_content__):array();
			
				$update_meta         = false;
				$updated_gallery_ids = array();

				if ( ! empty( $attachments ) ) {
					foreach ( $attachments as $attachment_id ) {
						$attachment = wp_get_attachment_image( $attachment_id, 'woocommerce_single' );

						// if attachment is empty skip.
						if ( empty( $attachment ) ) {
							$update_meta = true;
							continue;
						}

						echo '<li class="image" data-attachment_id="' . esc_attr( $attachment_id ) . '">
								' . $attachment . '
								<ul class="actions">
									<li><a href="#" class="delete tips" data-tip="' . esc_attr__( 'Delete image', 'woocommerce' ) . '">' . __( 'Delete', 'woocommerce' ) . '</a></li>
								</ul>
							</li>';

						// rebuild ids to be saved.
						$updated_gallery_ids[] = $attachment_id;
					}

					// need to update product meta to set new gallery ids
					if ( $update_meta ) {
						update_post_meta( $post->ID, '_wrest_the_content_', implode( ',', $updated_gallery_ids ) );
					}
				}
				?>
			</ul>

			<input type="hidden" id="__wrest_post_content__" name="__wrest_post_content__" value="<?php echo esc_attr( implode( ',', $updated_gallery_ids ) ); ?>" />

		</div>
		<p class="add___wrest_post_content__s hide-if-no-js">
			<a href="#" data-choose="新增图文介绍" data-update="<?php esc_attr_e( 'Add to gallery', 'woocommerce' ); ?>" data-delete="<?php esc_attr_e( 'Delete image', 'woocommerce' ); ?>" data-text="<?php esc_attr_e( 'Delete', 'woocommerce' ); ?>">新增图文介绍</a>
		</p>
		
		<script type="text/javascript">
			(jQuery)(function($){
				// Product gallery file uploads.
				var product_gallery_frame;
				var $image_gallery_ids = $( '#__wrest_post_content__' );
				var $__wrest_post_content__s    = $( '#__wrest_post_content___container' ).find( 'ul.__wrest_post_content__s' );

				$( '.add___wrest_post_content__s' ).on( 'click', 'a', function( event ) {
					var $el = $( this );

					event.preventDefault();

					// If the media frame already exists, reopen it.
					if ( product_gallery_frame ) {
						product_gallery_frame.open();
						return;
					}

					// Create the media frame.
					product_gallery_frame = wp.media.frames.product_gallery = wp.media({
						// Set the title of the modal.
						title: $el.data( 'choose' ),
						button: {
							text: $el.data( 'update' )
						},
						states: [
							new wp.media.controller.Library({
								title: $el.data( 'choose' ),
								filterable: 'all',
								multiple: true
							})
						]
					});

					// When an image is selected, run a callback.
					product_gallery_frame.on( 'select', function() {
						var selection = product_gallery_frame.state().get( 'selection' );
						var attachment_ids = $image_gallery_ids.val();

						selection.map( function( attachment ) {
							attachment = attachment.toJSON();

							if ( attachment.id ) {
								attachment_ids   = attachment_ids ? attachment_ids + ',' + attachment.id : attachment.id;
								var attachment_image =  attachment.url;

								$__wrest_post_content__s.append( '<li class="image" data-attachment_id="' + attachment.id + '"><img src="' + attachment_image + '" /><ul class="actions"><li><a href="#" class="delete" title="' + $el.data('delete') + '">' + $el.data('text') + '</a></li></ul></li>' );
							}
						});

						$image_gallery_ids.val( attachment_ids );
					});

					// Finally, open the modal.
					product_gallery_frame.open();
				});

				// Image ordering.
				$__wrest_post_content__s.sortable({
					items: 'li.image',
					cursor: 'move',
					scrollSensitivity: 40,
					forcePlaceholderSize: true,
					forceHelperSize: false,
					helper: 'clone',
					opacity: 0.65,
					placeholder: 'wc-metabox-sortable-placeholder',
					start: function( event, ui ) {
						ui.item.css( 'background-color', '#f6f6f6' );
					},
					stop: function( event, ui ) {
						ui.item.removeAttr( 'style' );
					},
					update: function() {
						var attachment_ids = '';

						$( '#__wrest_post_content___container' ).find( 'ul li.image' ).css( 'cursor', 'default' ).each( function() {
							var attachment_id = $( this ).attr( 'data-attachment_id' );
							attachment_ids = attachment_ids + attachment_id + ',';
						});

						$image_gallery_ids.val( attachment_ids );
					}
				});

				// Remove images.
				$( '#__wrest_post_content___container' ).on( 'click', 'a.delete', function() {
					$( this ).closest( 'li.image' ).remove();

					var attachment_ids = '';

					$( '#__wrest_post_content___container' ).find( 'ul li.image' ).css( 'cursor', 'default' ).each( function() {
						var attachment_id = $( this ).attr( 'data-attachment_id' );
						attachment_ids = attachment_ids + attachment_id + ',';
					});

					$image_gallery_ids.val( attachment_ids );

					// Remove any lingering tooltips.
					$( '#tiptip_holder' ).removeAttr( 'style' );
					$( '#tiptip_arrow' ).removeAttr( 'style' );

					return false;
				});
			});
		</script>
		<?php
	}
	
	/**
	 * Save meta box data.
	 *
	 * @param int     $post_id
	 * @param WP_Post $post
	 */
	public static function save( $post_ID) {
	// 首先，我们需要检查当前用户是否被授权做这个动作。
        if ( ! current_user_can( 'edit_post', $post_ID ) ){
            return;
        }

        // 其次，我们需要检查，是否用户想改变这个值。
        if ( ! isset( $_POST['__wrest_post_content_hidden__'] ) || ! wp_verify_nonce( $_POST['__wrest_post_content_hidden__'], plugin_basename( __FILE__ ) ) ){
            return;
        }
        
		$attachment_ids = isset( $_POST['__wrest_post_content__'] ) ? array_filter( explode( ',', sanitize_text_field( $_POST['__wrest_post_content__'] ) ) ) : array();
		
		update_post_meta($post_ID, '_wrest_the_content_', implode( ',', $attachment_ids ) );
	}
}