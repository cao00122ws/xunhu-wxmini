<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：其他
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Default_Basic extends Abstract_WRest_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu_default_basic';
        $this->title='基础设置';
    }
    
    /* (non-PHPdoc)
     * @see Abstract_WRest_Settings_Menu::menus()
     */
    public function menus(){
       
        return apply_filters("wrest_admin_menu_{$this->id}", array(
            WRest_Settings_Default_Basic_Default::instance(),
            new WRest_Menu_Store_Goods_Share(),
        ));
    }
}

class WRest_Menu_Default_Shipping extends Abstract_WRest_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu_default_shipping';
        $this->title='配送';
    }

    /* (non-PHPdoc)
     * @see Abstract_WRest_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wrest_admin_menu_{$this->id}", array(
            new WRest_Menu_Store_Order()
        ));
    }
}
?>