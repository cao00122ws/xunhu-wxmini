<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Default_Order extends Abdtract_WRest_Setting_Layout{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        $this->id='menu-default-order';
        $this->title='订单状态';
        $this->init_form_fields();
    }

    public function init_form_fields(){
        $this->form_fields = array(
            'title1'=>array(
                'title'=>'订单列表设置',
                'type'=>'subtitle'
            ),
            'order_status_list'=>array(
                'title'=>'订单状态',
                'type'=>'order_status_list'
            ),

            'title2'=>array(
                'title'=>'订单详情设置',
                'type'=>'subtitle'
            ),
            'status_header_bg'=>array(
                'title'=>'订单状态：背景图',
                'type'=>'image',
                'default'=>array(
                    'url'=>WREST_URL.'/assets/images/v2/icon/order/status-bg.jpg',
                    'width'=>1024,
                    'height'=>120
                ),
            ),
            'status_header_color'=>array(
                'title'=>'订单状态：文字色',
                'type'=>'color',
                'default'=>'ffffff'
            )
        );
    }
    
    public function register_status($status,$default=null){
        $config = $this->get_option('order_status_list');
        if(!$config||!is_array($config)){
            $config = array();
        }
        
        return isset($config[$status])?$config[$status]:$default;
    }
    
    public function reflect_status($new_status){
        $config = $this->get_option('order_status_list');
        if(!$config||!is_array($config)){
            $config = array();
        }
        
        foreach ($config as $status=>$settings){
            if($settings['name']==$new_status){
                return $settings;
            }
        }
        
        return null;
    }
    
    /**
     * 
     * @param string $wc_status
     * @param string $type short|full
     * @return string
     */
    public function get_status_name($wc_status,$type='short'){
        if(strpos($wc_status, 'wc-')!==0){
            $wc_status = "wc-{$wc_status}";
        }
        $config = $this->get_option('order_status_list');
        if(!$config||!is_array($config)){
            $config = array();
        }
        
        $new_status = $wc_status;
        if(isset($config[$wc_status])){
            $new_status =$config[$wc_status]['name'];
        }
        
        return $type=='short'?substr($new_status, 3):$new_status;
    }
    
    public function generate_order_status_list_html($key, $data) {
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'class' => '',
            'type' => 'order_status_list',
            'desc_tip' => false,
            'default'=>null,
            'description' => ''
        );
         
        $data = wp_parse_args ( $data, $defaults );
        $config = $this->get_option($key);
        if(!$config||!is_array($config)){$config=array();}
        ob_start ();
        ?>
        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
        	<th scope="row" class="titledesc">
        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
				<?php echo $this->get_tooltip_html( $data ); ?>
			</th>
        	<td class="forminp">
    			<style type="text/css">
    			     .wrest-order-status-tb td{text-align:left;width:150px;padding:5px;}
                    .field-drop-zone{
                    	 border: 1px dashed #fff;
                            background-color: #FFF;
                            margin: 0 auto 10px;
                            height: 75px;
                            width: 100%;
                            -webkit-box-sizing: border-box;
                            -moz-box-sizing: border-box;
                            box-sizing: border-box;
                    }
    			</style>
        		<fieldset>
        			<legend class="screen-reader-text">
        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
        			</legend>
        			<table class="wrest-order-status-tb" id="<?php echo $field?>-container">
        				<tr class="wrest-order-status-not-sort">
        					<td>隐藏</td>
        					<td>系统状态</td>
        					<td>系统名称</td>
        					<td>自定义状态</td>
        					<td>自定义名称</td>
        					<td>顺序(拖动排序)</td>
        				</tr>
        				<tbody>
            				<?php 
            				global $wrest_unregister_wc_order_status_list,
            				$wrest_unreset_wc_order_status_label,
            				$wrest_unreset_wc_order_status_key;
            				
            				$wrest_unregister_wc_order_status_list = true;
            				$system_status = wc_get_order_statuses();
            				$wrest_unregister_wc_order_status_list = false;
            				
            				$wrest_unreset_wc_order_status_label = $wrest_unreset_wc_order_status_key = true;
            				$status_array = wc_get_order_statuses();
            				$wrest_unreset_wc_order_status_label = $wrest_unreset_wc_order_status_key = false;
            				
            				$status_list = array();
            				foreach ($status_array as $status=>$label){
            				    $_c = $this->register_status($status);
            				    $status_list[]  = array(
            				        'name'=>$status,
            				        'label'=>$label,
            				        'sort'=>$_c&&isset($_c['sort'])?absint($_c['sort']):0
            				    );
            				}
            				
            				usort($status_list, function($l,$r){
            				    return $l['sort']>$r['sort'];
            				});
            				
            				foreach ($status_list as $item){
            				    $status = $item['name'];
            				    $label = $item['label'];
            				    
            				    $is_system_status = isset($system_status[$status]);
            				    ?>
            				    <tr data-status="<?php echo esc_attr($status)?>" id="wrest-tr-<?php echo $field?>-<?php echo $status?>" class="wrest-tr-<?php echo $field?> wrest-order-status-sort">
            				    	<td><input type="checkbox" class="status-disabled" <?php echo isset($config[$status]['disabled'])&&$config[$status]['disabled']=='yes'?'checked':''?> /></td>
            				    	<td><code style="<?php echo $is_system_status?'color:#888888':'';?>"><?php echo $status?></code></td>
            				    	<td><code style="<?php echo $is_system_status?'color:#888888':'';?>"><?php echo $label?></code></td>
            				    	<td><input maxlength="20" <?php echo $is_system_status?'readonly':'';?> class="status-name" type="text" value="<?php echo esc_attr(isset($config[$status])?$config[$status]['name']:$status)?>" /></td>
            				    	<td><input class="status-label" type="text" value="<?php echo esc_attr(isset($config[$status])?$config[$status]['label']:$label)?>" /></td>
            				    	<td><i style="cursor:pointer;" class="dashicons dashicons-menu move ui-sortable-handle"></i></td>
            				    </tr>
            				    <?php 
            				}?>
        				</tbody>
        			</table>
        			<div class="description xh-mT30 xh-c-sub xh-f-sub">订单状态排序，在小程序/我的账户/订单列表 实现</div>
        			<input type="hidden" name="<?php echo $field;?>" id="<?php echo $field?>" value="<?php echo json_encode($config)?>" />
        			<?php echo $this->get_description_html( $data ); ?>
        		</fieldset>
        		<script type="text/javascript">
					(function($){
						$(function(){
							$('#<?php echo $field?>-container tbody').sortable({
								cursor:'move',
								axis:"y",
								tolerance:'pointer',
						        placeholder: "field-drop-zone",
								update:function(event, ui){
									window.status_<?php $field?>_view._init_();
								}
						    }).disableSelection();
						});
						
						window.status_<?php $field?>_view={
							_init_:function(){
								var config ={};
								var index = 0;
								
								$('.wrest-tr-<?php echo $field?>').each(function(){
									var status = $(this).data('status');
									config[status]={
										disabled:$(this).find('.status-disabled:checked').length>0?'yes':'no',
										name:$.trim($(this).find('.status-name').val()),
										label:$.trim($(this).find('.status-label').val()),
										sort:index++
									};
								});

								$('#<?php echo $field?>').val(JSON.stringify(config));
							}
						};
						
						window.status_<?php $field?>_view._init_();
						$('#<?php echo $field?>-container .status-disabled').change(function(){
							window.status_<?php $field?>_view._init_();
						});
						$('#<?php echo $field?>-container .status-label,#<?php echo $field?>-container .status-name').keyup(function(){
							window.status_<?php $field?>_view._init_();
						});
					})(jQuery);
        		</script>
        	</td>
        </tr>
        <?php
		
		return ob_get_clean ();
	}
    
	public function validate_order_status_list_field($key) {
	    $text = $this->get_option ( $key );
	    $field = $this->get_field_key ( $key );
	    return isset($_POST [$field])?json_decode(stripslashes($_POST [$field]),true):null;
	}
	
    private function get_refund_tips(){
    	ob_start();
    	?><h1>
			    退货及退款须知
			</h1>
			<h5>
			    退货退款流程
			</h5>
			<ol>
			    <li>
			        <p>
			            确定收货后可申请退货。
			        </p>
			    </li>
			    <li>
			        <p>
			            将申请退货的商品退还到收货地点扫码后，退款申请即时生
			效。(退还商品后的48小时以内退还货款）
			        </p>
			    </li>
			    <li>
			        <p>
			            商家收到退货商品后，确定是合理的退货理由时，将会正常
			退款。(顾客需要承担责任的情况，将在实际支付金额中去除
			邮费退还剩余金额）
			        </p>
			    </li>
			</ol>
			<h5>
			    以下情况不支持退款
			</h5>
			<ol>
			    <li>
			        <p>
			            非商品质量问题退货，产品的标签，包装，商品毁损等情况
			时无法退款（若是单纯不想买的情况，需要确定包装，产品
			 &nbsp;是否开封，产品是否有破损等）
			        </p>
			    </li>
			    <li>
			        <p>
			            因顾客的失误造成的商品丢失或破损的情况时无法退款
			        </p>
			    </li>
			    <li>
			        <p>
			            因顾客的使用消费导致商品部分价值缺失时无法退款（使用，
			拆分，破损等导致商品价值受损，无法进行二次销售时）
			        </p>
			    </li>
			</ol><?php
			return ob_get_clean();
    }
    
}