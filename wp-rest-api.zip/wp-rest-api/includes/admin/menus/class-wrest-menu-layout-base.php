<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Base extends Abdtract_WRest_Setting_Layout{    

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        $this->id='menu-store-base';
        $this->title='全局设置';
        $this->init_form_fields();
    }

    public function init_form_fields(){
        if(!$this->version){
            return;
        }
        //get_terms()
        $this->form_fields = array(
            'subtitle_product'=>array(
                'title'=>'店铺',
                'type'=>'subtitle'
            ),
            'enable_sale_qty'=>array(
                'type'=>'checkbox',
                'title'=>'显示销量',
                'default'=>'yes',
                'label'=>'启用',
                'description'=>'商品列表内开启销量显示'
            ),
            'enable_oversea_address'=>array(
                'type'=>'checkbox',
                'title'=>'海外地址',
                'label'=>'启用',
                'description'=>'编辑账单地址时，允许选择海外地址'
            ),
            'address_model'=>array(
                'title'=>'配送方式',
                'type'=>'select',
                'options'=>function(){
                    return apply_filters('wrest_address_modal', array(
                        'default'=>'系统默认：省-市-地区 详细地址'
                    ));
                },
                'description'=>'如需更多配送方式，请<a target="_blank" href="https://www.wpweixin.net/" target="_blank">联系我们</a>定制。'
            ),
            'subtitle_comment'=>array(
                'title'=>'资讯',
                'type'=>'subtitle'
            ),
            'default_comment'=>array(
                'type'=>'textarea',
                'title'=>'默认评论内容',
                'default'=> '系统默认好评',
                'custom_attributes'=>array(
                    'style'=>'min-height:200px;min-width:400px'
                ),
                'description' => '当用户评论留空时，默认填充内容'
            ),
            'subtitle_pro'=>array(
                'title'=>'产品',
                'type'=>'subtitle'
            ),
            'pro_purchase_note'=>array(
                'type'=>'image',
                'title'=>'商品购买须知'
            ),
            'idcard_license'=>array(
                'title'=>'身份认证：授权须知',
                'type'=>'select',
                'post_type'=>'wrest_page'
            )
        );
    }
    
}