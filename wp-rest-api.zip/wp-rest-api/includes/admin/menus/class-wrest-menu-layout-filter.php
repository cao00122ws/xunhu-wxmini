<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Filter extends Abdtract_WRest_Setting_Layout{    

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        $this->id='menu-store-filter';
        $this->title='数据筛选';
        $this->init_form_fields();
    }

    public function init_form_fields(){
        $this->form_fields = array(
            'navigationBarTitleText'=>array(
                'title'=> '小程序名称',
                'type'=>'emoji',
                'default'=>get_bloginfo('name')
            )
        );
    }
}