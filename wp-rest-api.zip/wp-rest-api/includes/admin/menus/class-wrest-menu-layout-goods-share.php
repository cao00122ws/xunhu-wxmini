<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Goods_Share extends Abdtract_WRest_Setting_Layout{    

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        $this->id='menu-store-goods-share';
        $this->title='好物圈';
        $this->description='<h5 >开通步骤：</h5>
							<ol>
								<li><a href="https://mp.weixin.qq.com/" target="_blank">微信公众平台</a>，在左侧导航栏点击“微信搜索”，进入“搜索信息”，点击“开通”好物圈。</li>
								<li>申请开通好物圈插件：访问<a href="https://mp.weixin.qq.com/wxopen/plugindevdoc?appid=wx56c8f077de74b07c&lang=zh_CN" target="_blank">好物圈</a>，“申请开通”，并成功开通</li>
								<li><span style="color:red;">在已开通的前提下</span>，<b>勾选此项</b>，然后重新导出小程序，测试并发布。</li>
								<li style="color:red;">警告：请勿在未开通时，勾选此项并导出,会造成小程序无法编译</li>
								<li>商品图册内必须至少一张(原图)宽度大于750px的商品图片，否在分享失败(宽高比建议4:3 - 1:1之间)</li>
							</ol>';
        $this->init_form_fields();
    }

    public function init_form_fields(){
        
        $this->form_fields = array(
        		'enable_goodShare'=>array(
        				'type'=>'checkbox',
        				'title'=>'好物圈',
        				'label'=>'确认启用 <span style="color:red;">(我已确认好物圈插件已通过申请)</span>'
        		),
        		'subtitle_brand'=>array(
        				'title'=> '品牌信息',
        				'type'=>'subtitle',
        		),
        		'name'=>array(
        				'title'=> '商家名称(可选)',
        				'type'=>'text',
        		),
        		'logo'=>array(
        				'title'=> '商家(品牌)LOGO(可选)',
        				'type'=>'image',
        		),
        		'contact'=>array(
        				'title'=> '商家电话(可选)',
        				'type'=>'text'
        		),
        		'subtitle_product'=>array(
        				'title'=> '通用商品信息',
        				'type'=>'subtitle',
        		),
        		'category_list'=>array(
        				'title'=> '商品分类(必填)',
        				'type'=>'text',
        				'default'=>'服装',
        				'placeholder'=>'服装,上衣,短袖衬衫',
        				'description'=>'多个分类，“逗号”分隔。更多分类，请参考<a href="'.WREST_URL.'/assets/platform_category.csv" target="_blank" download>分类目录</a>'
        		),
        		'poi_list'=>array(
        				'title'=> '店铺位置(可选)',
        				'type'=>'textarea',
        				'css'=>'min-height:200px;width:400px;',
        				'placeholder'=>"116.32676,40.003305,0,麦当劳,珠江新城店,新港中路123号\r\n117.32676,41.003305,5,麦当劳,客村店,新港中路103号",
        				'description'=>'多个店铺信息换行分隔，格式：<code>经度,维度,配送范围,门店名称,分店名称,门店地址</code><br/>
						<ol>
							<li>经纬度：门店的经度，WGS84标准，取值范围为-180到180的数字,门店的纬度，取值范围为-90到90的数字</li>
							<li>配送范围(0~5)(单位km)：门店可送达半径，单位km，大于等于0的数字</li>
							<li>门店名称：（仅为商户名，如：国美、麦当劳，不应包含地区、地址、分店名等信息，错误示例：北京国美），20个字符以内。非空白字符串</li>
							<li>分店名称：（<span style="color:red;">不应包含地区信息，不应与门店名有重复，错误示例：北京王府井店</span>），20个字符以内，20个字符以内。非空白字符串</li>
							<li>门店地址：（不包含省市区信息，如：新港中路123号）。非空白字符串</li>						
						</ol>'
        		)
        		
        );
    }
    
    public function generate_wechat_menu_edit_html($config = null){
        return WRest::instance()->WP->requires(WREST_DIR, 'wechat/menu-edit.php',array(
            'request'=>$config,
            'context'=>WRest_Helper::generate_unique_id()
        ));
    }
}