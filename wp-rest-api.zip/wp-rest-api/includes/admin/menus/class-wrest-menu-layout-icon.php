<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Icon extends Abdtract_WRest_Setting_Layout{    

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        $this->id='menu-store-icon';
        $this->title='店铺图标';
        $this->init_form_fields();
    }

    public function init_form_fields(){
        if(!$this->version){
            return;
        }
        
        require_once 'class-wrest-menu-store-layout.php';
        $layout = WRest_Menu_Store_Layout::instance();
        $this->form_fields = array(
            'subtitle_common'=>array(
                'title'=>'系统通用',
                'type'=>'subtitle'
            ),
            'none_comment_items'=>array(
                'title'=> '空评论列表',
                'type'=>'image',
                'default'=>array(
                    'url'=>WREST_URL.'/assets/images/v2/product/empty-comment.png',
                    'width'=>360,
                    'height'=>477
                ),
                'description'=>'购物车商品内容为空时，显示当前图片（尺寸：360x*）'
            ),
            'none_cat_icon'=>array(
                'title'=> '商品分类图标(默认)',
                'type'=>'image',
                'default'=>array(
                    'url'=>function_exists('wc_placeholder_img_src')? wc_placeholder_img_src():'',
                    'width'=>80,
                    'height'=>80
                ),
                'description'=>'购物车商品内容为空时，显示当前图片（尺寸：360x*）'
            ),
            'none_cart_items'=>array(
                'title'=> '空购物车',
                'type'=>'image',
                'default'=>array(
                    'url'=>WREST_URL.'/assets/images/v2/product/cartsky.png',
                    'width'=>360,
                    'height'=>477
                ),
                'description'=>'购物车商品内容为空时，显示当前图片（尺寸：360x*）'
            ),
            'subtitle_product'=>array(
                'title'=>'商品列表',
                'type'=>'subtitle'
            ),
            
            'is_sale_out'=>array(
                'title'=>'图标：商品缺货',
                'type'=>'image',
                'width'=>200,
                'height'=>200,
                'default'=>array(
                    'url'=>WREST_URL.'/assets/images/icon/sale-out.png',
                    'width'=>256,
                    'height'=>256
                )
            ),
            'is_on_sale'=>array(
                'title'=>'图标：促销中',
                'type'=>'image',
                'width'=>74,
                'height'=>74,
                'default'=>$layout->get_field($this->version, 'WRest_Template_Layout_Products')->get_option('icon_is_on_sale'),
            ),
            'is_featured'=>array(
                'title'=>'图标：热卖中',
                'type'=>'image',
                'width'=>74,
                'height'=>74,
                'default'=>$layout->get_field($this->version, 'WRest_Template_Layout_Products')->get_option('icon_is_featured')
            ),
            'is_new'=>array(
                'title'=>'图标：新货',
                'type'=>'image',
                'width'=>74,
                'height'=>74,
                'default'=>$layout->get_field($this->version, 'WRest_Template_Layout_Products')->get_option('icon_is_new')
            ),
    		'cart_more'=>array(
    				'title'=>'(购物车)更多',
    				'type'=>'image',
    				'width'=>128,
    				'height'=>50,
    				'default'=>$layout->get_field($this->version, 'WRest_Template_Layout_Products')->get_option('cart_more')
    		),
    		'cart_add'=>array(
    				'title'=>'(购物车)+',
    				'type'=>'image',
    				'width'=>50,
    				'height'=>50,
    				'default'=>$layout->get_field($this->version, 'WRest_Template_Layout_Products')->get_option('cart_add')
    		),
    		'cart_cut'=>array(
    				'title'=>'(购物车)-',
    				'type'=>'image',
    				'width'=>50,
    				'height'=>50,
    				'default'=>$layout->get_field($this->version, 'WRest_Template_Layout_Products')->get_option('cart_cut')
    		)
            
        );
    }
}