<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Order extends Abdtract_WRest_Setting_Layout{    

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        $this->id='menu-store-order';
        $this->title='订单提示';
        $this->init_form_fields();
    }

    public function init_form_fields(){
        $this->form_fields = array(
            'title1'=>array(
                'title'=>'退货相关',
                'type'=>'subtitle'
            ),
            'enable_refund_when_processing'=>array(
                'title'=>'(待发货订单)允许客户申请退款时限(小时)',
                'type'=>'text',
                'placeholder'=>'不允许',
                'description'=>'留空：不允许。(待发货订单)在<b>支付后x小时</b>内，允许用户执行退款申请操作。'
            ),
//             'enable_refund_when_shiped'=>array(
//                 'title'=>'(已发货订单)允许客户申请退款时限(小时)',
//                 'type'=>'text',
//                 'placeholder'=>'不允许',
//                 'description'=>'留空：不允许。(已发货订单)在<b>发货后x小时</b>内，允许用户执行退款申请操作。'
//             ),
            'enable_refund_when_received'=>array(
                'title'=>'(已收货订单)允许客户申请退款时限(小时)',
                'type'=>'text',
                'placeholder'=>'不允许',
                'description'=>'留空：不允许。(已收货订单)在<b style="color:red;">发货后x小时</b>内，允许用户执行退款申请操作。'
            ),
    		'refund_reasions'=>array(
    				'title'=>'退款理由',
    				'type'=>'textarea',
    				'description'=>'多个退款理由，换行分隔。',
    				'default'=>"物品损坏\r\n购买错误\r\n颜色不对\r\n其它原因"
    		),
    		'refund_tips'=>array(
    				'title'=>'退款提示',
    				'type'=>'editor',
    				'default'=>$this->get_refund_tips()
    		),
            'title1'=>array(
                'title'=>'订单详情',
                'type'=>'subtitle'
            ),
    		'order_detail_tips'=>array(
    				'title'=>'订单详情备注',
    				'type'=>'editor'
    		)
        );
    }
    
    private function get_refund_tips(){
    	ob_start();
    	?><h1>
			    退货及退款须知
			</h1>
			<h5>
			    退货退款流程
			</h5>
			<ol>
			    <li>
			        <p>
			            确定收货后可申请退货。
			        </p>
			    </li>
			    <li>
			        <p>
			            将申请退货的商品退还到收货地点扫码后，退款申请即时生
			效。(退还商品后的48小时以内退还货款）
			        </p>
			    </li>
			    <li>
			        <p>
			            商家收到退货商品后，确定是合理的退货理由时，将会正常
			退款。(顾客需要承担责任的情况，将在实际支付金额中去除
			邮费退还剩余金额）
			        </p>
			    </li>
			</ol>
			<h5>
			    以下情况不支持退款
			</h5>
			<ol>
			    <li>
			        <p>
			            非商品质量问题退货，产品的标签，包装，商品毁损等情况
			时无法退款（若是单纯不想买的情况，需要确定包装，产品
			 &nbsp;是否开封，产品是否有破损等）
			        </p>
			    </li>
			    <li>
			        <p>
			            因顾客的失误造成的商品丢失或破损的情况时无法退款
			        </p>
			    </li>
			    <li>
			        <p>
			            因顾客的使用消费导致商品部分价值缺失时无法退款（使用，
			拆分，破损等导致商品价值受损，无法进行二次销售时）
			        </p>
			    </li>
			</ol><?php
			return ob_get_clean();
    }
    
}