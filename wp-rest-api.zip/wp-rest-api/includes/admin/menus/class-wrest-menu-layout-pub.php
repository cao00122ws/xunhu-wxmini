<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Pub extends Abdtract_WRest_Setting_Layout{    

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        $this->id='menu-store-pub';
        $this->title='发布设置';
        $this->description="小程序sdk>=2.6.1(微信版本>=7.0.3)";
        $this->init_form_fields();
    }
    
    public function export_menus($create_file = false){ 	
    	if($create_file){
    		if(!WRest::instance()->WP->removeDir(WREST_DIR.'/output/v2/exts/')){
    			throw new Exception('移除“output/v2/exts”目录时发生异常！');
    		}
    		if(!WRest::instance()->WP->removeDir(WREST_DIR.'/output/v2/images/navbar/')){
    			throw new Exception('移除“output/v2/images/navbar/”目录时发生异常！');
    		}
    	}
    	
    	$menus = $this->get_option('menus');
    	if(!$menus||!is_array($menus)||!count($menus)){
    		return array();
    	}
    	
    	$count = 0;
    	$menuArray = array();
    	foreach ($menus as $menu){
    	    if($menu['page']=='custom'){
    	        $params = isset($menu['page_param'])? explode('?', $menu['page_param']):array('');
    	        $menu['page'] = $params[0];
    	        $menu['page_param'] = null;
    	    }
    	    
    		if(empty($menu['page_title'])){
    			throw new Exception('导航菜单：标题不能为空');
    		}
    		
    		if(empty($menu['page'])){
    			throw new Exception('导航菜单：页面链接不能为空');
    		}
    		
    		
    		$iconPath = isset($menu['icon']['url'])&&$menu['icon']['url']?$menu['icon']['url']:null;
    		if(!empty($iconPath)){
    			$iconPath = WRest::instance()->WP->convert_remoteimage_to_local($iconPath, '/images/navbar/');
    		}
    		
    		$selectedIconPath = isset($menu['icon_selected']['url'])&&$menu['icon_selected']['url']?$menu['icon_selected']['url']:null;
    		if(!empty($selectedIconPath)){
    			$selectedIconPath = WRest::instance()->WP->convert_remoteimage_to_local($selectedIconPath, '/images/navbar/');
    		}
    		
    		require_once WREST_DIR.'/includes/miniprogram/pages/art/index.js.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/art/index.json.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/art/index.wxml.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/art/index.wxss.php';
    		
    		require_once WREST_DIR.'/includes/miniprogram/pages/cat/index.js.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/cat/index.json.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/cat/index.wxml.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/cat/index.wxss.php';
    		
    		require_once WREST_DIR.'/includes/miniprogram/pages/page/index.js.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/page/index.json.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/page/index.wxml.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/page/index.wxss.php';
    		
    		require_once WREST_DIR.'/includes/miniprogram/pages/pro/index.js.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/pro/index.json.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/pro/index.wxml.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/pro/index.wxss.php';
    		
    		require_once WREST_DIR.'/includes/miniprogram/pages/web/index.js.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/web/index.json.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/web/index.wxml.php';
    		require_once WREST_DIR.'/includes/miniprogram/pages/web/index.wxss.php';
    		
    		$page = ltrim($menu['page'],'/');
    		switch ($page){
    			case 'pages/subcat/index':
    				$cat_id = isset($menu['page_param'])?absint($menu['page_param']):0;
    				if(!$cat_id){
    					throw new Exception('分类详情页面：参数-分类/标签ID不能为空！');
    				}
    				
    				$term = get_term($cat_id);
    				if(!$term){
    					throw new Exception('分类详情页面：参数-分类/标签不存在！');
    				}
    				
    				if($create_file){
    					$js = new WRest_Mini_Pages_Cat_JS($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Cat_WXML($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Cat_JSON($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Cat_WXSS($term);
    					$js->save($this->version);
    					
    				}
    				$page = "exts/cat{$term->term_id}/index";
    				break;
    			case 'pages/product/detail/index':
    				$cat_id = isset($menu['page_param'])?absint($menu['page_param']):0;
    				if(!$cat_id){
    					throw new Exception('商品详情页面：参数-产品ID不能为空！');
    				}
    				
    				$term = get_post($cat_id);
    				if(!$term){
    					throw new Exception('商品详情页面：产品不存在！');
    				}
    				
    				if($create_file){
    					$js = new WRest_Mini_Pages_Pro_JS($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Pro_WXML($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Pro_JSON($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Pro_WXSS($term);
    					$js->save($this->version);
    					
    				}
    				$page = "exts/pro{$term->ID}/index";
    				break;
    			case 'pages/article/detail/index':
    				$cat_id = isset($menu['page_param'])?absint($menu['page_param']):0;
    				if(!$cat_id){
    					throw new Exception('文章详情页面：参数-产品ID不能为空！');
    				}
    				
    				$term = get_post($cat_id);
    				if(!$term){
    					throw new Exception('文章详情页面：产品不存在！');
    				}
    				
    				if($create_file){
    					$js = new WRest_Mini_Pages_Art_JS($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Art_WXML($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Art_JSON($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Art_WXSS($term);
    					$js->save($this->version);
    					
    				}
    				$page = "exts/art{$term->ID}/index";
    				break;
    			case 'pages/page/index':
    				$cat_id = isset($menu['page_param'])?absint($menu['page_param']):0;
    				if(!$cat_id){
    					throw new Exception('小程序页面：参数-页面ID不能为空！');
    				}
    				
    				$term = get_post($cat_id);
    				if(!$term){
    					throw new Exception('小程序页面：页面不存在！');
    				}
    				
    				if($create_file){
    					$js = new WRest_Mini_Pages_Pg_JS($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Pg_WXML($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Pg_JSON($term);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Pg_WXSS($term);
    					$js->save($this->version);
    					
    				}
    				$page = "exts/page{$term->ID}/index";
    				break;
    			case 'pages/web-view/index':
    				$url = isset($menu['page_param'])?esc_url_raw($menu['page_param']):0;
    				if(!$url){
    					throw new Exception('浏览器：参数-URL地址不能为空！');
    				}
    				static $wrest_webview_key;
    				if(!$wrest_webview_key){
    					$wrest_webview_key = 0;
    				}else{
    					$wrest_webview_key++;
    				}
    				
    				if($create_file){
    					$js = new WRest_Mini_Pages_Web_JS($wrest_webview_key,$url);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Web_WXML($wrest_webview_key,$url);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Web_JSON($wrest_webview_key,$url);
    					$js->save($this->version);
    					
    					$js = new WRest_Mini_Pages_Web_WXSS($wrest_webview_key,$url);
    					$js->save($this->version);
    					
    				}
    				$page = "exts/web{$wrest_webview_key}/index";
    				break;
    		}
    		
    		if(isset($menuArray[$page])){
    			continue;
    		}
    		
    		$menuObj = array(
    				'pagePath'=>$page,
    				'text'=>WRest_Emoji_Editor::html_to_text($menu['page_title'])
    		);
    		if($iconPath||$selectedIconPath){
    			$menuObj['iconPath'] = $iconPath;
    			$menuObj['selectedIconPath'] = $selectedIconPath;
    		}
    		
    		$count++;
    		$menuArray[$page]=$menuObj;
    		if($count>=5){break;}
    	}
    	
    	return $menuArray;
    }
    
    public function init_form_fields(){
        if(!$this->version){
            return;
        }
        
        require_once 'class-wrest-menu-store-layout.php';
        $layout = WRest_Menu_Store_Layout::instance();
        
        $this->form_fields = array(
            'navigationBarTitleText'=>array(
                'title'=> '小程序名称',
                'type'=>'emoji',
            		'default'=>get_bloginfo('name'),
            		'description'=>'小程序主体名称'
            ),
            'app_whitelist'=>array(
                'type'=>'textarea',
                'title'=>'第三方小程序白名单',
                'placeholder'=>"APPID1\nAPPID2\nAPPID3...",
                'description'=>'需要跳转第三方小程序时，需要在此添加APPID白名单(最多10个)'
            ),
            'assets_url'=>array(
                'type'=>'text',
                'title'=>'图片资源目录',
                'default'=>WREST_URL.'/assets',
                'description'=>'您可以在此处设置云存储地址，并且需要把<code>插件/assets</code>下的资源同步到云上'
            ),
        		
            'menus'=>array(
                'title'=>'导航菜单',
                'type'=>'custom',
                'default'=>$layout->get_navbar($this->version)->get_option('items'),
                'func'=>function($key,$api,$data){
                    $field = $api->get_field_key ( $key );
                    $menu_configs = $api->get_option($key);
                    if(!$menu_configs||!is_array($menu_configs)){
                        $menu_configs = array();
                    }
                    ?>
                    <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
                    	<th scope="row" class="titledesc">
                    		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
            				<?php echo $api->get_tooltip_html( $data ); ?>
            			</th>
                    	<td class="forminp">
                    		<input type="hidden" name="<?php echo $field?>" id="<?php echo $field?>"/>
                            <?php if(!defined('xunhuweb-menu-edit')){
    						    define('xunhuweb-menu-edit', 1);
    						    ?>
    						    <script type='text/javascript' src='<?php echo WREST_URL?>/assets/js/nav-menu.js'></script>
                                 <link rel="stylesheet"  href='<?php echo WREST_URL?>/assets/css/nav-menus.css' type='text/css' />
                                 <link rel="stylesheet" type="text/css" href="<?php echo WREST_URL?>/assets/css/emotion_editor.css"/>
                                 <script type='text/javascript'>
                                    /* <![CDATA[ */
                                    var navMenuL10n = {"noResultsFound":"\u672a\u627e\u5230\u7ed3\u679c\u3002","warnDeleteMenu":"\u60a8\u5c06\u6c38\u4e45\u5220\u9664\u6240\u9009\u83dc\u5355\u3002\n\u70b9\u51fb\u201c\u53d6\u6d88\u201d\u505c\u6b62\uff0c\u70b9\u51fb\u201c\u786e\u5b9a\u201d\u5220\u9664\u3002","saveAlert":"\u79bb\u5f00\u8fd9\u4e2a\u9875\u9762\uff0c\u60a8\u6240\u505a\u7684\u66f4\u6539\u5c06\u4e22\u5931\u3002","untitled":"\uff08\u65e0\u6807\u7b7e\uff09"};
                                    var menus = {"oneThemeLocationNoMenus":"","moveUp":"\u4e0a\u79fb\u4e00\u9879","moveDown":"\u4e0b\u79fb\u4e00\u9879","moveToTop":"\u4e0a\u79fb\u5230\u9876","moveUnder":"\u79fb\u81f3%s\u4e0b","moveOutFrom":"\u4ece%s\u79fb\u51fa","under":"%s\u4e0b","outFrom":"%s\u4e4b\u5916","menuFocus":"%1$s\u3002%3$s\u4e2a\u83dc\u5355\u9879\u4e4b%2$s\u3002","subMenuFocus":"%1$s\u3002%3$s\u83dc\u5355\u4e2d\u7684\u7b2c%2$d\u9879\u3002"};
                                    /* ]]> */
                                </script>
                                <style type="text/css">.menu-item-depth-1{margin-left:0!important;}</style>
    						    <?php 
    						}?>
                            <h2><button class="button" id="<?php echo $field?>-btn-add-menu" type="button">新增菜单(至少2个，最多5个)</button></h2>
                            <div class="nav-menus-php">
                             	<ul class="menu ui-sortable" id="<?php echo $field?>-menu-to-edit">
                             		<?php if($menu_configs){
                             		    foreach ($menu_configs as $config){
                             		        echo $api->generate_wechat_menu_edit_html($config);
                             		    }
                             		}?>
                             	</ul>
                             </div>
                             
                             <script type="text/javascript">
                             	jQuery(function($){
                             		$(document).bind('on_wechat_menu_position_change',function(){
        								$('#<?php echo $field?>-menu-to-edit .menu-item.menu-item-depth-0').each(function(){
        									var $submenu = $(this).next('.menu-item.menu-item-depth-1');
        									if($submenu.length>0){
        										$('#menu-'+$(this).data('context')+'-content').hide();
        									}else{
        										$('#menu-'+$(this).data('context')+'-content').show();
        									}
        								});
        							});
        							
        							$(document).trigger('on_wechat_menu_position_change');
        							
        							var navMenu = xunhuwebNavMenu($('#<?php echo $field?>-menu-to-edit'));
        							 
        							$('#<?php echo $field?>-btn-add-menu').click(function(){
        								$('#wpbody-content').loading();
            							$.ajax({
            								url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_admin",'tab'=>'create_navbar_menu'),true,true)?>',
            								type:'post',
            								timeout:120*1000,
            								async:true,
            								cache:false,
            								dataType:'json',
            								complete:function(){
            									$('#wpbody-content').loading('hide');
            								},
            								success:function(e){
            									if(e.errcode!=0){
            										alert(e.errmsg);
            										return;
            									}
            									
            									navMenu.addMenuItemToBottom(e.data);
            									
            								},
            								error:function(e){
            									console.error(e.responseText);
            									alert('系统异常，请重试！');
            								}
            							});
        							});
        							$(document).bind('WrestOnMainFormSubmit',function(){
            							var menus = [];
										$('#<?php echo $field?>-menu-to-edit li.menu-item').each(function(){
											var $icon = $(this).find('.icon');
											var $icon_selected = $(this).find('.icon_selected');
											var menu = {
													page_title:$.trim($(this).find('.page-title').html()),
													page:$.trim($(this).find('.page').val()),
													page_param:$.trim($(this).find('.page_param').val()),
													icon:$icon.attr('src')?{
														url:$icon.attr('src'),
														width:$icon.data('width'),
														height:$icon.data('height')
													}:null,
													icon_selected:$icon_selected?{
														url:$icon_selected.attr('src'),
														width:$icon_selected.data('width'),
														height:$icon_selected.data('height')
													}:null
											};
											menus.push(menu);
										});

										$('#<?php echo $field?>').val(JSON.stringify(menus));
            						});
                                 });
        					</script>
                        </td>
                    </tr>
                     <?php 
                  },
                  'validate'=>function($key,$api){
                     $field = $api->get_field_key ( $key );
                     return isset($_POST[$field])&&$_POST[$field]? json_decode(stripslashes($_POST[$field]),true):null;
                  }
            )
        );
    }
    
    public function generate_wechat_menu_edit_html($config = null){
        return WRest::instance()->WP->requires(WREST_DIR, 'wechat/menu-edit.php',array(
            'request'=>$config,
            'context'=>WRest_Helper::generate_unique_id()
        ));
    }
}