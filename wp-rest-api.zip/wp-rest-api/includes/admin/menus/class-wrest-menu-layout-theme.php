<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Theme extends Abdtract_WRest_Setting_Layout{    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    public function __construct($version=null){
        parent::__construct($version);
        
        $this->id='menu-store-theme';
        $this->title='店铺主题';
        $this->init_form_fields();
    }

    public static function get_lineheight(){
        return 1.5;
    }
    public function init_form_fields(){
        if(!$this->version){
            return;
        }
        
        require_once 'class-wrest-menu-store-layout.php';
        $layout = WRest_Menu_Store_Layout::instance();
        
        $this->form_fields = array(
    		'subtitle_page'=>array(
    				'title'=>'页面',
    				'type'=>'subtitle'
    		),
    		'page_backgroundColor'=>array(
    				'title'=>'页面背景色',
    				'type'=>'color',
    				'default'=>'f3f3f3'
    		),
    		'page_backgroundTextStyle'=>array(
    				'title'=>'下拉 loading 的样式',
    				'type'=>'select',
    				'default'=>'dark',
    				'options'=>array(
    						'dark'=>'深色',
    						'light'=>'浅色'
    				)
    		),
            'subtitle_navigation'=>array(
                'title'=>'导航栏',
                'type'=>'subtitle'
            ),
    		'navigationBar_TextStyle'=>array(
    				'title'=>'导航栏图标风格',
    				'type'=>'select',
    				'default'=>'black',
    				'options'=>array(
    						'black'=>'黑色',
    						'white'=>'白色'
    				)
    		),
    		'statusBar_BackgroundColor'=>array(
    				'title'=>'状态栏背景颜色',
    				'type'=>'color',
    				'default'=>'ffffff',
    				'description'=>'注意，需要和“导航栏图标风格”形成色差，否在导致无法看见时间等状态栏信息'
    		),
            'navigationBar_BackgroundColor'=>array(
                'title'=>'导航栏背景颜色',
                'type'=>'color',
                'default'=>'ffffff'
            ),
    		'navigationBar_Textcolor'=>array(
    				'title'=>'导航栏标题文字颜色',
    				'type'=>'color',
    				'default'=>'000000',
    				'description'=>'注意，需要和“导航栏背景颜色”形成色差，否在导致无法看见标题'
    		),
            'subtitle_navbar'=>array(
                'title'=>'导航菜单',
                'type'=>'subtitle'
            ),
            'navbar_color'=>array(
                'title'=>'导航菜单文字默认颜色',
                'type'=>'color',
                'default'=>'707070',
            ),
		    'navbar_selectedColor'=>array(
		        'title'=>'导航菜单文字选中时的颜色',
		        'type'=>'color',
		        'default'=>'000000'
		    ),
		    'navbar_backgroundColor'=>array(
		        'title'=>'导航菜单背景色',
		        'type'=>'color',
		        'default'=>'ffffff'
		    ),
		    'navbar_borderStyle'=>array(
		        'title'=>'导航菜单上边框的颜色',
		        'type'=>'select',
		        'default'=>'white',
		        'options'=>array(
		            'white'=>'白色',
		            'black'=>'黑色'
		        )
		    ),
		    'navbar_position'=>array(
		        'title'=>'导航菜单的位置',
		        'type'=>'select',
		        'default'=>'bottom',
		        'options'=>array(
		            'bottom'=>'底部',
		            'top'=>'顶部'
		        )
		    )
            ,
            'subtitle_color_txt'=>array(
                'title'=>'文本内容颜色配置',
                'type'=>'subtitle'
            ),
            'color_main_i'=>array(
                'title'=> '主标题/导航',
                'type'=>'color',
                'default'=>'222222',
                'description'=>'页面内首要层级信息，一级标题'
            ),
            'color_main'=>array(
                'title'=> '主要内容',
                'type'=>'color',
                'default'=>'353535',
                'description'=>'如标题，列表菜单，导航标题'
            ),
            'color_sub'=>array(
                'title'=> '次要内容颜色',
                'type'=>'color',
                'default'=>'888888',
                'description'=>'文章内容等，次要内容，如副标题，摘要等'
            ),
            'color_placeholder'=>array(
                'title'=> '时间戳与表单缺省值',
                'type'=>'color',
                'default'=>'b2b2b2'
            ),
            'color_tab'=>array(
                'title'=> 'Tab菜单背景色',
                'type'=>'color',
                'default'=>'ffffff'
            ),
            'color_panel'=>array(
                'title'=> '面板(Panel)背景色',
                'type'=>'color',
                'default'=>'ffffff'
            ),
            'color_panel_active'=>array(
                'title'=> '面板(Panel)背景色（高亮）',
                'type'=>'color',
                'default'=>'F9F9F9',
                'description'=>'在面板内，需要重点关注区域的背景色'
            ),
            'color_link'=>array(
                'title'=> '可点击的文字链接',
                'type'=>'color',
                'default'=>'0f82ce',
            ),
            'color_handle_warning'=>array(
                'title'=> '高危操作文字',
                'type'=>'color',
                'default'=>'ed3f14',
                'description'=>'删除，退款等高危操作'
            ),
            'subtitle_active'=>array(
                'title'=> '高亮',
                'type'=>'subtitle'
            ),
            'color_active_border'=>array(
                'title'=> '高亮边框',
                'type'=>'color',
                'default'=>'e4007f',
                'description'=>'菜单选中，分类选中时的边框颜色'
            ),
            'color_active_bg'=>array(
                'title'=> '高亮背景',
                'type'=>'color',
                'default'=>'fdf2f8',
                'description'=>'菜单选中，分类选中时的背景颜色'
            ),
            'color_active_font'=>array(
                'title'=> '高亮文字',
                'type'=>'color',
                'default'=>'e4007f',
                'description'=>'菜单选中，分类选中时的文字颜色'
            ),
            'color_active_price'=>array(
                'title'=> '高亮价格',
                'type'=>'color',
                'default'=>'ff0000',
                'description'=>'醒目的价格颜色'
            ),
            'subtitle_color_btn'=>array(
                'title'=>'按钮',
                'type'=>'subtitle'
            ),
            'btn_default'=>array(
                'title'=> '按钮(Default)',
                'type'=>'button',
                'default'=>array(
                    'bg'=>'ffffff',
                    'font'=>'000000',
                    'border'=>'e4e4e4'
                )
            ),
            'btn_primary'=>array(
                'title'=> '按钮(Primary)',
                'type'=>'button',
                'default'=>array(
                    'bg'=>'242424',
                    'font'=>'ffffff',
                    'border'=>'171717'
                )
            ),
            'btn_warning'=>array(
                'title'=> '按钮(Warning)',
                'type'=>'button',
                'default'=>array(
                    'bg'=>'e64340',
                    'font'=>'ffffff',
                    'border'=>'d95856'
                )
            ),
            'btn_disabled'=>array(
                'title'=> '按钮(Disabled)',
                'type'=>'button',
                'default'=>array(
                    'bg'=>'f1f1f1',
                    'font'=>'aeaeae',
                    'border'=>'f1f1f1'
                )
            ),
            
            'subtitle_fontsize'=>array(
                'title'=>'字体大小配置',
                'type'=>'subtitle'
            ),
            'fontsize_big'=>array(
                'title'=> '超级醒目的提示(rpx)',
                'type'=>'integer',
                'default'=>'36',
                'description'=>'用户昵称等内容'
            ),

            'fontsize_main_i'=>array(
                'title'=> '主标题/导航(rpx)',
                'type'=>'integer',
                'default'=>'30',
                'description'=>'页面内首要层级信息，一级标题，一级导航标题'
            ),
            'fontsize_main'=>array(
                'title'=> '次级标题(rpx)',
                'type'=>'integer',
                'default'=>'28',
                'description'=>'页面内二级标题，二级导航标题'
            ),
            'fontsize_sub'=>array(
                'title'=> '内容或描述(rpx)',
                'type'=>'integer',
                'default'=>'24',
                'description'=>'大段的描述信息，促销信息，评论内容等次级信息'
            ),
            'fontsize_small'=>array(
                'title'=> '可以忽略的(rpx)',
                'type'=>'integer',
                'default'=>'22',
                'description'=>'页面弱化的内容，如商品原价等不需要关注的信息'
            ),
            'subtitle_border'=>array(
                'title'=>'边框配置',
                'type'=>'subtitle'
            ),
            'border_solid'=>array(
                'title'=> '通用实线边框',
                'type'=>'border',
                'default'=>array(
                    'color'=>'e5e5e5',
                    'size'=>1
                )
            ),
            'border_dashed'=>array(
                'title'=> '通用虚线边框',
                'type'=>'border',
                'default'=>array(
                    'color'=>'d2d2d2',
                    'size'=>1
                )
            ),
            'subtitle_other'=>array(
                'title'=>'其它',
                'type'=>'subtitle'
            ),
            'size'=>array(
                'title'=>'常规边距（padding|marging）',
                'type'=>'integer',
                'default'=>30,
                'description'=>'常规边距',
            ),
            'custom_css'=>array(
                'title'=>'自定义全局wxss',
                'type'=>'textarea',
                'css'=>'min-height:200px;min-width:400px',
                'default'=>$layout->get_field($this->version, 'WRest_Template_Layout_Body')->get_option('custom_css'),
                'placeholder'=>'view{color:#444;font-size:20rpx}',
                'description'=>'注意：样式规则遵循wxss写法，错误的css会导致小程序无法运行'
            )
        );
    }
}