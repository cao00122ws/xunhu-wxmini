<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WRest_Menu_Shop_Publish extends Abstract_WRest_Settings {
    /**
     * @var WRest_Menu_Order_Default_Settings
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='menu_shop_publish';
        $this->title='店铺发布';
        $this->description='提示：新增版本号，避免新版本导致线上版本不可用的异常。';
    }

    public function admin_form_start(){}
     
    public function admin_options(){
       ?>	
       	<div class="wrap">
            <h1 class="wp-heading-inline">历史版本</h1>
             <a href="javascript:void(0);" onclick="window.versionView.addVersion();">新增版本</a>
            <hr class="wp-header-end">
           
            <form id="posts-filter" method="get">
            	<br class="clear">
                <h2 class="screen-reader-text">历史版本  </h2>
                <table class="wp-list-table widefat fixed striped posts">
                	<thead>
                    	<tr>
                    		<th class="manage-column column-primary">版本号</th>
                    		<th class="manage-column">发布状态</th>
                    		<th class="manage-column">模版内容</th>
                    		<th class="manage-column">操作</th>
						</tr>
                	</thead>
                	<tbody id="the-list">
                		<?php 
                		  global $wpdb;
                		  $versions = $wpdb->get_results(
                		      "select *
                		       from {$wpdb->prefix}wrest_version
                		       order by id desc
                		       limit 50;");
                		  if(!$versions||count($versions)==0){
                		      ?><tr class="no-items"><td class="colspanchange" colspan="4">没有找到版本</td></tr>	<?php 
                		  }else{
                		      foreach ($versions as $version){
                		          $obj = new WRest_Version($version);
                		          ?>
                		          <tr>
                		          	<td><?php echo $obj->get_version_code();?></td>
                		          	<td><?php echo $obj->get_status_html();?></td>
                		          	<td><a href="<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'export','version_id'=>$obj->id),true,true)?>" target="_blank" class="zent-btn-default zent-btn">导出</a> | <a href="javascript:void(0)" onclick="window.versionView.import(<?php echo $obj->id;?>);" target="_blank" class="zent-btn-default zent-btn">导入</a></td>
                		          	<td>
                		          		
                		          		<?php 
                		          		  if(!defined('WREST_TEST_DOMAIN')){
                		          		          ?><a class="button" href="javascript:void(0);" onclick="window.versionView.remove(<?php echo $obj->id?>);" style="color:red;margin-left:5px;">删除</a><?php
                      		          		  
                      		          		      ?><a class="button" href="javascript:void(0);" onclick="window.versionView.publish(<?php echo $obj->id?>);" style="color:green;margin-left:5px;">发布</a><?php 
                		          		  }
                		          		?>
                		          	</td>
                		          </tr>
                		          <?php 
                		      }
                		  }
                		?>
                	</tbody>
                </table>
            </form>
            <br class="clear">
            <input type="file" id="version-import-file" name="file" style="display:none;"/>
            <script type="text/javascript" src="<?php echo WREST_URL?>/assets/js/ajaxfileupload.js"></script>
            <script type="text/javascript">
				(function($){
					$('#version-import-file').change(function(){
						if(!$(this).val()){return;}
						$.ajaxFileUpload({
							url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'import'),true,true)?>', //用于文件上传的服务器端请求地址
							type:'POST',
		                    secureuri: false, //是否需要安全协议，一般设置为false
		                    fileElementId: 'version-import-file', //文件上传域的ID
		                    dataType: 'Json', //返回值类型 一般设置为json
		                    data: {                    
		                        'version_id': $(this).attr('vid'),
		                    },
		                    success: function (data, status){
			                    if(typeof data=='string'){
			                    	data = $.parseJSON(data);
				                }
		                        if(data.errcode=='0'){
									alert('导入成功！');
									return;
			                    }

		                        alert('导入失败:'+data.errmsg);
		                    },
		                    error: function (data, status, e){ 
		                        alert('网络超时，请重试！');
		                    }
						}); 
					});
					  
					window.versionView={
						'import':function(vid){
							if(confirm('导入配置文件会覆盖当前版本的店铺配置，确认执行？')){
								$('#version-import-file').attr('vid',vid).click();
							}
						},
						remove_file:function(id){
							if(!confirm('确定删除文件?')){return false;}
							var request ={
								id:id
							};
							if(window.versionView.loading){return false;}
							window.versionView.loading = true;
							$.ajax({
					            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'remove_shop_file'),true,true)?>',
					            type: 'post',
					            timeout: 60 * 1000,
					            async: true,
					            cache: false,
					            data: request,
					            dataType: 'json',
					            beforeSend : function (XMLHttpRequest) {
					                XMLHttpRequest.setRequestHeader("request_type","ajax");
					                $('#posts-filter').loading('show');
					            },
					            complete: function() {
					            	$('#posts-filter').loading('hide');
					            	window.versionView.loading=false;
					            },
					            success: function(m) {
					            	if(m.errcode!=0){
					            		alert(m.errmsg);
										return;
									}

					            	location.reload();
					            },
					            error:function(e){
					            	alert('网络异常，请重试！');
					            	console.error(e.responseText);
					            }
					         });
						},
						rebuild_file:function(id){
							var request ={
								id:id
							};
							if(window.versionView.loading){return false;}
							window.versionView.loading = true;
							$.ajax({
					            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'rebuild_shop_file'),true,true)?>',
					            type: 'post',
					            timeout: 60 * 1000,
					            async: true,
					            cache: false,
					            data: request,
					            dataType: 'json',
					            beforeSend : function (XMLHttpRequest) {
					                XMLHttpRequest.setRequestHeader("request_type","ajax");
					                $('#posts-filter').loading('show');
					            },
					            complete: function() {
					            	$('#posts-filter').loading('hide');
					            	window.versionView.loading=false;
					            },
					            success: function(m) {
					            	if(m.errcode!=0){
					            		alert(m.errmsg);
										return;
									}

					            	location.href=m.data;
					            },
					            error:function(e){
					            	alert('网络异常，请重试！');
					            	console.error(e.responseText);
					            }
					         });
						},
						remove:function(id){
							var request ={
								id:id
							};
							if(window.versionView.loading){return false;}
							window.versionView.loading = true;
							$.ajax({
					            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'shop_version_remove'),true,true)?>',
					            type: 'post',
					            timeout: 60 * 1000,
					            async: true,
					            cache: false,
					            data: request,
					            dataType: 'json',
					            beforeSend : function (XMLHttpRequest) {
					                XMLHttpRequest.setRequestHeader("request_type","ajax");
					                $('#posts-filter').loading('show');
					            },
					            complete: function() {
					            	$('#posts-filter').loading('hide');
					            	window.versionView.loading=false;
					            },
					            success: function(m) {
					            	if(m.errcode!=0){
					            		alert(m.errmsg);
										return;
									}

					            	location.reload();
					            },
					            error:function(e){
					            	alert('网络异常，请重试！');
					            	console.error(e.responseText);
					            }
					         });
						},
						addVersion:function(){
							if(window.versionView.loading){return false;}
							window.versionView.loading = true;
							$.ajax({
					            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'add_version'),true,true)?>',
					            type: 'post',
					            timeout: 60 * 1000,
					            async: true,
					            cache: false,
					            data: {},
					            dataType: 'json',
					            beforeSend : function (XMLHttpRequest) {
					                XMLHttpRequest.setRequestHeader("request_type","ajax");
					                $('#posts-filter').loading('show');
					            },
					            complete: function() {
					            	$('#posts-filter').loading('hide');
					            	window.versionView.loading=false;
					            },
					            success: function(m) {
					            	if(m.errcode!=0){
					            		alert(m.errmsg);
										return;
									}

					            	location.reload();
					            },
					            error:function(e){
					            	alert('网络异常，请重试！');
					            	console.error(e.responseText);
					            }
					         });
						},
						publish:function(id){
							var request ={
								id:id
							};
							if(window.versionView.loading){return false;}
							window.versionView.loading = true;
							$.ajax({
					            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'shop_publish'),true,true)?>',
					            type: 'post',
					            timeout: 60 * 1000,
					            async: true,
					            cache: false,
					            data: request,
					            dataType: 'json',
					            beforeSend : function (XMLHttpRequest) {
					                XMLHttpRequest.setRequestHeader("request_type","ajax");
					                $('#posts-filter').loading('show');
					            },
					            complete: function() {
					            	$('#posts-filter').loading('hide');
					            	window.versionView.loading=false;
					            },
					            success: function(m) {
					            	if(m.errcode!=0){
					            		alert(m.errmsg);
										return;
									}

					            	location.href=m.data;
					            },
					            error:function(e){
					            	alert('网络异常，请重试！');
					            	console.error(e.responseText);
					            }
					         });
						}
					};
				})(jQuery);
            </script>
       </div>
      <?php 
	}
	
    public function admin_form_end(){} 
}