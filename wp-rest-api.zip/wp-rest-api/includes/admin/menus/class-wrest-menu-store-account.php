<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Account extends Abdtract_WRest_XCX_Setting_Menu{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    public function get_current_navbar_tab(){
        return false;
    }
    
    public function requiredAuth($version){
        return true;
    }
    
    public function isShowRightBar_Cart(){
        return false;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu-store-account';
        $this->title='个人中心';
    }

    public function get_template_type(){
    	return "account";
    }
    
    public function has_templates(){
        return false;
    }

    public function get_controllers($controllers = array()){
        $controllers['account'] = array(
            'title'=>'个人中心',
            'components'=>array(
                'WRest_Template_Userinfo'=>array(
                    'title'=>'用户信息'
                ),
                'WRest_Template_Useraddress'=>array(
                    'title'=>'配送地址'
                ),
                'WRest_Template_KF'=>array(
                    'title'=>'联系客服'
                ),
                'WRest_Template_Orderinfo'=>array(
                    'title'=>'订单信息'
                ),
                'WRest_Template_Wishlist'=>array(
                    'title'=>'产品收藏<span style="color:red">NEW</span>'
                ),
                'WRest_Template_Emailbind'=>array(
                    'title'=>'我的邮箱'
                )
            )
        );
        
        return parent::get_controllers($controllers);
    }
    
    public function get_config_data($version = null,&$version_obj=null){
        $fields = parent::get_config_data($version,$version_obj);
        if(!isset($fields['window']['navigationBarTitleText'])||empty($fields['window']['navigationBarTitleText'])){
            $fields['window']['navigationBarTitleText']='个人中心';
            $fields['window']['navHide']='yes';
            $fields['window']['requiredAuth']='yes';
        }
        
        if(!isset($fields['body'])||!count($fields['body'])){
            $fields['body']=array(
                array(
                    'type'=>'WRest_Template_Userinfo'
                ),
                array(
                    'type'=>'WRest_Template_Link',
                    'title'=>'我的订单',
                	'subtitle'=>'查看全部',
                    'border_bottom'=>'yes',
                    'link'=>array(
                        'url'=>'/package_a/pages/order/list/index'
                    )
                ),
                array(
                    'type'=>'WRest_Template_Orderinfo',
                ),
                
                
                array(
                    'type'=>'WRest_Template_Blank',
                    'height'=>30
                ),
                array(
                    'type'=>'WRest_Template_Useraddress',
                    'border_bottom'=>'yes'
                ),
                array(
                    'type'=>'WRest_Template_Wishlist',
                    'border_bottom'=>'yes',
                ),
                array(
                    'type'=>'WRest_Template_KF'
                )
            );
        }
        return $fields;
    }
}?>