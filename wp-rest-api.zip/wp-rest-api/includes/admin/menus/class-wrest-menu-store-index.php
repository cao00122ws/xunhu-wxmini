<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Index extends Abdtract_WRest_XCX_Setting_Menu{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    public function get_current_navbar_tab(){
        return '/pages/index/index';
    }
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu-store-index';
        $this->title='店铺首页';
        $this->init_form_fields();
    }
    
    public function get_template_type(){
    	return "index";
    }
    
    public function get_config_data($version = null,&$version_obj=null){
        $fields = parent::get_config_data($version,$version_obj);
        if(!isset($fields['window']['navigationBarTitleText'])||empty($fields['window']['navigationBarTitleText'])){
            $fields['window']['navigationBarTitleText']=get_bloginfo('name');
        }
        return $fields;
    }
}?>