<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Layout extends Abdtract_WRest_XCX_Setting_Menu{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * 
     * @var WRest_Theme
     */
    private $theme;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    public function get_current_navbar_tab(){
        return '/pages/index/index';
    }

    /**
     * @param WRest_Version $version
     * @param string $fieldkey
     * @param string $default
     * @return mixed
     */
    public function get_navbar_field($version,$fieldkey,$default = null){
        return $this->get_navbar($version)->get_option($fieldkey,$default);
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu-store-layout';
        $this->title='全局设置';
        $this->init_form_fields();
    }
    
    public function get_template_type(){
    	return "layout";
    }
    
    public function has_templates(){
        return false;
    }
    
    /**
     * @param WRest_Version $version
     * @param string $fieldkey
     * @param string $default
     * @return mixed
     */
    public function get_window_field($version,$fieldkey,$default = null){
        return $this->get_window($version)->get_option($fieldkey,$default);
    }
    
    public function get_theme($version){
        if($this->theme){
            return $this->theme;
        }
        
        $layout = WRest_Menu_Store_Layout::instance();
        $theme_id = $layout->get_field($version, 'WRest_Template_Layout_Body')->get_option('theme','blue');
        $theme = new WRest_Theme($theme_id);
        if(!$theme->is_load()){
            return null;
        }
        
        $theme->content = maybe_unserialize($theme->content);
        $this->theme = $theme;
        return $this->theme;
    }
    
    public function get_theme_color($version,$group,$field){
       $theme = $this->get_theme($version);
       
       return $theme&&$theme->content&&isset($theme->content[$group][$field])?$theme->content[$group][$field]:'';
    }
    
    public function render_templates($request,$response = array()){
        return new WP_Error(404,'your request is not found!',array('status'=>404));
    }
   
    public function get_controllers($controllers = array()){
        $controllers['layout'] = array(
            'title'=>'全局设置',
            'components'=>array(
                'WRest_Template_Layout_Window'=>array(
                    'title'=>'导航栏'
                ),
                'WRest_Template_Layout_Body'=>array(
                    'title'=>'主题'
                ),
                'WRest_Template_Layout_Navbar'=>array(
                    'title'=>'通用导航'
                )
            )
        );
        return parent::get_controllers($controllers);
    }
    
    public function get_navbar($version){
        if(!isset($this->_navbars[$version->id])){
            $config = $this->get_config($version);
            $this->_navbars[$version->id] = new WRest_Template_Layout_Navbar($version,0,$config&&is_array($config)&&isset($config['navbar'])&&is_array($config['navbar'])?$config['navbar']:array());
        }
    
        return $this->_navbars[$version->id];
    }
    
    public function get_window($version){
        if(!isset($this->_headers[$version->id])){
            $config = $this->get_config($version);
            $this->_headers[$version->id] = new WRest_Template_layout_Window($version,0,$config&&is_array($config)&&isset($config['window'])&&is_array($config['window'])?$config['window']:array());
        }
    
        return $this->_headers[$version->id];
    }
    
    /**
     * 
     * @param string $version
     * @return Abstract_WRest_Template_Layout
     */
    public function get_field($version,$class){
    	$config = $this->get_config($version);
    	$body_config =  $config&&is_array($config)&&isset($config['body'])&&is_array($config['body'])?$config['body']:array();
    	
    	$_config = array();
    	foreach ($body_config as $index=>$template){
    		$type = isset($template['type'])?$template['type']:null;
    		if(!$type){
    			continue;
    		}
    		
    		if($type==$class&&class_exists($class)){
    			return new $class($version,$index,$template);
    		}
    	}
    	
    	static $body_field;
    	if(!$body_field){$body_field=0;}
    	return new $class($version,$body_field++);
    }
    public function get_body($version){
    	return array(
    			$this->get_field($version,"WRest_Template_Layout_Body"),
    			$this->get_field($version,"WRest_Template_Layout_Search"),
    			$this->get_field($version,"WRest_Template_Layout_Products"),
    			$this->get_field($version,"WRest_Template_Layout_ProductFilter")
    	);
    }
    public function app_view_window($version_obj, $config){
        ?>
        <style type="text/css">
			.zent-design-preview-item {
			    position: relative;
			    margin: 10px 0;
			}
			#the-app-body{padding-top:1px;padding-bottom:1px;}
		</style>
        <div data-react-beautiful-dnd-droppable="0" class="zent-design__item-list" style="min-height:0px;padding-bottom: 0px" id="the-app-page">
			<?php 
			$this->get_window($version_obj)->render($this);
			?>
		</div>
        <?php
    }
    
    public function app_view_navbar($version_obj, $config){
        if($this->get_current_navbar_tab()){ ?>
			<div data-react-beautiful-dnd-droppable="0"  style="padding-bottom: 0px;min-height:0px;" class="zent-design__item-list" id="the-app-navbar">
        		<?php 
    			$this->get_navbar($version_obj)->render($this);
    			?>
			</div><?php 
        }
    }

    public function app_view_controls($version_obj,$config){}
    
    public function admin_options_content($version_obj,$editCall=null){
        if(!isset($_REQUEST['theme_id'])){
            parent::admin_options_content($version_obj);
            return;
        }
        
        $themeObj=null;
        if(!empty($_REQUEST['theme_id'])){
            $themeObj = new WRest_Theme(sanitize_text_field($_REQUEST['theme_id']));
            if(!$themeObj->is_load()){
                parent::admin_options_content($version_obj);
                return;
            }
            
            $theme = maybe_unserialize($themeObj->content);
            if(!$theme||!is_array($theme)){
                $theme = array();
            }
        }else{
            $theme = array();
        }

        $fields = array(
            'main'=>array(
                'title'=>'字体',
                'description'=>'微信内字体的使用与所运行的系统字体保持一致，常用字号为20, 18, 17, 16,14 13, 11(pt)，使用场景具体如下：',
                'fields'=>array(
                    'light'=>array(
                        'title'=>'Light',
                        'default'=>round(40*4/3),
                        'description'=>'只能为阿拉伯数字信息，如金额，时间等。'
                    )
                )
            )
        )
        ?>
        <style>
		  .theme-editor{
	           display:flex;
		  	   flex-direction:column;
		  	   padding:30px;
		  	   justify-content:flex-start;
		  }	
		  
		  .theme-field{
	           display:flex;
		  	   flex-direction:column;
		  	   justify-content:flex-start;
		  	   padding:20px;
		  	   border-bottom:solid 1px #f4f4f4;
		  }
		  .theme-field-title{
	           margin-bottom:20px;
		  	   font-size:18px;
		  }
		  .theme-field-description{
	           font-size:14px;
		  	   margin-bottom:10px;
		  }
		  .theme-field-content{
	           display:flex;
		  	   flex-direction:row;
		  	   flex-wrap:wrap;		  	
		  	   justify-content:flex-start;
		  }
		  .theme-field-item{
    		   height:80px;
    		   width:180px;
    		   display:flex;
		  	   flex-direction:column;
		  	   justify-content:center;
		  	   align-items:center;
		  	   margin:0 30px;
		  	   margin:30px;
           }
           .theme-field-item-view{
	          height:60px;
    		  width:180px;
           	  border-radius:10px;
		  	  border:solid 1px #d3d3d3;
           }
           .theme-field-item-edit{
	           margin-top:10px;
           	   font-size:14px;
           }
           .theme-field-item-edit-val{
	           font-size:12px;
           	    color:#444
           }
		</style>
		 <input type="hidden" value="<?php echo $themeObj?$themeObj->tid:'';?>" id="theme-id" />
        <div class="theme-editor">
        	<div class="theme-field">
        		<h5 class="theme-field-title">主题名称</h5>
        		<div class="theme-field-content">
        			<input type="text" style="width:400px;" placeholder="请输入主题名称" maxlength="120" id="theme-title" value="<?php echo $themeObj?esc_attr($themeObj->title):'';?>" />
        		</div>
        	</div>
        
        	<div class="theme-field">
        		<h5 class="theme-field-title">主色</h5>
        		<div class="theme-field-description">Primary作为主色调，Light Primary 常用于 hover，Dark Primary 常用于 active</div>
        		<div class="theme-field-content">
        			<?php 
            			$this->theme_field_item($theme,'main','primary','Primary');
            			$this->theme_field_item($theme,'main','light_primary','Light Primary');
            			$this->theme_field_item($theme,'main','dark_primary','Dark Primary');
        			?>
        		</div>
        	</div>
        	
        	<div class="theme-field">
        		<h5 class="theme-field-title">辅助色</h5>
        		<div class="theme-field-description">辅助色是具有代表性的颜色，常用于信息提示，比如成功、警告和失败。</div>
        		<div class="theme-field-content">
        			<?php 
            			$this->theme_field_item($theme,'alert','info','Info');
            			$this->theme_field_item($theme,'alert','success','Success');
            			$this->theme_field_item($theme,'alert','warning','购物车按钮背景色');
            			$this->theme_field_item($theme,'alert','error','优惠券背景色');
        			?>
        		</div>
        	</div>
        	
        	<div class="theme-field">
        		<h5 class="theme-field-title">中性色</h5>
        		<div class="theme-field-description">中性色常用于文本、背景、边框、阴影等，可以体现出页面的层次结构。</div>
        		<div class="theme-field-content">
        			<?php 
            			$this->theme_field_item($theme,'content','title','标题 Title');
            			$this->theme_field_item($theme,'content','content','正文 Content');
            			$this->theme_field_item($theme,'content','sub_color','辅助/图标 Sub Color');
            			$this->theme_field_item($theme,'content','disabled','失效 Disabled');
            			$this->theme_field_item($theme,'content','border','边框 Border');
            			$this->theme_field_item($theme,'content','divider','分割线 Divider');
            			$this->theme_field_item($theme,'content','background','背景 Background');
        			?>
        		</div>
        	</div>
        	
        	<div class="theme-field">
        		<h5 class="theme-field-title">其他</h5>
        		<div class="theme-field-description">优惠券，高亮选中标记色。</div>
        		<div class="theme-field-content">
        			<?php 
            			$this->theme_field_item($theme,'content','title','标题 Title');
            			$this->theme_field_item($theme,'content','content','正文 Content');
            			$this->theme_field_item($theme,'content','sub_color','辅助/图标 Sub Color');
            			$this->theme_field_item($theme,'content','disabled','失效 Disabled');
            			$this->theme_field_item($theme,'content','border','边框 Border');
            			$this->theme_field_item($theme,'content','divider','分割线 Divider');
            			$this->theme_field_item($theme,'content','background','背景 Background');
        			?>
        		</div>
        	</div>
        </div>
        <div class="save">
			<div class="inner">
				<button type="button" class="zent-btn-primary zent-btn" id="btn-reset-theme"><span>重置</span></button>  
				<button type="button" class="zent-btn-danger zent-btn" id="btn-save-theme"><span>保存</span></button>     					
			</div>
		</div>
        <script type="text/javascript">
			(function($){
				$('#btn-reset-theme').click(function(){
					<?php if($themeObj&&$themeObj->is_system&&isset(WRest_Theme::$default_themes[$themeObj->tid])){
					    ?>
					    var theme = <?php echo json_encode(WRest_Theme::$default_themes[$themeObj->tid]['content'])?>;
					    <?php 
					}else{
					    ?>
					    var theme = <?php echo $theme&&count($theme)>0?json_encode($theme):'{}'?>;
					    <?php 
					}?>
					
					for(var group in theme){
						var fields = theme[group];
						for(var field in fields){
							window['set_'+group+'_'+field+'_val'](fields[field]);
						}
					}
				});
				
				$('#btn-save-theme').click(function(){
					var form = {};
					$(document).trigger('onthemesubmit',form);
					if(window.loading){return;}
					window.loading=true;
					jQuery.ajax({
			            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'save_theme','version_id'=>$version_obj->id),true,true)?>',
			            type: 'post',
			            timeout: 60 * 1000,
			            async: true,
			            cache: false,
			            data: {
				            tid:$('#theme-id').val(),
				            title:$.trim($('#theme-title').val()),
							content:JSON.stringify(form)
				        },
			            dataType: 'json',
			            beforeSend  : function (XMLHttpRequest) {
			                XMLHttpRequest.setRequestHeader("request_type","ajax");
			                $('#app-container').loading('show');
			            },
			            complete: function() {
			            	window.loading=false;
			            	$('#app-container').loading('hide');
			            	window.templateView.loading=false;
			            },
			            success: function(m) {
			            	if(m.errcode!=0){
			            		alert(m.errmsg);
								return;
							}

			            	if(confirm('修改成功！(即将返回设置小程序模板)')){
			            		location.href='<?php echo admin_url('admin.php?page=wrest_page_default&section=menu_store_settings&sub=menu-store-layout')?>';
			            	}
			            },
			            error:function(e){
			            	alert('网络异常，请重试！');
			            	console.error(e.responseText);
			            }
			         });
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    private function theme_field_item($theme,$group,$field,$title){
        $default = isset($theme[$group][$field])?$theme[$group][$field]:'';
        $id="theme-{$group}-{$field}";
        $default = ltrim($default,'#');
        if(!$default){$default='ffffff';}
        ?>
        <div class="theme-field-item" > 
			<div id="<?php echo $id;?>-view" class="theme-field-item-view" style="background-color:#<?php echo $default ;?>"></div>
			<div class="theme-field-item-edit"><?php echo $title;?> 
			<span class="theme-field-item-edit-val" id="<?php echo $id;?>">#<?php echo $default ;?></span></div>
		</div>
		<script type="text/javascript">
			(function($){
				window.set_<?php echo "{$group}_{$field}"?>_val = function(color){
					$('#<?php echo $id;?>').text(color);
					$('#<?php echo $id;?>-view').css('background-color',color);
				};
				$('#<?php echo $id;?>-view').colpick({
				    layout:'full',
				    submit:0,
				    color:'<?php echo $default ?>',
				    colorScheme:'light',
				    onChange:function(hsb,hex,rgb,el,bySetColor) {
				    	$('#<?php echo $id;?>').text('#'+hex);
						$('#<?php echo $id;?>-view').css('background-color','#'+hex);
				    }
			    });

			    $(document).bind('onthemesubmit',function(e,form){
			    	if(!form.<?php echo $group?>){
			    		form.<?php echo $group?>={};
				    }

			    	form.<?php echo $group?>.<?php echo $field?> = $.trim($('#<?php echo $id;?>').text());
				});
			})(jQuery);
		</script>
        <?php 
    }
}