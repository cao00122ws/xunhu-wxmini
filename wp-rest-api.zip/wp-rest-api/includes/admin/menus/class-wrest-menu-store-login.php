<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Menu_Store_Login extends Abdtract_WRest_XCX_Setting_Menu{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ))
            self::$_instance = new self();
        return self::$_instance;
    }
    
    public function get_current_navbar_tab(){
        return false;
    }
    
    private function __construct(){
        $this->id='menu-store-login';
        $this->title='登录页面';
    }
    
    public function isShowRightBar(){
        return false;
    }
    
    public function requiredAuth($version){
        return false;
    }
    
    public function get_template_type(){
    	return "login";
    }
    
    public function has_templates(){
        return false;
    }

    public function get_config_data($version = null,&$version_obj=null){
        $fields = parent::get_config_data($version,$version_obj);
       if(!$fields){
           $fields = json_decode('{"window":{"type":"WRest_Template_Window","navigationBarTitleText":"微信登录","requiredAuth":""},"body":[{"type":"WRest_Template_Canvas","title_common":null,"auth_type":"default","item":{"items":[],"bg":{"url":"'.WREST_URL.'/assets/images/login/loginbg3.jpg","width":"750","height":"1627"}},"posi":{"position":"fixed","w":"center","h":"top","z_index":"0","w_len":"0","h_len":"0","width":"750"}},{"type":"WRest_Template_Canvas","title_common":null,"auth_type":"default","item":{"items":[{"link":{"url":"open-type-getUserInfo","params":""},"left":0,"top":0,"width":394,"height":39}],"bg":{"url":"'.WREST_URL.'/assets/images/login/loginbt1.png","width":"750","height":"84"}},"posi":{"position":"fixed","w":"center","h":"bottom","z_index":"100","w_len":"0","h_len":"200","width":"750"}},{"type":"WRest_Template_Canvas","title_common":null,"auth_type":"default","item":{"items":[{"link":{"url":"open-type-getPhoneNumber","params":""},"left":0,"top":0,"width":391,"height":46}],"bg":{"url":"'.WREST_URL.'/assets/images/login/loginbt2.png","width":"750","height":"84"}},"posi":{"position":"fixed","w":"center","h":"bottom","z_index":"200","w_len":"0","h_len":"90","width":"750"}}],"footer":[],"bg":[]}',true);
       }
        return $fields;
    }
}?>