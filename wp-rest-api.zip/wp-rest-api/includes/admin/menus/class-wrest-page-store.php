<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Page_Shop_Push extends Abstract_WRest_Settings_Page{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='page_store_push';
        $this->title='发布';
    }

    /* (non-PHPdoc)
     * @see Abstract_WRest_Settings_Menu::menus()
     */
    public function menus(){
        $submenus =array(
            WRest_Menu_Shoppage_Publish::instance(),
        );

        $return = apply_filters("wrest_admin_page_{$this->id}", WRest_Helper_Array::where($submenus, function($m){
            $menus= $m->menus();
            return count($menus)>0;
        }));

       return $return?$return:array();
    }
}    
/**
 * 菜单：登录设置
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Page_Shoppage extends Abstract_WRest_Settings_Page{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='page_store';
        $this->title='店铺管理';
    }
    
    /* (non-PHPdoc)
     * @see Abstract_WRest_Settings_Menu::menus()
     */
    public function menus(){
        $submenus =array(
        	WRest_Menu_Shoppage_Settings::instance(),
           // WRest_Menu_Shoppage_Publish::instance(),
        );
        
        $return = apply_filters("wrest_admin_page_{$this->id}", WRest_Helper_Array::where($submenus, function($m){
            $menus= $m->menus();
            return count($menus)>0;
        }));
        
        return $return?$return:array();
    }
}

class WRest_Menu_Shoppage_Base extends Abstract_WRest_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu_store_base';
        $this->title='店铺设置';
    }

    /* (non-PHPdoc)
     * @see Abstract_WRest_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wrest_admin_menu_{$this->id}", array(
            new WRest_Menu_Store_Base(),

            WRest_Menu_Default_Order::instance(),
        	//new WRest_Menu_Store_Order(),
            new WRest_Menu_Store_Theme(),
            new WRest_Menu_Store_Icon(),
           
        ));
    }
}

class WRest_Menu_Shoppage_Publish  extends Abstract_WRest_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='menu_store_publish';
        $this->title='店铺发布';
    }
    
    /* (non-PHPdoc)
     * @see Abstract_WRest_Settings_Menu::menus()
     */
    public function menus(){
        require_once 'class-wrest-menu-shop-publish.php';
        
        return apply_filters("wrest_admin_menu_{$this->id}", array(
            new WRest_Menu_Store_Pub(),
            WRest_Menu_Shop_Publish::instance(),
        ));
    }
}

class WRest_Menu_Shoppage_Settings extends Abstract_WRest_Settings_Menu{
	/**
	 * Instance
	 * @since  1.0.0
	 */
	private static $_instance;
	
	/**
	 * Instance
	 * @since  1.0.0
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) )
			self::$_instance = new self();
			return self::$_instance;
	}
	
	/**
	 * 菜单初始化
	 *
	 * @since  1.0.0
	 */
	private function __construct(){
		$this->id='menu_store_settings';
		$this->title='店铺页面';
		$this->hidden_in_nav = true;
	}
	
	/* (non-PHPdoc)
	 * @see Abstract_WRest_Settings_Menu::menus()
	 */
	public function menus(){
		return apply_filters("wrest_admin_menu_{$this->id}", array(
			WRest_Menu_Store_Index::instance(),
		    WRest_Menu_Store_Cat::instance(),
		    WRest_Menu_Store_CatDetail::instance(),
		    WRest_Menu_Store_Account::instance(),
		    WRest_Menu_Store_Login::instance(),
		));
	}
}