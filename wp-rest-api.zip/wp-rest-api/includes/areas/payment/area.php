<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WRest_Payment_Area extends Abstract_WRest_Area{
    public function __construct(){
        $this->namespace ='payment/v1';
    }
    
    public function requires(){
       require_once 'controllers/class-order-rest-controller.php';
       do_action('wrest_payment_area_requires');
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WRest_Area::controllers()
     */
    public function controllers(){
       return apply_filters('wrest_payment_controllers', array(
           new WRest_Order_Rest_Controller()
       ));
    }
}
