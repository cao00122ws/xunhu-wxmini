<?php
if (!defined('ABSPATH')) {
    exit ();
}

class WRest_Order_Rest_Controller extends Abstract_WRest_Controller {
    public function __construct() {
        $this->rest_base = 'order';
    }

    public function register_routes() {
        register_rest_route($this->namespace, "/{$this->rest_base}/index", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array(
                    $this,
                    'get_order_detail'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));
        
        register_rest_route($this->namespace, "/{$this->rest_base}/refund/imageupload", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array($this,'upload_refund_image'),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));
        
        register_rest_route($this->namespace, "/{$this->rest_base}/statuses", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array(
                    $this,
                    'get_order_statuses'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));
        register_rest_route($this->namespace, "/{$this->rest_base}/received", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array(
                    $this,
                    'received_order'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));
        register_rest_route($this->namespace, "/{$this->rest_base}/refund", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array(
                    $this,
                    'refund_order'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));
        
        register_rest_route($this->namespace, "/{$this->rest_base}/cancel", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array(
                    $this,
                    'cancel_order'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));

        
        register_rest_route($this->namespace, "/{$this->rest_base}/repay", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array(
                    $this,
                    're_pay_order'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));

        register_rest_route($this->namespace, "/{$this->rest_base}/list", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array(
                    $this,
                    'get_order_list'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));
        
        register_rest_route($this->namespace, "/{$this->rest_base}/add_comment", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array(
                    $this,
                    'add_comment'
                ),
                'permission_callback' => array(
                    $this,
                    'get_private_items_permissions_check'
                )
            )
        ));

        
        register_rest_route($this->namespace, "/{$this->rest_base}/pre-refund", array(
        		array(
        				'methods' => WP_REST_Server::ALLMETHODS,
        				'callback' => array(
        						$this,
        						'pre_refund'
        				),
        				'permission_callback' => array(
        						$this,
        						'get_private_items_permissions_check'
        				)
        		)
        ));
        
        
        register_rest_route($this->namespace, "/{$this->rest_base}/refund-m", array(
        		array(
        				'methods' => WP_REST_Server::ALLMETHODS,
        				'callback' => array(
        						$this,
        						'pre_refund_m'
        				),
        				'permission_callback' => array(
        						$this,
        						'get_private_items_permissions_check'
        				)
        		)
        ));
    }
    
    public function upload_refund_image($request){
        $order_ID = absint($request->get_param('id'));
        $order = WRest::instance()->get_product_api()->get_order($order_ID);
        if (!$order||!$order->is_load()) {
            return new WP_Error("notfound", '订单信息加载异常!', array('status' => 500));
        }
    
        $fileId = WRest_Helper::upload_image('file', $order_ID);
        if(is_wp_error($fileId)){
            return $fileId;
        }
    
        $res = array();
        $res['imgId'] = $fileId;
        $res['imgUrl'] = wp_get_attachment_image_url($fileId);
        return new WP_REST_Response($res);
    }
    
    public function pre_refund_m($request){
    	$api = WRest::instance()->get_product_api();
    	$version = $this->get_version($request);
    	if (is_wp_error($version)) {
    		return $version;
    	}
    	
    	return $api->pre_refund_order_m($version,$request);
    }
    
    /**
     * 
     * @param WP_REST_Request $request
     */
    public function pre_refund($request){
    	$api = WRest::instance()->get_product_api();
    	$version = $this->get_version($request);
    	if (is_wp_error($version)) {
    		return $version;
    	}
    	
    	return $api->pre_refund_order($version,absint($request->get_param('id')));
    }
    
    public function refund_order($request){
        $api = WRest::instance()->get_product_api();
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }
        
        return $api->refund_order($version, $request);
    }
    
    public function received_order($request) {
        $api = WRest::instance()->get_product_api();
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }
    
        return $api->received_order($version, absint($request->get_param('id')));
    }
    
    private function get_cancel_status_list(){
        $status_Api = WRest_Menu_Default_Order::instance();
        
        return array(
            $status_Api->get_status_name('wc-refunded','full'),
            $status_Api->get_status_name('wc-refund-hold','full'),
            $status_Api->get_status_name('wc-refund-failed','full'),
            $status_Api->get_status_name('wc-refunding','full'),
            $status_Api->get_status_name('wc-cancelled','full')
        );
    }
    
    
    /**
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_order_statuses($request){
        $counts = WRest::instance()->get_product_api()->get_user_order_counts();
        $sdk = $request->get_param('sdk');
        if($sdk&&version_compare($sdk, '1.0.1','>=')){
            return new WP_REST_Response(array(
                'total'=>array_sum(array_values($counts)),
                'items'=>array_values(Abstract_WRest_Order::get_status_group($counts))
            ));
        }
        
        //兼容老版本
        
        return new WP_REST_Response(array(
            'total'=>array_sum(array_values($counts)),
            'items'=>Abstract_WRest_Order::get_status_group($counts)
        ));
    }
    
    /**
     * 添加评论
     */
    public function add_comment($request){
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }
        
        //订单
        $orderId= absint($request->get_param('orderId'));
        $orderApi = WRest::instance()->get_product_api()->get_order($orderId);
        if(!$orderApi||!$orderApi->is_load()){
            return new WP_Error('fail-comment', '订单信息异常！', array('status' => 500));
        }
        
        if(!$orderApi->permission_check()){
            return new WP_Error('fail-comment', '你无权操作当前订单！', array('status' => 500));
        }
        
        $api_status = WRest_Menu_Default_Order::instance();
        $status_received = $api_status->get_status_name('wc-completed');
        if(!in_array( $orderApi->get_order()->get_status(),array( $status_received))){
            return new WP_Error('fail-comment', '订单未完成收货，无法进行评论！', array('status' => 500));
        }
        
        $_res = null;
        try {
            $_res=$this->check_comment($request,$request->get_params(),$version);
        } catch (Exception $e) {
            return new WP_Error('fail-comment', $e->getMessage(), array('status' => 500));
        }
      
        //不需要密码
        add_filter('post_password_required', function($false,$post){
            return false;
        },99,2);
        
        add_filter('wp_is_comment_flood', function($false){
            return false;
        },99,1);
        add_filter('duplicate_comment_id', function($false){
            return false;
        },10,1);
        $comments = array();
        
        foreach ($_res['products'] as $v){
            $_res1 = wp_handle_comment_submission( wp_unslash( $v ) );
            
            if($_res1 instanceof WP_Error) {
                foreach ($comments as $c){
                    wp_delete_comment($c->comment_ID,true);
                }
                return $_res1;
            }
            
            $comments[]=$_res1;
            if ( isset($v['rating'])&&$v['rating'] <= 5 && $v['rating'] >= 0) { 
			    update_comment_meta( $_res1->comment_ID, 'rating', absint( $v['rating'] ));
			}
		
            update_comment_meta($_res1->comment_ID,'wrest_imgs',is_array($v['imgs'])?$v['imgs']:[]);
        }
        
        update_post_meta($orderId,'wrest_order_comment',1);
        WRest::instance()->get_product_api()->clear_user_order_counts();
        
        //$api_status = WRest_Menu_Default_Order::instance();
        //$status_completed = $api_status->get_status_name('wc-completed');
         
//         if(!$orderApi->get_order()->update_status( $status_completed, '用户完成了订单评论！' )){
//             return new WP_Error('system-error','系统异常！',array('status'=>500));
//         }
        
        return new WP_REST_Response(array());
    }

    /**
     * 验证评论数据
     * return data|false
     */
    private function check_comment($request,$data,$version){
        //商品
        if(!$data['products']) {
            throw new Exception('评论信息异常:评论内容不能为空！');
        }
        
        if(!is_array($data['products'])) $data['products']=json_decode($data['products'],true);
        foreach ($data['products'] as $k=>$v){
            //comment_post_ID
            $v['comment_post_ID']=absint($v['comment_post_ID']);
            if(!wc_get_product($v['comment_post_ID'])){
                throw new Exception('评论信息异常:未找到评论对象！');
            }
            
            $data['products'][$k]['comment_post_ID']=$v['comment_post_ID'];
           
            if($v['comment']){
                $data['products'][$k]['comment']=sanitize_text_field($v['comment']);
            }else{
                $base = new WRest_Menu_Store_Base($version);
                $data['products'][$k]['comment']=sanitize_text_field($base->get_option('default_comment'));
            }
            //imgs
            if(!is_array($v['imgs'])) $v['imgs']=json_decode($v['imgs'],true);
            foreach ($v['imgs'] as $k1=>$v1){
                if(!get_post($v1)){
                    throw new Exception('评论图片信息异常，请核对！');
                }
            }
            
            $data['products'][$k]['imgs']=$v['imgs'];
            //comment_parent
            $v['comment_parent']=absint($v['comment_parent']);
            if($v['comment_parent']) {
                throw new Exception('评论信息异常:未找到评论对象！');
            }
            
            $data['products'][$k]['comment_parent']=$v['comment_parent'];
            //rating
            $v['rating']=absint($v['rating']);
            if($v['rating']<1||$v['rating']>5){
                $v['rating'] = 5;
            }
            $data['products'][$k]['rating']=$v['rating'];
        }
        return $data;
    }

    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_order_list($request) {
        $api = WRest::instance()->get_product_api();
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        $html_status = sanitize_text_field($request->get_param('status'));
        $page_index = absint($request->get_param('page_index'));
        if ($page_index <= 0) {
            $page_index = 1;
        }
        
        $statuses = wc_get_order_statuses();
        $v = sanitize_text_field($request->get_param('v'));
        if(version_compare($v, '1.0.1','>=')){
            if(empty($html_status)){
                return new WP_Error('invalid-request', '请求数据异常!', array('status' => 500));
            }
            
            return new WP_REST_Response($this->__get_order_list($version, $html_status, $page_index));
        }
        
        if ($html_status) {
            $wc_status = $api->html_status_to_wc_status($html_status);
            if (!isset($statuses[$wc_status])) {
                return new WP_Error('invalid-request', '请求数据异常!', array('status' => 500));
            }

            return new WP_REST_Response(array(
                'orderList' => array(
                    $html_status => $this->__get_order_list($version, $wc_status, $page_index)
                )
            ));
        }

        $results = array();
        foreach ($statuses as $wc_status => $title) {
            $results[$api->wc_status_to_html_status($wc_status)] = $this->__get_order_list($version, $wc_status, $page_index);
        }

        return new WP_REST_Response(array(
            'orderList' => $results
        ));
    }

    private function __get_order_list($version, $status, $page_index) {
        $api = WRest::instance()->get_product_api();
        $page_size = 24;
        $start = ($page_index - 1) * $page_size;

        $request = array(
            'fields' => 'ids',
            'post_type' => $api->order_type,
            'posts_per_page' => $page_size,
            'offset' => $start,
            'order' => 'DESC',
            'orderby' => 'ID',
            'meta_key' => '_customer_user',
            'meta_value' => get_current_user_id()
        );
        
        switch ($status){
            case 'wc-all';
                $request['post_status'] = array_keys(wc_get_order_statuses());
                break;
            default:
                $status_group = Abstract_WRest_Order::get_status_group(null);
                if(isset($status_group[$status])){
                    $request['post_status'] = $status_group[$status]['sub'];
                }else{
                    $request['post_status'] = apply_filters('wrest_query_order_list_status', $status);
                }
                
                break;
        }
        
        $wp_query = new WP_Query($request);
        $orders = array();
        foreach ($wp_query->posts as $post_ID){
            $order = $api->get_order($post_ID);
            if (!$order||!$order->is_load() || !$order->permission_check()) {
                continue;
            }
            
            $orders[] = $order->to_simple($version);
        }

        return array(
            'items' => $orders,
            'page_size' => $page_size,
            'page_index' => $page_index,
            'total_count' => $wp_query->found_posts,
            'page_count' => ceil($wp_query->found_posts * 1.0 / $page_size)
        );
    }

    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function re_pay_order($request) {
        $api = WRest::instance()->get_product_api();
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        return $api->process_re_checkout($version, $request);
    }

    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function cancel_order($request) {
        $api = WRest::instance()->get_product_api();
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        return $api->cancel_order($version, absint($request->get_param('id')));
    }

    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_order_detail($request) {
        $orderCall = apply_filters('wrest_order_detail_call', function($request){
            $api = WRest::instance()->get_product_api();
            $order = $api->get_order(absint($request->get_param('id')));
            if (!$order->is_load()) {
                return new WP_Error('order-not-found', '订单信息未找到！', array('status' => 500));
            }
            if (!$order->permission_check()) {
                return new WP_Error('view-permission-limit', '您没有权限访问当前订单！', array('status' => 500));
            }
            if ('Y' == $request->get_param('checkorder') && $order) {
                $order->process_payment_check();
            }
            
            $version = WRest::instance()->WP->get_version($request);
            if (is_wp_error($version)) {
                return $version;
            }
            
            return $order->to_detail($version);
        },$request);
        
        $api_status = WRest_Menu_Default_Order::instance();
//         $status_received = $api_status->get_status_name('wc-completed');
//         $status_completed = $api_status->get_status_name('wc-completed');
        
        $order = call_user_func($orderCall,$request);
        return new WP_REST_Response(array(
            'orderInfo' => $order,
            'status_completed'=>"wrest-completed" ,
            'status_comment' =>"wrest-completed" 
        ));
    }
}