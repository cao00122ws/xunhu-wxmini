<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WRest_Product_Area extends Abstract_WRest_Area{
    public function __construct(){
        $this->namespace ='product/v1';
    }
    
    public function requires(){
        require_once 'controllers/class-cart-rest-controller.php';
        require_once 'controllers/class-shipping-rest-controller.php';
        require_once 'controllers/class-wc-sinic-rest-controller.php';
        require_once 'controllers/class-product-rest-controller.php';
        require_once 'controllers/class-wc-social-login-rest-controller.php';
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WRest_Area::controllers()
     */
    public function controllers(){
       return array(
           new WRest_Cart_Rest_Controller(),
           new WRest_Product_Rest_Controller(),
           new WRest_Shipping_Rest_Controller(),
           new WRest_Wc_Sinic_Rest_Controller(),
           new WRest_Wc_Social_Login_Rest_Controller(),
       );
    }
}
