<?php
if (! defined ( 'ABSPATH' )) {
	exit ();
}

class WRest_Product_Rest_Controller extends Abstract_WRest_Controller {
	public function __construct() {
		$this->rest_base = 'product';
	}
	public function register_routes() {
		register_rest_route ( $this->namespace, "/{$this->rest_base}/changeFav", array (
		    array (
		        'methods' => WP_REST_Server::CREATABLE,
		        'callback' => array ($this,'changeFav'),
				'permission_callback' => array (
						$this,
						'get_private_items_permissions_check'
				)
		    )
		));
		register_rest_route ( $this->namespace, "/{$this->rest_base}/wl", array (
		    array (
		        'methods' => WP_REST_Server::ALLMETHODS,
		        'callback' => array ($this,'getwishlist'),
		        'permission_callback' => array (
		            $this,
		            'get_private_items_permissions_check'
		        )
		    )
		));
		register_rest_route ( $this->namespace, "/{$this->rest_base}/wishlist", array (
		    array (
		        'methods' => WP_REST_Server::ALLMETHODS,
		        'callback' => array ($this,'getwishlist'),
		        'permission_callback' => array (
		            $this,
		            'get_private_items_permissions_check'
		        )
		    )
		));
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/addCoupon", array (
		    array (
		        'methods' => WP_REST_Server::ALLMETHODS,
		        'callback' => array ($this,'addCoupon'),
		        'permission_callback' => array (
		            $this,
		            'get_private_items_permissions_check'
		        )
		    )
		));

		register_rest_route ( $this->namespace, "/{$this->rest_base}/coupons", array (
		    array (
		        'methods' => WP_REST_Server::ALLMETHODS,
		        'callback' => array ($this,'getCoupons'),
		        'permission_callback' => array (
		            $this,
		            'get_private_items_permissions_check'
		        )
		    )
		));
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function getCoupons($request){
	    $version = $this->get_version ( $request );
	    if (is_wp_error ( $version )) {
	        return $version;
	    }
	    
	    $user_ID = get_current_user_id();
	    global $wpdb;
	    $now = current_time( 'timestamp' );
	    $results = $wpdb->get_results(
	       "select w.id,
	               w.coupon_id,
	               w.status
	        from {$wpdb->prefix}wrest_coupon w
	        where w.user_ID={$user_ID}
	              and w.status in('prepare','using')
	        order by w.created_time desc
	        limit 50;");
	    
	    $response = array();
	    $invalid=array();
	    foreach ($results as $item){
	        $coupon = new WC_Coupon($item->coupon_id);
	        if(!$coupon->get_id()){
	            $wpdb->query("delete from {$wpdb->prefix}wrest_coupon where id={$item->id}");
	            continue;
	        }
	        
	        $model = WRest_Coupon::to_detail($coupon);
	        $model['is_using'] = $item->status=='using';
	        $model['is_valid'] =$item->status=='prepare'&&WRest_Coupon::is_valid_for_cart($coupon);
	        if($model['is_valid']){
	            $response[]= $model;
	        }else{
	            $invalid[]=$model;
	        }
	    }
	    
	    foreach ($invalid as $item){
	        $response[]=$item;
	    }
	    
	    WRest_Domain_WC::refresh_user_coupon();
	    return new WP_REST_Response(array(
	        'items'=>$response
	    ));
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function addCoupon($request){
	    $version = $this->get_version ( $request );
	    if (is_wp_error ( $version )) {
	        return $version;
	    }
	    
	    $coupon_id = $request->get_param('id');
	    $coupon = new WC_Coupon($coupon_id);
	    if(!$coupon->get_id()){
	        return new WP_Error('invalid-rquest','优惠券信息未找到!',array('status'=>500));
	    }
	    
	    $couponApi = WRest_Coupon::load($coupon);
        if($couponApi){
            return new WP_Error('invalid-rquest','您已领取过当前优惠券!',array('status'=>500));
        }
        
        $user_ID =  get_current_user_id();
        $wrest_coupon = new WRest_Coupon();
        $wrest_coupon->coupon_id = $coupon->get_id();
        $wrest_coupon->created_time = current_time( 'timestamp');
        $wrest_coupon->status = 'prepare';
        $wrest_coupon->user_ID =$user_ID;
        
        $error = $wrest_coupon->insert();
        if(!WRest_Error::is_valid($error)){
            return $error;
        }
        
        WRest_Domain_WC::refresh_user_coupon();
        
        return new WP_REST_Response(array(
            'coupon_id'=>$coupon->get_id(),
            'isIncluded'=>true
        ));
	}

	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function getwishlist($request){
	    $version = $this->get_version ( $request );
	    if (is_wp_error ( $version )) {
	        return $version;
	    }
	    
	    $api = WRest::instance()->get_product_api();
	    $pageIndex = absint($request->get_param('pageIndex'));
	    if($pageIndex<1){$pageIndex = 1;}
	    $pageSize = 24;
	    
	    $res =WRest_Wishlist::get_wishlist($pageIndex, $pageSize, 'product');
	    if(is_wp_error($res)){
	        return $res;
	    }
	    
	    $items = $res['items'];
	    $total_qty= $res['total_count'];
	    
	    $results = array();
	    if($items){
	        foreach($items as $post_ID){
	            $product = $api->get_product($post_ID)->to_simple($version,'woocommerce_single');
	            if(!$product){
	                continue;
	            }
	            $results[]=$product;
	        }
	    }
	    
	    $modal = 'detail';
	    return new WP_REST_Response(array(
	        'modal'=>$modal,
	        'items'=>Abstract_WRest_Product::to_list_mode($modal, $results),
	        'total_count'=>$total_qty,
	        'page_count'=>absint(ceil(($total_qty*1.0)/$pageSize)),
	        'page_index'=>$pageIndex,
	        'pageSize'=>$pageSize
	    ));
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function changeFav($request){
	    $product = wc_get_product(absint($request->get_param('id')));
	    if(!$product){
	        return new WP_Error('NOT-found','产品信息未找到！',array('status'=>404));
	    }
	    
	    if(WRest_Wishlist::is_in_wishlist($product->get_id(), 'product')){
	        return WRest_Wishlist::remove_wishlist($product->get_id(), 'product');
	    }else{
	        return WRest_Wishlist::add_wishlist($product->get_id(), 'product');
	    }
	}
}