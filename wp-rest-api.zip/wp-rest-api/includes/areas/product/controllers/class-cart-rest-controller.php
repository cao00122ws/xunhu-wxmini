<?php
if (! defined ( 'ABSPATH' )) {
	exit ();
}
require_once WREST_DIR . '/includes/admin/abstracts/abstract-wrest-xcx-setting.php';
require_once WREST_DIR . '/includes/admin/menus/class-wrest-menu-store-index.php';
class WRest_Cart_Rest_Controller extends Abstract_WRest_Controller {
	public function __construct() {
		$this->rest_base = 'checkout';
	}
	public function register_routes() {
		register_rest_route ( $this->namespace, "/{$this->rest_base}/index", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'process_checkout'
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check'
						)
				)
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/pre", array (
		    array (
		        'methods' => WP_REST_Server::CREATABLE,
		        'callback' => array (
		            $this,
		            'pre_checkout'
		        ),
		        'permission_callback' => array (
		            $this,
		            'get_private_items_permissions_check'
		        )
		    )
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/address/save", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'save_address'
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check'
						)
				)
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/shipping/update", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'update_shipping'
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check'
						)
				)
		) );
		
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/gateway/update", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'update_gateway'
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check'
						)
				)
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/coupon/add", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'add_coupon'
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check'
						)
				)
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/coupon/remove", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'remove_coupon'
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check'
						)
				)
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/cart/add", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'add_to_cart' 
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check' 
						) 
				) 
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/cart/clear", array (
		    array (
		        'methods' => WP_REST_Server::CREATABLE,
		        'callback' => array (
		            $this,
		            'clear_cart'
		        ),
		        'permission_callback' => array (
		            $this,
		            'get_private_items_permissions_check'
		        )
		    )
		) );
		
		register_rest_route ( $this->namespace, "/{$this->rest_base}/cart/set_quantity", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'cart_set_quantity' 
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check' 
						) 
				) 
		) );
		register_rest_route ( $this->namespace, "/{$this->rest_base}/cart/get", array (
				array (
						'methods' => WP_REST_Server::ALLMETHODS,
						'callback' => array (
								$this,
								'cart_get' 
						) 
				) 
		) );
		register_rest_route ( $this->namespace, "/{$this->rest_base}/cart/remove", array (
				array (
						'methods' => WP_REST_Server::CREATABLE,
						'callback' => array (
								$this,
								'cart_removeitem' 
						),
						'permission_callback' => array (
								$this,
								'get_private_items_permissions_check' 
						) 
				) 
		) );
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function pre_checkout($request){
	    $version = $this->get_version ( $request );
	    if (is_wp_error ( $version )) {
	        return $version;
	    }
	    
	    return WRest::instance ()->get_product_api ()->pre_process_checkout( $version, $request );
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function process_checkout($request){
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		
		do_action('wrest_collection_form_id',$request);
		
		return WRest::instance ()->get_product_api ()->process_checkout( $version, $request );
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function update_gateway($request){
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		
		return WRest::instance ()->get_product_api ()->cart_update_payment_method( $version, $request );
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function update_shipping($request){
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		
		return WRest::instance ()->get_product_api ()->cart_update_shipping_method( $version, $request );
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function add_coupon($request){
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		
		$coupon_code = $request->get_param('coupon_code');
		return WRest::instance ()->get_product_api ()->cart_add_coupon( $version, $coupon_code );
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function remove_coupon($request){
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		
		$coupon_code = $request->get_param('coupon_code');
		return WRest::instance ()->get_product_api ()->cart_remove_coupon( $version, $coupon_code );
	}

	/**
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function save_address($request){
		return WRest::instance ()->get_product_api ()->save_address ($request);
	}
	
	/**
	 *
	 * @param WP_REST_Request $request        	
	 * @return WP_REST_Response
	 */
	public function add_to_cart($request) {
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		do_action('wrest_collection_form_id',$request);
		return WRest::instance ()->get_product_api ()->add_to_cart ( $version, $request );
	}

	/**
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function clear_cart($request) {
	    $version = $this->get_version ( $request );
	    if (is_wp_error ( $version )) {
	        return $version;
	    }
	    do_action('wrest_collection_form_id',$request);
	    return WRest::instance ()->get_product_api ()->clear_cart ( $version, $request );
	}
	
	
	public function cart_set_quantity($request) {
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		do_action('wrest_collection_form_id',$request);
		return WRest::instance ()->get_product_api ()->cart_set_quantity ( $version, $request );
	}
	
	public function cart_removeitem($request) {
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		do_action('wrest_collection_form_id',$request);
		return WRest::instance ()->get_product_api ()->cart_remove_item ( $version, $request );
	}
	public function cart_get($request) {
		$version = $this->get_version ( $request );
		if (is_wp_error ( $version )) {
			return $version;
		}
		
		$include_product=$request->get_param('include_product')=='yes';
		$include_checkout=$request->get_param('include_checkout')=='yes';
		return new WP_REST_Response ( WRest::instance ()->get_product_api ()->get_cart ( $version ,array(
				'include_product'=>$include_product,
				'include_checkout'=>$include_checkout
		)) );
	}
}