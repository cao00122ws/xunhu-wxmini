<?php
if (!defined('ABSPATH')) {
    exit ();
}

class WRest_Shipping_Rest_Controller extends Abstract_WRest_Controller
{
    public function __construct()
    {
        $this->rest_base = 'shipping';
    }

    public function register_routes()
    {
        register_rest_route($this->namespace, "/{$this->rest_base}", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this,'get_shipping'],
                'schema' => [$this, 'get_private_items_permissions_check']
            )
        ));
    }

    public function get_shipping($request){
        $version = $this->get_version ( $request );
        if (is_wp_error ( $version )) {
            return $version;
        }

        $api = WRest::instance ()->get_product_api ();
        $order = $api->get_order( absint($request->get_param('id')));
        if(!$order->is_load()){
            return new WP_Error('order-not-found','订单信息未找到！',array('status'=>500));
        }
        if(! $order->permission_check()){
            return new WP_Error('view-permission-limit','您没有权限访问当前订单！',array('status'=>500));
        }

        $response = $order->get_shipping();
        return array(
            'hashShipping'=>$order->has_shipping(),
            'company' => $response&&isset($response['company'])?$response['company']:'',
            'shipping_no' =>$response&&isset($response['shipping_no'])?$response['shipping_no']:'',
            'status' => $response&&isset($response['status'])?$response['status']:'',
            'detail' => $response&&isset($response['detail'])&&$response['detail']?$response['detail']:[],
        );;
    }
}