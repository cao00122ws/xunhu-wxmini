<?php
if (!defined('ABSPATH')) {
    exit ();
}

class WRest_Wc_Sinic_Rest_Controller extends Abstract_WRest_Controller
{
    public function __construct()
    {
        $this->rest_base = 'wc_sinic';
    }

    public function register_routes()
    {
        register_rest_route($this->namespace, "/{$this->rest_base}/check_idcard", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this,'check_idcard'],
                'schema' => [$this, 'get_private_items_permissions_check']
            )
        ));
        
        register_rest_route($this->namespace, "/{$this->rest_base}/check_idcard/pre", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => [$this,'check_idcard_pre'],
                'schema' => [$this, 'get_private_items_permissions_check']
            )
        ));
    }
    
    public function check_idcard_pre($request){
        $version = $this->get_version ( $request );
        if (is_wp_error ( $version )) {
            return $version;
        }
        
        $base = new WRest_Menu_Store_Base($version);
        return new WP_REST_Response(array(
            'license_title'=>'跨境购物须知',
            'license_page_id'=>$base->get_option('idcard_license')
        ));
    }

    public function check_idcard($request){
        $version = $this->get_version ( $request );
        if (is_wp_error ( $version )) {
            return $version;
        }
        
        $username=$request->get_param('username');
        $idcard=$request->get_param('idcard');
        if(!$username||!$idcard){
            return new WP_Error("invalid",'请正确填写身份信息!',array('status'=>500));
        }
        
        $now = time();
        $last_idcard_check_time = absint(WC()->session->get('wrest_last_idcard_check_time'));
        $left = $now-$last_idcard_check_time;
        if($last_idcard_check_time&&$left<60&&$left>0){
            $left = 60-$left;
            return new WP_Error("invalid","请等待{$left}秒后重试！",array('status'=>500));
        }
        
        WC()->session->set('wrest_last_idcard_check_time',$now);
        $res=WC_Sinic_Add_On_Aliyun_Idcard::instance()->check_idcard($username,$idcard);
        if(!$res){
            return new WP_Error("invalid","身份信息不匹配，请重试!",array('status'=>500));
        }
        
        return new WP_REST_Response(array(
            'success'=>true
        ));
    }
}