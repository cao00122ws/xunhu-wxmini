<?php
if (!defined('ABSPATH')) exit;

class WRest_Wc_Social_Login_Rest_Controller extends Abstract_WRest_Controller {
    public function __construct() {
        $this->rest_base = 'wc_social_login';
    }

    public function register_routes() {
        register_rest_route($this->namespace, "/{$this->rest_base}/email", [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'email'],
                'schema' => [$this, 'get_private_items_permissions_check']
            ]
        ]);
        register_rest_route($this->namespace, "/{$this->rest_base}/email/send_code", [
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'send_code'],
                'schema' => [$this, 'get_private_items_permissions_check']
            ]
        ]);
        register_rest_route($this->namespace, "/{$this->rest_base}/email/bind", [
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [$this, 'email_bind'],
                'schema' => [$this, 'get_private_items_permissions_check']
            ]
        ]);
    }

    //获取用户邮箱
    public function email($request){
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        global $current_user;
        return new WP_REST_Response([
            'email_info'=>[
                'email' => $current_user->user_email?$current_user->user_email:'',
            ]
        ]);
    }

    //发送验证码
    public function send_code($request){
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        $email=trim($request->get_param('email'));
        if(!is_email($email)){
            return new WP_Error("invalid", '邮箱格式错误!', array('status' => 500));
        }

        $code = substr(str_shuffle(time()), 0,6);
        wc()->session->set("{$email}_email_code",$code);

        //测试
        //return new WP_REST_Response(['success' => true,'email_code'=>$code]);

        $subject = apply_filters('wsocial_email_validate_subject',sprintf( __("[%s]identity verification",XH_SOCIAL),get_option('blogname')));
        $message = apply_filters('wsocial_email_validate_subject', __("Hello!Your verification code is:",XH_SOCIAL)."\r\n\r\n".$code."\r\n\r\n".__("If this was a mistake, just ignore this email and nothing will happen.",XH_SOCIAL));
        if(defined('XH_MOBILE_TEST')&&XH_MOBILE_TEST){
            echo XH_Social_Error::error_custom(print_r(array(
                'subject'=>$subject,
                'content'=>$message
            ),true))->to_json();
        }

        add_action('wp_mail_failed', function($error){
            if(!$error instanceof WP_Error){
                return true;
            }
            return new WP_Error("invalid", $error->get_error_message(), array('status' => 500));
        },10,1);

        try {
            if(@wp_mail($email, $subject, $message)){
                return new WP_REST_Response(['success' => true]);
            }else{
                return new WP_Error("invalid", '发送邮件失败', array('status' => 500));
            }
        } catch (Exception $e) {
            return new WP_Error("invalid", $e->getMessage(), array('status' => 500));
        }
    }

    //邮箱绑定
    public function email_bind($request){
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        $email=trim($request->get_param('email'));
        $code=trim($request->get_param('code'));
        if(!is_email($email)){
            return new WP_Error("invalid", '邮箱错误!', array('status' => 500));
        }
        $email_code= wc()->session->get("{$email}_email_code");
        if(mb_strlen($code,"utf-8")!=6||$code!=$email_code){
            return new WP_Error("invalid", '验证码错误!', array('status' => 500));
        }

        global $current_user;

        //判断邮箱是否已存在
        $user=get_user_by('email',$email);
        if($user){
            if($user->ID!=$current_user->ID){
                return new WP_Error("invalid", "邮箱已经绑定账户:{$user->user_login}，请更换新邮箱!", array('status' => 500));
            }
        }

        //修改用户邮箱
        $res=wp_update_user(['ID'=>$current_user->ID,'user_email'=>$email]);
        if(!$res){
            return new WP_Error("invalid", '邮箱绑定失败!', array('status' => 500));
        }else{
            return new WP_REST_Response(['success' => true]);
        }
    }

}