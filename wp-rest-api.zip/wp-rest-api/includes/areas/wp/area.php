<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WRest_WP_Area extends Abstract_WRest_Area{
    public function __construct(){
        $this->namespace ='wp/v1';
    }
    
    public function requires(){
        require_once 'controllers/class-article-rest-controller.php';
        require_once 'controllers/class-store-rest-controller.php';
        require_once 'controllers/class-user-rest-controller.php';
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WRest_Area::controllers()
     */
    public function controllers(){
       return array(
           new WRest_Article_Rest_Controller(),
           new WRest_Store_Rest_Controller(),
           new WRest_User_Rest_Controller()
       );
    }
}