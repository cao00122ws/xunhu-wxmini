<?php
if (!defined('ABSPATH')) {
    exit;
}

class WRest_Article_Rest_Controller extends Abstract_WRest_Controller {

    public function __construct() {
        $this->rest_base = 'article';
    }

    public function register_routes() {
        register_rest_route($this->namespace, "/{$this->rest_base}/cate", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array($this, 'get_article_cate'),
            )
        ));
        register_rest_route($this->namespace, "/{$this->rest_base}/list", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array($this, 'get_article_list'),
            )
        ));
        register_rest_route($this->namespace, "/{$this->rest_base}/tags", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array($this, 'get_search_tags'),
            )
        ));
        register_rest_route($this->namespace, "/{$this->rest_base}/art_pds", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array($this, 'get_article_and_products'),
            )
        ));

        register_rest_route($this->namespace, "/add_comment", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array($this, 'add_comment'),
                'permission_callback' => array($this, 'get_private_items_permissions_check'),
            )
        ));

        register_rest_route($this->namespace, "/comments", array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_comments'),
            )
        ));
        register_rest_route($this->namespace, "/comments_child", array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'getChildComments'),
            )
        ));
        register_rest_route($this->namespace, "/upload_comment_img", array(
            array(
                'methods' => WP_REST_Server::ALLMETHODS,
                'callback' => array($this, 'uploadImgByComment'),
                'permission_callback' => array($this, 'get_private_items_permissions_check')
            )
        ));
        register_rest_route($this->namespace, "/del_comment", array(
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array($this, 'del_comment'),
                'permission_callback' => array($this, 'get_private_items_permissions_check')
            )
        ));
    }

    /**
     * 删除评论
     */
    public function del_comment($request) {
        $id = $request->get_param('id') ? absint($request->get_param('id')) : -1;
        $_res = get_comment($id);
        if (!$_res) return new WP_Error("Delete failed", "删除失败!没有此评论", ['status' => 500]);
        if ($_res->user_id != get_current_user_id() && !current_user_can('manage_options'))
            return new WP_Error("Delete failed", "删除失败!无删除权限", ['status' => 500]);
        
        $_res1 = wp_delete_comment($id);
        if (!$_res1) return new WP_Error("Delete failed", "删除失败!", ['status' => 500]);
        return new WP_REST_Response(['res' => 1]);
    }

    /**
     * 提交评论
     */
    public function add_comment($request) {
        do_action('wrest_collection_form_id',$request);
        
        $params = $request->get_params();
        $params['imgs'] = isset($params['imgs']) ? $params['imgs'] : '';
        $params['imgs'] = json_decode($params['imgs'], true);
     
        $_res = wp_handle_comment_submission(wp_unslash($params));
        if ($_res instanceof WP_Error) return $_res;

        update_comment_meta($_res->comment_ID, 'wrest_imgs', is_array($params['imgs']) ? $params['imgs'] : []);
       
        $res = [
            'id' => $_res->comment_ID,
            'author' => $_res->comment_author,
            'authorImg' => $_res->user_id ? get_avatar_url($_res->user_id) : WREST_URL . '/assets/images/avatar/default.jpg',
            'content' => $_res->comment_content,
            'imgs' => WRest_Comment::getImgsByImgIds($params['imgs']),
            'date' => '刚刚',
            'reply' => 0,
        ];
        return new WP_REST_Response($res);
    }

    /**
     * 根据评论id查询回复
     */
    public function getChildComments($request) {
        $id = absint($request->get_param('id'));
        $pageindex = absint($request->get_param('page'));
        $commment = get_comment($id);
        if(!$commment){
            return new WP_Error("notfound", '评论信息加载异常!', array('status' => 404));
        }
        
        WRest_Hooks::update_comment_count($commment->comment_ID, $commment);
        
        $api = new WRest_Comment($commment->comment_post_ID,$commment->comment_ID);
        return new WP_REST_Response($api->get_comments($pageindex));
    }

    /**
     * 获取评论
     */
    public function get_comments($request) {
        $id = absint($request->get_param('id'));
        $post = get_post($id);
        if (!$post) return new WP_Error('post-not-found', 'Post not found!', array('status' => 404));
    
        $api = new WRest_Comment($post->ID);
        return new WP_REST_Response($api->get_comments($request->get_param('page')));
    }
    
    /**
     * 上传图片，返回图片ID
     */
    public function uploadImgByComment($request) {
        $postId = absint($request->get_param('id'));
        if (!get_post($postId)) {
            return new WP_Error("notfound", '文章信息加载异常!', array('status' => 404));
        }

        $fileId = WRest_Helper::upload_image('file', $postId);
        if(is_wp_error($fileId)){
            return $fileId;
        }
        
        $res = array();
        $res['imgId'] = $fileId;
        $res['imgUrl'] = wp_get_attachment_image_url($fileId);
        return new WP_REST_Response($res);
    }

    /**
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_article_cate($request) {
        $term_query = new WP_Term_Query(array(
            'taxonomy'=>'category',
            'parent'=>0,
            'meta_query'=>array(
                array(
                    'relation'=>'OR',
                    array(
			           'key' => '__wrest_disable__', //(字符串) - 自定义字段的键
			           'compare' => 'NOT EXISTS'
			        ),
			        array(
			            'key' => '__wrest_disable__', //(字符串) - 自定义字段的键
			            'value' =>'yes', //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
			            'type' => 'CHAR', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
			            'compare' => '!=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
			        ),
                )
            )
        ));
        
        $data = [];
        if($term_query->terms){
            foreach ($term_query->terms as $v) {
                $data[] = [
                    'key' => $v->term_id,
                    'title' => $v->name
                ];
            }
        }
        
        $v = $request->get_param('v');
        if(!$v||version_compare($v, '1.0.1','<')){
            return new WP_REST_Response($data);
        }
        return new WP_REST_Response(array(
            'catList'=>$data
        ));
    }

    /**
     * 获取文章热门搜索
     */
    public function get_search_tags() {
        global $wpdb;
        $_tags = $wpdb->get_results(
            "select k.*
				 from {$wpdb->prefix}wrest_keywords k
				 where k.status='publish'
				       and k.type ='article'
			     order by k.is_feature desc,k.count desc
				 limit 20;");
        $tags = [];
        foreach ($_tags as $v) {
            $tags[] = $v->label;
        }
        return new WP_REST_Response(['data' => $tags]);
    }

    /**
     * 获取制定分类下的文章id
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_article_list($request) {
        $params = $request->get_params() ? $request->get_params() : [];
        $params['page'] = isset($params['page']) ? $params['page'] : 1;
        $params['cate'] = isset($params['cate']) ? $params['cate'] : 1;
        $params['keywords'] = isset($params['keywords']) ? $params['keywords'] : '';
        $_pageNum = absint($params['page']);
        $pageNum = $_pageNum>=1 ? $_pageNum : 1;
        $_pageSize = absint(get_option('posts_per_page'));
        $pageSize = $_pageSize>0 ? $_pageSize : 10;
        
        //判断是那种获取方式
        if ($params['cate']) $selParams = ['paged' => $pageNum, 'posts_per_page' => $pageSize, 'cat' => absint($params['cate'])];
        if ($params['keywords']) {
            //将关键字插入数据库
            $keywords = $this->sanitize_keywords($params['keywords']);
            global $wpdb;
            $_res = $wpdb->get_row("select * from {$wpdb->prefix}wrest_keywords where label='{$keywords}';");
            if ($_res) {
                $wpdb->update($wpdb->prefix . 'wrest_keywords', ['count' => $_res->count + 1], ['id' => $_res->id]);
            } else {
                $wpdb->insert("{$wpdb->prefix}wrest_keywords", array(
                    'label' => $keywords,
                    'count' => 1,
                    'type' => 'article',
                    'is_feature' => 0,
                    'status' => 'publish'
                ));
            }
            $selParams = ['paged' => $pageNum, 'posts_per_page' => $pageSize, 'post_type' => 'post', 's' => $keywords];
        }
        
        add_filter('posts_search',  'WRest_Hooks::wpse_11826_search_by_title', 10, 2 );
        $the_query = new WP_Query($selParams);
        remove_filter('posts_search',  'WRest_Hooks::wpse_11826_search_by_title');
        $data = [];
        if ($the_query->posts) {
            foreach ($the_query->posts as $post) {
                $post_thumbnail_id = get_post_thumbnail_id($post);
                $img = null;
                if ($post_thumbnail_id) {
                    $img = wp_get_attachment_image_src($post_thumbnail_id, 'single');
                }
                if (!$img) {
                    $img = [WREST_URL . '/assets/images/empty.png', 35, 35];
                }
                $data[] = [
                    'img' => ['url' => $img[0], 'width' => $img[1], 'height' => $img[2]],
                    'id' => $post->ID,
                    'title' => get_the_title($post),
                    'date' => date('Y-m-d', strtotime($post->post_date)),
                    'commentNum' => absint($post->comment_count)
                ];
            }
        }
        $res = ['page' => $pageNum, 'pageCount' => ceil($the_query->found_posts / $pageSize), 'tolCount' => $the_query->found_posts, 'data' => $data];
        return new WP_REST_Response($res);
    }
    
    
    /**
     * @param WP_REST_Request $request
     * 获取文章和相关产品
     */
    public function get_article_and_products($request) {
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        $id = absint($request->get_param('id'));

        $post = get_post($id);
        if (!$post) return new WP_Error('post-not-found', 'Post not found!', array('status' => 404));

        
        
        if ($post->post_status != 'publish') {
            if (!current_user_can('edit_post', $post->ID)) {
                return new WP_Error('post-not-found', 'Post not found!', array('status' => 404));
            }
        }
        
        $api = WRest::instance()->get_product_api();
        $product_ids = get_post_meta($post->ID, '__wrest_post_products__', true);
        $products = $product_ids && is_array($product_ids) && count($product_ids) > 0 ? $api->get_product_list($version, array(
            'post__in' => $product_ids,
            'paginate' => false,
            'limit' => 30
        ), 'woocommerce_single') : null;

        $post_thumbnail_id = get_post_thumbnail_id($id);
        $image = wp_get_attachment_image_src($post_thumbnail_id, 'single');

//         $GLOBALS['post'] = $post;
//         setup_postdata($post);
       
//         ob_start();
//         the_content();
//         $content = ob_get_clean();
        
        $res = [
            'article' => [
                'id' => $post->ID,
                'post_type'=>'post',
                'title' => get_the_title($post),
            		'content' => WRest_Helper_String::towxml(wp_kses_post( wpautop(do_shortcode($post->post_content) ))),
                'date' => date('Y-m-d', strtotime($post->post_date)),
                'commentCount' => absint($post->comment_count),
                'image' => $image && count($image) >= 3 ? array(
                    'url' => $image[0],
                    'width' => $image[1],
                    'height' => $image[2]
                ) : null,
                'needPassword' => false,
                'password' => sanitize_text_field($request->get_param('password'))
            ],
            'products' => $products['items']
        ];


        if (post_password_required($post)) $res['article']['needPassword'] = true;

        return new WP_REST_Response($res);
    }

    /**
     * 过滤关键字
     */
    private function sanitize_keywords($keyword) {
        $keyword = trim(wc_clean($keyword));
        if (empty($keyword) && mb_strlen($keyword, 'utf-8') < 2) {
            return null;
        }
        $keyword = urldecode($keyword);
        $keyword = str_replace(array("\r", "\n", "%"), '', $keyword);
        global $wpdb;
        return $wpdb->esc_like(mb_strimwidth($keyword, 0, 16, '', 'utf-8'));
    }
}