<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WRest_Store_Rest_Controller extends Abstract_WRest_Controller{

    public function __construct(){
        $this->rest_base = 'store';
    }

    public function register_routes() {
        register_rest_route( $this->namespace, "/{$this->rest_base}/config" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_config' ),
            )
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/index" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_store_index' ),
            ),
            
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/login" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_store_login' )
            ),
            
        ));

        register_rest_route( $this->namespace, "/{$this->rest_base}/account" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_store_account' )
            )
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/product/detail" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_store_product_detail' )
            ),
            
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/category" , array(
        		array(
        				'methods'             => WP_REST_Server::ALLMETHODS,
        				'callback'            => array( $this, 'get_store_category' )
        		),
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/category2" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_store_category2' )
            ),
        ));

        register_rest_route( $this->namespace, "/{$this->rest_base}/category3" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_store_category3' )
            ),
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/category/data" , array(
        		array(
        				'methods'             => WP_REST_Server::ALLMETHODS,
        				'callback'            => array( $this, 'product_search' )
        		),
        		
        ));
      
        register_rest_route( $this->namespace, "/{$this->rest_base}/search" , array(
        		array(
        				'methods'             => WP_REST_Server::ALLMETHODS,
        				'callback'            => array( $this, 'get_store_search' )
        		),
        		
        ));

        register_rest_route( $this->namespace, "/{$this->rest_base}/page" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'get_store_page' )
            ),
        
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/search/data" , array(
    		array(
    				'methods'             => WP_REST_Server::ALLMETHODS,
    				'callback'            => array( $this, 'get_store_search_data' )
    		),	
        ));
    }
    
    /**
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_config($request){
        $version = $this->get_version($request);
        if (is_wp_error ( $version )) {
            return $version;
        }
        
        $layout = WRest_Menu_Store_Layout::instance();
        $window = $layout->get_window($version);
        $config = array(
            'apiMain'=>home_url('/wp-json'),
            'apiAssets'=>WREST_URL.'/assets'
        );
        
        foreach ($layout->get_body($version) as $field){
            $subconfig = $field->get_config();
            if($subconfig){
                foreach ($subconfig as $field_name=>$val){
                    if($field->fields[$field_name]['type']=='image'&&isset($val['local'])&&'Y'==$val['local']){
                        $val['url'] = WRest::instance()->WP->convert_remoteimage_to_local($val['url'], '/images/icon/');
                        $subconfig[$field_name] = $val;
                    }
                }
            }
            $config[$field->getConfigId()] = $subconfig;
        }
        
        return new WP_REST_Response(array(
            'config'=>$config
        ));
    }
    
    /**
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_store_account($request){
        require_once WREST_DIR.'/includes/admin/menus/class-wrest-menu-store-account.php';       
        return WRest_Menu_Store_Account::instance()->render_templates($request);
    }
    
    /**
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_store_page($request){
        require_once WREST_DIR.'/includes/shop/class-wrest-page-api.php';
        $page_id =$request->get_param('id');
        $post = $page_id?get_post($page_id):null;
        if(!$post||$post->post_type!='wrest_page'||$post->post_status!='publish'){
            return new WP_Error('nofound','页面信息未找到！',['status'=>404]);
        }
        
        $version = $this->get_version ( $request );
        if (is_wp_error ( $version )) {
            return $version;
        }
        
        $page = new WRest_Page_Content($post);
        if($page->requiredAuth($version)&&!is_user_logged_in()){
        	return $this->get_store_login($request);
        }
        
        return $page->render_templates($request,array(
            'page_title'=>get_the_title($post),
            'required_login'=>$page->requiredAuth($version),
            'comment_status'=>$post->comment_status
        ));
    }
    
    /**
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_store_index($request){
        require_once WREST_DIR.'/includes/admin/menus/class-wrest-menu-store-index.php';
        return WRest_Menu_Store_Index::instance()->render_templates($request);
    }
    
    public function get_store_login($request){
        require_once WREST_DIR.'/includes/admin/menus/class-wrest-menu-store-login.php';
        
        return WRest_Menu_Store_Login::instance()->render_templates($request);
    }
    
    public function get_store_category2($request){
        return WRest_Menu_Store_Cat::instance()->render_templates($request);
    }
    
    /**
     *
     * @param WP_REST_Request $request
     */
    public function get_store_category3($request){
        $api = WRest::instance()->get_product_api();
        $category = get_term($request->get_param('id'));
        if(!$category||is_wp_error($category)){
            return new WP_Error('not-found','未找到分类信息！',array('status'=>404));
        }
        $response =array(
            'obj'=>array(
                'title'=>$category->name
            )
        );
        return WRest_Menu_Store_CatDetail::instance()->render_templates($request,$response);
    }
    
    public function product_search($request){
        $version = $this->get_version($request);
        if (is_wp_error ( $version )) {
            return $version;
        }
       return WRest::instance()->get_product_api()->process_product_search($request,$version);
    }
    
    /**
     *
     * @param WP_REST_Request $request
     */
    public function get_store_product_detail($request){
    	$version = $this->get_version ( $request );
    	if (is_wp_error ( $version )) {
    		return $version;
    	}
    	
    	$api = WRest::instance()->get_product_api();
        $product_id = absint($request->get_param('id'));
     
        $post = get_post($product_id);
        if(!$post){
            return new WP_Error('not-found','未找到产品信息！',array('status'=>404));
        }
        $GLOBALS['post'] = $post;
        setup_postdata($post);
        
        $product = $api->get_product($product_id)->to_detail($version);
        if(!$product){
        	return new WP_Error('not-found','未找到产品信息！',array('status'=>404));
        }
        
        return new WP_REST_Response(array(
        	'productInfo'=>$product
        ));
    }
    
    /**
     * 
     * @param WP_REST_Request $request
     */
    public function get_store_search_data($request){
    	$version = $this->get_version ( $request );
    	if (is_wp_error ( $version )) {
    		return $version;
    	}
    	
    	$api = WRest::instance()->get_product_api();
    	$keyword = $api->sanitize_keywords($request->get_param('keyword'));
    	if(!$keyword){
    		return new WP_REST_Response(array(
    				'items'=>null
    		));
    	}
    	
    	global $wpdb;
    	$items = $wpdb->get_results($wpdb->prepare(
    		   "select p.ID
    			from {$wpdb->posts} p
    			where p.post_status='publish'
	    			and p.post_type='{$api->post_type}'
	    			and p.post_title like %s
    			order by p.ID desc
    			limit 20;", $keyword."%"));
    	
    	$results = array();
    	if($items){
    		foreach ($items as $item){
    			$product = $api->get_product($item->ID)->to_simple($version,'woocommerce_single');
    			if(!$product){continue;}
    			$results[]=$product;
    		}
    	}
    	return new WP_REST_Response(array(
    			'items'=>$results
    	));
    }
    
    public function get_store_search($request){
    	$version = $this->get_version ( $request );
    	if (is_wp_error ( $version )) {
    		return $version;
    	}
    	
    	global $wpdb;
    	$hotkeywords = $wpdb->get_results(
    			"select k.*
				 from {$wpdb->prefix}wrest_keywords k
				 where k.status='publish'
				       and k.type ='product'
			     order by k.is_feature desc,k.count desc
				 limit 20;");
    	
    	$api = WRest::instance()->get_product_api();
    	$cats = $api->get_product_cats($version,array(
    	    $api->cat_type
    	));
    	$filters = $api->get_product_filters($version);
    	$sorts = $api->get_product_sorts();
    	
    	$sdk = $request->get_param('sdk');
    	if($sdk&&version_compare($sdk, '1.0.1','>=')){
    	    $catArray = array(
    	        array(
    	            'term_id' => 0,
    	            'name' => '全部',
    	            'children' => null
    	        )
    	    );
    	    if(isset($cats['items1'])&&$cats['items1']){
    	        foreach ($cats['items1'] as $term_id=>$cat){
    	            $catArray[]=$cat;
    	        }
    	    }
    	    $cats['items1'] = $catArray;
    	}
    	
    	return new WP_REST_Response(array(
    			'hotLabels'=>$hotkeywords,
    			'cats'=>$cats,
    			'filters'=>$filters,
    			'sorts'=>$sorts
    	));
    }
    
    public function get_store_category($request){
    	$version = $this->get_version ( $request );
    	if (is_wp_error ( $version )) {
    		return $version;
    	}
        $api = WRest::instance()->get_product_api();
    	$cats = $api->get_product_cats($version,array(
    	    $api->cat_type
    	));
    	$filters = $api->get_product_filters($version);
    	$sorts = $api->get_product_sorts();
    	$data = array(
    			'cats'=>$cats,
    			'filters'=>$filters,
    			'sorts'=>$sorts
    	);
    	
    	return new WP_REST_Response($data);
    }
}