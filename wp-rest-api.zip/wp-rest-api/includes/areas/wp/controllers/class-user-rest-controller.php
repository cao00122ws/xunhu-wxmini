<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
require_once WREST_DIR.'/includes/admin/abstracts/abstract-wrest-xcx-setting.php';
require_once WREST_DIR.'/includes/admin/menus/class-wrest-menu-store-index.php';

class WRest_User_Rest_Controller extends Abstract_WRest_Controller{

    public function __construct(){
        $this->rest_base = 'user';
    }

    public function register_routes() {
    	do_action('wrest_register_routes_wp_user',$this);
        register_rest_route( $this->namespace, "/{$this->rest_base}/index" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'index' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            )
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/prebind" , array(
        		array(
        				'methods'             => WP_REST_Server::ALLMETHODS,
        				'callback'            => array( $this, 'prebind' ),
        				'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
        		)
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/dobind" , array(
        		array(
        				'methods'             => WP_REST_Server::ALLMETHODS,
        				'callback'            => array( $this, 'dobind' ),
        				'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
        		)
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/login" , array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'login' )
            )
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/bindMobileCode" , array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'bindMobileCode' )
            )
        ));

        register_rest_route( $this->namespace, "/{$this->rest_base}/refresh" , array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'refresh' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            )
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/login2" , array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'login2' )
            )
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/login3" , array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'login3' )
            )
        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/bindphone" , array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'bindphone' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            ),
        
        ));

        register_rest_route( $this->namespace, "/{$this->rest_base}/getValidationPhone" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'getValidationPhone' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            ),

        ));
        register_rest_route( $this->namespace, "/{$this->rest_base}/sendMobileCode" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'sendMobileCode' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            ),

        ));

        register_rest_route( $this->namespace, "/{$this->rest_base}/address" , array(
        		array(
    				'methods'             => WP_REST_Server::ALLMETHODS,
    				'callback'            => array( $this, 'get_address' ),
        		    'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
        		),
        		
        ));

        register_rest_route( $this->namespace, "/{$this->rest_base}/addressConfig" , array(
            array(
            				'methods'             => WP_REST_Server::ALLMETHODS,
            				'callback'            => array( $this, 'load_address' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            ),
        
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/confirmAddress" , array(
            array(
                'methods'             => WP_REST_Server::ALLMETHODS,
                'callback'            => array( $this, 'confirm_address' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            ),
        
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/removeAddress" , array(
            array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => array( $this, 'remove_address' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            ),
        
        ));
        
        register_rest_route( $this->namespace, "/{$this->rest_base}/addresslist" , array(
            array(
				'methods'             => WP_REST_Server::ALLMETHODS,
				'callback'            => array( $this, 'get_address_list' ),
                'permission_callback' => array( $this, 'get_private_items_permissions_check' ),
            ),
        
        ));
    }

    /**
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function bindMobileCode($request){
        $code = $request->get_param('code');
        $phone  = $request->get_param('phone');
        $addressId  = $request->get_param('addressId');

        $last_code = wc()->session->get('social_login_mobile_code');
        if(!$last_code){
            return new WP_Error('error','请重新获取验证码！');
        }
        if($code!=$last_code){
            return new WP_Error('error','验证码错误！');
        }
        $last_phone = wc()->session->get('social_login_mobile_last_send');
        if($last_phone!=$phone){
            return new WP_Error('error','请重新获取验证码！');
        }

        $customer = wc()->cart->get_customer();
        $customer->set_billing_phone($phone);
        $customer->save_data();
        update_user_meta($customer->get_id(),'__billing_phone_is_valid',$phone);

        if($addressId){
            $address_list = get_user_meta($customer->get_id(),'__wrest_address_list__',true);
            if(!$address_list||!is_array($address_list)){
                $address_list = array();
            }

            $new_address_list = array();
            foreach ($address_list as $item){
                if($item['id']==$addressId ){
                    $item['telNumber'] = $phone;
                    $item['phone_is_valid'] = true;
                }

                $new_address_list[]=$item;
            }

            update_user_meta($customer->get_id(),'__wrest_address_list__', $new_address_list);
        }

        return new WP_REST_Response(array(
            'success'=>true
        ));
    }


    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function sendMobileCode($request){
        $version = $this->get_version($request);
        if (is_wp_error($version)) {
            return $version;
        }

        $phone=trim($request->get_param('phone'));
        if(!class_exists('XH_Social')){
            return new WP_Error('inner-error','登录插件未启用！');
        }
        if(!class_exists('XH_Social_Add_On_Social_Mobile')){
            return new WP_Error('inner-error','登录插件手机扩展未启用！');
        }
        $time = intval(wc()->session->get('social_login_mobile_last_send_time',0));
        $now = time();

        if($time>$now){
            return new WP_Error('error',sprintf(__('Please wait for %s seconds!',XH_SOCIAL),$time-$now));
        }

        wc()->session->set('social_login_mobile_last_send_time',$now+60);
        $api = XH_Social_Add_On_Social_Mobile::instance();

        $sms_api = $api->get_sms_api();
        if(!$sms_api){
            return new WP_Error('error',__('[system error]sms api is invalid!',XH_SOCIAL));
        }

        $code = substr(str_shuffle(time()), 0,6);
        wc()->session->set('social_login_mobile_code',$code);
        wc()->session->set('social_login_mobile_last_send',$phone);
        $login_sms_params_str =$api->get_option('login_sms_params');
        $login_sms_params=null;
        if(!empty($login_sms_params_str)){
            $login_sms_params = explode(',', $login_sms_params_str);
        }

        $params = array();

        foreach ($login_sms_params as $param){
            switch ($param){
                case 'code':
                    $params['code']="$code";
                    break;
                case 'sitename':
                    $params['sitename']=get_option('blogname');
                    break;
                case 'product':
                    $params['product']=get_option('blogname');
                    break;
                case 'currenttime':
                    $params['currenttime']=date_i18n('Y-m-d H:i');
                    break;
                default:
                    $params = apply_filters('wsocial_sms_login_params', $params,$this);
                    break;
            }
        }

        if(defined('XH_MOBILE_TEST')&&XH_MOBILE_TEST){
            return new WP_Error('error',print_r($params,true));
        }

        $error = $sms_api->send($api->get_option('login_sms_id'),$phone, $params);
        if(!XH_Social_Error::is_valid($error)){
            return new WP_Error('error',$error->errmsg);
        }

        return new WP_REST_Response(['success' => true]);
    }

    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function prebind($request){
    	return apply_filters('wrest_user_prebind', new WP_Error('no-found','no found!',array('status'=>404)),$request);
    }
    
    public function dobind($request){
    	return apply_filters('wrest_user_dobind', new WP_Error('no-found','no found!',array('status'=>404)),$request);
    }
    
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function bindphone($request){
        global $current_user;
        
        $encryptedData = urldecode($request->get_param('encryptedData'));
        $iv = urldecode($request->get_param('iv'));
        $code =urldecode( $request->get_param('code'));
        if(empty($code)){
            return new WP_Error(4001,"code is required!",array( 'status' => 4001 ));
        }
        
        $config = WRest_Settings_Default_Basic_Default::instance();      
        $appid = $config->get_option('appid');
        $appsecret = $config->get_option('appsecret');
        
        try{
            $response = WRest_Helper_Http::http_get("https://api.weixin.qq.com/sns/jscode2session?appid={$appid}&secret={$appsecret}&js_code={$code}&grant_type=authorization_code&t=".time());
            $response= json_decode($response,true);
            if(isset($response['errcode'])){
                return new WP_Error($response['errcode'],$response['errmsg'],array( 'status' => absint($response['errcode']) ));
            }
            
            $session_key  = isset($response['session_key'])?$response['session_key']:null;
         
            require_once WREST_DIR.'/includes/wechat/class-wrest-wxBizDataCrypt.php';
            $pc = new WRest_WXBizDataCrypt($appid, $session_key);
            $user_data = null;
            $errCode = $pc->decryptData($encryptedData, $iv, $user_data );
            if ($errCode !== 0) {
                return new WP_Error($errCode,"绑定超时，错误编号：{$errCode}",array( 'status' => absint($errCode)));
            }
            
            $user_data = json_decode($user_data,true);
            update_user_meta(get_current_user_id(), '__wrest_valid_phone', array(
                //用户绑定的手机号（国外手机号会有区号）
                'phoneNumber' => $user_data['phoneNumber'],
                //没有区号的手机号
                'purePhoneNumber' => $user_data['purePhoneNumber'],
                //区号
                'countryCode' => $user_data['countryCode']
            ));
            
            return new WP_REST_Response(array(
                'phone1'=>$user_data['phoneNumber']
            ));
        } catch (Exception $e) {
            WRest_Log::error("手机绑定异常：".$e->getMessage());
            return new WP_Error($e->getCode(),$e->getMessage(),array( 'status' =>$e->getCode()));
        };
    }
    
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function confirm_address($request){
        $address_id = $request->get_param('id');
        if(!$address_id){
            return new WP_Error('invlaid-request',"请求无效！",array( 'status' => 500));
        }
    
        $api = WRest::instance()->get_product_api();
        return $api->confirm_address($address_id);
    }
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function remove_address($request){
        $address_id = $request->get_param('id');
        if(!$address_id){
            return new WP_Error('invlaid-request',"请求无效！",array( 'status' => 500));
        }
        
        $api = WRest::instance()->get_product_api();
        return $api->remove_address($address_id);
    }
    
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_address_list($request){
        $api = WRest::instance()->get_product_api();
        return new WP_REST_Response(array(
            'items'=>$api->get_address_list()
        ));
    }
    
    public function load_address($request){
        global $current_user;
        $version = $this->get_version ( $request );
        if (is_wp_error ( $version )) {
            return $version;
        }
         
        require_once WREST_DIR.'/includes/shop/class-wrest-address.php';

        $base = new WRest_Menu_Store_Base($version);
        $api = WRest::instance()->get_product_api();
        
        return new WP_REST_Response(array(
            'enable_mobile_v'=>'no',
            'enable_oversea_address'=>$base->get_option('enable_oversea_address'),
            'countries'=>WC()->countries->get_allowed_countries(),
            'addressList'=>WRest_Address::get_address()
        ));
    }
    
    /**
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function get_address($request){
    	global $current_user;
    	$version = $this->get_version ( $request );
    	if (is_wp_error ( $version )) {
    	    return $version;
    	}
    	
    	$base = new WRest_Menu_Store_Base($version);
    	$api = WRest::instance()->get_product_api();
    	$sdk = $request->get_param('sdk');
    	
    	if($sdk&&version_compare($sdk, '1.0.3','>=')){
    	    $address_id = $request->get_param('id');
    	    if(!$address_id){
                return new WP_REST_Response(array(
                    'address'=>$api->get_address()
                ));
    	    }
    	    
    	    return new WP_REST_Response(array(
    	        'address'=>$api->get_address_detail($address_id)
    	    ));
    	}
    	
    	if(!$sdk||version_compare($sdk, '1.0.1','<=')){
    	    return new WP_REST_Response(array(
    	        'enable_mobile_v'=>'no',
    	        'enable_oversea_address'=>$base->get_option('enable_oversea_address'),
    	        'countries'=>WC()->countries->get_allowed_countries(),
    	        'address'=>$api->get_address()
    	    ));
    	}
    	
    	$address_id = $request->get_param('id');
    	if(!$address_id){
    	    return new WP_REST_Response(array(
    	        'enable_mobile_v'=>'no',
    	        'enable_oversea_address'=>$base->get_option('enable_oversea_address'),
    	        'countries'=>WC()->countries->get_allowed_countries(),
    	        'address'=>array(
    	            "region"=> ['北京市', '北京市', '东城区']
    	        )
    	    ));
    	}
    	
    	return new WP_REST_Response(array(
	        'enable_mobile_v'=>'no',
    	    'enable_oversea_address'=>$base->get_option('enable_oversea_address'),
    	    'countries'=>WC()->countries->get_allowed_countries(),
			'address'=>$api->get_address_detail($address_id)
    	));
    }

    /**
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function getValidationPhone($request){
        $version = $this->get_version ( $request );
        if (is_wp_error ( $version )) {
            return $version;
        }

        $customer = WC()->cart->get_customer();
        $api = WRest::instance()->get_product_api();
        $address_id = $request->get_param('id');
        if(!$address_id){
            return new WP_REST_Response(array(
                'phone'=>$customer->get_billing_phone(),
                'msg'=>WRest_Settings_Default_Basic_Default::instance()->get_option('msg_page_phone_v'),
                'phone_is_valid'=>get_user_meta($customer->get_id(),'__billing_phone_is_valid',true)==$customer->get_billing_phone()
            ));
        }

        $address = $api->get_address_detail($address_id);
        if(!$address){
            return new WP_REST_Response(array(
                'phone'=>$customer->get_billing_phone(),
                'msg'=>WRest_Settings_Default_Basic_Default::instance()->get_option('msg_page_phone_v'),
                'phone_is_valid'=>get_user_meta($customer->get_id(),'__billing_phone_is_valid',true)==$customer->get_billing_phone()
            ));
        }
        return new WP_REST_Response(array(
            'phone'=>$address['phone'],
            'msg'=>WRest_Settings_Default_Basic_Default::instance()->get_option('msg_page_phone_v'),
            'phone_is_valid'=>$address['phone_is_valid']
        ));
    }

    /**
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function index($request){
        global $current_wrest_user;
		if(!$current_wrest_user){
		    $current_wrest_user= new WRest_User(get_current_user_id());
		}
		
        if(!$current_wrest_user->is_load()){
            return new WP_Error(401,"invalid user info!",array( 'status' => 401 ));
        }
       
        $api = WRest::instance()->get_product_api();       
        return new WP_REST_Response(array(
            'userInfo'=>array(
                'headimgurl'=>$current_wrest_user->img,
                'display_name'=>$current_wrest_user->get_nickname(),
            ),
        	'address'=>$api->get_address()
        ));
    }
    
    public function refresh($request){
        $v = absint($request->get_param('v'));
        if($v>=2){
            $encryptedData = urldecode($request->get_param('encryptedData'));
            $iv = urldecode($request->get_param('iv'));
            $rawData =urldecode($request->get_param('rawData'));
            $signature = urldecode($request->get_param('signature'));
            $code =urldecode( $request->get_param('code'));
        }else{
            $encryptedData = base64_decode($request->get_param('encryptedData'));
            $iv = base64_decode($request->get_param('iv'));
            $rawData =urldecode($request->get_param('rawData'));
            $signature = base64_decode($request->get_param('signature'));
            $code =base64_decode( $request->get_param('code'));
        }
        
        if(empty($code)){
            return new WP_Error(4001,"code is required!",array( 'status' => 4001 ));
        }
        $config = WRest_Settings_Default_Basic_Default::instance();
        
        $appid = $config->get_option('appid');
        $appsecret = $config->get_option('appsecret');
        
        try{
            $response = WRest_Helper_Http::http_get("https://api.weixin.qq.com/sns/jscode2session?appid={$appid}&secret={$appsecret}&js_code={$code}&grant_type=authorization_code&t=".time());
            $response= json_decode($response,true);
            if(isset($response['errcode'])){
                return new WP_Error($response['errcode'],$response['errmsg'],array( 'status' => absint($response['errcode']) ));
            }
        
            $session_key  = isset($response['session_key'])?$response['session_key']:null;
            $wp_user_id=0;
        
            require_once WREST_DIR.'/includes/wechat/class-wrest-wxBizDataCrypt.php';
            $pc = new WRest_WXBizDataCrypt($appid, $session_key);
            $user_data = null;
            $errCode = $pc->decryptData($encryptedData, $iv, $user_data );
            if ($errCode !== 0) {
                return new WP_Error($errCode,"登录超时，错误编号：{$errCode}",array( 'status' => absint($errCode)));
            }
        
            $user_data = json_decode($user_data,true);
        
            $update=array();
            if(isset($user_data['openId'])&&!empty($user_data['openId'])){
                $update['openid']= $user_data['openId'];
            }else{
                return new WP_Error($errCode,"登录超时：invalid openid",array( 'status' => 500));
            }
        
            if(isset($user_data['nickName'])&&!empty($user_data['nickName'])){
                $update['nickname']= $user_data['nickName'];
            }
        
            if(isset($user_data['gender'])&&!empty($user_data['gender'])){
                $update['sex']=$user_data['gender'];
            }
        
            if(isset($user_data['province'])&&!empty($user_data['province'])){
                $update['province']=$user_data['province'];
            }
        
            if(isset($user_data['city'])&&!empty($user_data['city'])){
                $update['city']=$user_data['city'];
            }
        
            if(isset($user_data['country'])&&!empty($user_data['country'])){
                $update['country']=$user_data['country'];
            }
        
            if(isset($user_data['avatarUrl'])&&!empty($user_data['avatarUrl'])){
                $update['headimgurl']=str_replace('http://', '//', $user_data['avatarUrl']);
            }
        
            if(isset($user_data['unionId'])&&!empty($user_data['unionId'])){
                $update['unionid']=$user_data['unionId'];
            }
        
            if(empty($update['unionid'])){
                $update['unionid'] = "u_{$update['openid']}";
            }
        
            
        
            $update['img'] = $update['headimgurl'];
            unset($update['headimgurl']);
        
            $wp_user_id = get_current_user_id();
            $wrest_user = new WRest_User($wp_user_id);
            if(!$wrest_user->is_load()){
                return new WP_Error('un-authorized','未登录！',['status'=>401]);
            }
        
            $update['nickname'] = json_encode(array(
                'value'=>$update['nickname']
            ));
            
            $wrest_user->reset_userdata($wrest_user->user_ID,$update['unionid'],$update['openid']);
            $error = $wrest_user->update($update);
            if(!WRest_Error::is_valid($error)){
                WRest_Log::error("登录异常：".$error->to_json());
                return $error;
            }
            
            $wp_user_id = $wrest_user->user_ID;
        
            try {
                $this->convert_remoteimage_to_local($wp_user_id,$update['img']);
            } catch (Exception $e) {
                $social_img = get_user_meta($wp_user_id, '_social_img',true);
                if(!$social_img){
                    update_user_meta($wp_user_id, '_social_img', $update['img']);
                }
            }
        } catch (Exception $e) {
            WRest_Log::error("登录异常：".$e->getMessage());
            return new WP_Error($e->getCode(),$e->getMessage(),array( 'status' =>$e->getCode()));
        }
        
        $time_now = time();
        $token = array(
            'user'=>array(
                'id'=>$wp_user_id,
                'ip'=>WRest_Helper_Http::get_client_ip(),
                'notice_str'=>str_shuffle($time_now)
            ),
            'exp'=> $time_now+ (60*60*24 * 3),
            'iat'=>$time_now
        );
         
        require_once WREST_DIR.'/includes/JWT.php';
        return new WP_REST_Response(array(
            'token'=>WRest_JWT::encode($token, WRest::instance()->get_hash_key())
        ));
    }
    
	public function login3($request){
        $v = absint($request->get_param('v'));
        if($v>=2){
            $encryptedData = urldecode($request->get_param('encryptedData'));
            $iv = urldecode($request->get_param('iv'));
            $rawData =urldecode($request->get_param('rawData'));
            $signature = urldecode($request->get_param('signature'));
            $code =urldecode( $request->get_param('code'));
        }else{
            $encryptedData = base64_decode($request->get_param('encryptedData'));
            $iv = base64_decode($request->get_param('iv'));
            $rawData =urldecode($request->get_param('rawData'));
            $signature = base64_decode($request->get_param('signature'));
            $code =base64_decode( $request->get_param('code'));
        }
        
        if(empty($code)){
            return new WP_Error(4001,"code is required!",array( 'status' => 4001 ));
        }
        $config = WRest_Settings_Default_Basic_Default::instance();
        
        $appid = $config->get_option('appid');
        $appsecret = $config->get_option('appsecret');
        
        try{
            $response = WRest_Helper_Http::http_get("https://api.weixin.qq.com/sns/jscode2session?appid={$appid}&secret={$appsecret}&js_code={$code}&grant_type=authorization_code&t=".time());
            $response= json_decode($response,true);
            if(isset($response['errcode'])){
                return new WP_Error($response['errcode'],$response['errmsg'],array( 'status' => absint($response['errcode']) ));
            }
        
            $session_key  = isset($response['session_key'])?$response['session_key']:null;
            $wp_user_id=0;
        
            require_once WREST_DIR.'/includes/wechat/class-wrest-wxBizDataCrypt.php';
            $pc = new WRest_WXBizDataCrypt($appid, $session_key);
            $user_data = null;
            $errCode = $pc->decryptData($encryptedData, $iv, $user_data );
            if ($errCode !== 0) {
                return new WP_Error($errCode,"登录超时，错误编号：{$errCode}",array( 'status' => absint($errCode)));
            }
        
            $user_data = json_decode($user_data,true);
        
            $update=array();
            if(isset($user_data['openId'])&&!empty($user_data['openId'])){
                $update['openid']= $user_data['openId'];
            }else{
                return new WP_Error($errCode,"登录超时：invalid openid",array( 'status' => 500));
            }
        
            if(isset($user_data['nickName'])&&!empty($user_data['nickName'])){
                $update['nickname']= $user_data['nickName'];
            }
        
            if(isset($user_data['gender'])&&!empty($user_data['gender'])){
                $update['sex']=$user_data['gender'];
            }
        
            if(isset($user_data['province'])&&!empty($user_data['province'])){
                $update['province']=$user_data['province'];
            }
        
            if(isset($user_data['city'])&&!empty($user_data['city'])){
                $update['city']=$user_data['city'];
            }
        
            if(isset($user_data['country'])&&!empty($user_data['country'])){
                $update['country']=$user_data['country'];
            }
        
            if(isset($user_data['avatarUrl'])&&!empty($user_data['avatarUrl'])){
                $update['headimgurl']=str_replace('http://', '//', $user_data['avatarUrl']);
            }
        
            if(isset($user_data['unionId'])&&!empty($user_data['unionId'])){
                $update['unionid']=$user_data['unionId'];
            }
        
            if(empty($update['unionid'])){
                $update['unionid'] = "u_{$update['openid']}";
            }
        
            $update['img'] = $update['headimgurl'];
            unset($update['headimgurl']);
        
            $wp_user_id = get_current_user_id();
            $wrest_user = new WRest_User($wp_user_id);
            if(!$wrest_user->is_load()){
                return new WP_Error('un-authorized','未登录！',['status'=>401]);
            }
			$nickname = $update['nickname'];
            $update['nickname'] = json_encode(array(
                'value'=>$update['nickname']
            ));
            
            $wrest_user->reset_userdata($wrest_user->user_ID,$update['unionid'],$update['openid']);
            $error = $wrest_user->update($update);
            if(!WRest_Error::is_valid($error)){
                WRest_Log::error("登录异常：".$error->to_json());
                return $error;
            }
            
            $wp_user_id = $wrest_user->user_ID;
        
            try {
                $this->convert_remoteimage_to_local($wp_user_id,$update['img']);
            } catch (Exception $e) {
                $social_img = get_user_meta($wp_user_id, '_social_img',true);
                if(!$social_img){
                    update_user_meta($wp_user_id, '_social_img', $update['img']);
                }
            }
			
			if(!class_exists('XH_Social_Channel_Wechat')){
				return new WP_Error('error','未启用登录插件：微信扩展!');
			}
			//微信已绑定其他账户，那么解绑并绑定到当前账号
			$extuser = XH_Social_Channel_Wechat::instance()->get_ext_user('unionid',$update['unionid']);
			if($extuser){
				XH_Social_Channel_Wechat::instance()->update_wp_user_info($extuser->id,$wp_user_id );
			}
			
			wp_update_user(array(
							'ID'=>$wp_user_id,
							'first_name'=>$this->filter_display_name(WRest_Helper_String::remove_emoji($nickname)),
							'nickname'=>$this->filter_display_name(WRest_Helper_String::remove_emoji($nickname))
						));
			
        } catch (Exception $e) {
            WRest_Log::error("登录异常：".$e->getMessage());
            return new WP_Error($e->getCode(),$e->getMessage(),array( 'status' =>$e->getCode()));
        }
        
        return new WP_REST_Response(array(
           
        ));
    }


    /**
     * 
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function login($request){
        $v = absint($request->get_param('v'));
        if($v>=2){
            $encryptedData = urldecode($request->get_param('encryptedData'));
            $iv = urldecode($request->get_param('iv'));
            $rawData =urldecode($request->get_param('rawData'));
            $signature = urldecode($request->get_param('signature'));
            $code =urldecode( $request->get_param('code'));
        }else{
            $encryptedData = base64_decode($request->get_param('encryptedData'));
            $iv = base64_decode($request->get_param('iv'));
            $rawData =urldecode($request->get_param('rawData'));
            $signature = base64_decode($request->get_param('signature'));
            $code =base64_decode( $request->get_param('code'));
        }
        
        if(empty($code)){
            return new WP_Error(4001,"code is required!",array( 'status' => 4001 ));
        }
        $config = WRest_Settings_Default_Basic_Default::instance();
        
        $appid = $config->get_option('appid');
        $appsecret = $config->get_option('appsecret');
        
        try{
            $response = WRest_Helper_Http::http_get("https://api.weixin.qq.com/sns/jscode2session?appid={$appid}&secret={$appsecret}&js_code={$code}&grant_type=authorization_code&t=".time());
            $response= json_decode($response,true);
            if(isset($response['errcode'])){
                return new WP_Error($response['errcode'],$response['errmsg'],array( 'status' => absint($response['errcode']) ));
            }
            
            $session_key  = isset($response['session_key'])?$response['session_key']:null;
            $wp_user_id=0;

            require_once WREST_DIR.'/includes/wechat/class-wrest-wxBizDataCrypt.php';
            $pc = new WRest_WXBizDataCrypt($appid, $session_key);
            $user_data = null;
            $errCode = $pc->decryptData($encryptedData, $iv, $user_data );
            if ($errCode !== 0) {
                return new WP_Error($errCode,"登录超时，错误编号：{$errCode}",array( 'status' => absint($errCode)));
            }
            
            $user_data = json_decode($user_data,true);
            
            $update=array();
            if(isset($user_data['openId'])&&!empty($user_data['openId'])){
                $update['openid']= $user_data['openId'];
            }else{
                return new WP_Error($errCode,"登录超时：invalid openid",array( 'status' => 500));
            }
            
            if(isset($user_data['nickName'])&&!empty($user_data['nickName'])){
                $update['nickname']= $user_data['nickName'];
            }
            
            if(isset($user_data['gender'])&&!empty($user_data['gender'])){
                $update['sex']=$user_data['gender'];
            }
            
            if(isset($user_data['province'])&&!empty($user_data['province'])){
                $update['province']=$user_data['province'];
            }
            
            if(isset($user_data['city'])&&!empty($user_data['city'])){
                $update['city']=$user_data['city'];
            }
            
            if(isset($user_data['country'])&&!empty($user_data['country'])){
                $update['country']=$user_data['country'];
            }
            
            if(isset($user_data['avatarUrl'])&&!empty($user_data['avatarUrl'])){
                $update['headimgurl']=str_replace('http://', '//', $user_data['avatarUrl']);
            }
            
            if(isset($user_data['unionId'])&&!empty($user_data['unionId'])){
                $update['unionid']=$user_data['unionId'];
            }
            
            if(empty($update['unionid'])){
                $update['unionid'] = "u_{$update['openid']}";
            }
            
            try {
                $wp_user_id = apply_filters('wrest_per_wechat_login', 0,$update);
            } catch (Exception $e) {
                return new WP_Error("systemerror",$e->getMessage());
            }
            
            $update['img'] = $update['headimgurl'];
            unset($update['headimgurl']);
            
            $wrest_user = new WRest_User($wp_user_id);
            if(!$wrest_user->is_load()){
                $wrest_user = $wrest_user->get_user_by_unionid($update['unionid']);
            }
          
            if(!$wrest_user||!$wrest_user->is_load()){
                $wrest_user = $wrest_user->get_user_by_openid($update['openid']);
            }
            
            if(!$wrest_user){
                $wrest_user = new WRest_User();
            }
            
            if($wp_user_id&&$wrest_user->is_load()&&$wrest_user->user_ID!=$wp_user_id){
                $wrest_user = new WRest_User();
            }
            
            if($wrest_user->is_load()){
                $update['nickname'] = json_encode(array(
                    'value'=>$update['nickname']
                ));
                $wrest_user->reset_userdata($wrest_user->user_ID,$update['unionid'],$update['openid']);
                $error = $wrest_user->update($update);
                if(!WRest_Error::is_valid($error)){
                    WRest_Log::error("登录异常：".$error->to_json());
                    return $error;
                }
                $wp_user_id = $wrest_user->user_ID;
            }else{
                //避免用户信息被删除
                $wrest_user->reset_userdata(0,$update['unionid'],$update['openid']);
                if(!$wp_user_id){
                    $userdata=apply_filters('wsocial_insert_user_Info',array(
                        'user_login'=>$this->generate_user_login($update['nickname']),
                        'user_nicename'=>WRest_Helper_String::guid(),
                        'first_name'=>$this->filter_display_name(WRest_Helper_String::remove_emoji($update['nickname'])),
                        'user_email'=>null,
                        'display_name'=>$this->filter_display_name(WRest_Helper_String::remove_emoji($update['nickname'])),
                        'nickname'=>$this->filter_display_name(WRest_Helper_String::remove_emoji($update['nickname'])),
                        'user_pass'=>str_shuffle(time())
                    ),$this);
                  
                    $wp_user_id =wp_insert_user($userdata);
                    if(is_wp_error($wp_user_id)){
                        WRest_Log::error("登录异常：".$wp_user_id->get_error_message());
                        return $wp_user_id;
                    }
                }
                
                $update['user_ID'] = $wp_user_id;
				$update['role'] = 'customer';
                $update['nickname'] = json_encode(array(
                    'value'=>$update['nickname']
                ));
                $update['role'] ='customer';
                $wrest_user =  new WRest_User($update);
                $error = $wrest_user->insert();
                if(!WRest_Error::is_valid($error)){
                    WRest_Log::error("登录异常：".$error->to_json());
                    return new WP_Error($error->errcode,$error->errmsg,array( 'status' => absint($error->errcode)));
                }
            }
            
            try {
                $this->convert_remoteimage_to_local($wp_user_id,$update['img']);
            } catch (Exception $e) {
                $social_img = get_user_meta($wp_user_id, '_social_img',true);
                if(!$social_img){
                    update_user_meta($wp_user_id, '_social_img', $update['img']);
                }
            }
        } catch (Exception $e) {
            WRest_Log::error("登录异常：".$e->getMessage());
            return new WP_Error($e->getCode(),$e->getMessage(),array( 'status' =>$e->getCode()));
        }  
        
        $time_now = time();
        $token = array(
            'user'=>array(
                'id'=>$wp_user_id,
                'ip'=>WRest_Helper_Http::get_client_ip(),
                'notice_str'=>str_shuffle($time_now)
            ),
            'exp'=> $time_now+ (60*60*24 * 3),
            'iat'=>$time_now
        );
   
        require_once WREST_DIR.'/includes/JWT.php';
        return new WP_REST_Response(array(
            'token'=>WRest_JWT::encode($token, WRest::instance()->get_hash_key())
        ));
    }
    
    public function login2($request){
        $encryptedData = urldecode($request->get_param('encryptedData'));
        $iv = urldecode($request->get_param('iv'));
        $code =urldecode( $request->get_param('code'));
        if(empty($code)){
            return new WP_Error(4001,"code is required!",array( 'status' => 4001 ));
        }
        
        $config = WRest_Settings_Default_Basic_Default::instance();      
        $appid = $config->get_option('appid');
        $appsecret = $config->get_option('appsecret');
        
        try{
            $response = WRest_Helper_Http::http_get("https://api.weixin.qq.com/sns/jscode2session?appid={$appid}&secret={$appsecret}&js_code={$code}&grant_type=authorization_code&t=".time());
            $response= json_decode($response,true);
            if(isset($response['errcode'])){
                return new WP_Error($response['errcode'],$response['errmsg'],array( 'status' => absint($response['errcode']) ));
            }
            
            $unionid = isset($response['unionid'])?$response['unionid']:null;
            $openid = isset($response['openid'])?$response['openid']:null;
            $session_key  = isset($response['session_key'])?$response['session_key']:null;
         
            require_once WREST_DIR.'/includes/wechat/class-wrest-wxBizDataCrypt.php';
            $pc = new WRest_WXBizDataCrypt($appid, $session_key);
            $user_data = null;
            $errCode = $pc->decryptData($encryptedData, $iv, $user_data );
            if ($errCode !== 0) {
                return new WP_Error($errCode,"绑定超时，错误编号：{$errCode}",array( 'status' => absint($errCode)));
            }
            
             $user_data = json_decode($user_data,true);
//             update_user_meta(get_current_user_id(), '__wrest_valid_phone', array(
//                 //用户绑定的手机号（国外手机号会有区号）
//                 'phoneNumber' => $user_data['phoneNumber'],
//                 //没有区号的手机号
//                 'purePhoneNumber' => $user_data['purePhoneNumber'],
//                 //区号
//                 'countryCode' => $user_data['countryCode']
//             ));
            
//             return new WP_REST_Response(array(
//                 'phone1'=>$user_data['phoneNumber']
//             ));
            if(empty($openid)){
                 return new WP_Error($errCode,"绑定超时，错误编号：-1(错误的openid)",array( 'status' => 500));
            }
             
            if(empty($unionid)){
                $unionid = "u_".$openid;
            }
            
            $user_data['openid'] = $openid;
            $user_data['unionid'] = $unionid;
            
            $update=array(
                'openid'=>$openid,
                'phone'=>$user_data['phoneNumber'],
                'unionid'=>$unionid,
            );
            
			if(version_compare($request->get_param('sdk'),'1.0.5','>=')){
				if(!class_exists('XH_Social_Channel_Mobile')){
					return new WP_Error('error','未启用登录插件：手机扩展!');
				}
                $user = XH_Social_Channel_Mobile::instance()->get_wp_user('mobile',$update['phone']);
                if(!$user){
                    $userdata=apply_filters('wsocial_insert_user_Info',array(
                        'user_login'=>$this->generate_user_login($update['phone']),
                        'user_nicename'=>WRest_Helper_String::guid(),
                        'first_name'=>$this->filter_display_name($update['phone']),
                        'user_email'=>null,
                        'display_name'=>$this->filter_display_name($update['phone']),
                        'nickname'=>$this->filter_display_name($update['phone']),
                        'user_pass'=>str_shuffle(time())
                    ),$this);
                    $wp_user_id =wp_insert_user($userdata);
                    if(is_wp_error($wp_user_id)){
                        WRest_Log::error("登录异常：".$wp_user_id->get_error_message());
                        return $wp_user_id;
                    }

                    $error = XH_Social_Channel_Mobile::instance()->create_ext_user($update['phone'],$wp_user_id);
                    if($error instanceof XH_Social_Error){
                        WRest_Log::error("登录异常：".$error->errmsg);
                        return new WP_Error('error',$error->errmsg);
                    }
					
					if(!class_exists('XH_Social_Channel_Wechat')){
						return new WP_Error('error','未启用登录插件：微信扩展!');
					}
                    //微信已绑定其他账户
                    $wechatuser = XH_Social_Channel_Wechat::instance()->get_ext_user('unionid',$update['unionid']);
					
                    $wrest_user = new WRest_User();
                    $wrest_user->reset_userdata(0,$update['unionid'],$update['openid'],$update['phone']);
                    $update['user_ID'] = $wp_user_id;
                    $update['nickname'] = json_encode(array(
                        'value'=>$this->filter_display_name($update['phone'])
                    ));
					
					if($wechatuser){
						$update['nickname'] = json_encode(array(
							'value'=>$wechatuser->nickname
						));
						$update['headimgurl'] = $wechatuser->img;
						wp_update_user(array(
							'ID'=>$wp_user_id,
							'first_name'=>$this->filter_display_name(WRest_Helper_String::remove_emoji($wechatuser->nickname)),
							'nickname'=>$this->filter_display_name(WRest_Helper_String::remove_emoji($wechatuser->nickname))
						));
					}
					
					$update['role'] = 'customer';
                    $wrest_user =  new WRest_User($update);
                    $error = $wrest_user->insert();
                    if(!WRest_Error::is_valid($error)){
                        WRest_Log::error("登录异常：".$error->to_json());
                        return new WP_Error($error->errcode,$error->errmsg,array( 'status' => absint($error->errcode)));
                    }

					
                    $time_now = time();
                    $token = array(
                        'user'=>array(
                            'id'=>$wp_user_id,
                            'ip'=>WRest_Helper_Http::get_client_ip(),
                            'notice_str'=>str_shuffle($time_now)
                        ),
                        'exp'=> $time_now+ (60*60*24 * 3),
                        'iat'=>$time_now
                    );

                    require_once WREST_DIR.'/includes/JWT.php';
                    return new WP_REST_Response(array(
                        'login_code'=>$wechatuser?'wechat_is_bind':'wechat_need_bind',
						'phone'=>$update['phone'],
                        'token'=>WRest_JWT::encode($token, WRest::instance()->get_hash_key())
                    ));
                }

				//如果手机用户存在
                //微信已绑定其他账户
				if(!class_exists('XH_Social_Channel_Wechat')){
					return new WP_Error('error','未启用登录插件：微信扩展!');
				}
                $wechatuser = XH_Social_Channel_Wechat::instance()->get_ext_user('unionid',$update['unionid']);
                $wrest_user = new WRest_User($user->ID);
                if(!$wrest_user->is_load()){
                    $wrest_user->reset_userdata(0,$update['unionid'],$update['openid'],$update['phone']);
                    $update['user_ID'] = $user->ID;
                    $update['nickname'] = json_encode(array(
                        'value'=>$this->filter_display_name($update['phone'])
                    ));
					if($wechatuser){
						$update['nickname'] = json_encode(array(
							'value'=>$wechatuser->nickname
						));
						$update['headimgurl'] = $wechatuser->img;
					}
					$update['role'] = 'customer';
                    $wrest_user =  new WRest_User($update);
                    $error = $wrest_user->insert();
                    if(!WRest_Error::is_valid($error)){
                        WRest_Log::error("登录异常：".$error->to_json());
                        return new WP_Error($error->errcode,$error->errmsg,array( 'status' => absint($error->errcode)));
                    }
                }else{
					if($wechatuser){
						$wrest_user->reset_userdata($wrest_user->user_ID,$update['unionid'],$update['openid'],$update['phone']);
						$update['nickname'] = json_encode(array(
							'value'=>$wechatuser->nickname
						));
						$update['headimgurl'] = $wechatuser->img;
						$error = $wrest_user->update($update);
						if(!WRest_Error::is_valid($error)){
							WRest_Log::error("登录异常：".$error->to_json());
							return new WP_Error($error->errcode,$error->errmsg,array( 'status' => absint($error->errcode)));
						}
						
						wp_update_user(array(
							'ID'=>$wrest_user->user_ID,
							'first_name'=>$wechatuser->nickname,
							'nickname'=>$wechatuser->nickname
						));
					}
				}
                
                $time_now = time();
                $token = array(
                    'user'=>array(
                        'id'=>$user->ID,
                        'ip'=>WRest_Helper_Http::get_client_ip(),
                        'notice_str'=>str_shuffle($time_now)
                    ),
                    'exp'=> $time_now+ (60*60*24 * 3),
                    'iat'=>$time_now
                );

				$code = null;
				if(!$wrest_user->img){
					$code = 'wechat_need_bind';
				}
				if($wechatuser&&$wechatuser->ID!=$user->ID){
					$code = 'wechat_is_bind';
				}

                require_once WREST_DIR.'/includes/JWT.php';
                return new WP_REST_Response(array(
                    'login_code'=>$code,
					'phone'=>$update['phone'],
                    'token'=>WRest_JWT::encode($token, WRest::instance()->get_hash_key())
                ));
            }
			
            try {
                $wp_user_id = apply_filters('wrest_per_phone_login', 0,$user_data);
            } catch (Exception $e) {
                return new WP_Error("systemerror",$e->getMessage());
            }
           
            $wrest_user = new WRest_User($wp_user_id);
            if(!$wrest_user->is_load()){
                $wrest_user = $wrest_user->get_user_by_unionid($update['unionid']);
            }
          
            if(!$wrest_user||!$wrest_user->is_load()){
                $wrest_user = $wrest_user->get_user_by_openid($update['openid']);
            }
            
            if(!$wrest_user){
                $wrest_user = new WRest_User();
            }
            
            if(!$wrest_user->is_load()){
                $wrest_user = $wrest_user->get_user_by_phone($update['phone']);
                if(!$wrest_user){
                    $wrest_user = new WRest_User();
                }
            }else{
                $wrest_user1 = $wrest_user->get_user_by_phone($update['phone']);
                if($wrest_user1
                    &&$wrest_user1->is_load()
                    &&$wrest_user1->user_ID!=$wrest_user->user_ID){
                    $wrest_user1->remove();
                }
            }
          
            if($wp_user_id&&$wrest_user->is_load()&&$wrest_user->user_ID!=$wp_user_id){
                $wrest_user = new WRest_User();
            }
           
            if($wrest_user->is_load()){
				$wp_user = get_userdata($wrest_user->user_ID);
				if($wp_user){
					$update['nickname'] = json_encode(array(
						'value'=>$wp_user->nickname
					));
				}
                $wrest_user->reset_userdata($wrest_user->user_ID,$update['unionid'],$update['openid'],$update['phone']);
                $error = $wrest_user->update($update);
                if(!WRest_Error::is_valid($error)){
                    WRest_Log::error("登录异常：".$error->to_json());
                    return $error;
                }
				
                $wp_user_id = $wrest_user->user_ID;
            }else{
                //避免用户信息被删除
                $wrest_user->reset_userdata(0,$update['unionid'],$update['openid'],$update['phone']);
                if(!$wp_user_id){
                    $userdata=apply_filters('wsocial_insert_user_Info',array(
                        'user_login'=>$this->generate_user_login($update['phone']),
                        'user_nicename'=>WRest_Helper_String::guid(),
                        'first_name'=>'依欧美'.$this->filter_display_name($update['phone']),
                        'user_email'=>null,
                        'display_name'=>'依欧美'.$this->filter_display_name($update['phone']),
                        'nickname'=>'依欧美'.$this->filter_display_name($update['phone']),
                        'user_pass'=>str_shuffle(time())
                    ),$this);
    
                    $wp_user_id =wp_insert_user($userdata);
                    if(is_wp_error($wp_user_id)){
                        WRest_Log::error("登录异常：".$wp_user_id->get_error_message());
                        return $wp_user_id;
                    }
                }
                
                $update['user_ID'] = $wp_user_id;
                $update['nickname'] = json_encode(array(
                    'value'=>'依欧美'.$this->filter_display_name($update['phone'])
                ));
                $update['role'] ='customer';
                $wrest_user =  new WRest_User($update);
                $error = $wrest_user->insert();
                if(!WRest_Error::is_valid($error)){
                    WRest_Log::error("登录异常：".$error->to_json());
                    return new WP_Error($error->errcode,$error->errmsg,array( 'status' => absint($error->errcode)));
                }
				
				if(class_exists('XH_Social_Channel_Mobile')){
					XH_Social_Channel_Mobile::instance()->create_ext_user($update['phone'],$wp_user_id);
				}
            }
            
            update_user_meta($wp_user_id, '__wrest_valid_phone', array(
                //用户绑定的手机号（国外手机号会有区号）
                'phoneNumber' => $user_data['phoneNumber'],
                //没有区号的手机号
                'purePhoneNumber' => $user_data['purePhoneNumber'],
                //区号
                'countryCode' => $user_data['countryCode']
            ));
            
        } catch (Exception $e) {
            WRest_Log::error("登录异常：".$e->getMessage());
            return new WP_Error($e->getCode(),$e->getMessage(),array( 'status' =>$e->getCode()));
        }
    
        $time_now = time();
        $token = array(
            'user'=>array(
                'id'=>$wp_user_id,
                'ip'=>WRest_Helper_Http::get_client_ip(),
                'notice_str'=>str_shuffle($time_now)
            ),
            'exp'=> $time_now+ (60*60*24 * 3),
            'iat'=>$time_now
        );
         
        require_once WREST_DIR.'/includes/JWT.php';
        return new WP_REST_Response(array(
            'token'=>WRest_JWT::encode($token, WRest::instance()->get_hash_key())
        ));
    }
    
    private function convert_remoteimage_to_local($wp_user_id,$remote_image_url){
        if(!$remote_image_url){
            throw new Exception("读取远程文件失败：文件地址不能为空");
        }
         
        if(stripos($remote_image_url, '//')===0){
            $remote_image_url="https:{$remote_image_url}";
        }
    
        if(stripos($remote_image_url, 'http://')===0&&stripos($remote_image_url, 'https://')===0){
            throw new Exception("读取远程文件失败：文件地址类型异常，{$remote_image_url}");
        }
         
        $filekey = '/'.md5($remote_image_url);
        $social_img = get_user_meta($wp_user_id, '_social_img',true);
        if($social_img&&strpos($social_img, $filekey)){
            return $social_img;
        }
    
        $config = wp_get_upload_dir();
        $localdir = $config['path'];
         
        $localpath = $localdir.$filekey;
    
        $img = WRest_Helper_Http::http_get($remote_image_url,false,null,5);
        if(!$img){
            throw new Exception("读取远程文件失败：{$remote_image_url}");
        }
         
        if(!@file_put_contents($localpath, $img)){
            throw new Exception("文件写入失败：{$localpath}");
        }
        
        $url = $config['url'].$filekey;
        $response = apply_filters('wp_handle_upload',array( 'file' => $localpath, 'url' => $url, 'type' => "image/png", 'error' => false ), 'sideload');
        
        update_user_meta($wp_user_id, '_social_img',$response['url']);
        return $response['url'];
    }
    
    private function filter_display_name($nickname_or_loginname_or_displayname){
        $_return = $nickname_or_loginname_or_displayname;
        //如果是手机号，那么
        if(preg_match('/^\d+$/',$nickname_or_loginname_or_displayname)&&strlen($nickname_or_loginname_or_displayname)>=8){
            //139****4325
            $_return= substr($nickname_or_loginname_or_displayname, 0,3)."****".substr($nickname_or_loginname_or_displayname, -4);
        }else if(is_email($nickname_or_loginname_or_displayname)&&strlen($nickname_or_loginname_or_displayname)>4){
            $index_of_at = strpos($nickname_or_loginname_or_displayname, '@');
            if($index_of_at!==false&&$index_of_at>1){
                //12@qq.com
                $length =$index_of_at-4;
                if($length<=0){$length=1;}
                if($length>3){$length=3;}
    
                $_return = substr( $nickname_or_loginname_or_displayname, 0,$length)."****".substr( $nickname_or_loginname_or_displayname, $index_of_at>7?7:$index_of_at);
            }
        }
    
        return apply_filters('wsocial_filter_display_name', $_return,$nickname_or_loginname_or_displayname);
    }
    
    private function generate_user_login($nickname){
        $_nickname = $nickname;
        
        $nickname1 =  apply_filters('wsocial_user_login_pre', null,$_nickname);
        if(!empty($nickname1)){
            return $nickname1;
        }
      
        $nickname = sanitize_user(WRest_Helper_String::remove_emoji($_nickname),true);
        if(empty($nickname)){
            $nickname = mb_substr(str_shuffle("abcdefghigklmnopqrstuvwxyz123456") ,0,4,'utf-8');
        }
       
        $nickname =  apply_filters('wsocial_user_login_sanitize', $nickname,$_nickname);
        if(mb_strlen($nickname)>32){
            $nickname = mb_substr($nickname, 0,32,'utf-8');
        }
        
        $pre_nickname =$nickname;
    
        $index=0;
        while (username_exists($nickname)){
            $index++;
            if($index==1){
                $nickname=$pre_nickname.'_'.time();//年+一年中的第N天
                continue;
            }
            
            //加随机数
            $nickname.=mt_rand(1000, 9999);
            if(strlen($nickname)>60){
                $nickname = $pre_nickname.'_'.time();
            }
            
            //尝试次数过多
            if($index>5){
                $nickname = WRest_Helper_String::guid();
                break;
            }
        }
    
        return apply_filters('wsocial_user_login', $nickname,$_nickname);  
    }
    
}