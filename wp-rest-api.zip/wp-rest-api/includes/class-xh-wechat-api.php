<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
require_once 'wechat/class-wechat-token.php';
class WRest_Wechat_Api{
    private $appid,$appsecret,$crossdomain_url;
    public function __construct($appid,$appsecret,$crossdomain_url=null){
        $this->appid = $appid;
        $this->appsecret = $appsecret;
        $this->crossdomain_url =$crossdomain_url;
    }
    
    public function get_smallprogram_qrcode_unlimit($page,$scene=null){
        $tokenApi = new WRest_Wechat_Token($this->appid, $this->appsecret,$this->crossdomain_url);
        $retry = 2;
        $access_token =$tokenApi->smallprogram_access_token($retry,false);
        if($access_token instanceof WRest_Error){
            return $access_token;
        }
    
        try {
            $response = WRest_Helper_Http::http_post("https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token={$access_token}",json_encode(array(
                'scene'=>$scene,
                'page'=>ltrim($page,'/')
            ),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
            
            $error = new WRest_Wechat_Error($this->appid, $this->appsecret,$this->crossdomain_url);
            return "data:image/png;base64,".base64_encode($error->validate($response));
        } catch (Exception $e) {
            WRest_Log::error($e);
            return new WRest_Error(-1,$e->getMessage());
        }
    }
    
    public function get_smallprogram_qrcode($page,$params=array()){
        $tokenApi = new WRest_Wechat_Token($this->appid, $this->appsecret,$this->crossdomain_url);
        $retry = 2;
        $access_token =$tokenApi->smallprogram_access_token($retry,false);
        if($access_token instanceof WRest_Error){
            return $access_token;
        }
        $param_str = '';
        if(count($params)){
            $param_str='?'.http_build_query($params);
        }
        try {
            $response = WRest_Helper_Http::http_post("https://api.weixin.qq.com/wxa/getwxacode?access_token={$access_token}",json_encode(array(
                'path'=>ltrim($page,'/').$param_str
            ),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    
            $error = new WRest_Wechat_Error($this->appid, $this->appsecret,$this->crossdomain_url);
            return "data:image/png;base64,".base64_encode($error->validate($response));
        } catch (Exception $e) {
            WRest_Log::error($e);
            return new WRest_Error(-1,$e->getMessage());
        }
    }
    
    public function addTemplate($tid, $keywords_list=array()){
        $tokenApi = new WRest_Wechat_Token($this->appid, $this->appsecret,$this->crossdomain_url);
        $retry = 2;
        $access_token =$tokenApi->smallprogram_access_token($retry,false);
        if($access_token instanceof WRest_Error){
            return $access_token;
        }
        
        try {
            $response = WRest_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/wxopen/template/add?access_token={$access_token}",json_encode(array(
                'id'=>$tid,
                'keyword_id_list'=>$keywords_list
            ),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        
            $error = new WRest_Wechat_Error($this->appid, $this->appsecret,$this->crossdomain_url);
            return $error->validate($response);
        } catch (Exception $e) {
            WRest_Log::error($e);
            return new WRest_Error(-1,$e->getMessage());
        }
    }
    
    public function getTemplate($tid){
        $tokenApi = new WRest_Wechat_Token($this->appid, $this->appsecret,$this->crossdomain_url);
        $retry = 2;
        $access_token =$tokenApi->smallprogram_access_token($retry,false);
        if($access_token instanceof WRest_Error){
            return $access_token;
        }
        
        try {
            $response = WRest_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/wxopen/template/library/get?access_token={$access_token}",json_encode(array(
                'id'=>$tid
            ),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        
            $error = new WRest_Wechat_Error($this->appid, $this->appsecret,$this->crossdomain_url);
            return $error->validate($response);
        } catch (Exception $e) {
            WRest_Log::error($e);
            return new WRest_Error(-1,$e->getMessage());
        }
    }
    
    public function deleteTemplate($templateId){
        $tokenApi = new WRest_Wechat_Token($this->appid, $this->appsecret,$this->crossdomain_url);
        $retry = 2;
        $access_token =$tokenApi->smallprogram_access_token($retry,false);
        if($access_token instanceof WRest_Error){
            return $access_token;
        }
    
        try {
            $response = WRest_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/wxopen/template/del?access_token={$access_token}",json_encode(array(
                'template_id'=>$templateId
            ),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    
            $error =  new WRest_Wechat_Error($this->appid, $this->appsecret,$this->crossdomain_url);
            return $error->validate($response);
        } catch (Exception $e) {
            WRest_Log::error($e);
            return new WRest_Error(-1,$e->getMessage());
        }
    }
    
    public function getTemplateList($start=0,$size=20){
        $tokenApi = new WRest_Wechat_Token($this->appid, $this->appsecret,$this->crossdomain_url);
        $retry = 2;
        $access_token =$tokenApi->smallprogram_access_token($retry,false);
        if($access_token instanceof WRest_Error){
            return $access_token;
        }
        
        try {
            $response = WRest_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/wxopen/template/list?access_token={$access_token}",json_encode(array(
                'offset'=>$start,
                'count'=>$size
            ),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        
            $error =  new WRest_Wechat_Error($this->appid, $this->appsecret,$this->crossdomain_url);
            $response=$error->validate($response);
            
            $list = isset($response['list'])?$response['list']:null;
            $results = array();
            if($list){
                foreach ($list as $item){
                    $results[$item['template_id']] = $item;
                }
            }
            return $results;
        } catch (Exception $e) {
            WRest_Log::error($e);
            return new WRest_Error(-1,$e->getMessage());
        } 
    }
    
    public function sendTemplate($touser,$weapp_template_msg=null,$mp_template_msg=null){
        $tokenApi = new WRest_Wechat_Token($this->appid, $this->appsecret,$this->crossdomain_url);
        $retry = 2;
        $access_token =$tokenApi->smallprogram_access_token($retry,false);
        if($access_token instanceof WRest_Error){
            return $access_token;
        }
        
        try {
            $response = WRest_Helper_Http::http_post("https://api.weixin.qq.com/cgi-bin/message/wxopen/template/uniform_send?access_token={$access_token}",json_encode(array(
                'touser'=>$touser,
                'weapp_template_msg'=>$weapp_template_msg,
                'mp_template_msg'=>$mp_template_msg
            ),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
        
            $error =  new WRest_Wechat_Error($this->appid, $this->appsecret,$this->crossdomain_url);
            return $error->validate($response);
        } catch (Exception $e) {
            WRest_Log::error($e);
            return new WRest_Error(-1,$e->getMessage());
        }
    }
}