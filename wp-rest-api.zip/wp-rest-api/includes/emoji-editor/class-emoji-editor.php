<?php
if (! defined('ABSPATH'))
    exit();

require_once 'class-emoji-editor-config.php';

class WRest_Emoji_Editor{
    private static $__faceArray;
    public static function getFaceArray(){
        if(self::$__faceArray){
            return self::$__faceArray;
        }
        
        self::$__faceArray = array(
            WRest_Emoji_Editor_Config::$face1,
            WRest_Emoji_Editor_Config::$face2,
            WRest_Emoji_Editor_Config::$face3,
            WRest_Emoji_Editor_Config::$face4,
            WRest_Emoji_Editor_Config::$face5
        );
        return self::$__faceArray;
    }
    
    public static function text_to_html($content){
        $faceArray = self::getFaceArray();
        foreach ($faceArray as $group=>$faces){
            $count = count($faces);
            for ($index = 0;$index<$count;$index+=2){
                $content= str_replace($faces[$index], '<img data-emoji="'.$group.'-'.$index.'" src="'.WREST_URL.'/assets/emoji-editor/images/ee'.$faces[$index+1].'.png" width="20px" height="20px" style="cursor:pointer;" />', $content);
            }
        }
        
        return WRest_Helper_String::remove_emoji($content);
    }
   
    public static function html_to_text($content){
       $content = preg_replace_callback('/<img[^>]*data\-emoji\="(\d+\-\d+)"[^>]*>/i',function($m){
           if(count($m)!=2){
               return $m[0];
           }
           
           $ids = explode('-', $m[1]);
           if(count($ids)!=2){
               return $m[0];
           }
           $faceArray = self::getFaceArray();
           return isset($faceArray[$ids[0]][$ids[1]])?$faceArray[$ids[0]][$ids[1]]:$m[0];
       },$content);

       //去除标签
       return trim(strip_tags($content));
    }
    
    public static function editor($content = null,$context=null,$attribute=array()){
        if(!$context){
            $context = WRest_Helper::generate_unique_id();
        }
        
        if(!defined('WSOCIAL_EMOJI_EDITOR')){
            define('WSOCIAL_EMOJI_EDITOR', true);
            ?>
            <style type="text/css">
                .wsocial-emoji-editor{width:98%;min-width:390px;padding: 3px;-moz-border-radius: 5px;font-size: 14px;line-height: 1.6;background-color: #fff;border: 1px solid #ccc;}
                .wsocial-emoj-switch {background: url(<?php echo WREST_URL?>/assets/emoji-editor/images/emotion_editor_z3a7b39.png) 0 0 no-repeat;width: 20px;height: 20px;vertical-align: middle;display: inline-block;} 
                .wsocial-emoji-editor-tab ul{padding-left:15px;list-style:none;width:400px;height:25px;color:#272727;border-bottom:2px solid #1c7fdb;cursor:pointer;}
                .wsocial-emoji-editor-tab ul li{float:left;display:inline;line-height:25px;}
                .wsocial-emoji-editor-emoji-item-emojis{width:400px;padding:0;}               
                .wsocial-emoji-editor-tab ul li a{ display:block; padding:0 11px;height:25px; text-align:center;line-height:25px;text-decoration:none;color:#000;font-size:14px;_display:inline; _zoom:1;}
                .wsocial-emoji-editor-tab ul li a.active{color:#fff;background-color:#1c7fdb;font-weight:700;}
                .wsocial-emoji-editor-tab ul:after{content:"\0020";clear:both;display:block;height:0;}
                .wsocial-emoji-editor-tab ul{zoom:1;}
                .wsocial-emoji-item{clear:none;width:20px;height:20px;float:left;cursor:pointer;list-style: none;line-height: 17px;padding: 3px 5px !important;border-bottom: 1px dashed #EBEBED;}
                
                </style>
                <script type="text/javascript">
					window.wsocial_emoji_editor=[
						<?php echo json_encode(WRest_Emoji_Editor_Config::$face1,JSON_UNESCAPED_UNICODE)?>,
						<?php echo json_encode(WRest_Emoji_Editor_Config::$face2,JSON_UNESCAPED_UNICODE)?>,
						<?php echo json_encode(WRest_Emoji_Editor_Config::$face3,JSON_UNESCAPED_UNICODE)?>,
						<?php echo json_encode(WRest_Emoji_Editor_Config::$face4,JSON_UNESCAPED_UNICODE)?>,
						<?php echo json_encode(WRest_Emoji_Editor_Config::$face5,JSON_UNESCAPED_UNICODE)?>
					];
				</script>
            <?php
        }
        ?>
        <div style="clear: both"></div>
        <div>
             <div style="position:relative;">
              <input type="hidden" name="<?php echo $context?>" id="<?php echo $context?>" value="<?php echo esc_attr($content)?>"/>
              <div contenteditable="plaintext-only" style="text-indent:25px;cursor:auto;-webkit-user-modify:read-write-plaintext-only; <?php echo isset($attribute['style'])?$attribute['style']:null?>" class="wsocial-emoji-editor <?php echo isset($attribute['class'])?$attribute['class']:null?>" id="wsocial-emoji-editor-<?php echo $context?>"><?php echo $content;?></div>            
              <a style="position:absolute;left:5px;top:3px;" href="javascript:void(0);" class="wsocial-emoj-switch" id="wsocial-emoji-editor-<?php echo $context?>-switch"></a>
             </div>
             <div style="clear: both"></div>
             
        	<div id="wsocial-emoji-editor-emojis-<?php echo $context?>" style="width:400px;display:none;margin:0px;padding:0px;">
        		<div class="wsocial-emoji-editor-tab">
        		   <ul>
        				<li><a class="wsocial-emoji-editor-emoji-item-<?php echo $context?> active" href="#wsocial-emoji-editor-emoji-item1-<?php echo $context?>">表情</a></li>
        				<li><a class="wsocial-emoji-editor-emoji-item-<?php echo $context?>" href="#wsocial-emoji-editor-emoji-item2-<?php echo $context?>">自然</a></li>
                        <li><a class="wsocial-emoji-editor-emoji-item-<?php echo $context?>" href="#wsocial-emoji-editor-emoji-item3-<?php echo $context?>">社会</a></li>
                        <li><a class="wsocial-emoji-editor-emoji-item-<?php echo $context?>" href="#wsocial-emoji-editor-emoji-item4-<?php echo $context?>">物品</a></li>
                        <li><a class="wsocial-emoji-editor-emoji-item-<?php echo $context?>" href="#wsocial-emoji-editor-emoji-item5-<?php echo $context?>">字符</a></li>
        		   </ul>
        		</div>
        		<ul class="wsocial-emoji-editor-emoji-item-emojis wsocial-emoji-editor-emoji-item-emojis-<?php echo $context?>" id="wsocial-emoji-editor-emoji-item1-<?php echo $context?>"></ul>
        		<ul class="wsocial-emoji-editor-emoji-item-emojis wsocial-emoji-editor-emoji-item-emojis-<?php echo $context?>" id="wsocial-emoji-editor-emoji-item2-<?php echo $context?>" style="display:none"></ul>
                <ul class="wsocial-emoji-editor-emoji-item-emojis wsocial-emoji-editor-emoji-item-emojis-<?php echo $context?>" id="wsocial-emoji-editor-emoji-item3-<?php echo $context?>" style="display:none"></ul>
                <ul class="wsocial-emoji-editor-emoji-item-emojis wsocial-emoji-editor-emoji-item-emojis-<?php echo $context?>" id="wsocial-emoji-editor-emoji-item4-<?php echo $context?>" style="display:none"></ul>
                <ul class="wsocial-emoji-editor-emoji-item-emojis wsocial-emoji-editor-emoji-item-emojis-<?php echo $context?>" id="wsocial-emoji-editor-emoji-item5-<?php echo $context?>" style="display:none"></ul>
        	</div>
        </div>
        <script type="text/javascript">
        	(function($){
        		window.on_wechat_emoji_editor_submit_<?php echo $context?>=function(){
					return $('#wsocial-emoji-editor-<?php echo $context?>').html();
            	};
            	
        		var f1=f2=f3=f4=f5="";
        		for(i=0;i<wsocial_emoji_editor[0].length;i+=2)f1+='<li onclick="window.wsocial_emoji_editor_insert_emoji_<?php echo $context?>(0,'+i+')" class="wsocial-emoji-item"><img src="<?php echo WREST_URL?>/assets/emoji-editor/images/ee'+window.wsocial_emoji_editor[0][(i+1)]+'.png" width="20px" height="20px" style="cursor:pointer;" /></li>';
        		for(i=0;i<wsocial_emoji_editor[1].length;i+=2)f2+='<li onclick="window.wsocial_emoji_editor_insert_emoji_<?php echo $context?>(1,'+i+')" class="wsocial-emoji-item"><img src="<?php echo WREST_URL?>/assets/emoji-editor/images/ee'+window.wsocial_emoji_editor[1][(i+1)]+'.png" width="20px" height="20px" style="cursor:pointer;" /></li>';
        		for(i=0;i<wsocial_emoji_editor[2].length;i+=2)f3+='<li onclick="window.wsocial_emoji_editor_insert_emoji_<?php echo $context?>(2,'+i+')" class="wsocial-emoji-item"><img src="<?php echo WREST_URL?>/assets/emoji-editor/images/ee'+window.wsocial_emoji_editor[2][(i+1)]+'.png" width="20px" height="20px" style="cursor:pointer;" /></li>';
        		for(i=0;i<wsocial_emoji_editor[3].length;i+=2)f4+='<li onclick="window.wsocial_emoji_editor_insert_emoji_<?php echo $context?>(3,'+i+')" class="wsocial-emoji-item"><img src="<?php echo WREST_URL?>/assets/emoji-editor/images/ee'+window.wsocial_emoji_editor[3][(i+1)]+'.png" width="20px" height="20px" style="cursor:pointer;" /></li>';
        		for(i=0;i<wsocial_emoji_editor[4].length;i+=2)f5+='<li onclick="window.wsocial_emoji_editor_insert_emoji_<?php echo $context?>(4,'+i+')" class="wsocial-emoji-item"><img src="<?php echo WREST_URL?>/assets/emoji-editor/images/ee'+window.wsocial_emoji_editor[4][(i+1)]+'.png" width="20px" height="20px" style="cursor:pointer;" /></li>';

        		$("#wsocial-emoji-editor-emoji-item1-<?php echo $context?>").html(f1);
        		$("#wsocial-emoji-editor-emoji-item2-<?php echo $context?>").html(f2);
        		$("#wsocial-emoji-editor-emoji-item3-<?php echo $context?>").html(f3);
        		$("#wsocial-emoji-editor-emoji-item4-<?php echo $context?>").html(f4);
        		$("#wsocial-emoji-editor-emoji-item5-<?php echo $context?>").html(f5);
        		
        		$('.wsocial-emoji-editor-emoji-item-<?php echo $context?>').click(function(e){
        			$('.wsocial-emoji-editor-emoji-item-<?php echo $context?>.active').removeClass('active');
        			$(this).addClass('active');
        			$('.wsocial-emoji-editor-emoji-item-emojis-<?php echo $context?>').css({display:'none'});
        			$($(this).attr('href')).css({display:'block'});
        			e.stopPropagation();
        			return false;
        		});
        		
        		$('#wsocial-emoji-editor-emojis-<?php echo $context?>').click(function(e){
        			$('#wsocial-emoji-editor-emojis-<?php echo $context?>').attr('active','1').css({display:'block'});
        			e.stopPropagation();
        		});
        
        		$('#wsocial-emoji-editor-<?php echo $context?>').click(function(e){
        			if($('#wsocial-emoji-editor-emojis-<?php echo $context?>').attr('active')=='1'){
            			$('#wsocial-emoji-editor-emojis-<?php echo $context?>').attr('active','1').css({display:'block'});
            			e.stopPropagation();
        			}
        		}).keyup(function(){
					$('#<?php echo $context?>').val(window.on_wechat_emoji_editor_submit_<?php echo $context?>());
					$(document).trigger("on_emoji_editor_<?php echo $context?>_change");
            	});
        		
        		$('#wsocial-emoji-editor-<?php echo $context?>-switch').click(function(e){
        			if($('#wsocial-emoji-editor-emojis-<?php echo $context?>').attr('active')!='1'){
            			$('#wsocial-emoji-editor-emojis-<?php echo $context?>').attr('active','1').css({display:'block'});
            			e.stopPropagation();
        			}
        		});
        		
        		$(document).click(function(e){
        			$('#wsocial-emoji-editor-emojis-<?php echo $context?>').attr('active','0').css({display:'none'});
        		});
        		
        		window.wsocial_emoji_editor_insert_emoji_<?php echo $context?>=function(faceindex,i){
        			var html = '<img data-emoji="'+faceindex+'-'+i+'" src="<?php echo WREST_URL?>/assets/emoji-editor/images/ee'+window.wsocial_emoji_editor[faceindex][i+1]+'.png" width="20px" height="20px" />';
        
        			var $editor = $('#wsocial-emoji-editor-<?php echo $context?>');
        			
           			var sel, range;
          		    if (window.getSelection) {
          		        sel = window.getSelection();
            		    if(!(sel.anchorNode&&sel.anchorNode.parentNode&&sel.anchorNode.parentNode.id&&sel.anchorNode.parentNode.id=='wsocial-emoji-editor-<?php echo $context?>')){
        						$editor.html($editor.html()+html);
        						$editor.keyup();
        						return;
        				}
          		        if (sel.getRangeAt && sel.rangeCount) {
          		            range = sel.getRangeAt(0);
          		            range.deleteContents();
          		            var el = document.createElement("div");
          		            el.innerHTML = html;
          		            var frag = document.createDocumentFragment(), node, lastNode;
          		            while ( (node = el.firstChild) ) {
          		                lastNode = frag.appendChild(node);
          		            };
          		            range.insertNode(frag);
          		            if (lastNode) {
          		                range = range.cloneRange();
          		                range.setStartAfter(lastNode);
          		                range.collapse(true);
          		                sel.removeAllRanges();
          		                sel.addRange(range);
          		            };
          		        };
          		    } else if (document.selection && document.selection.type != "Control") {
          		        // IE9以下
          		        document.selection.createRange().pasteHTML(html);
          		    };

        			$editor.keyup();
        		};
        	
        	})(jQuery);
        </script>
        <?php 
    }
}