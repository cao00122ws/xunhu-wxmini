<?php 
abstract class Abstract_WRest_Mini_TPL extends Abstract_WRest_Mini{
   
	public function get_controllers(){
	    return apply_filters('wrest_body_templates', array(
	        'WRest_Template_KF',
	        'WRest_Template_Orderinfo',
	        'WRest_Template_Useraddress',
	        'WRest_Template_Userinfo',
	        'WRest_Template_Wishlist',
	        'WRest_Template_Emailbind',

	        'WRest_Template_Authorize_Btn_Login',
	    
	        'WRest_Template_Category',
	    
	        'WRest_Template_AlertAd',
	        'WRest_Template_Blank',
	        'WRest_Template_Canvas',
	        'WRest_Template_Dialog',
	        'WRest_Template_Editor',
	        'WRest_Template_GG',
	        'WRest_Template_Graphic_Navigation',
	        'WRest_Template_GZH',
	        'WRest_Template_License',
	        'WRest_Template_Line',
	        'WRest_Template_Link',
	    
	        'WRest_Template_MagicCube',
	        'WRest_Template_Picture_Advertisement',
	        'WRest_Template_Posts',
	        'WRest_Template_Product_List',
	        'WRest_Template_Products',
	        'WRest_Template_Search',
	        'WRest_Template_Title',
	        'WRest_Template_Video',
	        'WRest_Template_Map',
	    ));
	}
	
	public abstract function get_group();
	
	public function render_tpls($version,$foritem,$forindex){
	    $index=0;
	    $group = $this->get_group();
	    foreach ($this->get_controllers() as $class){
	        if(class_exists($class)){
	            $component =  new $class($version,$index++,array());
	            if($component->group==$group){
	                $func = apply_filters('wrest_generate_wxml_item', array($component,'generate_wxml_item'),$component);
	                 call_user_func_array($func, array($foritem,$forindex));
	            }
	        }
	    }
	}
}
?>