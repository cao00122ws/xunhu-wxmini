<?php 
abstract class Abstract_WRest_Mini{
    public $file;
    
	public function __construct($file){
		$this->file = WRest::instance()->WP->get_smallprogram_base_dir($file);
	}
	
	/**
	 * @param WRest_Version|int $version
	 */
	public abstract function render($version);
	
	/**
	 * @param WRest_Version|int $version
	 */
	public function save($version){
		$info = pathinfo($this->file);
		$extension = isset($info['extension'])&&$info['extension']?$info['extension']:'';
		ob_start();
		switch ($extension){
			case 'wxml':
				?>
				<!-- 
				  Project: Wordpress小程序
				  Author: hoter@xunhuweb.com
				  Version: <?php echo $version->get_version_code()?>
				  Date :<?php echo date_i18n('Y-m-d H:i')?>
				  Copyright: xunhuweb (https://www.wpweixin.net)
				  -->
				<?php
				break;
			case 'js':
			case 'wxss':
				?>
				/**
				 * Project: Wordpress小程序
				 * Author: hoter@xunhuweb.com
				 * Version: <?php echo $version->get_version_code()?>
				 * Date :<?php echo date_i18n('Y-m-d H:i')?>
				 * Copyright: xunhuweb (https://www.wpweixin.net)
				 */
				<?php
			break;
		}
		$pre = ob_get_clean();
		
		$dir = @dirname($this->file);
		if(!@is_dir($dir)&&!@mkdir($dir,0777,true)){
			throw new Exception("文件夹创建失败：{$dir}");
		}
		
		if(!@file_put_contents($this->file,$pre. $this->render($version))){
			throw new Exception("文件读写失败：{$this->file}");
		}
		return true;
	}
	
	
}
?>