<?php 
class WRest_Mini_App_Js extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct('app.js');
	}
	
	private static function get_image($config){
	    if(!$config
	        ||!is_array($config)
	        ||!isset($config['url'])
	        ||empty($config['url'])
	        ||!isset($config['width'])
	        ||!$config['width']
	        ||!isset($config['height'])
	        ||!$config['height']
	        ){
	        return null;
	    }
	    
	    if(isset($config['local'])&&$config['local']=='yes'){
	        $config['url'] =  WRest::instance()->WP->convert_remoteimage_to_local($config['url'], '/images/icon/');
	    }
	    return $config;
	}
	
	public function render($version){ 
	    $theme = new WRest_Menu_Store_Theme($version);
	    $icon = new WRest_Menu_Store_Icon($version);
	    $pub = new WRest_Menu_Store_Pub($version);
	    $order = new WRest_Menu_Default_Order($version);
	    
		$iconConfig = array();
		$fields = $icon->get_form_fields();
		foreach ($fields as $field_key=>$settings){
		    if(isset($settings['type'])&&$settings['type']=='image'){
		        $iconConfig["icon_{$field_key}"]= self::get_image($icon->get_option($field_key));
		    }
		}
		
		$iconConfig["icon_status_header_bg"] =  self::get_image($order->get_option('status_header_bg'));
		
		$themeConfig = array();
		
		$themeConfig['navigationBar_TextStyle'] = $theme->get_option('navigationBar_TextStyle');
		$themeConfig['theme_size'] = $theme->get_option('size');
		$themeConfig['theme_line_height'] =WRest_Menu_Store_Theme::get_lineheight();
		$themeConfig['theme_fontsize_sub'] = $theme->get_option('fontsize_sub');
		$themeConfig['theme_c_main'] = '#'.$theme->get_option('color_main');
		$themeConfig['theme_panel'] = '#'.$theme->get_option('color_panel');
		$menus = $pub->export_menus(false);
		if(!$menus||!is_array($menus)){
		    $menus = array();
		}
		
		$menuArray = array();
		if($menus&&count($menus)>=2){
		    $count = 0;
		    foreach ($menus as $menuKey=>$pageSets){
		    	$param_Array = array();
		        if($menuArray[$menuKey]){
		            continue;
		        }
		
		        $menuArray[$menuKey]=$param_Array;
		    }
		}
		
		$events = array();
		$extends = apply_filters('wrest_register_extends', array());
		foreach ($extends as $extend){
		    $extend->register_events($events);
		}
		$apimain = trim(home_url('?rest_route='));
		if(stripos($apimain, 'https://')!==0){
		    throw new Exception('小程序只支持https路由，请在：wordpress 设置/常规 修改域名为https');
		}
		ob_start();
		?>
		const extendList = [];
		<?php 
		foreach ($events as $ev){
		   ?>extendList.push(require('<?php echo $ev;?>'));<?php  
		}
		?>
		
		
		App({
		    Util: require('utils/util.js'),
		    formIds:{},
			//已废弃
			data:{ __config__:{}},
			tmpCart:{},
		    config:{
		        sdk:'1.0.6',
		        version:'<?php echo $version->get_version_code()?>',
			    apiMain:'<?php echo $apimain?>',
			    apiAssets:'<?php echo rtrim($pub->get_option('assets_url',WREST_URL.'/assets'),'/');?>',
		        theme:<?php echo json_encode($themeConfig,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);?>,
		    	menus:<?php echo json_encode($menuArray,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)?>,
		    	icons:<?php echo json_encode($iconConfig,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)?>
		    },
		    apply_filters(action) {
		        if (arguments.length < 2) {
		            throw 'apply filters need argument 2!'
		        }
		        var args = Array.prototype.slice.call(arguments, 1);
		        for (var index in extendList) {
		            var handler = extendList[index];
		            if(!handler.filters){continue;}
                    if (typeof handler.filters[action] != 'function') {
		                continue;
		            }

                    args[0] = handler.filters[action].apply(handler, args);
		        }
		        return args[0];
		    },
		    do_action(action) {
		     	var args = Array.prototype.slice.call(arguments, 1);
		        for (var index in extendList) {
		            var handler = extendList[index];
		            if(!handler.actions){continue;}
                    if (typeof handler.actions[action] != 'function') {
		                continue;
		            }

                    handler.actions[action].apply(handler, args);
		        }
		    },
		    getApi:function(route){
		    	if (!route){
                    return this.config.apiMain;
                }
                route = route.toString();
                if (route[0]!='/'){
                    route = "/" +route;
                 }
                return this.config.apiMain + route;
		    },
		    logout:function(){
		    	this.TOKEN=false;
		    	wx.removeStorageSync('system:token');
		    },
		    isAuthorized: function() {
		        if (typeof this.TOKEN == 'undefined') {
		            try {
		                var cached = wx.getStorageSync('system:token');
		                this.TOKEN = cached ? cached : false;
		            } catch (e) {
		                this.TOKEN = false;
		                //ignore
		            }
		        }

		        return this.TOKEN;
		    },
            onLaunch(){
                wx.getStorageInfo({
                    success: function(res) {
                        if (res.currentSize / res.limitSize>=0.8){
                            wx.clearStorage();
                        }
                    },
                })
            },
			__temp_sys__:false,
		    getSystemInfo: function(onSuccess) {
		        var that = this;
		        if (that.__temp_sys__) {
    		        if (onSuccess) {
                        var pages = getCurrentPages();
                        var obj = Object.assign({}, that.__temp_sys__);
                        var isTab = pages && pages.length > 0 && that.config.menus && typeof that.config.menus[pages[pages.length-1].route]!='undefined';
                        obj.isTab = isTab;
                        obj.isIphoneX = obj.isIphoneX && !isTab;
                        onSuccess(obj);
                    }
		            return;
		        }
		        
				wx.getSystemInfo({
	                success: function(res) {
                 		var isIOS = false;
		                if (res.platform && res.platform.toLowerCase() == 'ios') {
		                    isIOS = true;
		                } else if (res.platform && res.platform.toLowerCase() == 'devtools') {
		                    isIOS = res.system && res.system.toLowerCase().indexOf('ios') > -1;
		                }
		                
                        var statusBarHeight = res.statusBarHeight ? res.statusBarHeight : 20;
                        var navbarHeight = isIOS ? 40 : 48;
		                that.__temp_sys__ = {
		                	isIOS: isIOS,
		                    windowHeight: res.windowHeight,
		                    windowWidth: res.windowWidth,
		                    screenHeight: res.screenHeight,
                    		screenWidth: res.screenWidth,
		                    statusBarHeight: statusBarHeight,
		                    isIphoneX: res.model && res.model.search('iPhone X') != -1,
		                    navbarHeight: navbarHeight,
		                    //v7.0.0以上版本，才支持 自定义navbar
		                    navHeight:res.version >= '7.0.0'?(statusBarHeight+navbarHeight):0
		                };
		                if (onSuccess) {
		                    var pages = getCurrentPages();
	                        var obj = Object.assign({}, that.__temp_sys__);
	                        var isTab = pages && pages.length > 0 && that.config.menus && typeof that.config.menus[pages[pages.length-1].route]!='undefined';
	                        obj.isTab = isTab;
	                        obj.isIphoneX = obj.isIphoneX && !isTab;
	                        onSuccess(obj);
		                }
	                },
	            });
		    }
		})
		<?php 
		return ob_get_clean();
	}
}
?>