<?php

class WRest_Mini_App_Json extends Abstract_WRest_Mini {
    public function __construct() {
        parent::__construct('app.json');
    }

    public function render($version) {
        $theme = new WRest_Menu_Store_Theme($version);
        $pub = new WRest_Menu_Store_Pub($version);
        $window = array(
            'navigationBarBackgroundColor' => '#' . $theme->get_option('navigationBar_BackgroundColor', 'ffffff'),
            'navigationBarTextStyle' => $theme->get_option('navigationBar_TextStyle', 'black'),//white|black
            'navigationBarTitleText' => WRest_Emoji_Editor::html_to_text($pub->get_option('navigationBarTitleText')),
            'backgroundColor' => '#' . $theme->get_option('page_backgroundColor', 'F8F8F8'),
            'backgroundTextStyle' => $theme->get_option('page_backgroundTextStyle', 'dark'),//dark|light
            'backgroundColorTop' => '#' . $theme->get_option('page_backgroundColor', 'F8F8F8'),//顶部窗口的背景色，仅 iOS 支持
            'backgroundColorBottom' => '#' . $theme->get_option('page_backgroundColor', 'F8F8F8'),//底部窗口的背景色，仅 iOS 支持
            'enablePullDownRefresh' => true,
            'onReachBottomDistance' => 50,
            'pageOrientation' => 'portrait',//portrait|auto 屏幕旋转设置
        );

        $tabBar = array(
            'color' => '#' . $theme->get_option('navbar_color', '707070'),
            'selectedColor' => '#' . $theme->get_option('navbar_selectedColor', 'ec5151'),
            'backgroundColor' => '#' . $theme->get_option('navbar_backgroundColor', 'ffffff'),
            'borderStyle' => $theme->get_option('navbar_borderStyle', 'white'),//black|white
            'position' => $theme->get_option('navbar_position', 'bottom'),
        );

        $extMenusArray = array(
            "" => array(
                "pages/index/index",
                "pages/category/index",
                "pages/cart/index",
                "pages/web-view/index",
                "pages/account/index",
                "pages/page/index",
                "pages/article/list/index",
                "pages/article/detail/index",
                "pages/article/search/index",
                "pages/search/index",
                "pages/pay/index",
                "pages/email-bind/index",
                "pages/my-coupon/index"
            ),
            'package_a' => array(
                "pages/address/index",
                "pages/address-detail/index",
                "pages/category/index",
                "pages/checkout/index",
                "pages/checkout/coupon/index",
                "pages/checkout/idcard/index",
                "pages/order/list/index",
                "pages/order/detail/index",
                "pages/order/order-comment/index",
                "pages/order/refund/index",
                "pages/order/refund-m/index",
                "pages/product/detail/index",
                "pages/product/comment-list/index",
                "pages/bind/index",
                "pages/wishlist/index",
                "pages/phone-v/index",
            ),
            'package_c' => array(
                "pages/login/index"
            ),
            'package_b' => array()
        );

        $menus = $pub->export_menus(true);
        $list = array();
        if ($menus && count($menus) >= 2) {
            foreach ($menus as $menuPage => $menuSet) {
                if (!in_array($menuPage, $extMenusArray)) {
                    $extMenusArray[""][] = $menuPage;
                }
                $list[] = $menuSet;
            }
        }
        $tabBar['list'] = $list;

        $navigateToMiniProgramAppIdList = $pub->get_option('app_whitelist');
        $navigateToMiniProgramAppIdLists = $navigateToMiniProgramAppIdList ? explode("\r\n", $navigateToMiniProgramAppIdList) : array();
        if (count($navigateToMiniProgramAppIdLists) > 10) {
            throw new Exception('小程序APPID白名单最多10个');
        }

        $appList = array();
        foreach ($navigateToMiniProgramAppIdLists as $item) {
            if ($item) {
                $appList[] = trim($item);
            }
        }

        $components = array(
            "add-to-cart" => "/components/add-to-cart/index",
            "unauthoirze" => "/components/unauthoirze/index",
            "navigation" => "/components/common/navigation/index",
            "icon-button" => "/components/common/icon-button/index",
            "HTML" => "/components/html2wxml/html2wxml",
            "search-bar" => "/components/common/search-bar/index",
            "cat-dj" => "/components/productcat/dj/index",
            "cat-sj" => "/components/productcat/sj/index",
            "cat-wm" => "/components/productcat/wm/index",
            "cat-ss" => "/components/productcat/ss/index",
            "cat-Fit" => "/components/cat-filter/index",
            "pro-Fit" => "/components/pro-filter/index",
            "TITLE" => "/components/common/title/index",
            "coupon" => "/components/coupon/index",
            "badge" => "/components/common/badge/index",
            "nav" => "/components/nav/index",
            "pro-img" => "/components/product/image/index",
            "pro-big" => "/components/product/big/index",
            "pro-detail" => "/components/product/detail/index",
            "pro-list" => "/components/product/list/index",
            "pro-o3" => "/components/product/oneline3/index",
            "pro-small" => "/components/product/small/index",
            "pro-swip" => "/components/product/swip/index",
            "navT" => "/components/common/nav-title/index",
            "bar" => "/components/bar/index"
        );

        $plugins = array();
        $goodsShare = new WRest_Menu_Store_Goods_Share($version);
        if ('yes' == $goodsShare->get_option('enable_goodShare')) {
            $components['share-button'] = "plugin://goodsSharePlugin/share-button";
            $plugins['goodsSharePlugin'] = array(
                'version' => '3.2.0',
                'provider' => 'wx56c8f077de74b07c'
            );
        }

        $extends = apply_filters('wrest_register_extends', array());
        foreach ($extends as $extend) {
            $extend->register_components($components);
            $extend->register_pages($extMenusArray);
        }

        $config = array(
            'subpackages' => array(),
            'preloadRule' => array(
                "pages/index/index" => array(
                    "network" => "all",
                    "packages" => array("package_a")
                )
            ),
            'window' => $window,
            'tabBar' => $tabBar,
            'debug' => false,
            'networkTimeout' => array(
                "request" => 60000,
                "connectSocket" => 60000,
                "uploadFile" => 120000,
                "downloadFile" => 120000
            ),
            'sitemapLocation' => 'sitemap.json',
            'navigateToMiniProgramAppIdList' => array_values(array_unique($appList)),
            'usingComponents' => $components
        );

        if (count($plugins)) {
            $config['plugins'] = $plugins;
        }

        foreach ($extMenusArray as $package => $pages) {
            if ($package === '') {
                $config["pages"] = array_values(array_unique($pages));
            } else {
                $config["subpackages"][] = array(
                    "root" => $package,
                    "name" => $package,
                    "pages" => array_values(array_unique($pages))
                );
            }
        }

        return json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICOD);
    }
}

?>