<?php 
class WRest_Mini_App_WXSS extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct('app.wxss');
	}
	
	public function render($version){ 
		ob_start();
		?>
		@import "/theme.wxss";
        @import "/template.wxss";
        @import "/templates/prolist/index.wxss";

        .xh-page {
        display: flex;
        flex-direction: column;
        min-height: 100%;
        }
        .container {
        justify-content: space-between;
        }

        .container .left {
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        max-width:660rpx;
        }

        .container .left .icon {
        margin-right: 30rpx;
        }

        .container .right .icon-back {
        display: block;
        position: absolute;
        right: 0rpx;
        top: 50%;
        transform: translate3d(0, -50%, 0) rotate(45deg);
        border: 4rpx solid #aaa;
        border-left: 0;
        border-bottom: 0;
        }

        .container .right {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: row;
        }

        .container .right .sub-title {
        padding-right: 45rpx;
        position: relative;
        }

        .container .right .sub-title::after {
        content: " ";
        display: inline-block;
        height: 16rpx;
        width: 16rpx;
        border-width: 2rpx 2rpx 0 0;
        border-color: #b2b2b2;
        border-style: solid;
        -webkit-transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
        transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
        top: -4rpx;
        position: absolute;
        top: 50%;
        margin-top: -10rpx;
        right: 10rpx;
        }

        <?php
		return ob_get_clean();
	}
}
?>