<?php 
class WRest_Mini_TPL_Bg_WXML extends Abstract_WRest_Mini_TPL{
	public function __construct(){
		parent::__construct('templates/bg.wxml');
	}
	
	public function render($version){ 
		ob_start();
		?>
		<template name="tpl-bg">
    		<?php
    		$this->render_tpls($version, 'tpl', 'tpl_index');
    		?>
		</template>
		<?php 
		return ob_get_clean();
	}
    /**
     * {@inheritDoc}
     * @see Abstract_WRest_Mini_TPL::get_group()
     */
    public function get_group()
    {
       return 'bg';
    }

}
?>