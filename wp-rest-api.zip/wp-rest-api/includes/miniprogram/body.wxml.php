<?php 
class WRest_Mini_TPL_Body_WXML extends Abstract_WRest_Mini_TPL{
	public function __construct(){
		parent::__construct('templates/body.wxml');
	}
	
	public function render($version){ 
		ob_start();
		?>
		<template name="tpl-body">
    		<block wx:for="{{tpls}}" wx:key="{{__section_index__}}" wx:for-index="__section_index__" wx:for-item="__section__">
    		<?php
    		$this->render_tpls($version, '__section__', '__section_index__');
    		?>
    		</block>
		</template>
		<?php 
		
		return ob_get_clean();
	}/**
     * {@inheritDoc}
     * @see Abstract_WRest_Mini_TPL::get_group()
     */
    public function get_group()
    {
       return 'body';
    }
}
?>