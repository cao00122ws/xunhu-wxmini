<?php 
class WRest_Mini_TPL_Footer_WXML extends Abstract_WRest_Mini_TPL{
	public function __construct(){
		parent::__construct('templates/footer.wxml');
	}
	
	public function render($version){ 
		ob_start();
		?>
		<template name="tpl-footer">
    		<?php
    		$this->render_tpls($version, 'tpl', 'tpl_index');
    		?>
		</template>
		<?php 
		return ob_get_clean();
	}
	
	/**
     * {@inheritDoc}
     * @see Abstract_WRest_Mini_TPL::get_group()
     */
    public function get_group()
    {
       return 'footer';
    }
}
?>