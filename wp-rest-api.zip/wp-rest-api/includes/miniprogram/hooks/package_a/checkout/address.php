<?php 
class WRest_Mini_Hooks_Package_A_Checkout_Address extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct("hooks/package_a/checkout/address.wxml");

	}
	
    public function render($version){
	    ob_start();
	    ?>
	    <Checkoutaddress  wx:if="{{!cart.address_model||cart.address_model=='default'}}" cart="{{cart}}" bindaddresschange="onCartChange" /><?php 
	    return apply_filters('wrest_hooks_package_a_checkout_address', ob_get_clean());
	}
}
?>