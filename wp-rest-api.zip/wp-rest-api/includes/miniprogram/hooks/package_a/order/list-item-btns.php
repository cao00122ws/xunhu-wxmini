<?php 
class WRest_Mini_Hooks_Package_A_Order_List_Item_Btns extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct("hooks/package_a/order/list-item-btns.wxml");

	}
	
    public function render($version){
	    ob_start();
	    ?>
	   
	    <?php 
	    return apply_filters('wrest_hooks_package_a_order_list_item_btns', ob_get_clean());
	}
}
?>