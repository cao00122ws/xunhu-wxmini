<?php 
class WRest_Mini_Hooks_Package_A_Order_List_Item_Columns extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct("hooks/package_a/order/list-item-columns.wxml");

	}
	
    public function render($version){
	    ob_start();
	    ?>
	    <view class="xh-row xh-w  xh-mT30">
            <text style="max-width:380rpx;" class="xh-c-sub xh-f-sub single-ellipsis">{{order.summary}}</text>
            <text class="xh-c-main xh-f-sub xh-mL15">等共{{order.item_count}}件</text>
        </view>

        <view class="xh-row xh-w xh-mT15">
            <text class="xh-c-main xh-f-sub">支付金额：</text>
            <text class="xh-c-main xh-f-sub">{{order.currency_symbol}}{{order.total}}</text>
        </view>
	    <?php 
	    return apply_filters('wrest_hooks_package_a_order_list_item_columns', ob_get_clean());
	}
}
?>