<?php 
class WRest_Mini_Hooks_Package_A_Product_Add_To_Cart_Left extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct("hooks/package_a/product/add-to-cart-left.wxml");

	}
	
    public function render($version){
	    ob_start();
	    ?>
	    <button class="brandstore-btn-ll" plain="true" open-type="contact" show-message-card="true" send-message-title="{{productInfo.title}}">
            <image mode="aspectFit" class="icon" src="{{apiAssets}}/images/icon/wechat.png" />
            <view class="xh-f-small" style="color:#62b900;">客服</view>
        </button>
        <button class="brandstore-btn-ll" plain="true" open-type="share">
            <image class="icon" mode="aspectFit" src="{{apiAssets}}/images/v2/icon/share.png?v=3" style="" />
            <view class="xh-c-sub xh-f-small">分享</view>
        </button>
        <button class="brandstore-btn-ll" bindtap="favProductSize" plain="true">
            <image class="icon" mode="aspectFit" wx:if="{{productInfo.isFav}}" src="{{apiAssets}}/images/icon/collect_selected.png" />
            <image class="icon" mode="aspectFit" wx:else src="{{apiAssets}}/images/icon/collect_normal.png" />
            <view class="xh-c-sub xh-f-small">收藏</view>
        </button>
	     <?php 
	    return apply_filters('wrest_hooks_package_a_product_add_to_cart_left', ob_get_clean());
	}
}
?>