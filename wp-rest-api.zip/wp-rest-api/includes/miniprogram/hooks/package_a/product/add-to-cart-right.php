<?php 
class WRest_Mini_Hooks_Package_A_Product_Add_To_Cart_Right extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct("hooks/package_a/product/add-to-cart-right.wxml");

	}
	
    public function render($version){
	    ob_start();
	    ?>
	    <view class="btn-right-ll xh-solid-l">
            <form bindsubmit="addNow" class="btn-form" report-submit-timeout="3000" report-submit="true">
                <button class="xh-btn xh-btn-no-radius xh-btn-default xh-btn-no-border" hover-class="xh-btn-default-hover" formType="submit">加入购物车</button>
            </form>
            <form bindsubmit="buyNow" class="btn-form" report-submit-timeout="3000" report-submit="true">
                <button class="xh-btn xh-btn-primary xh-btn-no-radius xh-btn-no-border" hover-class="xh-btn-primary-hover" formType="submit">立即购买</button>
            </form>
        </view>
	     <?php 
	    return apply_filters('wrest_hooks_package_a_product_add_to_cart_right', ob_get_clean());
	}
}
?>