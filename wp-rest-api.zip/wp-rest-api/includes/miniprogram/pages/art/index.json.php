<?php 
class WRest_Mini_Pages_Art_Json extends Abstract_WRest_Mini{
   /**
    * @var WP_Post
    */
    private $page;
    /**
     * 
     * @param WP_Post $page
     * @param array $settings
     */
	public function __construct($page){
		parent::__construct("exts/art{$page->ID}/index.json");
		$this->page = $page;
	}
	
    public function render($version){ 
		$config = array(
			"navigationBarTitleText"=>$this->page->post_title,
			"enablePullDownRefresh"=>true
		);
		
		ob_start();
		echo json_encode($config,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); 
		return ob_get_clean();
	}
}
?>