<?php 
class WRest_Mini_Pages_Cat_JS extends Abstract_WRest_Mini{
   /**
    * @var WP_Term
    */
    private $wp_term;
    /**
     * 
     * @param WP_Term $wp_term
     * @param array $settings
     */
	public function __construct($wp_term){
		parent::__construct("exts/cat{$wp_term->term_id}/index.js");
		$this->wp_term = $wp_term;
	}
	
    public function render($version){ 
		ob_start();
		?>
		Page(Object.assign({},require('../../templates/cat/index.js'),{
			id:'<?php echo $this->wp_term->term_id?>'
		}));
		<?php 
		return ob_get_clean();
	}
}
?>