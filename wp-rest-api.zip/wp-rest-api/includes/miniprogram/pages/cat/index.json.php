<?php 
class WRest_Mini_Pages_Cat_Json extends WRest_Mini_Pages_Page_Json{
   /**
    * @var WP_Term
    */
    private $wp_term;
    /**
     * 
     * @param WP_Term $wp_term
     * @param array $settings
     */
	public function __construct($wp_term){
		parent::__construct(WRest_Menu_Store_CatDetail::instance(),"exts/cat{$wp_term->term_id}/index.json");
		$this->wp_term = $wp_term;
	}
	
	public function getNavTitle($version){
	    return $this->wp_term->name;
	}
}
?>