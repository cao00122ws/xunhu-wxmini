<?php 
class WRest_Mini_Pages_Cat_WXML extends Abstract_WRest_Mini{
    /**
     * @var WP_Term
     */
    private $wp_term;
    /**
     *
     * @param WP_Term $wp_term
     * @param array $settings
     */
	public function __construct($wp_term){
		parent::__construct("exts/cat{$wp_term->term_id}/index.wxml");
		$this->wp_term = $wp_term;
	}
	
    public function render($version){
	    ob_start();
	    ?>
	     <include src="/templates/cat/index.wxml" />
	    <?php 
	    return ob_get_clean();
	}
}
?>