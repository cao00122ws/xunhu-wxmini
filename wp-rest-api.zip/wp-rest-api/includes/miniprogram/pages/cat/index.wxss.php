<?php 
class WRest_Mini_Pages_Cat_WXSS extends WRest_Mini_Pages_Page_WXSS{
/**
     * @var WP_Term
     */
    private $wp_term;
    /**
     *
     * @param WP_Term $wp_term
     * @param array $settings
     */
	public function __construct($wp_term){
		parent::__construct(WRest_Menu_Store_CatDetail::instance(),"exts/cat{$wp_term->term_id}/index.wxss");
		$this->wp_term = $wp_term;
	}
}
?>