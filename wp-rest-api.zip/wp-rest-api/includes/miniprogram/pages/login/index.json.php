<?php 
class WRest_Mini_Pages_Login_Json extends Abstract_WRest_Mini{
    public $api;
    
	public function __construct(){
		parent::__construct("package_c/pages/login/index.json");
		$this->api = WRest_Menu_Store_Login::instance();
	}
	
    public function render($version){ 
		$config = array(
			"navigationBarTitleText"=>WRest_Emoji_Editor::html_to_text($this->api->get_window_field($version, 'navigationBarTitleText',get_bloginfo('name'))),
			"enablePullDownRefresh"=>false,
		    "navigationStyle"=>"custom"
		);
		
		ob_start();
		echo json_encode($config,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); 
		return ob_get_clean();
	}
}
?>