<?php 
class WRest_Mini_Pages_Login_WXML extends WRest_Mini_Pages_Page_WXML{
	public function __construct(){
		parent::__construct(WRest_Menu_Store_Login::instance(),"package_c/pages/login/index.wxml");
	}
	
    public function render($version){ 
        $title = WRest_Emoji_Editor::html_to_text($this->api->get_window_field($version, 'navigationBarTitleText',get_bloginfo('name')));
		ob_start();
		?>
		<nav hidden showAni="{{navbarShowAni}}" title="<?php echo esc_attr($title)?>" />
		
         <view wx:if="{{login_confirm_code}}" style="display: flex;align-items: center;justify-content: center; position: fixed;bottom: 0;left: 0;width: 100%;height: 100%;background-color: rgba(0, 0, 0, 0.6);z-index: 300;">
            <view class="xh-panel xh-column " style="width: 600rpx;height:280rpx;justify-content:space-between;">
                <view class="xh-w xh-p30 xh-c-main xh-f-main xh-t-c">{{login_confirm_code=='wechat_need_bind'?('微信是否绑定到当前手机账户？（依欧美账户）'):('微信已经绑定其他账户，是否解绑并绑定到当前手机号？')}}</view>
                <view class="xh-w xh-row ">
                   <button class="xh-btn xh-btn-default xh-btn-no-radius" hover-class='xh-btn-default' style="width: 50%;" bindtap='onCancel'>取消</button>
                    <button class="xh-btn xh-btn-primary xh-btn-no-radius" hover-class='xh-btn-primary' style="width: 50%;" open-type="getUserInfo" bindgetuserinfo="onGetUserInfo">确定</button>
                </view>
            </view>
        </view>
		<?php 
		$nav = ob_get_clean();
		
        return $nav.parent::render($version);
	}
}
?>