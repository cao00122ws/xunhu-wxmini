<?php 
class WRest_Mini_Pages_Page_Json extends Abstract_WRest_Mini{
    private $api,$settings;
	public function __construct($api,$pathPath,$settings=array()){
		parent::__construct($pathPath);
		$this->api  = $api;
		$this->settings = shortcode_atts(array(
		    'enablePullDownRefresh'=>true
		), $settings);
	}
	
	public function getNavTitle($version){
	    $api = $this->api;
	    return WRest_Emoji_Editor::html_to_text($api->get_window_field($version, 'navigationBarTitleText',get_bloginfo('name')));
	}
	
	public function render($version){ 
		$config = array(
			"navigationBarTitleText"=>$this->getNavTitle($version),
			"enablePullDownRefresh"=>'yes'==$this->settings['enablePullDownRefresh']
		);
		
		ob_start();
		echo json_encode($config,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); 
		return ob_get_clean();
	}
}
?>