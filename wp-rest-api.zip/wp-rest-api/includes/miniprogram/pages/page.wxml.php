<?php 
class WRest_Mini_Pages_Page_WXML extends Abstract_WRest_Mini{
	/**
	 * 
	 * @var Abdtract_WRest_XCX_Setting_Menu
	 */
 	protected $api,$settings;
 	
	public function __construct($api,$pathPath,$settings=array()){
		parent::__construct($pathPath);
		$this->api  = $api;
		$this->settings = shortcode_atts(array(
		    'style_body'=>null
		), $settings);
	}
	
	public function render($version){ 	  
		$api = $this->api;
	
		ob_start();
		?>
		 <import src="/templates/body.wxml" />
		 <import src="/templates/bg.wxml" />
		 <import src="/templates/footer.wxml" />
	 	 
	 	 <?php if($api->isShowRightBar()){
		     ?><bar wx:if="{{templates.length}}" show="{{rightBarShow}}" cart="{{cart}}" <?php echo !$api->isShowRightBar_Home()?'hideHome':'';?> <?php echo !$api->isShowRightBar_Cart()?'hideCart':'';?>/><?php 
		 }?>
		 <view id="body">
		 	<template is="tpl-body" data="{{tpls:templates,config:config,cart:cart}}" />
         </view>
         <view id="footer">	
         	<template is="tpl-footer" data="{{tpl:footer,config:config,cart:cart}}" />
         </view>	
         <view id="bg">
          	<template is="tpl-bg" data="{{tpl:bg,config:config,cart:cart}}" />
         </view>
        <?php 
		return ob_get_clean();
	}
}
?>