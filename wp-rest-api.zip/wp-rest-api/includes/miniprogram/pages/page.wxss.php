<?php 
class WRest_Mini_Pages_Page_WXSS extends Abstract_WRest_Mini{
	/**
	 * 
	 * @var Abdtract_WRest_XCX_Setting_Menu
	 */
 	private $api,$settings;
	public function __construct($api,$pathPath,$settings=array()){
		parent::__construct($pathPath);
		$this->api  = $api;
		$this->settings = shortcode_atts(array(
		   
		), $settings);
	}
	
	public function render($version){ 	  
		$api = $this->api;
	
		ob_start();
		?>
		
        <?php 
		return ob_get_clean();
	}
}
?>