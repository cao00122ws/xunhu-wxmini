<?php 
class WRest_Mini_Pages_Pg_JS extends Abstract_WRest_Mini{
   /**
    * @var WP_Post
    */
    private $page;
    /**
     * 
     * @param WP_Post $page
     * @param array $settings
     */
	public function __construct($page){
		parent::__construct("exts/page{$page->ID}/index.js");
		$this->page = $page;
	}
	
	public function render($version){ 
		
		ob_start();
		?>
		Page(Object.assign({},require('../../templates/page/index.js'),{
			id:'<?php echo $this->page->ID?>'
		}));
		<?php 
		return ob_get_clean();
	}
}
?>