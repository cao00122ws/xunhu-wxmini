<?php 
class WRest_Mini_Pages_Pg_Json extends WRest_Mini_Pages_Page_Json{
   /**
    * @var WP_Post
    */
    private $page;
    /**
     * 
     * @param WP_Post $page
     * @param array $settings
     */
	public function __construct($page){
		parent::__construct(WRest_Menu_Store_CatDetail::instance(),"exts/page{$page->ID}/index.json");
		$this->page = $page;
	}
	
	public function getNavTitle($version){
	    return $this->page->post_title;
	}
}
?>