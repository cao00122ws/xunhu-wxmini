<?php 
class WRest_Mini_Pages_Pg_WXSS extends WRest_Mini_Pages_Page_WXSS{
    /**
    * @var WP_Post
    */
    private $page;
    /**
     * 
     * @param WP_Post $page
     * @param array $settings
     */
	public function __construct($page){
		parent::__construct(WRest_Menu_Store_CatDetail::instance(),"exts/page{$page->ID}/index.wxss");
		$this->page = $page;
	}
}
?>