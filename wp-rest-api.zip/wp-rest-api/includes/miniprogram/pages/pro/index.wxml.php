<?php 
class WRest_Mini_Pages_Pro_WXML extends Abstract_WRest_Mini{
    /**
    * @var WP_Post
    */
    private $page;
    /**
     * 
     * @param WP_Post $page
     * @param array $settings
     */
	public function __construct($page){
		parent::__construct("exts/pro{$page->ID}/index.wxml");
		$this->page = $page;
	}
	
	public function render($version){
	    ob_start();
	    ?>
	     <include src="/templates/pro/index.wxml" />
	    <?php 
	    return ob_get_clean();
	}
}
?>