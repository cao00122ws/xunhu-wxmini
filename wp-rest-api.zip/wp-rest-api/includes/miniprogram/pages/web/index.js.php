<?php 
class WRest_Mini_Pages_Web_JS extends Abstract_WRest_Mini{
    private $url;
 
    public function __construct($wrest_webview_key,$url){
		parent::__construct("exts/web{$wrest_webview_key}/index.js");
		$this->url = $url;
	}
	
	public function render($version){ 
		
		ob_start();
		?>
		Page(Object.assign({},require('../../templates/web/index.js'),{
			url:'<?php echo urlencode($this->url)?>'
		}));
		<?php 
		return ob_get_clean();
	}
}
?>