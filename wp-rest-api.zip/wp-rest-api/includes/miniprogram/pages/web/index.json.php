<?php 
class WRest_Mini_Pages_Web_Json extends Abstract_WRest_Mini{

    public function __construct($wrest_webview_key,$url){
    	parent::__construct("exts/web{$wrest_webview_key}/index.json");
	}
	
    public function render($version){ 
		$config = array(
			"enablePullDownRefresh"=>false
		);
		
		ob_start();
		echo json_encode($config,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); 
		return ob_get_clean();
	}
}
?>