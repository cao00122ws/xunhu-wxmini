<?php 
class WRest_Mini_Pages_Web_WXML extends Abstract_WRest_Mini{
    /**
     * 
     * @param WP_Post $page
     * @param array $settings
     */
    public function __construct($wrest_webview_key,$url){
    	parent::__construct("exts/web{$wrest_webview_key}/index.wxml");
	}
	
	public function render($version){
	    ob_start();
	    ?>
	     <include src="/templates/web/index.wxml" />
	    <?php 
	    return ob_get_clean();
	}
}
?>