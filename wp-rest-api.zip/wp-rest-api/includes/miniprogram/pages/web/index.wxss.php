<?php 
class WRest_Mini_Pages_Web_WXSS extends Abstract_WRest_Mini{
    public function __construct($wrest_webview_key,$url){
    	parent::__construct("exts/web{$wrest_webview_key}/index.wxss");
	}
	
	public function render($version){
	    ob_start();
	    ?>@import "/templates/web/index.wxss";<?php 
	    return ob_get_clean();
	}
}
?>