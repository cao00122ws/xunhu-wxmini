<?php
abstract class Abstract_WRest_Mini_Plugin{
    public $dir,$toDir;
    public function __construct($dir,$toDir){
        $this->dir = $dir;
        $this->toDir = $toDir;
    }
    
    public function register_components(&$components){}
    
    public function register_pages(&$pages){}
    
    public function register_events(&$event){}
    
    public function save($version){
        WRest::instance()->WP->copyDir($this->dir, $this->toDir);
    }
}

abstract class Abstract_WRest_Mini_Plugin_Root extends Abstract_WRest_Mini_Plugin {

	public function __construct($dir,$toDir){
		if(strpos($toDir, '/')!==0){
			$toDir ="/{$toDir}";
		}
		
		parent::__construct($dir, WREST_DIR."/output/v2/plugins".$toDir);
	}
}

abstract class Abstract_WRest_Mini_Plugin_Package extends Abstract_WRest_Mini_Plugin {

	public function __construct($dir,$toDir){
		if(strpos($toDir, '/')!==0){
			$toDir ="/{$toDir}";
		}
		
		parent::__construct($dir,  WREST_DIR."/output/v2/package_b".$toDir);
	}
}