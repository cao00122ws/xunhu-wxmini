<?php 
class WRest_Mini_Project_Config_Json extends Abstract_WRest_Mini{
	public function __construct(){
		parent::__construct('/project.config.json');
	}
	
	public function render($version){ 
		$api = WRest_Settings_Default_Basic_Default::instance();
		$pub = new WRest_Menu_Store_Pub($version);
		ob_start();
		?>
		{
    	"description": "项目配置文件",
    	"packOptions": {
    		"ignore": []
    	},
    	"setting": {
    		"urlCheck": false,
    		"es6": true,
    		"postcss": true,
    		"minified": true,
    		"newFeature": true,
    		"nodeModules": false,
    		"autoAudits": false,
    		"uglifyFileName": true
    	},
    	"compileType": "miniprogram",
    	"libVersion": "2.6.1",
    	"appid": "<?php echo esc_attr($api->get_option('appid'));?>",
    	"projectname": "<?php echo esc_attr(WRest_Emoji_Editor::html_to_text($pub->get_option('navigationBarTitleText')) );?>",
    	"debugOptions": {
    		"hidedInDevtools": []
    	},
    	"isGameTourist": false,
    	"simulatorType": "wechat",
    	"simulatorPluginLibVersion": {},
    	"condition": {
    		"search": {
    			"current": -1,
    			"list": []
    		},
    		"conversation": {
    			"current": -1,
    			"list": []
    		},
    		"plugin": {
    			"current": -1,
    			"list": []
    		},
    		"game": {
    			"currentL": -1,
    			"list": []
    		},
    		"miniprogram": {
    			"current": 7,
    			"list": []
    		}
    	}
    }
		<?php 
		return ob_get_clean();
	}
}
?>