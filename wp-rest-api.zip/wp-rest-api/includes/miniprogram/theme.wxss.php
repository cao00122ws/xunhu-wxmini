<?php 
class WRest_Mini_App_Theme_WXSS extends Abstract_WRest_Mini{
    private $args;
	public function __construct($args=array()){
		parent::__construct('/theme.wxss');
		$this->args = shortcode_atts(array(
		    'width'=>750,
		    'padding'=>30,
		    'ratio'=>1,
		    'page'=>'page',
		    'view'=>'view',
		    'text'=>'text',
		    'image'=>'image'
		), $args);
	}
	
	
	public function render($version){ 
		$layout = WRest_Menu_Store_Layout::instance();
		require_once WREST_DIR.'/includes/admin/menus/class-wrest-menu-layout-theme.php';
		$theme = new WRest_Menu_Store_Theme($version);
		$order = new WRest_Menu_Default_Order($version);
		
		ob_start();
		$lineheight = WRest_Menu_Store_Theme::get_lineheight();
		$padding = $this->args['padding']*$this->args['ratio'];
		
		echo $this->args['page']?>{
            box-sizing: border-box;
            background-color:#<?php echo $theme->get_option('page_backgroundColor')?>
        }
		<?php echo $this->args['view']?>{
			box-sizing: border-box;
			color:#<?php echo $theme->get_option('color_main')?>;
			font-size:<?php echo $theme->get_option('fontsize_sub')*$this->args['ratio']?>rpx;
			line-height:<?php echo $lineheight;?>;
		}
		<?php echo $this->args['image']?>{display:block;}
		.xh-dialog{background:rgba(0, 0, 0, 0.3);width:100%;height:100%;position:fixed;left:0;top:0;z-index:99}
		
		.xh-bg-tab{background-color:#<?php echo $theme->get_option('color_tab')?>}
		.xh-c-main-i{
			color:#<?php echo $theme->get_option('color_main_i')?>
		}
		.xh-f-price{
			font-size:<?php echo $theme->get_option('fontsize_main_i')*$this->args['ratio']?>rpx;
			line-height: <?php echo round($theme->get_option('fontsize_main_i')*$this->args['ratio']*$lineheight,2)?>rpx;
		}
		.xh-price-h-min{
			height:<?php echo round($theme->get_option('fontsize_main_i')*$this->args['ratio']*$lineheight,2)?>rpx;
		}
		/*------------------------------*/
		.xh-f-big{
			font-size:<?php echo $theme->get_option('fontsize_big')*$this->args['ratio']?>rpx;
		}
		/*------------------------------*/
		
		.xh-c-main{
			color:#<?php echo $theme->get_option('color_main')?>
		}
		
		.xh-f-main-i{
			font-size:<?php echo $theme->get_option('fontsize_main_i')*$this->args['ratio']?>rpx;
		}
		.xh-f-main{
			font-size:<?php echo $theme->get_option('fontsize_main')*$this->args['ratio']?>rpx;
		}
		.xh-H-main{
			min-height: <?php echo round($theme->get_option('fontsize_main')*$this->args['ratio']*$lineheight,2)?>rpx
		}
		.xh-H-main-2{
			min-height: <?php echo round($theme->get_option('fontsize_main')*$this->args['ratio']*2*$lineheight,2)?>rpx
		}
		.xh-nav-icon{
			max-width:<?php echo round($theme->get_option('fontsize_main')*$this->args['ratio']*$lineheight)?>rpx;
            max-height:<?php echo round($theme->get_option('fontsize_main')*$this->args['ratio']*$lineheight)?>rpx;
		}
		.xh-c-link{
			color:#<?php echo $theme->get_option('color_link')?>;
		}
		.xh-c-handle-w{
			color:#<?php echo $theme->get_option('color_handle_warning')?>;
		}
		.xh-c-price{
			color:#<?php echo $theme->get_option('color_active_price')?>;
		}
		/*------------------------------*/
		.xh-c-sub{
			color:#<?php echo $theme->get_option('color_sub')?>;
		}
		.xh-f-sub{
			font-size:<?php echo $theme->get_option('fontsize_sub')*$this->args['ratio']?>rpx;
		}
		.xh-H-sub{
			min-height:<?php echo round($theme->get_option('fontsize_sub')*$this->args['ratio']*$lineheight,2)?>rpx
		}
		.xh-H-sub-2{
			min-height:<?php echo round($theme->get_option('fontsize_sub')*$this->args['ratio']*2*$lineheight,2)?>rpx
		}
		
		/*------------------------------*/
		.xh-f-small{
			font-size:<?php echo $theme->get_option('fontsize_small')*$this->args['ratio']?>rpx;
		}
		/*------------------------------*/
		.xh-c-placeholder{color:#<?php echo $theme->get_option('color_placeholder')?>;}
		
		<?php 
		$solid = $theme->get_option('border_solid');
		if(!$solid||!is_array($solid)){$solid=array();}
		$dashed = $theme->get_option('border_dashed');
		if(!$dashed||!is_array($dashed)){$dashed=array();}
		?>
		
		.xh-solid-t{
			border-top:solid <?php echo isset($solid['size'])?$solid['size']:'1'?>rpx #<?php echo isset($solid['color'])?$solid['color']:'e5e5e5'?>;
		}
		
		.xh-solid-r{
			border-right:solid <?php echo isset($solid['size'])?$solid['size']:'1'?>rpx #<?php echo isset($solid['color'])?$solid['color']:'e5e5e5'?>;
		}
		.xh-solid-l{
			border-left:solid <?php echo isset($solid['size'])?$solid['size']:'1'?>rpx #<?php echo isset($solid['color'])?$solid['color']:'e5e5e5'?>;
		}
		.box-shadow-l{
            box-shadow:-8rpx 0 0 <?php echo WRest_Helper::hex2rgba(isset($solid['color'])?$solid['color']:'e5e5e5',0.8)?>;
        }
        .box-shadow-r{
            box-shadow:8rpx 0 0 <?php echo WRest_Helper::hex2rgba(isset($solid['color'])?$solid['color']:'e5e5e5',0.8)?>;
        }
		.xh-solid{
			border:solid <?php echo isset($solid['size'])?$solid['size']:'1'?>rpx #<?php echo isset($solid['color'])?$solid['color']:'e5e5e5'?>;
		}
		.xh-solid-b{
			border-bottom:solid <?php echo isset($solid['size'])?$solid['size']:'1'?>rpx #<?php echo isset($solid['color'])?$solid['color']:'e5e5e5'?>;
		}
		.xh-solid-b-after::after {
            content: '';
            width: 200%;
            height: 0;
            position: absolute;
            bottom: 0;
            left: 0;
            border-bottom: solid <?php echo isset($solid['size'])?$solid['size']:'1'?>rpx #<?php echo isset($solid['color'])?$solid['color']:'e5e5e5'?>;
            transform-origin: 0 0;
            transform: scale(0.5);
        }
        
        .xh-solid-after::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 200%;
            height: 200%;
            border: solid <?php echo isset($solid['size'])?$solid['size']:'1'?>rpx #<?php echo isset($solid['color'])?$solid['color']:'e5e5e5'?>;
            box-sizing: border-box;
            border-radius: 4rpx;
            transform-origin: 0 0;
            transform: scale(0.5);
        }
		.xh-row{
            display:flex!important;
            flex-direction: row;
            align-items:center;
            justify-content: flex-start;
        }
        .xh-row-c{justify-content:center;}
        .xh-column{
            display:flex!important;
            flex-direction:column;
            align-items:flex-start;
            justify-content: flex-start;
        }
        .xh-column-c{align-items:center;}
        
        .xh-bg-clear{background-color:transparent;}
		.xh-radius{border-radius:<?php echo 5*$this->args['ratio']?>rpx;}
		
		.xh-active-b{background-color:#<?php echo $theme->get_option('color_active_bg')?>}
		.xh-c-active{color:#<?php echo $theme->get_option('color_active_font')?>}
		.xh-c-active-B{border-bottom:solid 4rpx #<?php echo $theme->get_option('color_active_border')?>}
		.xh-active-border{border:solid 1rpx #<?php echo $theme->get_option('color_active_border')?>}
		
        .xh-bg{background-color:<?php echo WRest_Helper::hex2rgba($theme->get_option('page_backgroundColor'))?>}
		.xh-panel{background-color:<?php echo WRest_Helper::hex2rgba($theme->get_option('color_panel'))?>}
		.xh-panel-main{background-color:<?php echo WRest_Helper::hex2rgba($theme->get_option('color_panel_active'))?>}
		.xh-panel-hover{background-color:<?php echo WRest_Helper::hex2rgba($theme->get_option('color_panel'),0.2)?>}

		.xh-scroll{overflow:hidden;white-space: nowrap;flex-wrap:nowrap;}
		.xh-scroll .xh-scroll-item{display:inline-flex;}
		
		<?php 
		$btn_default = $theme->get_option('btn_default');
		if(!$btn_default||!is_array($btn_default)){$btn_default=array();}
		
		$btn_primary = $theme->get_option('btn_primary');
		if(!$btn_primary||!is_array($btn_primary)){$btn_primary=array();}
		
		$btn_warning = $theme->get_option('btn_warning');
		if(!$btn_warning||!is_array($btn_warning)){$btn_warning=array();}
		
		$btn_disabled = $theme->get_option('btn_disabled');
		if(!$btn_disabled||!is_array($btn_disabled)){$btn_disabled=array();}
		?>
		.xh-btn-default{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_default['bg'])?$btn_default['bg']:'')?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_default['font'])?$btn_default['font']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_default['border'])?$btn_default['border']:'')?>;
		}
		
		.xh-btn-default[plain]{
			background-color:transparent;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_default['border'])?$btn_default['border']:'')?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_default['font'])?$btn_default['font']:'')?>;
		}
		
		.xh-btn-default-hover{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_default['bg'])?$btn_default['bg']:'',0.6)?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_default['font'])?$btn_default['font']:'',0.6)?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_default['border'])?$btn_default['border']:'',0.6)?>;
		}
		
		.xh-btn-default-hover[plain]{
			background-color:transparent;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_default['font'])?$btn_default['font']:'',0.6)?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_default['border'])?$btn_default['border']:'',0.6)?>;
		}
		
		.xh-btn-primary{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_primary['bg'])?$btn_primary['bg']:'')?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_primary['font'])?$btn_primary['font']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_primary['border'])?$btn_primary['border']:'')?>;
		}
		.xh-btn-primary[plain]{
			background-color:transparent;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_primary['border'])?$btn_primary['border']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_primary['border'])?$btn_primary['border']:'')?>;
		}
		.xh-btn-primary-hover{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_primary['bg'])?$btn_primary['bg']:'',0.6)?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_primary['font'])?$btn_primary['font']:'',0.6)?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_primary['border'])?$btn_primary['border']:'',0.6)?>;
		}
		.xh-btn-primary-hover[plain]{
			background-color:transparent;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_primary['border'])?$btn_primary['border']:'',0.6)?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_primary['border'])?$btn_primary['border']:'',0.6)?>;
		}
		
		.xh-btn-warning{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_warning['bg'])?$btn_warning['bg']:'')?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_warning['font'])?$btn_warning['font']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_warning['border'])?$btn_warning['border']:'')?>;
		}
		.xh-btn-warning[plain]{
			background-color:transparent;
			color: <?php echo WRest_Helper::hex2rgba(isset($btn_warning['border'])?$btn_warning['border']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_warning['border'])?$btn_warning['border']:'')?>;
		}
		.xh-btn-warning-hover{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_warning['bg'])?$btn_warning['bg']:'',0.6)?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_warning['font'])?$btn_warning['font']:'',0.6)?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_warning['border'])?$btn_warning['border']:'',0.6)?>;
		}
		.xh-btn-warning-hover[plain]{
			background-color:transparent;
			color: <?php echo WRest_Helper::hex2rgba(isset($btn_warning['border'])?$btn_warning['border']:'',0.6)?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_warning['border'])?$btn_warning['border']:'',0.6)?>;
		}
		
		.xh-btn-disabled{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_disabled['bg'])?$btn_disabled['bg']:'')?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_disabled['font'])?$btn_disabled['font']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_disabled['border'])?$btn_disabled['border']:'')?>;
		}
		.xh-btn-disabled[disabled]{
			background-color:<?php echo WRest_Helper::hex2rgba(isset($btn_disabled['bg'])?$btn_disabled['bg']:'')?>;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_disabled['font'])?$btn_disabled['font']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_disabled['border'])?$btn_disabled['border']:'')?>;
		}
		.xh-btn-disabled[plain]{
			background-color:transparent;
			color:<?php echo WRest_Helper::hex2rgba(isset($btn_disabled['border'])?$btn_disabled['border']:'')?>;
			border:solid 1rpx <?php echo WRest_Helper::hex2rgba(isset($btn_disabled['border'])?$btn_disabled['border']:'')?>;
		}
		.xh-btn{padding:auto <?php echo $padding;?>rpx;margin:0;display:flex;flex-direction: column;justify-content: center;align-items:center;height:100rpx;font-size:32rpx;}
		.xh-btn-no-border{border: none!important;}
        .xh-btn-no-border::after{border: none!important;}
		.xh-btn-no-radius{border-radius: 0!important;}
		.xh-btn-no-radius::after{border-radius: 0!important;}
		.xh-btn-sm{height:70rpx;font-size:28rpx;}
        .xh-btn-xs{height:50rpx;font-size:22rpx;}
		.xh-btn-clear{border: none;border-radius: 0;padding:0;margin:0;}
		.xh-btn-clear::after{border: none;border-radius: 0;padding:0;margin:0;}
		.xh-coupon-active{background:#ff7573;color:#fff;}
		
		.xh-w{width:100%;}
		.xh-hidden{display:none;}
		.xh-t-c{text-align:center;}
		.xh-mw{max-width:100%;}
		.xh-w-345{width:<?php echo $this->args['width']/2;?>rpx!important;}
		.xh-w-750{width:<?php echo $this->args['width'];?>rpx!important;}
		.xh-w-690{width:<?php echo $this->args['width']-$padding*2;?>rpx!important;}
		.xh-w-720{width:<?php echo $this->args['width']-$padding;?>rpx!important;}
		.xh-mw-345{max-width:<?php echo $this->args['width']/2;?>rpx!important;}
		.xh-mw-750{max-width:<?php echo $this->args['width'];?>rpx!important;}
		.xh-mw-690{max-width:<?php echo $this->args['width']-$padding*2;?>rpx!important;}
		.xh-mw-720{max-width:<?php echo $this->args['width']-$padding;?>rpx!important;}
		.xh-B{font-weight: bold;}
        .xh-B2{font-weight: bolder;}
        
        .xh-p-tab{padding-top:<?php echo ($padding/2)+5;?>rpx!important;padding-bottom:<?php echo ($padding/2)+5;?>rpx!important;}
        .xh-p30{padding:<?php echo $padding;?>rpx!important;}
        .xh-pR30{padding-right:<?php echo $padding;?>rpx!important;}
        .xh-pL30{padding-left:<?php echo $padding;?>rpx!important;}
        .xh-pT30{padding-top:<?php echo $padding;?>rpx!important;}
        .xh-pB30{padding-bottom:<?php echo $padding;?>rpx!important;}
        
        .xh-p15{padding:<?php echo $padding/2;?>rpx!important;}
		.xh-pB15{padding-bottom:<?php echo $padding/2;?>rpx!important;}
		.xh-pT15{padding-top:<?php echo $padding/2;?>rpx!important;}
		.xh-pL15{padding-left:<?php echo $padding/2;?>rpx!important;}
        .xh-pR15{padding-right:<?php echo $padding/2;?>rpx!important;}
        
        .xh-m30{margin:<?php echo $padding;?>rpx!important;}
        .xh-mL30{margin-left:<?php echo $padding;?>rpx!important;}
		.xh-mR30{margin-right:<?php echo $padding;?>rpx!important;}
		.xh-mT30{margin-top:<?php echo $padding;?>rpx!important;}
		.xh-mB30{margin-bottom:<?php echo $padding;?>rpx!important;}
		
		.xh-m15{margin:<?php echo $padding/2;?>rpx!important;}
		.xh-mL15{margin-left:<?php echo $padding/2;?>rpx!important;}
		.xh-mT15{margin-top:<?php echo $padding/2;?>rpx!important;}
		.xh-mB15{margin-bottom:<?php echo $padding/2;?>rpx!important;}
		.xh-mR15{margin-right:<?php echo $padding/2;?>rpx!important;}
		
		.xh-p0{padding:0rpx!important;}
        .xh-pR0{padding-right:0rpx!important;}
        .xh-pL0{padding-left:0rpx!important;}
        .xh-pT0{padding-top:0rpx!important;}
        .xh-pB0{padding-bottom:0rpx!important;}
        
        .xh-m0{margin:0rpx!important;}
        .xh-mL0{margin-left:0rpx!important;}
		.xh-mR0{margin-right:0rpx!important;}
		.xh-mT0{margin-top:0rpx!important;}
		.xh-mB0{margin-bottom:0rpx!important;}
		.xh-nowrap{white-space: nowrap!important;flex-wrap:nowrap!important;}
		.xh-c{margin-left:auto!important;margin-right:auto!important;}
		
        .single-ellipsis {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box!important;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
            white-space:pre-wrap;
        }

        .multi-ellipsis {
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box!important;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            white-space:pre-wrap;
        }
       
        .noscroll {
            top: 0px;
            left: 0px;
            width: 100%;
            height: 100%;
            overflow: hidden;
            position: fixed;
            z-index: 0;
        }
        .sticky {
            position:sticky!important;
            top: 0;
            z-index: 2;
            display: block;
        }
        
        .woocommerce-price-container,.woocommerce-price-container .woocommerce-Price-amount {
         	font-size: <?php echo $theme->get_option('fontsize_main_i')*$this->args['ratio']?>rpx;
            color: #<?php echo $theme->get_option('color_main_i')?>;
            line-height: <?php echo $lineheight?>;
            height: <?php echo round($theme->get_option('fontsize_main_i')*$this->args['ratio']*$lineheight,2)?>rpx;
            overflow: hidden!important;
            white-space: nowrap!important;
            text-overflow: ellipsis;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1;
            flex-wrap:nowrap!important;
        }

        .woocommerce-price-container .ins,.woocommerce-price-container .del {
            text-decoration: none;
        }
         .woocommerce-price-container .woocommerce-Price-currencySymbol {
            font-size: <?php echo $theme->get_option('fontsize_sub')*$this->args['ratio']?>rpx;
        }
       
        .woocommerce-price-container .del{
            margin-left: <?php echo $padding/2?>rpx;
            text-decoration: line-through;
        }
        .woocommerce-price-container .del .woocommerce-Price-amount,.woocommerce-price-container .del .woocommerce-Price-currencySymbol{
            font-size: <?php echo $theme->get_option('fontsize_small')*$this->args['ratio']?>rpx;
            color: #<?php echo $theme->get_option('color_sub')?>;
            text-decoration: line-through;
        }
        .fix-iphonex-button {
            padding-bottom:68rpx!important;
        }
        
        .navigationBar-BackgroundColor{
        	background-color:#<?php echo $theme->get_option('navigationBar_BackgroundColor')?>
        }
        .statusBar-BackgroundColor{
        	background-color:#<?php echo $theme->get_option('statusBar_BackgroundColor')?>
        }
        .navigationBar-Textcolor{
        	color:#<?php echo $theme->get_option('navigationBar_Textcolor')?>
        }
        
        .xh-c-order-status-main{color:<?php echo WRest_Helper::hex2rgba($order->get_option('status_header_color'))?>}
        .xh-c-order-status-sub{color:<?php echo WRest_Helper::hex2rgba($order->get_option('status_header_color'),0.9)?>}
		<?php 
		echo $layout->get_field($version, 'WRest_Template_Layout_Body')->get_option('custom_css');
		return ob_get_clean();
	}
}
?>