<?php
class WRest_Domain_WC extends Abstract_WRest_Doamin{
	public $post_type ='product';
	public $order_type = 'shop_order';
	public $cat_type = 'product_cat';
	public $tag_type = 'product_tag';
	
	/**
	 *
	 * @param WP_REST_Request $request
	 */
	public function process_product_search($request,$version){
		$pageIndex = absint($request->get_param('pageIndex'));
		$modal = wc_clean($request->get_param('modal'));
		if(!$modal){$modal='small';}
		
		if($pageIndex<1){$pageIndex = 1;}
		$pageSize = 24;
		
		
		$api = $this;
		$args = array(
				'paginate'=>true,
				'limit'=>$pageSize,
				'offset'=>($pageIndex-1)*$pageSize
		);
		
		$filters = $api->get_product_filters($version);
		
		
		$sdk = $request->get_param('sdk');
		
		//TODO 老版本查询
		if(!$sdk||version_compare($sdk, '1.0.1','<')){
    		$filter = json_decode($request->get_param('filter'),true);
    		if(!$filter||!is_array($filter)){$filter=array();}
    		if($filters&&isset($filter['atts_selected'])){
    			foreach ($filters as $field=>$setting){
    				if(!isset($filter['atts_selected'][$field])){
    					continue;
    				}
    				
    				$call = $setting['call'];
    				$call($args, $field,$filter['atts_selected'][$field],$setting);
    			}
    		}
    		
    		if(isset($filter['s'])&&!empty($filter['s'])){
    			$keyword = $this->sanitize_keywords($filter['s']);
    			if($keyword&&mb_strlen($keyword,'utf-8')>=2){
    				global $wpdb;
    				
    				$keywordObj = $wpdb->get_row($wpdb->prepare(
    						"select k.id,
    						        k.count
    						from {$wpdb->prefix}wrest_keywords k
    						where k.label=%s
    						      and k.type='product'
    						limit 1;", $keyword));
    				
    				$ip = WRest_Helper_Http::get_client_ip();
    				if($keywordObj){
    					$keywordsObjItem = $wpdb->get_row($wpdb->prepare(
    							"select k.id
    							from {$wpdb->prefix}wrest_keywords_item k
    							where k.ip=%s
    							limit 1;", $ip));
    					if(!$keywordsObjItem){
    						$wpdb->insert("{$wpdb->prefix}wrest_keywords_item", array(
    								'keywords_id'=>$keywordObj->id,
    								'created_time'=>current_time( 'timestamp'),
    								'ip'=>$ip,
    								'user_ID'=>get_current_user_id()
    						));
    						
    						if(empty($wpdb->last_error)&&$wpdb->insert_id){
    							$wpdb->update("{$wpdb->prefix}wrest_keywords", array(
    									'count'=>$keywordObj->count+1
    							), array(
    									'id'=>$keywordObj->id
    							));
    						}
    					}
    				}else{
    					$wpdb->insert("{$wpdb->prefix}wrest_keywords", array(
    							'label'=>$keyword,
    							'count'=>1,
    							'type'=>'product',
    							'is_feature'=>0,
    							'status'=>'publish'
    					));
    					
    					if(empty($wpdb->last_error)&&$wpdb->insert_id){
    						$keywords_id = $wpdb->insert_id;
    						$wpdb->insert("{$wpdb->prefix}wrest_keywords_item", array(
    								'keywords_id'=>$keywords_id,
    								'created_time'=>current_time( 'timestamp'),
    								'ip'=>$ip,
    								'user_ID'=>get_current_user_id()
    						));
    					}
    				}
    				
    				$args['s'] = $keyword;
    			}
    		}
    		
    		$sorts = $api->get_product_sorts();
    		if($sorts&&isset($filter['sort_index'])&&isset($sorts[$filter['sort_index']])){
    			$call = $sorts[$filter['sort_index']]['call'];
    			$call($args);
    		}
    		
    		if(isset($filter['is_on_sale'])&&$filter['is_on_sale']){
    			$args['onsale'] = 'yes';
    		}
    		
    		if(isset($filter['is_feature'])&&$filter['is_feature']){
    			$args['featured'] = 'yes';
    		}
    		
    		$need_search_parent = false;
    		if(isset($args['product_type'])&&$args['product_type']){
    		    if(is_string($args['product_type'])&&$args['product_type']=='variation'){
    		        $need_search_parent=true;
    		    }else if(is_array($args['product_type'])&&in_array('variation', $args['product_type'])){
    		        $need_search_parent=true;
    		    }
    		}
    		
    		//我们现在查询的是 产品的product_variation类型，但是它没有绑定分类，我们只能找它父级的分类
    		if($need_search_parent){
    			if(
    					(isset($filter['current_sub_cat_id'])&&$filter['current_sub_cat_id'])
    					||
    					(isset($filter['current_cat_id'])&&$filter['current_cat_id'])
    					){
    						if(!isset($args['p_category'])){
    							$args['p_category']=array();
    						}
    						
    						if(isset($filter['current_sub_cat_id'])&&$filter['current_sub_cat_id']){
    							$cat_id = absint($filter['current_sub_cat_id']);
    							$args['p_category'][]=$cat_id;
    						}else if(isset($filter['current_cat_id'])&&$filter['current_cat_id']){
    							$cat_id = absint($filter['current_cat_id']);
    							$args['p_category'][]=$cat_id;
    						}
    			}
    		}else{
    			if(
    					(isset($filter['current_sub_cat_id'])&&$filter['current_sub_cat_id'])
    					||
    					(isset($filter['current_cat_id'])&&$filter['current_cat_id'])
    					){
    						if(!isset($args['category'])){
    							$args['category']=array();
    						}
    						
    						if(isset($filter['current_sub_cat_id'])&&$filter['current_sub_cat_id']){
    							$cat_id = absint($filter['current_sub_cat_id']);
    							$args['category'][]=$cat_id;
    						}else if(isset($filter['current_cat_id'])&&$filter['current_cat_id']){
    							$cat_id = absint($filter['current_cat_id']);
    							$args['category'][]=$cat_id;
    						}
    			}
    		}
		}else{
		    $params = $request->get_params();
		    foreach ($filters as $field=>$setting){
		        if(!isset($params[$field])||!$params[$field]){
		            continue;
		        }
		    
		        $call = $setting['call'];
		        $call($args, $field,json_decode($params[$field],true),$setting);
		    }
		    
		    $keywords = $this->sanitize_keywords($request->get_param('s'));
		    if($keywords&&mb_strlen($keywords,'utf-8')>=2){
	            global $wpdb;
	    
	            $keywordObj = $wpdb->get_row($wpdb->prepare(
	                "select k.id,
	                       k.count
	                from {$wpdb->prefix}wrest_keywords k
	                where k.label=%s
	                       and k.type='product'
	                limit 1;", $keywords));
	    
	            $ip = WRest_Helper_Http::get_client_ip();
	            if($keywordObj){
	                $keywordsObjItem = $wpdb->get_row($wpdb->prepare(
	                    "select k.id
	                    from {$wpdb->prefix}wrest_keywords_item k
	                    where k.ip=%s
	                    limit 1;", $ip));
	                if(!$keywordsObjItem){
	                    $wpdb->insert("{$wpdb->prefix}wrest_keywords_item", array(
	                        'keywords_id'=>$keywordObj->id,
	                        'created_time'=>current_time( 'timestamp'),
	                        'ip'=>$ip,
	                        'user_ID'=>get_current_user_id()
	                    ));
	    
	                    if(empty($wpdb->last_error)&&$wpdb->insert_id){
	                        $wpdb->update("{$wpdb->prefix}wrest_keywords", array(
	                            'count'=>$keywordObj->count+1
	                        ), array(
	                            'id'=>$keywordObj->id
	                        ));
	                    }
	                }
	            }else{
	                $wpdb->insert("{$wpdb->prefix}wrest_keywords", array(
	                    'label'=>$keywords,
	                    'count'=>1,
	                    'type'=>'product',
	                    'is_feature'=>0,
	                    'status'=>'publish'
	                ));
	                 
	                if(empty($wpdb->last_error)&&$wpdb->insert_id){
	                    $keywords_id = $wpdb->insert_id;
	                    $wpdb->insert("{$wpdb->prefix}wrest_keywords_item", array(
	                        'keywords_id'=>$keywords_id,
	                        'created_time'=>current_time( 'timestamp'),
	                        'ip'=>$ip,
	                        'user_ID'=>get_current_user_id()
	                    ));
	                }
	            }
	    
	            $args['s'] = $keywords;
		    }
		    
		    $sort = absint($request->get_param('sort'));
		    $sorts = $api->get_product_sorts();
		    if($sorts&&isset($sorts[$sort])){
		        $call = $sorts[$sort]['call'];
		        $call($args);
		    }
		
		    $is_on_sale = $request->get_param('is_on_sale');
		    if($is_on_sale){
		        $args['onsale'] = $is_on_sale;
		    }
		    
		    $featured = $request->get_param('is_feature');
		    if($featured){
		        $args['featured'] = $featured;
		    }
		    
		    $cat_id = absint($request->get_param('cat_id'));
		    if($cat_id){
                $term = get_term($cat_id);
                if($term){
    		        if(!isset($args['tax_query'])){
    		            $args['tax_query']=array();
    		        }
    		        
    		        $query = array(
    		            'relation'=>'AND'
    		        );
    		        
    		        $query[] = array(
    		            'taxonomy' => $term->taxonomy,
    		            'field'    => 'term_id',
    		            'terms'    => array(
    		                $cat_id
    		            ),
    		        );
    		        
    		        $args['tax_query'][]=$query;
                }
		    }
		    
		    $sameSellsPid = absint($request->get_param('sameSellsPid'));
		    if($sameSellsPid){
		        $product = wc_get_product($sameSellsPid);
		        if($product){
		            $exclude_ids = $product->get_upsell_ids();
		            if(!$exclude_ids||!is_array($exclude_ids)){
		                $exclude_ids=array();
		            }
		            
		            $exclude_ids[]=$product->get_id();
		            $cats_array = apply_filters( 'woocommerce_product_related_posts_relate_by_category', true, $sameSellsPid ) ? apply_filters( 'woocommerce_get_related_product_cat_terms', wc_get_product_term_ids( $sameSellsPid, 'product_cat' ), $sameSellsPid ) : array();
		            //$tags_array = apply_filters( 'woocommerce_product_related_posts_relate_by_tag', true, $sameSellsPid ) ? apply_filters( 'woocommerce_get_related_product_tag_terms', wc_get_product_term_ids( $sameSellsPid, 'product_tag' ), $sameSellsPid ) : array();
		            
		            $args['exclude'] = array(
		                $product->get_id()
		            );
		            
		            if($cats_array&&count($cats_array)){
		                if(!isset($args['category'])){
		                    $args['category']=array();
		                }
    		            foreach ($cats_array as $cid){
    		                $args['category'][]=$cid;
    		            }
		            }
// 		            if($tags_array&&count($tags_array)){
// 		                if(!isset($args['tag'])){
// 		                    $args['tag']=array();
// 		                }
// 		                foreach ($tags_array as $tid){
// 		                    $args['tag'][]=$cid;
// 		                }
// 		            }
		        }
		         
		    }
		}
		
		$query = $api->get_product_list($version, $args,'woocommerce_single');		
		$total_count = $query['total_count'];
		if($total_count<=0){
		    return new WP_REST_Response(array(
		        'items'=>null,
		        'pageIndex'=>$pageIndex,
		        'pageSize'=>$pageSize,
		        'totalCount'=>0,
		        'totalPage'=>0
		    ));
		}
		
		return new WP_REST_Response(array(
		    'items'=>Abstract_WRest_Product::to_list_mode($modal, $query['items']),
		    'pageIndex'=>$pageIndex,
		    'pageSize'=>$pageSize,
		    'totalCount'=>$total_count,
		    'totalPage'=>ceil($total_count*1.0/$pageSize)
		));
	}
	
	public function html_status_to_wc_status($html_status){
	    return  strpos($html_status, 'wc-')===0? ('wc-'.$html_status):$html_status;
	}
	
	public function wc_status_to_html_status($wc_status){
	    return strpos($wc_status, 'wc-')===0?substr($wc_status, strlen('wc-')):$wc_status;
	}
	public function get_cat_thumb_url($term){
	    $display_type = get_term_meta( $term->term_id, 'display_type', true );
	    $thumbnail_id = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
	     
	    if ( $thumbnail_id ) {
	        return wp_get_attachment_thumb_url( $thumbnail_id );
	    } else {
	        return wc_placeholder_img_src();
	    }
	}
	
	public function get_user_order_counts($user_ID=null){
	    global $wpdb;
	    if(!$user_ID){$user_ID=get_current_user_id();}
	    
	    $response = WRest_Cache_Helper::get("customer:{$user_ID}",'wrest:order:counts',60*60*24);
	    if($response){
	        return $response;
	    }
	    
	    $query = $wpdb->get_results(
	        "select p.post_status as status,
	                count(p.ID) as qty
	    		from {$wpdb->posts} p
	    		inner join {$wpdb->postmeta} pt on (pt.post_id=p.ID and pt.meta_key='_customer_user')
	         where pt.meta_value={$user_ID}
	               and p.post_type = '{$this->order_type}'
	         group by p.post_status;");
	    $response = array();
	    if($query){
	        foreach ($query as $item){
	            $response[$item->status] = absint($item->qty);
	        }
	    }
	    
	    WRest_Cache_Helper::set("customer:{$user_ID}",$response,'wrest:order:counts',60*60*24);
	    return $response;
	}
	
	public function clear_user_order_counts($user_ID=null){
	    if($user_ID){
	        WRest_Cache_Helper::clear('wrest:order:counts',"customer:{$user_ID}");
	    }
	}
	
	public function pre_refund_order_m($version,$request){
		$id = absint($request->get_param('id'));
		$orderApi = new WRest_Order_WC($id);
		if(!$orderApi->is_load()){
			return new WP_Error('no-found','订单信息未找到!',['status'=>500]);
		}
		
		if(!$orderApi->permission_check()){
			return new WP_Error('no-found','您无权限操作当前订单!',['status'=>500]);
		}
		
		$api_status = WRest_Menu_Default_Order::instance();
		$status_refund_hold = $api_status->get_status_name('wc-refund-hold');
		$status_refunded = $api_status->get_status_name('wc-refunded');
		$status_refunded_failed = $api_status->get_status_name('wc-refund-failed');
		$status_refunding = $api_status->get_status_name('wc-refunding');
		
		if(!in_array($orderApi->get_order()->get_status(), array($status_refunding,$status_refund_hold,$status_refunded,$status_refunded_failed))){
			return new WP_Error('no-found','无法查看退款详情!',['status'=>500]);
		}
		
		$upload_images = array();
		$uploads  =get_post_meta($orderApi->get_order()->get_id(),'__wres_refund_reason_uploads__',true);
		if($uploads){
		    foreach ($uploads as $upload_id){
		        $image = wp_get_attachment_image_src(absint($upload_id));
		        if($image&&count($image)){
		            $upload_images[]=$image[0];
		        }
		    }
		}
		
		$refund_failed_date =absint(get_post_meta($orderApi->get_order()->get_id(),'__wrest_refund_failed_date__',true));
		$refunding_date = absint(get_post_meta($orderApi->get_order()->get_id(),'__wrest_refunding_date__',true));
		$refunded_date = absint(get_post_meta($orderApi->get_order()->get_id(),'__wrest_refunded_date__',true));
		$refund_hold_date = absint(get_post_meta($orderApi->get_order()->get_id(),'__wrest_refund_hold_date__',true));
		
		$apiset = new WRest_Menu_Store_Order($version);
		
		$config = $api_status->reflect_status("wc-".$orderApi->get_order()->get_status());
		
		return new WP_REST_Response(array(
		        'status_cancel_list' =>'wrest-cancel-refund',
				'orderInfo'=>$orderApi->to_detail($version),
		        'is_refund_failed'=>in_array($orderApi->get_order()->get_status(), array($status_refunded_failed)),
				'pay_amount'=>WRest_Helper_String::get_format_price($orderApi->get_order()->get_total()),
				'refund_amount'=>WRest_Helper_String::get_format_price($orderApi->get_order()->get_total()),
				'refund_reason'=>get_post_meta($orderApi->get_order()->get_id(),'__wres_refund_reason__',true),
				'refund_reason_detail'=>get_post_meta($orderApi->get_order()->get_id(),'__wres_refund_reason_detail__',true),
				'refund_uploads'=>$upload_images,
		        'status_txt'=>$config?$config['label']:$orderApi->get_order()->get_status(),
		        'currency_symbol'=>get_woocommerce_currency_symbol($orderApi->get_order()->get_currency()),
		        'refund_date'=>$refunding_date?date('Y-m-d H:i',$refunding_date):null,
		        'refunded_date'=>$refunded_date?date('Y-m-d H:i',$refunded_date):null,
		        'refund_failed_date'=>$refund_failed_date?date('Y-m-d H:i',$refund_failed_date):null,
		        'refunde_hold_date'=>$refund_hold_date?date('Y-m-d H:i',$refund_hold_date):null,
		        'refund_real_amount'=> count($orderApi->get_order()->get_refunds())?  WRest_Helper_String::get_format_price($orderApi->get_order()->get_total_refunded()):null,
		        'refund_tips'=>WRest_Helper_String::towxml(wp_kses_post( wpautop( $apiset->get_option('refund_tips'))))
		));
	}
	
	public function pre_refund_order($version,$order_ID){
		$api = $this->get_order($order_ID);
		if(!$api->is_load()){
			return new WP_Error('no-found','订单信息未找到！',['status'=>500]);
		}
		
		if(!$api->permission_check()){
			return new WP_Error('no-found','您暂无权限修改此订单！',['status'=>500]);
		}
		
		$apiset = new WRest_Menu_Store_Order($version);
		$api_status = WRest_Menu_Default_Order::instance();
	    $status_completed = $api_status->get_status_name('wc-completed');
	    
		if(in_array($api->get_order()->get_status(),array($status_completed))){
			$order_shiped_time = absint(get_post_meta($api->get_order()->get_id(),'__wrest_shiped_date__',true));
			if(!$order_shiped_time){
			    $order_shiped_time = $api->get_order()->get_date_paid()?$api->get_order()->get_date_paid()->getOffsetTimestamp():0;
			}
			$now = current_time( 'timestamp');
			$enable_refund_when_received = floatval($apiset->get_option('enable_refund_when_received'));
			$is_can_refund = $order_shiped_time&&($now-($order_shiped_time +round($enable_refund_when_received*60*60))<=0);
			
			if(!$is_can_refund){
				return new WP_Error('no-found','已超过申请退货时间！',['status'=>500]);
			}
		}else{
			return new WP_Error('no-found','此订单暂无法退货！',['status'=>500]);
		}
		
		$refund_reasionList = explode("\r\n", $apiset->get_option('refund_reasions'));
		
		return new WP_REST_Response(array(
		    'status_cancel_list' =>'wrest-cancel-refund',
				'orderInfo'=>$api->to_detail($version),
				'refund_reasons'=>$this->get_refund_reasons($version),
				'dialog_title'=>apply_filters('wrest_pre_refund_dialog_title', '商品退还到收货地点，扫码确认后，退款申请即时生效。确定要申请退货吗？'),
				'refund_tips'=>WRest_Helper_String::towxml(wp_kses_post( wpautop( $apiset->get_option('refund_tips'))))
		));
	}
	
	private function get_refund_reasons($version){
	    $apiset = new WRest_Menu_Store_Order($version);
	    $refund_reasions = array(
	        '请选择退货理由'
	    );
	    
	    $refund_reasonList = explode("\r\n", $apiset->get_option('refund_reasions'));
	    if($refund_reasonList){
	        foreach ($refund_reasonList as $reason){
	            $refund_reasions[]=trim($reason);
	        }
	    }
	    
	    return $refund_reasions;
	}
	
	public function refund_order($version,$request){
		$order_ID = $request->get_param('id');
	    $api = $this->get_order($order_ID);
	    if(!$api->is_load()||!$api->permission_check()){
	        return new WP_Error('order-not-found','订单信息未找到！',array('status'=>500));
	    }
	    $apiset = new WRest_Menu_Store_Order($version);
	    if(!$api->permission_check()){
	    	return new WP_Error('no-found','您暂无权限修改此订单！',['status'=>500]);
	    }
	    
	    $refund_reason_index = absint($request->get_param('refund_reason'));
	    $refund_reason_detail = sanitize_text_field($request->get_param('refund_reason_detail'));
	    if(!$refund_reason_index){
	        return new WP_Error('no-found','请选择退货理由！',['status'=>500]);
	    }
	    
	    $refund_reasions = $this->get_refund_reasons($version);
	    if(!$refund_reasions||!isset($refund_reasions[$refund_reason_index])){
	    	return new WP_Error('no-found','请选择退货理由！',['status'=>500]);
	    }
	    
	    $refund_reason = $refund_reasions[$refund_reason_index];
	    if(empty($refund_reason_detail)){
	    	return new WP_Error('no-found','请详细描述退货原因！',['status'=>500]);
	    }
	    
	    $uploaded = $request->get_param('uploaded');
	    $uploaded = $uploaded?json_decode($uploaded,true):array();
	     
	    if($uploaded){
	         foreach ($uploaded as $uploaded_id){
	             if(!wp_attachment_is_image(absint($uploaded_id))){
	                 return new WP_Error('no-found','请检查上传图片！',['status'=>500]);
	             }
	         }
	    }
	    
	    $api_status = WRest_Menu_Default_Order::instance();
	    //$status_shiped = $api_status->get_status_name('wc-shiped');
	    $status_refunding = $api_status->get_status_name('wc-refunding');
	    $status_completed = $api_status->get_status_name('wc-completed');
	    if(in_array($api->get_order()->get_status(),array($status_completed))){
	    	$order_shiped_time = absint(get_post_meta($api->get_order()->get_id(),'__wrest_shiped_date__',true));
	    	if(!$order_shiped_time){
	    	    $order_shiped_time = $api->get_order()->get_date_paid()?$api->get_order()->get_date_paid()->getOffsetTimestamp():0;
	    	}
	    	$now = current_time( 'timestamp');
	    	$apiset = new WRest_Menu_Store_Order($version);
	    	$enable_refund_when_received = floatval($apiset->get_option('enable_refund_when_received'));
	    	$is_can_refund = $order_shiped_time&&($now-($order_shiped_time +round($enable_refund_when_received*60*60))<=0);
	    	
	    	if(!$is_can_refund){
	    		return new WP_Error('no-found','此订单暂无法退货！',['status'=>500]);
	    	}
	    }else{
	    	return new WP_Error('no-found','此订单暂无法退货！',['status'=>500]);
	    }
	
	    update_post_meta($api->get_order()->get_id(), '__wres_refund_reason__', $refund_reason);
	    update_post_meta($api->get_order()->get_id(), '__wres_refund_reason_detail__', $refund_reason_detail);
	    update_post_meta($api->get_order()->get_id(), '__wres_refund_reason_uploads__', $uploaded);
	    if(!$api->get_order()->update_status( $status_refunding, '客户提交了退货申请：'.$refund_reason.' - '.$refund_reason_detail )){
	        return new WP_Error('system-error','系统异常！',array('status'=>500));
	    }
	
	    return new WP_REST_Response(array(
	        'confirm'=>array(
	            'title'=>'退货申请已成功提交！我们在确认收到货物后，48小时内处理您的退款'
	        )
	    ));
	}
	
	public function received_order($version,$order_ID){
	    $api = $this->get_order($order_ID);
	    if(!$api->is_load()||!$api->permission_check()){
	        return new WP_Error('order-not-found','订单信息未找到！',array('status'=>500));
	    }
	    
	    $api_status = WRest_Menu_Default_Order::instance();
	    if(!in_array( $api->get_order()->get_status(), Abstract_WRest_Order::get_status_wait_received())){
	        return new WP_Error('order-limit','商品未配送或商品未到达配送地址，无法确认收货！',array('status'=>500));
	    }
	    
	    $api_status = WRest_Menu_Default_Order::instance();
	    $status_received = $api_status->get_status_name('wc-completed');
	    if(!$api->get_order()->update_status( $status_received, '用户确认收货！' )){
	        return new WP_Error('system-error','系统异常！',array('status'=>500));
	    }
	
	    return new WP_REST_Response(array(
	        'orderInfo'=>$api->to_detail($version)
	    ));
	}
	
	public function cancel_order($version,$order_ID){
		$api = $this->get_order($order_ID);
		if(!$api->is_load()||!$api->permission_check()){
			return new WP_Error('order-not-found','您暂无权限修改当前订单！',array('status'=>500));
		}
		
		if(!in_array( $api->get_order()->get_status(),  array( 'pending', 'failed','processing' ))){
			return new WP_Error('order-limit','此订单无法取消！',array('status'=>500));
		}
		
		
		if(in_array( $api->get_order()->get_status(),  array( 'pending', 'failed' ))){
    		if(!$api->get_order()->update_status( 'cancelled', '用户取消了订单！' )){
    			return new WP_Error('system-error','系统异常！',array('status'=>500));
    		}
    		
    		return new WP_REST_Response(array(
    		    'confirm'=>array(
    		        'title'=>'订单已取消!'
    		    )
    		));
		}
		
		if(in_array( $api->get_order()->get_status(),  array( 'processing' ))){
		    $order_paid_date = $api->get_order()->get_date_paid();
	        $now = current_time( 'timestamp');
	        $apiset = new WRest_Menu_Store_Order($version);
	        $enable_refund_when_processing = floatval($apiset->get_option('enable_refund_when_processing'));
	        $is_can_cancel = $order_paid_date&&($now-($order_paid_date->getOffsetTimestamp() +round($enable_refund_when_processing*60*60))<=0);
		    if(!$is_can_cancel){
		        return new WP_Error('order-limit','订单无法取消！',array('status'=>500));
		    }  
		    
		    $api_status = WRest_Menu_Default_Order::instance();
		    $status_refund_hold = $api_status->get_status_name('wc-refund-hold');
		   
		    if(!$api->get_order()->update_status( $status_refund_hold, '用户取消了订单，等待退款！' )){
		        return new WP_Error('system-error','系统异常！',array('status'=>500));
		    }
		    
		    return new WP_REST_Response(array(
		        'confirm'=>array(
		            'title'=>'订单已取消，退款将在24小时内退回到支付账户!'
		        )
		    ));
		}
		
		return new WP_Error('order-limit','此订单无法取消！',array('status'=>500));
	}
	
	public function get_order_statuses(){
	    return wc_get_order_statuses();
	}
	
	public function process_re_checkout($version,$request){
		$order_id = absint($request->get_param('id'));
		$order              = wc_get_order( $order_id );
		$hold_stock_minutes = min(array(
				30,
				(int) get_option( 'woocommerce_hold_stock_minutes', 0 )
		));
		
		try{
			
			// Order or payment link is invalid.
			if ( ! $order  ) {
				throw new Exception( __( 'Sorry, this order is invalid and cannot be paid for.', 'woocommerce' ) );
			}
			
			// Logged in customer trying to pay for someone else's order.
			if ( ! current_user_can( 'pay_for_order', $order_id ) ) {
				throw new Exception( __( 'This order cannot be paid for. Please contact us if you need assistance.', 'woocommerce' ) );
			}
			
			// Does not need payment.
			if ( ! $order->needs_payment() ) {
				/* translators: %s: order status */
				throw new Exception( sprintf( __( 'This order&rsquo;s status is &ldquo;%s&rdquo;&mdash;it cannot be paid for. Please contact us if you need assistance.', 'woocommerce' ), wc_get_order_status_name( $order->get_status() ) ) );
			}
			
			// Ensure order items are still stocked if paying for a failed order. Pending orders do not need this check because stock is held.
			if ( ! $order->has_status( 'pending' ) ) {
				$quantities = array();
				
				foreach ( $order->get_items() as $item_key => $item ) {
					if ( $item && is_callable( array( $item, 'get_product' ) ) ) {
						$product = $item->get_product();
						
						if ( ! $product ) {
							continue;
						}
						
						$quantities[ $product->get_stock_managed_by_id() ] = isset( $quantities[ $product->get_stock_managed_by_id() ] ) ? $quantities[ $product->get_stock_managed_by_id() ] + $item->get_quantity() : $item->get_quantity();
					}
				}
				
				foreach ( $order->get_items() as $item_key => $item ) {
					if ( $item && is_callable( array( $item, 'get_product' ) ) ) {
						$product = $item->get_product();
						
						if ( ! $product ) {
							continue;
						}
						
						if ( ! apply_filters( 'woocommerce_pay_order_product_in_stock', $product->is_in_stock(), $product, $order ) ) {
							/* translators: %s: product name */
							throw new Exception( sprintf( __( 'Sorry, "%s" is no longer in stock so this order cannot be paid for. We apologize for any inconvenience caused.', 'woocommerce' ), $product->get_name() ) );
						}
						
						// We only need to check products managing stock, with a limited stock qty.
						if ( ! $product->managing_stock() || $product->backorders_allowed() ) {
							continue;
						}
						
						// Check stock based on all items in the cart and consider any held stock within pending orders.
						$held_stock     = ( $hold_stock_minutes > 0 ) ? wc_get_held_stock_quantity( $product, $order->get_id() ) : 0;
						$required_stock = $quantities[ $product->get_stock_managed_by_id() ];
						
						if ( $product->get_stock_quantity() < ( $held_stock + $required_stock ) ) {
							/* translators: 1: product name 2: quantity in stock */
							throw new Exception( sprintf( __( 'Sorry, we do not have enough "%1$s" in stock to fulfill your order (%2$s available). We apologize for any inconvenience caused.', 'woocommerce' ), $product->get_name(), wc_format_stock_quantity_for_display( $product->get_stock_quantity() - $held_stock, $product ) ) );
						}
					}
				}
			}
			
			WC()->customer->set_props(
					array(
							'billing_country'  => $order->get_billing_country() ? $order->get_billing_country() : null,
							'billing_state'    => $order->get_billing_state() ? $order->get_billing_state() : null,
							'billing_postcode' => $order->get_billing_postcode() ? $order->get_billing_postcode() : null,
					));
			WC()->customer->save();
			
			do_action( 'woocommerce_before_pay_action', $order );
			
			WC()->customer->set_props( array(
					'billing_country'  => $order->get_billing_country() ? $order->get_billing_country()   : null,
					'billing_state'    => $order->get_billing_state() ? $order->get_billing_state()       : null,
					'billing_postcode' => $order->get_billing_postcode() ? $order->get_billing_postcode() : null,
					'billing_city'     => $order->get_billing_city() ? $order->get_billing_city()         : null,
			) );
			
			WC()->customer->save();
			
			// Update payment method
			if ( $order->needs_payment() ) {
				$available_gateway = self::get_available_payment_gateway($order->get_payment_method());
				if(!$available_gateway){
					throw new Exception('当前订单无法在小程序内支付！');
				}
				$result = $available_gateway->process_payment( $order_id );
				return new WP_REST_Response($result);
			} else {
				// No payment was required for order
				$order->payment_complete();
				return new WP_REST_Response(array(
						'result'=>'success',
						'complete'=>true
				));
			}
			
		}catch (Exception $e){
			return new WP_Error('system-error',$e->getMessage(),array('status'=>500));
		}
	}
	
	/**
	 *
	 * @param int|WP_Post|WC_Product $post_ID
	 */
	public function get_product($post_ID){
		return new WRest_Product_WC($post_ID);
	}
	
	public function get_currency_symbol(){
		return get_woocommerce_currency_symbol();
	}
	
	public function get_order($order_ID){
		return new WRest_Order_WC($order_ID);
	}
	
	public static function get_available_payment_gateways(){
		$available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
		
		if(!$available_gateways){
			return null;
		}
		
		$results = array();
		foreach ($available_gateways as $payment_id=>$gateway){
			if(!($gateway instanceof Abstract_WRest_WC_Payment_Gateway)){
			    if(!in_array($gateway->id, array('cod','bacs','cheque'))){
			        continue;
			    }
			}
			
			$results[$payment_id]=$gateway;
		}
		
		return $results;
	}
	
	/**
	 * 
	 * @param WC_Payment_Gateway $payment_gateway
	 */
	public static function is_available_payment_gateway($payment_gateway){
	    if(!$payment_gateway){
	        return false;
	    }
	    
	    $available_gateways = self::get_available_payment_gateways();    
	    if(!$available_gateways){
	        return false;
	    }
	    
	    if($payment_gateway instanceof WC_Payment_Gateway){
	       return isset($available_gateways[$payment_gateway->id]);
	    }
	    return isset($available_gateways[$payment_gateway]);
	}
	
	public static function get_available_payment_gateway($payment_id){
		$available_gateways = self::get_available_payment_gateways();
		
		if(!$available_gateways){
			return null;
		}
		
		return isset($available_gateways[$payment_id])?$available_gateways[$payment_id]:null;
	}
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function cart_update_payment_method($version,$request){
		wc_clear_notices();
		$payment_method = $request->get_param('payment_method');
		$available_gateways = self::get_available_payment_gateways();
		
		if(!$available_gateways||count($available_gateways)==0){
			return new WP_Error("invalid-payment-method",'invalid payment gateway!',array('status'=>500));
		}
		
		$available_gateways1=array();
		foreach ($available_gateways as $gateway){
			$available_gateways1[$gateway->id] = array(
					'id'=>$gateway->id,
					'icon'=>$gateway->icon,
					'title'=>$gateway->title,
					'description'=>$gateway->description,
					'chosen'=>$gateway->chosen
			);
		}
		
		if(!isset($available_gateways1[$payment_method])){
			return new WP_Error("invalid-payment-method",'invalid payment gateway!',array('status'=>500));
		}
		WC()->session->set( 'chosen_payment_method',$payment_method);
		
		return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>true
		)));
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function cart_update_shipping_method($version,$request){
		wc_clear_notices();
		$shipping_index = absint($request->get_param('shipping_index'));
		$shipping_method_id =  wc_clean( $request->get_param('shipping_method_id'));
		
		$chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
		if($chosen_shipping_methods&&isset($chosen_shipping_methods[$shipping_index])){
			$chosen_shipping_methods[$shipping_index] = $shipping_method_id;
			WC()->session->set( 'chosen_shipping_methods', $chosen_shipping_methods );
		}
	
		return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>true
		)));
	}
	
	/**
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function add_to_cart($version,$request){
		wc_clear_notices();
		$this->free_shipping_cache();
		
		$product_id = absint($request->get_param('product_id'));
		$quantity = absint($request->get_param('quantity'));
		if($quantity<1){$quantity=1;}
		$variation_id = absint($request->get_param('variation_id'));
		$variation = json_decode($request->get_param('variation'),true);
		
		$cart_item_key = WC()->cart->add_to_cart($product_id,$quantity,$variation_id,$variation);
		if(wc_get_notices()){
			$error =  self::wc_get_errors();
		    if($cart_item_key){
		        WC()->cart->remove_cart_item($cart_item_key);
		        wc_clear_notices();
		    }
		    
		    return $error;
		}
		
		return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>false
		)));
	}

	/**
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function clear_cart($version,$request){
	    wc_clear_notices();
	   
	    WC()->cart->empty_cart();
	    if(wc_get_notices()){
	        return self::wc_get_errors();
	    }
	
	    return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>false
		)));
	}
	public function cart_add_coupon($version,$coupon_code){
	    wc_clear_notices();
	   
		if ( WC()->cart->is_empty() && ! is_customize_preview() && apply_filters( 'woocommerce_checkout_update_order_review_expired', true ) ) {
			return new WP_Error("invalid-cart", __( 'Sorry, your session has expired.', 'woocommerce' ),array('status'=>500));
		}
		
		$coupon_code = sanitize_text_field( wp_unslash( $coupon_code ) );
		if(empty($coupon_code)){
			return new WP_Error("invalid-coupon-code","优惠券未找到！",array('status'=>500));
		}
		
		if(is_user_logged_in()){
		    $couponApi = WRest_Coupon::load($coupon_code);
		    if($couponApi){
		        if($couponApi->status=='using'){
		            return new WP_Error("invalid-coupon-code","优惠券已被其它订单占用！",array('status'=>500));
		        }
		        
		        $error = $couponApi->change_status('using');
		        if(!WRest_Error::is_valid($error)){
		            return $error;
		        }
		    
		        self::refresh_user_coupon();
		    }
		}
		
		if(!WC()->cart->add_discount( $coupon_code )){
			return self::wc_get_errors();
		}
		WC()->cart->check_cart_coupons();
		//忽略错误信息
		wc_clear_notices();
		return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>true
		)));
	}
	
	public function cart_remove_coupon($version,$coupon_code){
		wc_clear_notices();
		
		if ( WC()->cart->is_empty() && ! is_customize_preview() && apply_filters( 'woocommerce_checkout_update_order_review_expired', true ) ) {
			return new WP_Error("invalid-cart", __( 'Sorry, your session has expired.', 'woocommerce' ),array('status'=>500));
		}
		
		$coupon_code = sanitize_text_field( wp_unslash( $coupon_code ) );
		if(empty($coupon_code)){
		    return new WP_Error("invalid-coupon-code","优惠券未找到！",array('status'=>500));
		}
		
		$coupon = new WC_Coupon($coupon_code);
		if(!$coupon->get_id()){
		    return new WP_Error("invalid-coupon-code","优惠券未找到！",array('status'=>500));
		}
		
		if(is_user_logged_in()){
		    $api = WRest_Coupon::load($coupon);
		    if($api){
		        $error = $api->change_status('prepare');
		        if(!WRest_Error::is_valid($error)){
		            return $error;
		        }
		        self::refresh_user_coupon();
		    }
		}
		
		if(!WC()->cart->remove_coupon( $coupon_code )){
			return self::wc_get_errors();
		}
		WC()->cart->check_cart_coupons();
		//忽略错误信息
		wc_clear_notices();
		return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>true
		)));
	}
	
	public static function refresh_user_coupon(){
	    if(!is_user_logged_in()){
	        return;
	    }
	    
	    $user_ID = get_current_user_id();
	    global $wpdb;
	    $query = $wpdb->get_results(
	       "select w.coupon_id
	        from {$wpdb->prefix}wrest_coupon w
	        where w.user_ID={$user_ID}
	        order by w.created_time desc
	        limit 50;");
	    $array = array();
	    if($query){
	        foreach ($query as $item){
	            $array[]=$item->coupon_id;
	        }
	    }
	    
	    update_user_meta($user_ID, '__wrest_coupon_queue', $array);
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function cart_set_quantity($version,$request){
		wc_clear_notices();
		$cart_item_key = trim($request->get_param('cart_item_key'));
		$quantity = absint($request->get_param('quantity'));
		if($quantity<0){$quantity=0;}
		
		$cart_item_data = WC()->cart->get_cart_item($cart_item_key);
		if(!$cart_item_data){
			return new WP_Error('invalid-cart-item','商品信息已过期！',array('status'=>500));
		}
		
		$last_quantity = $cart_item_data['quantity'];
		$product_id = $cart_item_data['product_id'];
		$variation_id = $cart_item_data['variation_id'];
		$variation =  $cart_item_data['variation'];
		// Generate a ID based on product ID, variation ID, variation data, and other cart item data.
		$cart_id = WC()->cart->generate_cart_id( $product_id, $variation_id, $variation, $cart_item_data );
		
		$product_data =  wc_get_product( $variation_id ? $variation_id :  $product_id );
		if(!$product_data){
			return new WP_Error('invalid-cart-item','商品已下架！',array('status'=>500));
		}
		
		try{
			// Force quantity to 1 if sold individually and check for existing item in cart.
			if ( $product_data->is_sold_individually() ) {
				$quantity      = apply_filters( 'woocommerce_add_to_cart_sold_individually_quantity', 1, $quantity, $product_id, $variation_id, $cart_item_data );
				$found_in_cart = apply_filters( 'woocommerce_add_to_cart_sold_individually_found_in_cart', $cart_item_key && WC()->cart->cart_contents[ $cart_item_key ]['quantity'] > 0, $product_id, $variation_id, $cart_item_data, $cart_id );
				
				if ( $found_in_cart ) {
					/* translators: %s: product name */
					throw new Exception( sprintf( '<a href="%s" class="button wc-forward">%s</a> %s', wc_get_cart_url(), __( 'View cart', 'woocommerce' ), sprintf( __( 'You cannot add another "%s" to your cart.', 'woocommerce' ), $product_data->get_name() ) ) );
				}
			}
			
			WC()->cart->cart_contents[ $cart_item_key ]['quantity'] = 0;
			do_action( 'woocommerce_after_cart_item_quantity_update', $cart_item_key, $quantity, $cart_item_data['quantity'], $this );
			
			if ( ! $product_data->is_purchasable() ) {
				WC()->cart->remove_cart_item($cart_item_key);
				throw new Exception('当前商品已下架！');
			}
			
			// Stock check - only check if we're managing stock and backorders are not allowed.
			if ( ! $product_data->is_in_stock() ) {
				WC()->cart->remove_cart_item($cart_item_key);
				/* translators: %s: product name */
				throw new Exception('当前商品已售完！');
			}
			
			if ( ! $product_data->has_enough_stock( $quantity ) ) {
				WC()->cart->remove_cart_item($cart_item_key);
				/* translators: 1: product name 2: quantity in stock */
				throw new Exception('当前商品库存不足！');
			}
			
			// Stock check - this time accounting for whats already in-cart.
			if ( $product_data->managing_stock() ) {
				$products_qty_in_cart = WC()->cart->get_cart_item_quantities();
				
				if ( isset( $products_qty_in_cart[ $product_data->get_stock_managed_by_id() ] ) && ! $product_data->has_enough_stock( $products_qty_in_cart[ $product_data->get_stock_managed_by_id() ] + $quantity ) ) {
					WC()->cart->remove_cart_item($cart_item_key);
					throw new Exception('当前商品库存不足！');
				}
			}
			
    		WC()->cart->set_quantity( $cart_item_key, $quantity, false );
    		WC()->cart->cart_contents = apply_filters( 'woocommerce_cart_contents_changed',  WC()->cart->cart_contents );
    		do_action( 'woocommerce_add_to_cart', $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data );
    		if(wc_get_notices()){
    		    $error = self::wc_get_errors();
    		    WC()->cart->set_quantity( $cart_item_key, $last_quantity, true );
    		    wc_clear_notices();
    		    
    		    return $error;
    		}
    		
		}catch (Exception $e){
			if ( $e->getMessage() ) {
				wc_add_notice( $e->getMessage());
			}
		}
		
		if(wc_get_notices()){
			return self::wc_get_errors();
		}
		
		return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>true
		)));
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function cart_remove_item($version,$request){
		wc_clear_notices();
		$cart_item_key = trim($request->get_param('cart_item_key'));
		WC()->cart->remove_cart_item($cart_item_key);
		
		if(wc_get_notices()){
		    return self::wc_get_errors();
		}
		
		return new WP_REST_Response($this->get_cart($version,array(
				'include_product'=>true,
				'include_checkout'=>true
		)));
	}
	
	public function save_address_1($address){
		wc_clear_notices();
		
		$customer = WC()->cart->get_customer();
		if(!$customer){
			return new WP_Error('unauthoirzed','unauthoirzed!',array('status'=>401));
		}
		
		
		
		$countries = WC()->countries->get_countries();
		if(!isset( $countries[ $address['country'] ] )){
		    return new WP_Error('unknow-state','国家信息异常!',array('status'=>500));
		}
		
		$customer->set_billing_country($address['country']);
		$customer->set_shipping_country($address['country']);
		
		if($address['country']=='CN'){
		    $state = $this->province_to_state($address['provinceName']);
		    if(!$state){
		        return new WP_Error('unknow-state','省份信息不存在或无法配送!',array('status'=>500));
		    } 
		    $customer->set_billing_state($state);
		    $customer->set_shipping_state($state);
		    $customer->set_billing_city($address['cityName']);
		    $customer->set_shipping_city($address['cityName']);
		    
		    $customer->set_billing_address_1($address['countyName']);
		    $customer->set_shipping_address_1($address['countyName']);
		}else{
		    $state = $address['provinceName'];
		    $customer->set_billing_state($state);
		    $customer->set_shipping_state($state);
		    
		    $customer->set_billing_city($address['cityName']);
		    $customer->set_shipping_city($address['cityName']);
		    
		    $customer->set_billing_address_1(null);
		    $customer->set_shipping_address_1(null);
		}
		
		$customer->set_billing_address_2($address['detailInfo']);
		$customer->set_shipping_address_2($address['detailInfo']);
		
		$customer->set_billing_first_name($address['userName']);
		$customer->set_shipping_first_name($address['userName']);
		
		$customer->set_billing_phone($address['telNumber']);
		
		$customer->set_billing_postcode($address['postalCode']);
		$customer->set_shipping_postcode($address['postalCode']);
		
		$customer->save_data();
		
		return new WP_REST_Response($this->get_address());
	}
	
	/**
	 * 
	 * {@inheritDoc}
	 * @see Abstract_WRest_Doamin::save_address()
	 */
	public function save_address($request){
	    wc_clear_notices();
	
	    $address = shortcode_atts(array(
	        "country"=>'',
	        "cityName"=>null,
	        "countyName"=>null,
	        "detailInfo"=>null,
	        "postalCode"=>null,
	        "provinceName"=>null,
	        "telNumber"=>null,
	        "userName"=>null,
	        'v'=>null
	    ), $request->get_params());
	    
	    $sdk = $request->get_param('sdk');
	    if($sdk&&version_compare($sdk, '1.0.3','>=')){
	        $countries = array_keys(WC()->countries->get_allowed_countries());
	        if($address['country']===''||is_null($address['country'])){
	            $address['country'] = 'CN';
	        }else{
	            if(!isset($countries[$address['country']])){
	                return new WP_Error("invalid-address","国家信息无效!",array('status'=>500));
	            }
	            $address['country'] = $countries[$address['country']];
	        }
	        
	        if($address['country']=='CN'){
    	        $region = $request->get_param('region');
    	        $regions = $region?json_decode($region,true):null;
    	        
    	        if(!$regions||!is_array($regions)||count($regions)!=3){
    	            return new WP_Error("invalid-address","账单地址无效!",array('status'=>500));
    	        }
	            
    	        require_once 'class-wrest-address.php';
	            $addressList = WRest_Address::get_address();
	            if(!isset($addressList[$regions[0]])){
	                return new WP_Error("invalid-address","省份信息无效!",array('status'=>500));
	            }
	            
	            if(!isset($addressList[$regions[0]]['citys'][$regions[1]])){
	                return new WP_Error("invalid-address","城市信息无效!",array('status'=>500));
	            }
	            
	            if(!isset($addressList[$regions[0]]['citys'][$regions[1]]['districts'][$regions[2]])){
	                return new WP_Error("invalid-address","地区信息无效!",array('status'=>500));
	            }
	            
	            $address['provinceName'] = $addressList[$regions[0]]['title'];
	            $address['cityName'] = $addressList[$regions[0]]['citys'][$regions[1]]['title'];
	            $address['countyName'] = $addressList[$regions[0]]['citys'][$regions[1]]['districts'][$regions[2]]['title'];
	        }
	    }
	    
	    if($address['v']&&version_compare($address['v'], '1.0.1','>=')){
	        foreach ($address as $pop=>$v){
	            $address[$pop] = WRest_Helper_String::remove_emoji(trim(sanitize_text_field($v)));
	        }
	    }else{
	        foreach ($address as $pop=>$v){
	            $address[$pop] = WRest_Helper_String::remove_emoji(trim(sanitize_text_field(base64_decode($v))));
	        }
	    }
	    
	    $customer = WC()->cart->get_customer();
	    if(!$customer){
	        return new WP_Error('unauthoirzed','unauthoirzed!',array('status'=>401));
	    }
	    
	    if(empty($address['userName'])){
	        return new WP_Error("invalid-address","姓名不能为空!",array('status'=>500));
	    }

	    $countries = WC()->countries->get_countries();
	    if(!isset( $countries[ $address['country'] ] )){
	        return new WP_Error('unknow-state','国家信息异常!',array('status'=>500));
	    }

	    $address['id'] = $request->get_param('id');
	    if(!$address['id']){
	        $address['id'] = time();
	    }
	    
	    if($address['country']=='CN'){
	        if(empty($address['provinceName'])){
	            return new WP_Error("invalid-address","省份不能为空!",array('status'=>500));
	        }
	    
	        if(empty($address['cityName'])){
	            return new WP_Error("invalid-address","城市不能为空!",array('status'=>500));
	        }
	    
	        if(empty($address['countyName'])){
	            return new WP_Error("invalid-address","区县不能为空!",array('status'=>500));
	        }
	    }else{
	        if(empty($address['provinceName'])){
	            return new WP_Error("invalid-address","State/省不能为空!",array('status'=>500));
	        }
	        if(empty($address['cityName'])){
	            return new WP_Error("invalid-address","Suburb/区不能为空!",array('status'=>500));
	        }
	    }
	    
	    if(empty($address['telNumber'])){
	        return new WP_Error("invalid-address","电话不能为空!",array('status'=>500));
	    }
	    
	    $address_list = get_user_meta($customer->get_id(),'__wrest_address_list__',true);
	    if(!$address_list||!is_array($address_list)){
	        $address_list = array();
	    }
	     
	    $new_address_list = array();
	    foreach ($address_list as $item){
	        if(!isset($item['id'])||!$item['id']|| $item['id']==$address['id'] ){
	            continue;
	        }
	        
	        $new_address_list[]=$item;
	    }
	    
	    $new_address_list[]=$address;
	    update_user_meta($customer->get_id(),'__wrest_address_list__', $new_address_list);
	   
	    $wc_address = $this->get_address();
	    if(!$wc_address||!$wc_address['is_valid']){
	        return $this->save_address_1($address);
	    }else{
	        
	        if(!$sdk||version_compare($sdk, '1.0.1','<=')){
	            return $this->save_address_1($address);
	        } 
	    }
	    
	    return $this->format_address($address);
	}
	
	public function confirm_address($address_id){
	    $customer = WC()->cart->get_customer();
	    if(!$customer){
	        return new WP_Error('unauthorized','未登录！',['status'=>401]);
	    }
	
	    $address_list = get_user_meta($customer->get_id(),'__wrest_address_list__',true);
	    if(!$address_list||!is_array($address_list)){
	        $address_list = array();
	    }
	   
	    $new_address_list = array();
	    foreach ($address_list as $address){
	        if($address['id']==$address_id){
	            $this->save_address_1( $address);
	            return $address;
	        }
	    }
	     
	    return new WP_Error('invalid-request','请求无效！',['status'=>500]);
	}
	
	public function remove_address($address_id){
	    $customer = WC()->cart->get_customer();
	    if(!$customer){
	        return new WP_Error('unauthorized','未登录！',['status'=>401]);
	    }
	     
	    $address_list = get_user_meta($customer->get_id(),'__wrest_address_list__',true);
	    if(!$address_list||!is_array($address_list)){
	        $address_list = array();
	    }
	    
	    $new_address_list = array();
	    foreach ($address_list as $address){
	        if(!isset($address['id'])||!$address['id']|| $address['id']==$address_id){
	            continue;
	        }
	        $new_address_list[]=$address;
	    }
	    
	    update_user_meta($customer->get_id(),'__wrest_address_list__', $new_address_list);
	
	    return $new_address_list;
	}
	
	public function get_address_list(){
	    $customer = WC()->cart->get_customer();
	    if(!$customer){
	        return null;
	    }
	    
	    $address_list = get_user_meta($customer->get_id(),'__wrest_address_list__',true);
	    if(!$address_list||!is_array($address_list)){
	        $address_list = array();
	    }
	
	    if(!count($address_list)){
    	    $address_data = $this->get_address_data();
    	    $address = $this->format_address($address_data);
    	    if($address&&$address['is_valid']){
    	        $uid = time();
    	        $address['id'] = $uid;
    	        $address_list[]=$address_data;
    	       
    	        update_user_meta($customer->get_id(),'__wrest_address_list__', $address_list);
    	    }
	    }
	   
	    $response = array();
	    foreach ($address_list as $item){
	        $address = $this->format_address($item);
	        if($address&&$address['is_valid']){
	            $response[]=$address;
	        }
	    }
	    usort($response, function($l,$r){
	        return $l['id']>$r['id'];
	    });
	    return $response;
	}
	
	public function get_address_detail($address_id){
	    $customer = WC()->cart->get_customer();
	    if(!$customer){
	        return new WP_Error('unauthorized','未登录！',['status'=>401]);
	    }
	
	    $address_list = get_user_meta($customer->get_id(),'__wrest_address_list__',true);
	    if(!$address_list||!is_array($address_list)){
	        $address_list = array();
	    }
	   
	    $new_address_list = array();
	    foreach ($address_list as $address){
	        if($address['id']==$address_id){
	            return $this->format_address($address);
	        }
	    }
	     
	    return new WP_Error('invalid-request','请求信息无效！',['status'=>500]);
	}
	
	public function get_address(){
		return $this->format_address($this->get_address_data());
	}
	
	public function get_address_data(){
	    $customer = WC()->cart->get_customer();
	    if(!$customer){
	        return null;
	    }
	
	    $country = $customer->get_billing_country();
	    $state = $customer->get_billing_state();
	    $city = $customer->get_billing_city();
	    $address_1 = $customer->get_billing_address_1();
	    $address_2 = $customer->get_billing_address_2();
	    $city = $customer->get_billing_city();
	    $name = $customer->get_billing_first_name();
	    $phone = $customer->get_billing_phone();
	    $postcode = $customer->get_billing_postcode();
	
	    return array(
	        "id"=>time(),
	        "country"=>$country,
	        "cityName"=>$city,
	        "countyName"=>$address_1,
	        "detailInfo"=>$address_2,
	        "postalCode"=>$postcode,
	        "provinceName"=>$this->state_to_province($state),
	        "telNumber"=>$phone,
	        "userName"=>$name,
	    );
	}
	
	public function format_address($address){
	    if(!$address){
	        return null;
	    }
	    
	    $phoneStr = $address['telNumber'];
	    $country = $address['country'];
	    $countries = WC()->countries->get_countries();
	    $full_country = ( isset( $countries[$country ] ) ) ? $countries[ $country ] : $country;
	    
 	    $state_name = $address['provinceName'];
        $city = $address['cityName'];
        $address_1 = $address['countyName'];
	    
	    $address_2 = $address['detailInfo'];
	    $name = $address['userName'];
	    $phone = $address['telNumber'];
	    $postcode = $address['postalCode'];
	    
	    $detailStr = $country=='CN'?'':"{$full_country} ";
	    $detailStr.=$state_name?"$state_name ":'';
	    $detailStr.=$city?"{$city} ":'';
	    $detailStr.=$address_1?"{$address_1} ":'';
	    $detailStr.=$address_2?"{$address_2} ":'';
	    
	    $address = array(
	        'id'=>$address['id'],
	        'country'=>$country,
	        'full_country'=>$full_country,
	        'province'=>$state_name,
	        'city'=>$city?$city:'',
	        'county'=>$address_1?$address_1:'',
	        'detailAddress'=>$address_2?$address_2:'',
	        'region' =>array(
	            $state_name?$state_name:'北京市',
	            $city?$city:'北京市',
	            $address_1?$address_1:'东城区'
	        ),
	        'name'=>$name?$name:'',
	        'phone'=>$phone,
	        'postcode'=>$postcode?$postcode:'',
	        'phoneSub'=>$phoneStr&&strlen($phoneStr)>7? substr($phoneStr, 0,3)."****".substr($phoneStr, -4):$phoneStr
	    );
	    
	    $address['address_detail'] = apply_filters('wrest_address_format', $detailStr,$address);
	    
	    $is_valid = true;
	    $valid_error=null;
	    if($is_valid&&empty($address['name'])){
	        $is_valid = false;
	        $valid_error="姓名不能为空!";
	    }
	    
	    if($is_valid&&$address['country']=='CN'){
	        if($is_valid&&empty($address['province'])){
	            $is_valid = false;
	            $valid_error="省份不能为空!";
	        }
	    
	        if($is_valid&&empty($address['city'])){
	            $is_valid = false;
	            $valid_error="城市不能为空!";
	        }
	    
	        if($is_valid&&empty($address['county'])){
	            $is_valid = false;
	            $valid_error="区县不能为空!";
	        }
	    }else{
	        if($is_valid&&empty($address['province'])){
	            $is_valid = false;
	            $valid_error="城市/城镇不能为空!";
	        }
	    }
	    
	    if($is_valid&&empty($address['phone'])){
	        $is_valid = false;
	        $valid_error="电话不能为空!";
	    }
	    
	    $address['is_valid'] =$is_valid;
	    $address['valid_error'] =$valid_error;
	    return $address;
	}
	
	private function province_to_state($province){
	    require_once 'class-wrest-address.php';
		foreach(WRest_Address::$data as $code=>$pro){
			if($province== $pro['title']){
				return $code;
			}
		}
		
		return null;
	}
	
	private function state_to_province($code){
	    require_once 'class-wrest-address.php';
	    
	    return isset(WRest_Address::$data[$code])?WRest_Address::$data[$code]['title']:$code;
	}
	
	/**
	 * 为了兼容第三方插件 woocommerce-table-rate-shipping 对购物信息的筛选
	 * 此处去掉shipping缓存信息
	 */
	private function free_shipping_cache(){
	    if(WC()->cart->needs_shipping()){
	        $packages =WC()->cart->get_shipping_packages();
	        if($packages){
	            foreach ($packages as $package_key=>$package){
	                $wc_session_key = 'shipping_for_package_' . $package_key;
	                WC()->session->__unset( $wc_session_key );
	            }
	        }
	    }
	}
	
	/**
	 *
	 * @param WP_REST_Request $request
	 * @throws Exception
	 */
	public function pre_process_checkout($version,$request){
	    $this->free_shipping_cache();
	
	    wc_clear_notices();
	    WC()->cart->calculate_totals();
	    if(wc_get_notices()){
	        return self::wc_get_errors();
	    }
	    
	    $api = WC()->checkout();
	    $api->check_cart_items();
	    if(wc_get_notices()){
	        return self::wc_get_errors();
	    }
	    
	    $cart = $this->get_cart($version);
	    return new WP_REST_Response($cart);
	}
	
	/**
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function process_checkout($version,$request){
	    $this->free_shipping_cache();
		wc_maybe_define_constant( 'WOOCOMMERCE_CHECKOUT', true );
		wc_clear_notices();
		try{
			if ( WC()->cart->is_empty() ) {
				/* translators: %s: shop cart url */
				throw new Exception( sprintf( __( 'Sorry, your session has expired. <a href="%s" class="wc-backward">Return to shop</a>', 'woocommerce' ), esc_url( wc_get_page_permalink( 'shop' ) ) ) );
			}
			
			do_action( 'woocommerce_checkout_process' );
			$api = WC()->checkout();
			$errors      = new WP_Error();
			
			// Update cart totals now we have customer address.
			WC()->cart->calculate_totals();
			
			
			// Validate posted data and cart items before proceeding.
			$api->check_cart_items();
			$chosen_payment_method = WC()->session->get( 'chosen_payment_method');
			if ( WC()->cart->needs_payment() ) {
				$available_gateways = self::get_available_payment_gateways();
				
				if ( !$chosen_payment_method||! isset( $available_gateways[ $chosen_payment_method ] ) ) {
					$errors->add( 'payment', __( 'Invalid payment method.', 'woocommerce' ) );
				} else {
					$available_gateways[ $chosen_payment_method ]->validate_fields();
				}
			}
			
			$customer = WC()->cart->get_customer();
			if(!$customer){
				$errors->add( 'shipping','登录信息已过期！' );
			}
			
			$sdk = $request->get_param('sdk');
			if($sdk&&version_compare($sdk, '1.0.3','>=')){
				$page_id = wc_privacy_policy_page_id();
				if($page_id){
					$terms = $request->get_param('terms');
					if ( $terms!='yes' ) { // WPCS: input var ok, CSRF ok.
						$errors->add( 'terms', __( 'Please read and accept the terms and conditions to proceed with your order.', 'woocommerce' ) );
					}
					
				}
			}
			
			foreach ( $errors->get_error_messages() as $message ) {
				throw new Exception($message);
			}
			
			$posted_data = array(
					'payment_method'=>$chosen_payment_method,
					'shipping_method' =>  WC()->session->get('chosen_shipping_methods'),
					'order_comments' => sanitize_text_field($request->get_param('leavemessage'))
			);
			
			$base = new WRest_Menu_Store_Base($version);
			$modal = $base->get_option('address_model','default');
			$posted_data['shipping_wrest_address_model'] = $modal;
			
			switch ($modal){
				case 'default':
					$address = $this->get_address();
					
					
					if(!$address['is_valid']){
						$errors->add( 'shipping','请完善送货信息！' );
					}
					
					if ( WC()->cart->needs_shipping() ) {
						$shipping_country = WC()->customer->get_shipping_country();
						
						if ( empty( $shipping_country ) ) {
							$errors->add( 'shipping', __( 'Please enter an address to continue.', 'woocommerce' ) );
						} elseif ( ! in_array( WC()->customer->get_shipping_country(), array_keys( WC()->countries->get_shipping_countries() ), true ) ) {
							/* translators: %s: shipping location */
							$errors->add( 'shipping', sprintf( __( 'Unfortunately <strong>we do not ship %s</strong>. Please enter an alternative shipping address.', 'woocommerce' ), WC()->countries->shipping_to_prefix() . ' ' . WC()->customer->get_shipping_country() ) );
						} else {
							$chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
							
							foreach ( WC()->shipping->get_packages() as $i => $package ) {
								if ( ! isset( $chosen_shipping_methods[ $i ], $package['rates'][ $chosen_shipping_methods[ $i ] ] ) ) {
									$errors->add( 'shipping', __( 'No shipping method has been selected. Please double check your address, or contact us if you need any help.', 'woocommerce' ) );
								}
							}
						}
					}
					$posted_data = array_merge($posted_data,array(
							'billing_first_name'=>$customer->get_billing_first_name(),
							'billing_last_name' => $customer->get_billing_last_name(),
							'billing_company' => $customer->get_billing_company(),
							'billing_country' => $customer->get_billing_country(),
							'billing_address_1' => $customer->get_billing_address_1(),
							'billing_address_2' =>$customer->get_billing_address_2(),
							'billing_city' => $customer->get_billing_city(),
							'billing_state' => $customer->get_billing_state(),
							'billing_postcode' => $customer->get_billing_postcode(),
							'billing_phone' => $customer->get_billing_phone(),
							'billing_email' => $customer->get_billing_email(),
							
							'shipping_first_name' => $customer->get_billing_first_name(),
							'shipping_last_name' => $customer->get_billing_last_name(),
							'shipping_company' =>$customer->get_billing_company(),
							'shipping_country' => $customer->get_billing_country(),
							'shipping_address_1' => $customer->get_billing_address_1(),
							'shipping_address_2' =>$customer->get_billing_address_2(),
							'shipping_city' => $customer->get_billing_city(),
							'shipping_state' => $customer->get_billing_state(),
							'shipping_postcode' =>$customer->get_billing_postcode()
					));
					break;
				default:
					$posted_data = apply_filters("wrest_process_checkout_{$modal}_posted_data",$posted_data,$version,$request);
			}
			
			$posted_data = apply_filters( 'wrest_checkout_posted_data',$posted_data );			
			$has_idcard = class_exists('WC_Sinic')&&WC_Sinic::instance()->get_available_addon('wc_sinic_add_ons_idcard');
			if($has_idcard){
			    $idcard_info=get_user_meta(get_current_user_id(),'wc_sinic_aliyun_idcard',true);
			    if(!$idcard_info||!is_array($idcard_info)){
			        throw new Exception('请完成实名认证！');
			    }
			    //['username' => $username, 'idcard' => $idcard]
			    $posted_data['billing_idcard_username'] = $idcard_info['username'];
			    $posted_data['billing_idcard_no'] = $idcard_info['idcard'];
			}
			
			do_action( 'woocommerce_after_checkout_validation',$posted_data, $errors );
			
			//===================
			
			foreach ( $errors->get_error_messages() as $message ) {
				wc_add_notice( $message );
			}
			
			if (  0 === wc_notice_count(  ) ) {
				
				$order_id = $api->create_order($posted_data );
				$order    = wc_get_order( $order_id );
				if ( is_wp_error( $order_id ) ) {
					throw new Exception( $order_id->get_error_message() );
				}
				
				if ( ! $order ) {
					throw new Exception( __( 'Unable to create order.', 'woocommerce' ) );
				}
				do_action( "woocommerce_checkout_{$modal}_order_processed", $order_id, $posted_data, $order );
				
				do_action( 'woocommerce_checkout_order_processed', $order_id, $posted_data, $order );
				
				if ( WC()->cart->needs_payment() ) {
					$payment_method = $posted_data['payment_method'];
					$available_gateways =self::get_available_payment_gateways();
					
					if ( ! isset( $available_gateways[ $payment_method ] ) ) {
						throw new Exception( __( 'Invalid payment method.', 'woocommerce' ));
					}
					
					// Store Order ID in session so it can be re-used after payment failure.
					WC()->session->set( 'order_awaiting_payment', $order_id );
					
					// Process Payment.
					$result = $available_gateways[ $payment_method ]->process_payment( $order_id );
					//if($result['result']=='success'){
						//wc_empty_cart();
						//WC()->cart->set_session();
					//}
					if(is_array($result)){
					    $result['order_id'] = $order_id;
					}
					return new WP_REST_Response($result);
				} else {
					$order = wc_get_order( $order_id );
					$order->payment_complete();
					wc_empty_cart();
					WC()->cart->set_session();
					return new WP_REST_Response(array(
							'result'   => 'success',
					        'order_id' => $order_id,
							'complete' => true
					));
				}
			}
		}catch(Exception $e){
			wc_add_notice($e->getMessage());
		}
		
		unset( WC()->session->refresh_totals, WC()->session->reload_checkout );
		return self::wc_get_errors();
	}
	
	
	
	public function get_cart($version,$args=array()){
		$last_order_id = WC()->session->get( 'order_awaiting_payment');
		if($last_order_id){
			$order = wc_get_order($last_order_id);
			if(!$order){
				WC()->session->__unset('order_awaiting_payment');
			
			}else if($order->is_paid()){
				WC()->cart->empty_cart();
				WC()->cart->set_session();
				WC()->session->__unset('order_awaiting_payment');
			}
		}
		
// 		$args = shortcode_atts(array(
// 				'include_product'=>true,
// 				'include_checkout'=>true
// 		), $args);
		$args = array(
			'include_product'=>true,
			'include_checkout'=>true
		);
		$json = array(
			'items'=>array()
		);
		
		if($args['include_checkout']){
			WC()->cart->calculate_totals();
		}
		
		$temp = WC()->cart->get_cart();
		if($temp){
			foreach($temp as $key => $cartitem) {
			    $newcartitem = array(
			        'key'=>$cartitem['key'],
			        'product_id'=>$cartitem['product_id'],
			        'variation_id'=>$cartitem['variation_id'],
			        'variation'=>$cartitem['variation'],
			        'quantity'=>$cartitem['quantity'],
			    );
				$product_id   = $cartitem['variation_id'] > 0 ? $cartitem['variation_id'] : $cartitem['product_id'];
				if($args['include_product']){
					$product = $this->get_product($cartitem['data']);
					if(!$product->is_load()){continue;}
					$newcartitem['product'] = $product->to_simple($version,'thumbnail');
					$newcartitem['item_total'] = self::format_price( $cartitem['line_total']) ;
				}
				
				$subtitle = '';
				if(isset($cartitem['variation'])&&$cartitem['variation']&&is_array($cartitem['variation'])){
				    $index = 0;
				    foreach($cartitem['variation'] as $att=>$v){
				        $name = substr($att, strlen('attribute_'));
				        if(taxonomy_exists( $name )){
				            $term = get_term_by('slug', $v,$name);
				            if($term&&!is_wp_error($term)){
				                if($index++!=0){
				                    $subtitle.=" ";
				                }
				                $subtitle.="\"{$term->name}\"";
				            }
				        }else{
				            if($index++!=0){
				                $subtitle.=" ";
				            }
				            $subtitle.="\"{$v}\"";
				        }
				    }
				}
				$newcartitem['subtitle'] = $subtitle;
				//此处key不能使用variation_id,variation_id可能重复
				//此处使用product_i为key是为了方便前端取值
				$json['items'][$cartitem['variation_id'] > 0?$key:$product_id] = $newcartitem;
			}
		}
		
		$json['cart_total'] = self::format_price(  WC()->cart->total ) ;
		$json['cart_tax_total'] = self::format_price( WC()->cart->get_taxes_total()) ;
		$json['cart_subtotal'] = self::format_price( WC()->cart->subtotal) ;
		$json['cart_contents_count'] = WC()->cart->get_cart_contents_count();
		
		$json['currency'] = get_woocommerce_currency();
		$json['currency_symbol'] = get_woocommerce_currency_symbol();
		$base = new WRest_Menu_Store_Base($version);
		$json['address_model'] = $base->get_option('address_model');
		
		if($args['include_checkout']){
			//$json['subtotal_ex_tax'] = WC()->cart->subtotal_ex_tax;
			//$json['taxes_total'] = WC()->cart->get_taxes_total();
			
			$json['enable_order_comments'] = 'yes' == get_option( 'woocommerce_enable_order_comments', 'yes' );
			$json['applied_coupons'] = $this->get_cart_coupons();
			$json['coupons_enabled'] = wc_coupons_enabled();
			$json['discount_cart'] = self::format_price( WC()->cart->discount_cart) ;
			
			$json['needs_shipping'] = WC()->cart->needs_shipping();
			$json['needs_shipping_address'] = WC()->cart->needs_shipping_address();
			$json['address'] = $this->get_address();
			$json['shipping_total'] = self::format_price( WC()->cart->shipping_total) ;
            $idcard =  class_exists('WC_Sinic')&&WC_Sinic::instance()->get_available_addon('wc_sinic_add_ons_idcard');
            if($idcard ){
                $cardInfo = get_user_meta(get_current_user_id(),'wc_sinic_aliyun_idcard',true);
                $_username =$cardInfo&&is_array($cardInfo)&&isset($cardInfo['username'])?$cardInfo['username']:null;
                $_idcard =$cardInfo&&is_array($cardInfo)&&isset($cardInfo['idcard'])?$cardInfo['idcard']:null;
                
                if($_username&&strlen($_username)>1){
                    $len = mb_strlen($_username,'utf-8')-1;
                    $_username = mb_substr($_username, 0,1,'utf-8');
                    while ($len-->0){
                        $_username.='*';
                    }
                }
                
                if($_idcard&&strlen($_idcard)>3){
                    $_idcard = substr($_idcard, 0,3).'******'.substr($_idcard,-2);
                }
                $json['idcard'] =array(
                    'is_valid'=>$_username&&$_idcard,
                    'username' => $_username,
                    'no' => $_idcard
                );
            }
            global $wpdb;
            $coupon_count = 0;
            $user_ID = get_current_user_id();
            if($user_ID){
                $now = current_time( 'timestamp' );
                $couponList = $wpdb->get_results(
                    "select w.coupon_id,
                            w.id
                     from {$wpdb->prefix}wrest_coupon w
                     where w.user_ID={$user_ID}
                           and w.status='prepare'
                     order by w.created_time desc
                     limit 50;");
                
                if($couponList){
                    foreach ($couponList as $item){
                        $coupon = new WC_Coupon($item->coupon_id);
                        if(!$coupon->get_id()){
                            $wpdb->query("delete from {$wpdb->prefix}wrest_coupon where id={$item->id};");
                            continue;
                        }
                        
                        if(WRest_Coupon::is_valid_for_cart($coupon)){
                            $coupon_count++;
                        }
                    }
                }
            }
            
            $json['countOfActiveCoupons'] = $coupon_count;
			//$json['shipping_tax_total'] =  WC()->cart->shipping_tax_total;
			//$json['shipping_tax'] =   WC()->cart->shipping_tax;
			
			$page_id = wc_privacy_policy_page_id();
			if($page_id){ 
				$json['privacy_policy'] = array(
					'title'=>apply_filters('wrest_privacy_policy_title', __( 'privacy policy', 'woocommerce' )),
					'description'=>WRest_Helper_String::towxml(wp_kses_post( wpautop( wc_replace_policy_page_link_placeholders( wc_get_privacy_policy_text( 'checkout' ) ) ) )),
					'page_id'=>urlencode(get_permalink($page_id))
				);
			}
			$sdk = isset($_REQUEST['sdk'])?$_REQUEST['sdk']:null;
			$json['needs_payment'] =  WC()->cart->needs_payment();
			if($json['needs_payment']){
				$available_gateways =self::get_available_payment_gateways();
				if($available_gateways&&count($available_gateways)>0){
					$available_gateways1=array();
					$first_payment_method = null;
					foreach ($available_gateways as $gateway){
					    if($sdk&&version_compare($sdk, '1.0.3','<=')){
					        if(!$gateway instanceof Abstract_WRest_WC_Payment_Gateway){
					            continue;
					        }
					    }
					    
						if(!$first_payment_method){
							$first_payment_method = $gateway->id;
						}
						
						$available_gateways1[$gateway->id] = array(
							'id'=>$gateway->id,
							'icon'=>$gateway->icon,
							'title'=>$gateway->title,
							'description'=>$gateway->description,
							'chosen'=>$gateway->chosen
						);
					}
					
					$chosen_payment_method = WC()->session->get( 'chosen_payment_method');
					if(!$chosen_payment_method||!isset($available_gateways1[$chosen_payment_method])){
						$chosen_payment_method = $first_payment_method;
						WC()->session->set( 'chosen_payment_method',$chosen_payment_method);
					}
					
					$json['available_gateways'] =array_values($available_gateways1);
					$json['chosen_payment_method'] = $chosen_payment_method;
				}
			}
			
			if($json['needs_shipping']&&$json['needs_shipping_address']){
				$packages           = WC()->shipping->get_packages();
				
				$first              = true;
				
				$shippings = array();
				foreach ( $packages as $i => $package ) {
					$chosen_method = isset( WC()->session->chosen_shipping_methods[ $i ] ) ? WC()->session->chosen_shipping_methods[ $i ] : '';
					
					$rates = array();
					$index = 0;
					$chosen_index = 0;
					if($package['rates']){
						foreach ($package['rates'] as $key=>$rate){
							$rate instanceof WC_Shipping_Rate;
							$cost = self::format_price( $rate->get_cost() );
							$rates[] = array(
									'id'=>$rate->get_id(),
									'method_id'=>$rate->get_method_id(),
									'instance_id'=>$rate->get_instance_id(),
									'label'=>$rate->get_label()."(".($rate->get_cost()>0?($json['currency_symbol'].$cost):"免费").")",
									'cost'=>$cost
							);
							if($key==$chosen_method){
								$chosen_index =$index;
							}
							$index++;
						}
					}
					
					$shippings[$i]=array(
							'available_methods'        => $rates,
							//'show_package_details'     => count( $packages ) > 1,
							//'package_details'          => implode( ', ', $product_names ),
							/* translators: %d: shipping package number */
							'package_name'             => apply_filters( 'woocommerce_shipping_package_name', ( ( $i + 1 ) > 1 ) ? sprintf('配送 %d', ( $i + 1 ) ) :'配送', $i, $package ),
							'index'                    => $i,
							'chosen_method'            => $chosen_method,
							'chosen_index'			   => $chosen_index,
							//'formatted_destination'    => WC()->countries->get_formatted_address( $package['destination'], ', ' ),
							//'has_calculated_shipping'  => WC()->customer->has_calculated_shipping(),
					);
					
					$first = false;
				}
				
				$json['shipping'] = $shippings;
			}
		}
		
		return apply_filters('wrest_cart', $json,$this);
	}
	
	public function get_cart_coupons(){
		$cart = WC()->cart;
		$coupons = $cart->get_coupons();
		if(!$coupons){
			return null;
		}
		
		$results = array();
		foreach ($coupons as $code=>$coupon){
			$coupon instanceof WC_Coupon;
			$model = WRest_Coupon::to_detail($coupon);
			$model['free_amount'] = isset($cart->coupon_discount_amounts[$code])?$cart->coupon_discount_amounts[$code]:0;
			$results[] =$model;
		}
		
		return $results;
	}
	
	private static function wc_get_errors($clear=true){
		$notices = wc_get_notices();
		if($clear){
			wc_clear_notices();
		}
		$error = new WP_Error();
		if(!$notices){
			return $error;
		}
		
		foreach ($notices as $key=>$notice){
			$error->add($key, wc_clean(trim(strip_tags(is_array($notice)? join(';', $notice):$notice))));
		}
		
		return $error;
	}
	
	public function get_product_list($version,$config,$image_size = 'woocommerce_single',$mode=ARRAY_N){
	    $args = array(
	        'status'=>'publish'
	    );
	    
	    
	    if(isset($config['post__in'])&&$config['post__in']&&is_array($config['post__in'])&&count($config['post__in'])>0){
	       if(!isset($args['include'])||!$args['include']){
	           $args['include']=array();
	       }
	       foreach ($config['post__in'] as $p){
	           $args['include'][]=$p;
	       }
           $args['orderby']='post__in';
	    }
	    
	    if(isset($config['post__not_in'])&&$config['post__not_in']&&is_array($config['post__not_in'])){
	        if(!isset($args['exclude'])||!$args['exclude']){
	            $args['exclude']=array();
	        }
	        foreach ($config['post__not_in'] as $p){
	            $args['exclude'][]=$p;
	        }
	    }
	   
	    if(isset($config['exclude'])&&$config['exclude']&&is_array($config['exclude'])){
	        if(!isset($args['exclude'])||!$args['exclude']){
	            $args['exclude']=array();
	        }
	        foreach ($config['exclude'] as $p){
	            $args['exclude'][]=$p;
	        }
	    }
	    //==============================================================
	    if(isset($config['category'])&&$config['category']&&is_array($config['category'])){
	        $args['__wrest__category_id'] = $config['category'];
	    }
	    
	    if(isset($config['category'])&&$config['category']&&is_numeric($config['category'])){
	    	$args['__wrest__category_id'] = array($config['category']);
	    }
	    
	    //==============================================================
	    if(isset($config['tag'])&&$config['tag']&&is_array($config['tag'])){
	        $args['__wrest__tag_id'] = $config['tag'];
	    }
	    
	    if(isset($config['tax_query'])&&$config['tax_query']){
	        $args['tax_query'] = $config['tax_query'];
	    }
	    
	    if(isset($config['featured'])&&$config['featured']=='yes'){
	        $args['featured'] = true;
	    }
	    
	    if(isset($config['limit'])&&$config['limit']){
	        $args['limit'] = absint($config['limit']);
	    }
	    
	    if(isset($config['offset'])&&$config['offset']){
	        $args['offset'] = absint($config['offset']);
	    }

	    if(isset($config['posts_per_page'])&&$config['posts_per_page']){
	        $args['posts_per_page'] = absint($config['posts_per_page']);
	    }
	    
	    if(isset($args['limit'])&&isset($args['posts_per_page'])){
	        $args['paginate'] = true;
	    }
	    if(isset($config['paginate'])){
	        $args['paginate'] = $config['paginate'];
	    }
	    
	    if(isset($config['product_type'])){
	    	$args['type'] = $config['product_type'];
	    }
	    
	    if(isset($config['onsale'])&&$config['onsale']=='yes'){
	        if(!isset($args['__wrest__meta_query'])){
	            $args['__wrest__meta_query']=array();
	        }
	        
	        $args['__wrest__meta_query'][]=array(
	            'relation' => 'OR',
	            array(
                    'key' => '_sale_price_dates_from', //(字符串) - 自定义字段的键
                    'compare' => 'NOT EXISTS' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
	            ),
        		array(
        				'key' => '_sale_price_dates_from', //(字符串) - 自定义字段的键
        				'value' => '', //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
        				'type' => 'CHAR', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
        				'compare' => '=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
        		),
	            array(
	                'key' => '_sale_price_dates_from', //(字符串) - 自定义字段的键
	                'value' => date_i18n('Y-m-d'), //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
	                'type' => 'DATETIME', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
	                'compare' => '<=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
	            )
	        );
	        $args['__wrest__meta_query'][]=array(
	            'relation' => 'OR',
	            array(
	                'key' => '_sale_price_dates_to', //(字符串) - 自定义字段的键
	                'compare' => 'NOT EXISTS' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
	            ),
        		array(
        				'key' => '_sale_price_dates_to', //(字符串) - 自定义字段的键
        				'value' => '', //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
        				'type' => 'CHAR', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
        				'compare' => '=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
        		),
	            array(
	                'key' => '_sale_price_dates_to', //(字符串) - 自定义字段的键
	                'value' => date_i18n('Y-m-d'), //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
	                'type' => 'DATETIME', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
	                'compare' => '>=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
	            )
	        );
	        $args['__wrest__meta_query'][]=array(
	            'relation' => 'AND',
	            array(
	                'key' => '_sale_price', //(字符串) - 自定义字段的键
	                'value' => 0, //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
	                'type' => 'DECIMAL', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
	                'compare' => '>' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
	            )
	        );
	    }
	    
	    if(isset($config['meta_query'])&&$config['meta_query']){
	        if(!isset($args['__wrest__meta_query'])){
	            $args['__wrest__meta_query']=array();
	        }
	        
	        foreach ($config['meta_query'] as $metas){
	            $args['__wrest__meta_query'][]=$metas;
	        }
	    }
	
	    if(isset($config['sort'])){
	        switch ($config['sort']){
	            default:
	                break;
                case 'publish_date_desc':
                    $args['order'] ='DESC';
                    $args['orderby'] = 'post_date';
                    break;
                    
                case 'modify_date_desc':
                    $args['order'] ='DESC';
                    $args['orderby'] = 'post_modified';
                    break;
                    
	            case 'average_rating_desc':
	               $args['meta_key']='_wc_average_rating';
	               $args['order'] ='DESC';
	               $args['orderby'] = 'meta_value_num';
	               break;
               case 'average_rating_asc':
                   $args['meta_key']='_wc_average_rating';
                   $args['order'] ='ASC';
                   $args['orderby'] = 'meta_value_num';
                   break;
                   
               case 'review_count_desc':
                   $args['meta_key']='_wc_review_count';
                   $args['order'] ='DESC';
                   $args['orderby'] = 'meta_value_num';
                   break;
               case 'review_count_asc':
                   $args['meta_key']='_wc_review_count';
                   $args['order'] ='ASC';
                   $args['orderby'] = 'meta_value_num';
                   break;
                   
               case 'sale_qty_desc':
                   $args['meta_key']='total_sales';
                   $args['order'] ='DESC';
                   $args['orderby'] = 'meta_value_num';
                   break;
               case 'sale_qty_asc':
                   $args['meta_key']='total_sales';
                   $args['order'] ='ASC';
                   $args['orderby'] = 'meta_value_num';
                   break;
                   
               case 'price_desc':
                   $args['meta_key']='_price';
                   $args['order'] ='DESC';
                   $args['orderby'] = 'meta_value_num';
                   break;
               case 'price_asc':
                   $args['meta_key']='_price';
                   $args['order'] ='ASC';
                   $args['orderby'] = 'meta_value_num';
                   break;
                   
               case 'random':
                   $args['orderby'] = 'rand';
                   break;
	        }
	    }
	    
	    if(isset($config['s'])&&mb_strlen($config['s'],'utf-8')>=2){
	        $product_id = wc_get_product_id_by_sku($config['s']);
	        if($product_id){
	            $args['sku'] = $config['s'];
	        }else{
	            $args['s'] = $config['s'];
	        }
	    }
	    
	    add_filter('posts_join', __CLASS__.'::posts_join',10,2);
	    add_filter('posts_groupby',__CLASS__.'::posts_groupby',10,2);
	    add_filter('woocommerce_get_wp_query_args', __CLASS__.'::woocommerce_get_wp_query_args',10,2);
	    add_filter('posts_search',  'WRest_Hooks::wpse_11826_search_by_title', 10, 2 );
	    
	    
	    $query = new WC_Product_Query($args);
	    $queryData = $query->get_products();
	    
	    remove_filter('posts_join', __CLASS__.'::posts_join');
	    remove_filter('posts_groupby',__CLASS__.'::posts_groupby');
	    remove_filter('woocommerce_get_wp_query_args', __CLASS__.'::woocommerce_get_wp_query_args');
	    remove_filter('posts_search',  'WRest_Hooks::wpse_11826_search_by_title');
	    $products = null;
	    if(isset($args['paginate'])&&$args['paginate']){
	        $products = $queryData->products;
	        $total_count = absint($queryData->total);
	    }else{
	        $products = $queryData;
	        $total_count = $queryData?count($queryData):0;
	    }
	    
	    $results = array();
	    if($products){
	        foreach ($products as $item){
	            $product = $this->get_product($item);
	            if($product->is_load()){
	            	if($mode==ARRAY_N||$mode==ARRAY_A){
	                	$results[]=$product->to_simple($version,$image_size);
	            	}else{
	            		$results[]=$product;
	            	}
	            }
	        }
	    }
	    
		return array(
		    'items'=>$results,
		    'total_count'=>$total_count
		);
	}
	
	/**
	 *
	 * @param string $groupBy
	 * @param WP_Query $wp_query
	 */
	public static function posts_groupby($groupBy,$wp_query){
	    if(!$wp_query->query_vars||!isset($wp_query->query_vars['__wrest__p_category_id'])||!$wp_query->query_vars['__wrest__p_category_id']){
	        return $groupBy;
	    }
	
	    global $wpdb;
	    return " {$wpdb->posts}.post_parent ";
	}
	
	/**
	 *
	 * @param string $join
	 * @param WP_Query $wp_query
	 */
	public static function posts_join($join,$wp_query){
	    if(!$wp_query->query_vars||!isset($wp_query->query_vars['__wrest__p_category_id'])||!$wp_query->query_vars['__wrest__p_category_id']){
	        return $join;
	    }
	
	    $catArray=array();
	    if(is_numeric($wp_query->query_vars['__wrest__p_category_id'])){
	        $catArray[]=absint($wp_query->query_vars['__wrest__p_category_id']);
	    }else if(is_array($wp_query->query_vars['__wrest__p_category_id'])){
	        $catArray = array_map('absint', $wp_query->query_vars['__wrest__p_category_id']);
	    }
	
	    if(!count($catArray)){
	        return $join;
	    }
	
	    $sql = join(',', $catArray);
	    $api = WRest::instance()->get_product_api();
	    global $wpdb;
	    $join.=" inner join(
	    select tr.object_id
	    from {$wpdb->term_relationships} tr
	    inner join {$wpdb->term_taxonomy} tt on tt.term_taxonomy_id = tr.term_taxonomy_id
	    where tt.term_id in ({$sql})
    	    and tt.taxonomy='{$api->cat_type}'
    	    group by tr.object_id
    	    )wrest_p_category_id on wrest_p_category_id.object_id={$wpdb->posts}.post_parent ";
	    return $join;
	}
	
	public static function woocommerce_get_wp_query_args($wp_query_args, $query_vars){
	    if(isset($query_vars['__wrest__meta_query'])&&$query_vars['__wrest__meta_query']){
	        if(!isset($wp_query_args['meta_query'])||!$wp_query_args['meta_query']){
	            $wp_query_args['meta_query'] =array();
	        }
	
	        foreach ($query_vars['__wrest__meta_query'] as $metas){
	            $wp_query_args['meta_query'][]=$metas;
	        }
	    }
	    $api = WRest::instance()->get_product_api();
	    if(isset($query_vars['__wrest__category_id'])&&$query_vars['__wrest__category_id']){
	        //查询它的子类
	        $category_ids = array();
	        if(is_numeric($query_vars['__wrest__category_id'])){
	            $category_ids[]=absint($query_vars['__wrest__category_id']);
	        }else if(is_array($query_vars['__wrest__category_id'])){
	            $category_ids = array_unique(array_map('absint', $query_vars['__wrest__category_id']));
	        }
	
	        $catArray = array();
	
	        if(count($category_ids)>0){
	            foreach ($category_ids as $cat_id){
	                $catArray[]=$cat_id;
	                $children = get_term_children( $cat_id, $api->cat_type );
	
	                if($children){
	                    foreach ($children as $t){
	                        $catArray[]=$t;
	                    }
	                }
	            }
	        }
	
	        if(count($catArray)>0){
	            if(!isset($wp_query_args['tax_query'])){
	                $wp_query_args['tax_query']=array();
	            }
	
	            $query = array(
	                'relation'=>'AND'
	            );
	
	            $query[] = array(
	                'taxonomy' => $api->cat_type,
	                'field'    => 'term_id',
	                'terms'    => $catArray,
	            );
	            $wp_query_args['tax_query'][]=$query;
	        }
	    }
	
	    // Handle product tags.
	    if ( isset($query_vars['__wrest__tag_id'])&&$query_vars['__wrest__tag_id'] ) {
	        if(!isset($wp_query_args['tax_query'])){
	            $wp_query_args['tax_query']=array();
	        }
	        $query = array(
	            'relation'=>'AND'
	        );
	
	        $query[] = array(
	            'taxonomy' => $api->tag_type,
	            'field'    => 'term_id',
	            'terms'    => $query_vars['__wrest__tag_id'],
	        );
	        $wp_query_args['tax_query'][]=$query;
	    }
	     
	    return $wp_query_args;
	}
}