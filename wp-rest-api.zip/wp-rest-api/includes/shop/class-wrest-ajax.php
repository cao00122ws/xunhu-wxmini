<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * WRest_Ajax class
 *
 * @version     2.1.0
 * @category    Class
 */
class WRest_Ajax {

	/**
	 * Init shortcodes.
	 */
	public static function init() {
		$shortcodes = array(
		    'wrest_plugin'=>__CLASS__ . '::plugin',
		    'wrest_service'=>__CLASS__ . '::service',
		    'wrest_captcha'=>__CLASS__ . '::captcha',
		    'xunhuweb_cron'   =>__CLASS__ . '::cron',
			'wrest_obj_search'=>__CLASS__. '::obj_search',
		    'wrest_ueditor'=>__CLASS__. '::ueditor',
		);
		
		$add_ons = WRest::instance()->get_available_addons();
		if($add_ons){
		    foreach ($add_ons as $add_on){
		        $shortcodes["wrest_{$add_on->id}"] =array($add_on,'do_ajax');
		    }
		}
		
		$shortcodes = apply_filters('wrest_ajax', $shortcodes);
		foreach ( $shortcodes as $shortcode => $function ) {
		    add_action ( "wp_ajax_$shortcode",        $function);
		    add_action ( "wp_ajax_nopriv_$shortcode", $function);
		}
	}
	
	public static function ueditor(){
	    $action = 'wrest_ueditor';
	    $params=shortcode_atts(array(
	        'notice_str'=>null,
	        'action'=>$action,
	        $action=>null
	    ), stripslashes_deep($_REQUEST));
	    
	    if ( ! current_user_can( 'manage_options') ){
    		return;
    	}
	    
	    if(!WRest::instance()->WP->ajax_validate($params, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
	        echo WRest_Error::err_code(701)->to_json();
	        exit;
	    }
	    global $CONFIG;
	    $CONFIG =array(
	        "imageActionName"=> "uploadimage", /* 执行上传图片的action名称 */
	        "imageFieldName"=> "upfile", /* 提交的图片表单名称 */
	        "imageMaxSize"=> 2048000, /* 上传大小限制，单位B */
	        "imageAllowFiles"=> [".png", ".jpg", ".jpeg", ".gif", ".bmp"], /* 上传图片格式显示 */
	        "imageCompressEnable"=> true, /* 是否压缩图片,默认是true */
	        "imageCompressBorder"=> 1600, /* 图片压缩最长边限制 */
	        "imageInsertAlign"=> "none", /* 插入的图片浮动方式 */
	        "imageUrlPrefix"=> "", /* 图片访问路径前缀 */
	        "imagePathFormat"=> "/ueditor/images/{yyyy}{mm}{dd}/{time}{rand:6}", /* 上传保存路径,可以自定义保存路径和文件名格式 */
	        /* {filename} 会替换成原文件名,配置这项需要注意中文乱码问题 */
	        /* {rand:6} 会替换成随机数,后面的数字是随机数的位数 */
	        /* {time} 会替换成时间戳 */
	        /* {yyyy} 会替换成四位年份 */
	        /* {yy} 会替换成两位年份 */
	        /* {mm} 会替换成两位月份 */
	        /* {dd} 会替换成两位日期 */
	        /* {hh} 会替换成两位小时 */
	        /* {ii} 会替换成两位分钟 */
	        /* {ss} 会替换成两位秒 */
	        /* 非法字符 \ => * ? " < > | */
	        /* 具请体看线上文档=> fex.baidu.com/ueditor/#use-format_upload_filename */
	        
	        /* 涂鸦图片上传配置项 */
	        "scrawlActionName"=> "uploadscrawl", /* 执行上传涂鸦的action名称 */
	        "scrawlFieldName"=> "upfile", /* 提交的图片表单名称 */
	        "scrawlPathFormat"=> "/ueditor/images/{yyyy}{mm}{dd}/{time}{rand:6}", /* 上传保存路径,可以自定义保存路径和文件名格式 */
	        "scrawlMaxSize"=> 2048000, /* 上传大小限制，单位B */
	        "scrawlUrlPrefix"=> "", /* 图片访问路径前缀 */
	        "scrawlInsertAlign"=> "none",
	        
	        /* 截图工具上传 */
	        "snapscreenActionName"=> "uploadimage", /* 执行上传截图的action名称 */
	        "snapscreenPathFormat"=> "/ueditor/images/{yyyy}{mm}{dd}/{time}{rand:6}", /* 上传保存路径,可以自定义保存路径和文件名格式 */
	        "snapscreenUrlPrefix"=> "", /* 图片访问路径前缀 */
	        "snapscreenInsertAlign"=> "none", /* 插入的图片浮动方式 */
	        
	        /* 抓取远程图片配置 */
	        "catcherLocalDomain"=> ["127.0.0.1", "localhost", "img.baidu.com"],
	        "catcherActionName"=> "catchimage", /* 执行抓取远程图片的action名称 */
	        "catcherFieldName"=> "source", /* 提交的图片列表表单名称 */
	        "catcherPathFormat"=> "/ueditor/images/{yyyy}{mm}{dd}/{time}{rand:6}", /* 上传保存路径,可以自定义保存路径和文件名格式 */
	        "catcherUrlPrefix"=> "", /* 图片访问路径前缀 */
	        "catcherMaxSize"=> 2048000, /* 上传大小限制，单位B */
	        "catcherAllowFiles"=> [".png", ".jpg", ".jpeg", ".gif", ".bmp"], /* 抓取图片格式显示 */
	        
	        /* 上传视频配置 */
	        "videoActionName"=> "uploadvideo", /* 执行上传视频的action名称 */
	        "videoFieldName"=> "upfile", /* 提交的视频表单名称 */
	        "videoPathFormat"=> "/ueditor/videos/{yyyy}{mm}{dd}/{time}{rand:6}", /* 上传保存路径,可以自定义保存路径和文件名格式 */
	        "videoUrlPrefix"=> "", /* 视频访问路径前缀 */
	        "videoMaxSize"=> 102400000, /* 上传大小限制，单位B，默认100MB */
	        "videoAllowFiles"=> [
	            ".flv", ".swf", ".mkv", ".avi", ".rm", ".rmvb", ".mpeg", ".mpg",
	            ".ogg", ".ogv", ".mov", ".wmv", ".mp4", ".webm", ".mp3", ".wav", ".mid"], /* 上传视频格式显示 */
	        
	            /* 上传文件配置 */
	        "fileActionName"=> "uploadfile", /* controller里,执行上传视频的action名称 */
	        "fileFieldName"=> "upfile", /* 提交的文件表单名称 */
	        "filePathFormat"=> "/ueditor/files/{yyyy}{mm}{dd}/{time}{rand:6}", /* 上传保存路径,可以自定义保存路径和文件名格式 */
	        "fileUrlPrefix"=> "", /* 文件访问路径前缀 */
	        "fileMaxSize"=> 51200000, /* 上传大小限制，单位B，默认50MB */
	        "fileAllowFiles"=> [
	            ".png", ".jpg", ".jpeg", ".gif", ".bmp",
	            ".flv", ".swf", ".mkv", ".avi", ".rm", ".rmvb", ".mpeg", ".mpg",
	            ".ogg", ".ogv", ".mov", ".wmv", ".mp4", ".webm", ".mp3", ".wav", ".mid",
	            ".rar", ".zip", ".tar", ".gz", ".7z", ".bz2", ".cab", ".iso",
	            ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".md", ".xml"
	        ], /* 上传文件格式显示 */
	        
	        /* 列出指定目录下的图片 */
	        "imageManagerActionName"=> "listimage", /* 执行图片管理的action名称 */
	        "imageManagerListPath"=> "/ueditor/images/", /* 指定要列出图片的目录 */
	        "imageManagerListSize"=> 20, /* 每次列出文件数量 */
	        "imageManagerUrlPrefix"=> "", /* 图片访问路径前缀 */
	        "imageManagerInsertAlign"=> "none", /* 插入的图片浮动方式 */
	        "imageManagerAllowFiles"=> [".png", ".jpg", ".jpeg", ".gif", ".bmp"], /* 列出的文件类型 */
	        
	        /* 列出指定目录下的文件 */
	        "fileManagerActionName"=> "listfile", /* 执行文件管理的action名称 */
	        "fileManagerListPath"=> "/ueditor/files/", /* 指定要列出文件的目录 */
	        "fileManagerUrlPrefix"=> "", /* 文件访问路径前缀 */
	        "fileManagerListSize"=> 20, /* 每次列出文件数量 */
	        "fileManagerAllowFiles"=> [
	            ".png", ".jpg", ".jpeg", ".gif", ".bmp",
	            ".flv", ".swf", ".mkv", ".avi", ".rm", ".rmvb", ".mpeg", ".mpg",
	            ".ogg", ".ogv", ".mov", ".wmv", ".mp4", ".webm", ".mp3", ".wav", ".mid",
	            ".rar", ".zip", ".tar", ".gz", ".7z", ".bz2", ".cab", ".iso",
	            ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf", ".txt", ".md", ".xml"
	        ] /* 列出的文件类型 */
	    );
	    
	    $action = sanitize_text_field($_REQUEST['theAction']);    
	    switch ($action) {
	        case 'config':
	            $result =  json_encode($CONFIG);
	            break;
	            /* 上传图片 */
	        case 'uploadimage':
	            /* 上传涂鸦 */
	        case 'uploadscrawl':
	            /* 上传视频 */
	        case 'uploadvideo':
	            /* 上传文件 */
	        case 'uploadfile':
	            $result = require_once WREST_DIR.'/includes/ueditor/action_upload.php';
	            break;
	    
	            /* 列出图片 */
	        case 'listimage':
	            $result = require_once WREST_DIR.'/includes/ueditor/action_list.php';
	            break;
	            /* 列出文件 */
	        case 'listfile':
	            $result = require_once WREST_DIR.'/includes/ueditor/action_list.php';
	            break;
	    
	            /* 抓取远程文件 */
	        case 'catchimage':
	            $result = require_once WREST_DIR.'/includes/ueditor/action_crawler.php';
	            break;
	        default:
	            $result = json_encode(array(
	               'state'=> '请求地址出错'
	            ));
	            break;
	    }
	    
	    /* 输出结果 */
	    if (isset($_GET["callback"])) {
	        if (preg_match("/^[\w_]+$/", $_GET["callback"])) {
	            echo htmlspecialchars(sanitize_text_field($_GET["callback"])) . '(' . $result . ')';
	        } else {
	            echo json_encode(array(
	                'state'=> 'callback参数不合法'
	            ));
	        }
	    } else {
	        echo $result;
	    }
	    exit;
	}
	
	public static function obj_search(){
		$action ='wrest_obj_search';
		$params=shortcode_atts(array(
			'notice_str'=>null,
			'action'=>$action,
			$action=>null
		), stripslashes_deep($_REQUEST));
		
		if(!WRest::instance()->WP->ajax_validate($params, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
			echo WRest_Error::err_code(701)->to_json();
			exit;
		}
		if(!isset($_REQUEST['term'])){
			$_REQUEST['term'] ='';
		}
		
		$post_ID = 0;
		$keywords=null;
		if(isset($_REQUEST['term'])&&is_numeric($_REQUEST['term'])){
			$post_ID =absint($_REQUEST['term']);
		}else{
			$keywords = isset($_REQUEST['term'])?trim(stripslashes($_REQUEST['term'])):null;
			$keywords = mb_strimwidth($keywords, 0, 32,'','utf-8');
		}
		global $wpdb;
		$keywords = $wpdb->esc_like(($keywords));
		$type = isset($_REQUEST['obj_type'])?sanitize_key($_REQUEST['obj_type']):null;
		
		$results = apply_filters("wrest_obj_search_{$type}",null,$type, $keywords,$post_ID);
		if(!is_null($results)){
			echo json_encode(array(
					'items'=>$results
			));
			exit;
		}

		global $wpdb;
		
		switch ($type){
			case 'customer':
			case 'wp_user':
                $keywords = isset($_REQUEST['term'])?trim(stripslashes($_REQUEST['term'])):null;
                $keywords = mb_strimwidth($keywords, 0, 32,'','utf-8');
                $keywords = $wpdb->esc_like(($keywords));

				$users = $wpdb->get_results($wpdb->prepare(
				"select u.ID,
						u.user_login,
						u.user_email
				from {$wpdb->users} u
				where ( u.ID={$post_ID} or u.user_login like %s or u.user_email like %s or u.display_name like %s)
				limit 10;","%$keywords%","%$keywords%","%$keywords%"));

				$results = array();
				if($users){
					foreach ($users as $user){
						if(!empty($user->user_email)){
							$results[]=array(
									'id'=>$user->ID,
									'text'=>"{$user->user_login}({$user->user_email})"
							);
						}else{
							$results[]=array(
									'id'=>$user->ID,
									'text'=>"{$user->user_login}"
							);
						}
					}
				}
				
				echo json_encode(array(
						'items'=>$results
				));
				exit;
			case 'product_cat':	
			case 'product_tag':
				global $wpdb;
				$posts = $wpdb->get_results($wpdb->prepare(
						"select t.*
						from {$wpdb->terms} t
						inner join {$wpdb->term_taxonomy} tt on tt.term_id = t.term_id
						where tt.taxonomy='{$type}'
							  and ({$post_ID}=0 or t.term_id={$post_ID})
							  and (%s = '' or t.name like %s)
						limit 10;",$keywords, "%$keywords%"));
				$results = array();
				if($posts){
					foreach ($posts as $post){
						$results[]=array(
								'id'=>$post->term_id,
								'text'=>$post->name
						);
					}
				}
				
				echo json_encode(array(
						'items'=>$results
				));
				exit;
			case 'product':
				global $wpdb;
				
				$posts = $wpdb->get_results($wpdb->prepare(
						"select u.ID,
								u.post_title
						from {$wpdb->posts} u
						where ($post_ID=0 or u.ID=$post_ID)
							and (%s = '' or u.post_title like %s)
							and u.post_type in ('product','product_variation')
							and u.post_status='publish'
						limit 10;",$keywords, "%$keywords%"));
						
					$results = array();
					if($posts){
						foreach ($posts as $post){
							$results[]=array(
								'id'=>$post->ID,
								'text'=>$post->post_title
							);
						}
					}
					
					echo json_encode(array(
							'items'=>$results
					));
					exit;
			case 'shop_coupon':
				$posts = $wpdb->get_results($wpdb->prepare(
						"select u.ID,
								u.post_title,
								u.post_excerpt
						from {$wpdb->posts} u
						where ($post_ID=0 or u.ID=$post_ID)
							and (%s='' or u.post_title like %s)
							and u.post_type=%s
							and u.post_status='publish'
						limit 10;",$keywords,"%$keywords%", $type));

				$results = array();
				if($posts){
					foreach ($posts as $post){
						$results[]=array(
								'id'=>$post->ID,
								'text'=>$post->post_title.($post->post_excerpt?('('.$post->post_excerpt.')'):'')
						);
					}
				}
				
				echo json_encode(array(
						'items'=>$results
				));
				exit;
			default:
				if(empty($type)){
					$posts = $wpdb->get_results($wpdb->prepare(
							"select u.ID,
									u.post_title
							from {$wpdb->posts} u
							where ($post_ID=0 or u.ID=$post_ID)
								and (%s='' or u.post_title like %s)
								and u.post_status='publish'
							limit 10;",$keywords,"%$keywords%"));
				}else{
					$posts = $wpdb->get_results($wpdb->prepare(
							"select u.ID,
									u.post_title
							from {$wpdb->posts} u
							where ($post_ID=0 or u.ID=$post_ID)
								and (%s='' or u.post_title like %s)
								and u.post_type=%s
								and u.post_status='publish'
							limit 10;",$keywords,"%$keywords%", $type));
				}
				
				$results = array();
				if($posts){
					foreach ($posts as $post){
						$results[]=array(
								'id'=>$post->ID,
								'text'=>$post->post_title
						);
					}
				}
				
				echo json_encode(array(
						'items'=>$results
				));
				exit;
		}
	}
	
	//插件定时服务
	public static function cron(){
	    global $xunhuweb_cron;
	    if($xunhuweb_cron){
	        exit;
	    }
	
	    $xunhuweb_cron=true;
	    header("Access-Control-Allow-Origin:*");
	    $last_execute_time = intval(get_option('xunhuweb_cron',0));
	    $now = time();
	     
	    //间隔30秒
	    $step =$last_execute_time-($now-30);
	    if($step>0){
	        exit;
	    }
	     
	    update_option('xunhuweb_cron',$now,false);
	
	    try {
	        do_action('xunhuweb_cron');
	    } catch (Exception $e) {
	        WRest_Log::error($e);
	        //ignore
	    }
	
	    exit;
	}
	/**
	 * 验证码
	 * @since 1.0.0
	 */
	public static function captcha(){
	    $func = apply_filters('wrest_captcha', function(){
	        require_once WREST_DIR.'/includes/captcha/CaptchaBuilderInterface.php';
	        require_once WREST_DIR.'/includes/captcha/PhraseBuilderInterface.php';
	        require_once WREST_DIR.'/includes/captcha/CaptchaBuilder.php';
	        require_once WREST_DIR.'/includes/captcha/PhraseBuilder.php';
	         
	        $action ='wrest_captcha';
	        $params=shortcode_atts(array(
	            'notice_str'=>null,
	            'action'=>$action,
	            $action=>null
	        ), stripslashes_deep($_REQUEST));
	
	        if(isset($_REQUEST['captcha_key'])){
	            $params['captcha_key'] =sanitize_key($_REQUEST['captcha_key']);
	        }else{
	            $params['captcha_key'] ='wrest_captcha';
	        }
	
	        if(!WRest::instance()->WP->ajax_validate($params,isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
	            WRest::instance()->WP->wp_die(WRest_Error::err_code(701)->errmsg);
	            exit;
	        }
	
	        $builder = Gregwar\Captcha\CaptchaBuilder::create() ->build();
	        WRest::instance()->session->set($params['captcha_key'], $builder->getPhrase());
	
	        return WRest_Error::success($builder ->inline());
	    });
	         
        $error = call_user_func($func);
        echo $error->to_json();
        exit;
	}
	/**
	 * 远程服务
	 */
	public static function service(){
	   if ( ! current_user_can( 'manage_options') ){
    		return;
    	}
	    $action ='wrest_service';
	    $params=shortcode_atts(array(
	        'notice_str'=>null,
	        'action'=>$action,
	        $action=>null,
	        'tab'=>null
	    ), stripslashes_deep($_REQUEST));
	    
	    if(!WRest::instance()->WP->ajax_validate($params, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
	        echo (WRest_Error::err_code(701)->to_json());
	        exit;
	    }
	    
	    switch ($params['tab']){
	        //第三方扩展
	        case 'extensions':
	            $page_index = isset($_REQUEST['pageIndex'])?intval($_REQUEST['pageIndex']):1;
	            if($page_index<1){
	                $page_index=1;
	            }
	             
	            $keywords = isset($_REQUEST['keywords'])?sanitize_title_for_query($_REQUEST['keywords']):'';
	             
	            if(empty($keywords)){
	                $info = get_option('wrest-ajax:service:extensions:'.$page_index);
	                if(!$info||!is_array($info)){
	                    $info = array();
	                }
	                
	                if(isset($info['last_cache_time'])&&$info['last_cache_time']>time()){
	                    echo WRest_Error::success($info)->to_json();
	                    exit;
	                }
	            }
	            
	            $api ='https://www.wpweixin.net/wp-content/plugins/xh-hash/api-v3.php';
	            $params = array();
	            
	            $params['pageIndex']=$page_index;
	            $params['keywords']=$keywords;
	            $params['action']='extensions';
	            $params['license_id'] =WRest::$license_id[0];
	            
	            $request =wp_remote_post($api,array(
	                'timeout'=>10,
	                'body'=>$params
	            ));
	             
	            if(is_wp_error( $request )){
	                echo (WRest_Error::err_code(1000)->to_json());
	                exit;
	            }
	      
	            $info = json_decode( wp_remote_retrieve_body( $request ) ,true);
	            if(!$info||!is_array($info)){
	                echo (WRest_Error::err_code(1000)->to_json());
	                exit;
	            } 
	            if(empty($keywords)){
    	            $info['last_cache_time'] =time()+24*60*60;
    	            wp_cache_delete('wrest-ajax:service:extensions:'.$page_index,'options');
    	            update_option('wrest-ajax:service:extensions:'.$page_index,$info,false);
	            }
	            echo (WRest_Error::success($info)->to_json());

	            exit;
	        case 'plugins':
	            $page_index = isset($_REQUEST['pageIndex'])?intval($_REQUEST['pageIndex']):1;
	            if($page_index<1){
	                $page_index=1;
	            }
	            $category_id=isset($_REQUEST['category_id'])?intval($_REQUEST['category_id']):0;
	            $keywords = isset($_REQUEST['keywords'])?sanitize_title_for_query($_REQUEST['keywords']):'';
	            if(empty($keywords)){
	                $info = get_option("wrest-ajax:service:plugins:{$category_id}:{$page_index}");
	                if(!$info||!is_array($info)){
	                    $info = array();
	                }
	                 
	                if(isset($info['last_cache_time'])&&$info['last_cache_time']>time()){
	                    echo WRest_Error::success($info)->to_json();
	                    exit;
	                }
	            }
	            $api ='https://www.wpweixin.net/wp-content/plugins/xh-hash/api-v3.php';
	            $params = array();
	             
	            $params['pageIndex']=$page_index;
	            $params['keywords']=$keywords;
	            $params['action']='plugins';
	            $params['category_id'] =$category_id;
	            
	            $request =wp_remote_post($api,array(
	                'timeout'=>10,
	                'body'=>$params
	            ));
	            
	            if(is_wp_error( $request )){
	                echo (WRest_Error::err_code(1000)->to_json());
	                exit;
	            }
	            
	            $info = json_decode( wp_remote_retrieve_body( $request ) ,true);
	            if(!$info||!is_array($info)){
	                echo (WRest_Error::err_code(1000)->to_json());
	                exit;
	            }
	            if(empty($keywords)){
    	            $info['last_cache_time'] =time()+24*60*60;
    	            wp_cache_delete("wrest-ajax:service:plugins:{$category_id}:{$page_index}",'options');
    	            update_option("wrest-ajax:service:plugins:{$category_id}:{$page_index}",$info,false);
	            }
	            echo (WRest_Error::success($info)->to_json());
	            
	            exit;
	    }
	}

	/**
	 * 管理员对插件的操作
	 */
	public static function plugin(){
	    if ( ! current_user_can( 'manage_options') ){
    		 echo (WRest_Error::err_code(501)->to_json());
	        exit;
    	}
	    
	    $action='wrest_plugin';
	  
	    $params=shortcode_atts(array(
	        'notice_str'=>null,
	        'action'=>$action,
	        $action=>null,
	        'plugin_id'=>null,
	        'tab'=>null,
	        'hash'=>null
	    ), stripslashes_deep($_REQUEST));
	    if(!WRest::instance()->WP->ajax_validate($params,$params['hash'],true)){
	        echo (WRest_Error::err_code(701)->to_json());
	        exit;
	    }
	    
	    $plugins =WRest::instance()->WP->get_plugin_list_from_system();
	    if(!$plugins){
	        echo (WRest_Error::err_code(404)->to_json());
	        exit;
	    }
	    
	    $add_on =null;
	    $add_on_file='';
	    foreach ($plugins as $file=>$plugin){
	        if($plugin->id==$params['plugin_id']){
	            $add_on_file = $file;
	            $add_on=$plugin;
	            break;
	        }
	    }
	    $base_dir =  str_replace("\\", "/", WP_CONTENT_DIR);
	    $add_on_file_format = str_replace($base_dir, '[base_dir]', $add_on_file);
        if(!$add_on){
            echo (WRest_Error::err_code(404)->to_json());
            exit;
        }
       
	    $cache_time = 2*60*60; 
	    switch ($params['tab']){
	        //插件安装
	        case 'install':
	            $installed = get_option('wrest_plugins_installed',array());
	            if(!$installed||!is_array($installed)){
	                $installed =array();
	            }
	            $has = false;
	            foreach ($installed as $item){
	                if($item==$add_on_file_format){
	                    $has=true;break;
	                }
	            }
	           
	            if(!$has){
	                $installed[]=$add_on_file_format;
	                
	                try {
	                    if($add_on->depends){
	                        foreach ($add_on->depends as $id=> $depend){
	                           $contains = false;
	                           foreach (WRest::instance()->plugins as $plugin){
	                               if(!$plugin->is_active){
	                                   continue;
	                               }
	                               
	                               if($plugin->id==$id){
	                                   $contains=true;
	                                   break;
	                               }
	                           }
	                           
	                           if(!$contains){//依赖第三方插件
	                               echo (WRest_Error::error_custom(sprintf(__('Current add-on is relies on %s!',WREST),"“{$depend['title']}”"))->to_json());
	                               exit;
	                           }
	                        }
	                    }
	                    
	                    if(!empty($add_on->min_core_version)){
    	                    if(version_compare(WRest::instance()->version,$add_on->min_core_version, '<')){
    	                        echo (WRest_Error::error_custom(sprintf(__('Core version must greater than or equal to %s!',WREST),$add_on->min_core_version))->to_json());
    	                        exit;
    	                    }
	                    }
	                    
	                    WRest::instance()->__load_plugin($add_on);	                
	                    $add_on->on_install(); 
	                    
	                    ini_set('memory_limit','128M');
	                    do_action('wrest_flush_rewrite_rules');
                        flush_rewrite_rules();
	                } catch (Exception $e) {
	                    echo (WRest_Error::error_custom($e->getMessage())->to_json());
	                    exit;
	                }
	               
	            }
	           
	            $plugins_find = WRest::instance()->WP->get_plugin_list_from_system();
	            if(!$plugins_find||!is_array($plugins_find)){
	                $plugins_find=array();
	            }
	             
	           $options = array();
	            foreach ($installed as $item){
	                $has = false;
	                foreach ($plugins_find as $file=>$plugin){
	                    if($item==$file|| $item==str_replace($base_dir, '[base_dir]', $file)){
	                        $has =true;
	                        break;
	                    }
	                }
	                
	                if($has){
	                    $options[]=str_replace($base_dir, '[base_dir]', $item);
	                }
	            }
	            
	           wp_cache_delete("wrest_plugins_installed",'options');
	           update_option('wrest_plugins_installed', $options,true);
	           
	           echo (WRest_Error::success()->to_json());
	           exit;
	        //插件卸载   
	        case 'uninstall':
	            $installed = get_option('wrest_plugins_installed',array());
	         
	            if(!$installed||!is_array($installed)){
	                $installed =array();
	            }
	            
	            $new_values = array();
	            foreach ($installed as $item){
	                if($item!=$add_on_file_format){
	                    $new_values[]=$item;
	                }
	            }
	           
	            try {
	                foreach (WRest::instance()->plugins as $plugin){
	                    if(!$plugin->is_active){
	                        continue;
	                    }
	                    
	                    if(!$plugin->depends){
	                        continue;
	                    }
	                    
	                    foreach ($plugin->depends as $id=>$depend){
	                        if($id==$add_on->id){
	                            echo (WRest_Error::error_custom(sprintf(__('"%s" is relies on current add-on!',WREST),"“{$plugin->title}”"))->to_json());
	                            exit;
	                        }
	                    }
	                }
	                
	                $add_on->on_uninstall();
	            } catch (Exception $e) {
	                echo (WRest_Error::error_custom($e)->to_json());
	                exit;
	            }
	            
	            $plugins_find = WRest::instance()->WP->get_plugin_list_from_system();
	            if(!$plugins_find||!is_array($plugins_find)){
	                $plugins_find=array();
	            }
	            
	           $options = array();
	            foreach ($new_values as $item){
	                $has = false;
	                foreach ($plugins_find as $file=>$plugin){
	                    if($item==$file|| $item==str_replace($base_dir, '[base_dir]', $file)){
	                        $has =true;
	                        break;
	                    }
	                }
	                if($has){
	                    $options[]=str_replace($base_dir, '[base_dir]', $item);
	                }
	            }
	            
	            wp_cache_delete('wrest_plugins_installed', 'options');
	            $update =update_option('wrest_plugins_installed', $options,true);
	            echo (WRest_Error::success()->to_json());
	            exit;
	        //插件更新
	        case 'update':
	        case 'update_admin_options':
	        case 'update_plugin_list':
	           $info =get_option("wrest-ajax:plugin:update:{$add_on->id}");
	           if(!$info||!is_array($info)){
	               $info=array();
	           }
	           
	           if(!isset($info['_last_cache_time'])||$info['_last_cache_time']<time()){
	               $api ='https://www.wpweixin.net/wp-content/plugins/xh-hash/api-add-ons.php';
	               $request_data = array(
	                   'l'=>$add_on->id,
	                   's'=>get_option('siteurl'),
	                   'v'=>$add_on->version,
	                   'a'=>'update'
	               );
	               //插件为非授权插件
	               $license =null;
	                $info =WRest_Install::instance()->get_plugin_options();
	                if($info){
	                    if(isset($info[$add_on->id])){
	                        $license=$info[$add_on->id];
	                    }
	                    
	                    if(empty($license)){
	                        $license = isset($info['license'])?$info['license']:null;
	                    }
	                }
	                if(empty($license)){
	                    echo WRest_Error::error_unknow()->to_json();
	                    exit;
	                }
	                
	               $request_data['c']=$license;
	                
	               $request =wp_remote_post($api,array(
	                   'timeout'=>10,
	                   'body'=>$request_data
	               ));
	              
	               if(is_wp_error( $request )){
	                   echo (WRest_Error::error_custom($request)->to_json());
	                   exit;
	               }
	               
	               $info = json_decode( wp_remote_retrieve_body( $request ) ,true);
	               if(!$info||!is_array($info)){
	                   echo (WRest_Error::error_unknow()->to_json());
	                   exit;
	               }
	               
	               //缓存30分钟
	               $info['_last_cache_time'] = time()+$cache_time;
	               update_option("wrest-ajax:plugin:update:{$add_on->id}", $info,false);
	           }
	            
	           $msg =WRest_Error::success();
	           switch($params['tab']){
	               case 'update_admin_options':
	                   $txt =sprintf(__('There is a new version of %s - %s. <a href="%s" target="_blank">View version %s details</a> or <a href="%s" target="_blank">download now</a>.',WREST),
	                       $info['name'],
	                       $info['upgrade_notice'],
	                       $info['homepage'],
	                       $info['version'],
	                       $info['download_link']
	                       );
	                   $msg = new WRest_Error(0, version_compare($add_on->version,  $info['version'],'<')?$txt:'');
	                   break;
	               case 'update_plugin_list':
	                   $txt =sprintf(__('<tr class="plugin-update-tr active">
	                       <td colspan="3" class="plugin-update colspanchange">
	                       <div class="notice inline notice-warning notice-alt">
	                       <p>There is a new version of %s available.<a href="%s"> View version %s details</a> or <a href="%s" class="update-link">download now</a>.</p>
	                       <div class="">%s</div>
	                       </div></td></tr>',WREST),
	                       $info['name'],
	                       $info['homepage'],
	                       $info['version'],
	                       $info['download_link'],
	                       $info['upgrade_notice']
	                   );
	                   $msg = new WRest_Error(0, version_compare($add_on->version,  $info['version'],'<')?$txt:'');
	                   break; 
	           }
	           
	           echo $msg->to_json();
	           exit;
	    }
	}
}
