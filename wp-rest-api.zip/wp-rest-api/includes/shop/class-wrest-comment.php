<?php
class WRest_Comment{
    private $post_ID,$parent_comment_ID = 0;
    public function __construct($post_ID,$parent_comment_ID=0){
        $this->post_ID = $post_ID;
        $this->parent_comment_ID = $parent_comment_ID;
    }
    
    public function get_comments($pageIndex=1,$pageSize = null){
        $_pageNum = absint($pageIndex);
        $pageNum = $_pageNum >= 1 ? $_pageNum : 1;
        $_pageSize = is_null($pageSize)||$pageSize<=0? absint(get_option('comments_per_page')):absint($pageSize);
        $pageSize = $_pageSize > 0 ? $_pageSize : 10;
        
        $args = [
            'offset' => ($pageNum - 1) * $pageSize,
            'number' => $pageSize,
            'post_id' => $this->post_ID,
            'parent' => $this->parent_comment_ID,
            'no_found_rows' => false,
            'status' => 'approve',
            'include_unapproved' => array(
                get_current_user_id()
            )
        ];
        
        $query = new WP_Comment_Query($args);
        $res = [];
        if ($query->comments) {
            foreach ($query->comments as $comment) {
                $res[] = [
                    'id' => $comment->comment_ID,
                    'author' => $comment->comment_author,
                    'authorImg' => $comment->user_id ? get_avatar_url($comment->user_id) : WREST_URL . '/assets/images/avatar/default.jpg',
                    'content' => $comment->comment_content,
                    'imgs' => self::get_comment_imgs($comment->comment_ID),
                    'date' => self::getDataBycomment(strtotime($comment->comment_date)),
                    'reply' => @absint(get_comment_meta($comment->comment_ID,'_wrest_reply_count_',true)),
                    'rating'=>self::get_comment_rating($comment->comment_ID),
                	'canDel' => ($comment->user_id == get_current_user_id() || current_user_can('manage_options'))&&( current_time( 'timestamp')-strtotime($comment->comment_date)<3*24*60*60)
                ];
            }
            
        }
        
        return array(
            'items' => $res,
            'pageIndex' => $pageNum,
            'pageSize' => $pageSize,
            'totalCount' => $query->found_comments,
            'totalPage' => ceil($query->found_comments * 1.0 / $pageSize)
        );
    }
    
    public static function get_comment_rating($comment_ID){
        return absint(get_comment_meta($comment_ID,'rating',true));
    }
    
    public static function get_comment_imgs($comment_ID){
        $imgs = get_comment_meta($comment_ID, 'wrest_imgs', true);
        if(!$imgs||!is_array($imgs)||count($imgs)==0){
            return null;
        }
        
        return self::getImgsByImgIds($imgs);
    }
    public static function get_comment_img_list($comment_ID){
        $imgs = get_comment_meta($comment_ID, 'wrest_imgs', true);
        if(!$imgs||!is_array($imgs)||count($imgs)==0){
            return null;
        }
    
        $items = [];
        foreach ($imgs as $v) {
            $url =  wp_get_attachment_image_url($v, 'full');//thumbnail, medium, large or full
            if(!$url){
                continue;
            }
            $items[$v] = $url;
        }
        return $items;
    }
    /**
     * 根据图片id获取图片地址
     */
    public static function getImgsByImgIds($ids) {
        if(!$ids){
            return array();
        }
    
        $imgs = [];
        if ($ids && is_array($ids)) {
            foreach ($ids as $v) {
                $url =  wp_get_attachment_image_url($v, 'full');//thumbnail, medium, large or full
                if(!$url){
                    continue;
                }
                $imgs[] =$url;
            }
        }
        return $imgs;
    }
    
    /**
     * 获取对应的评论时间
     */
    public static function getDataBycomment($commentTime) {
        $currentTime = time();
        $time = $currentTime - $commentTime;
        if ($time < 60) $res = "刚刚";
        elseif ($time / 60 >= 1 && $time / 60 < 60) $res = floor($time / 60) . "分钟前";
        elseif ($time / 3600 >= 1 && $time / 3600 < 24) $res = floor($time / 3600) . "小时前";
        elseif ($time / 86400 >= 1 && $time / 86400 < 30) $res = floor($time / 86400) . "天前";
        else $res = date("Y年m月d日", $commentTime);
        return $res;
    }
}