<?php
class WRest_Coupon extends WRest_Object{
	public $id;
	public $coupon_id;
	public $user_ID;
	public $created_time;
	public $status;

	private $_coupon;
    public function set_coupon($coupon){
        $this->_coupon = $coupon;
    }
    
    /**
     * @return WC_Coupon
     */
    public function get_coupon(){
        if(!$this->_coupon){
            $this->_coupon = new WC_Coupon($this->coupon_id);
        }
        return $this->_coupon&&$this->_coupon->get_id()?$this->_coupon:null;
    }
    
	public function is_auto_increment(){
		return true;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'id';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_coupon';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
			'id'=>0,
			'coupon_id'=>0,
			'user_ID'=>0,
			'status'=>null,
			'created_time'=>0
		);
	}
	
	public static function load($coupon){
	    if(is_numeric($coupon)||is_string($coupon)){
	        $coupon = new WC_Coupon($coupon);
	    }
	    
	    if(!$coupon instanceof WC_Coupon||!$coupon->get_id()){
	        return null;
	    }
	    
	    $coupon_id =$coupon->get_id();
	    $user_ID = get_current_user_id();
	    global $wpdb;
	    
	    $c =  new WRest_Coupon($wpdb->get_row(
	       "select *
	        from {$wpdb->prefix}wrest_coupon
	        where coupon_id={$coupon_id}
	              and user_ID={$user_ID}
	        limit 1;"));
	    if(!$c->is_load()){
	        return null;
	    }
	    
	    $c->coupon = $coupon;
	    return $c;
	}
	
	public function is_prepare(){
	    if(!$this->is_load()){
	        return false;
	    }
	    return $this->status=='prepare';
	}
	public function is_using(){
	    if(!$this->is_load()){
	        return false;
	    }
	    return $this->status=='using';
	}
	public function change_status($status){
	    if(!$this->is_load()){
	        return WRest_Error::err_code(404);
	    }
	    return $this->update(array(
	         'status'=>$status
	    ));  
	}
	/**
	 *
	 * @param WC_Coupon $the_coupon
	 */
	public static function is_valid_for_cart($the_coupon){
	    $cart = WC()->cart;
	    // Check it can be used with cart.
	    if ( ! $the_coupon->is_valid() ) {
	        return false;
	    }
	     
	    // Check if applied.
	    if ( $cart->has_discount( $the_coupon->get_code() ) ) {
	        $the_coupon->add_coupon_message( WC_Coupon::E_WC_COUPON_ALREADY_APPLIED );
	        return false;
	    }
	     
	    // If its individual use then remove other coupons.
	    if ( $the_coupon->get_individual_use() ) {
	        $coupons_to_keep = apply_filters( 'woocommerce_apply_individual_use_coupon', array(), $the_coupon, $cart->applied_coupons );
	         
	        foreach ( $cart->applied_coupons as $applied_coupon ) {
	            $keep_key = array_search( $applied_coupon, $coupons_to_keep, true );
	            if ( false === $keep_key ) {
	                return false;
	            } else {
	                unset( $coupons_to_keep[ $keep_key ] );
	            }
	        }
	    }
	     
	    return true;
	}
	
	/**
	 * 
	 * @param WC_Coupon $coupon
	 */
	public static function to_detail($coupon){
	    if(!$coupon){return null;}
	    $symbo = get_woocommerce_currency_symbol();
	    $title = '';
	    switch ($coupon->get_discount_type()){
	        case 'percent':
	            $amount = $coupon->get_amount();
	            $amount = round((100-$amount)/10,1);
	            $mainAmount = round($amount);
	            if($amount==$mainAmount){
	                $title = $mainAmount.'折';
	            }else{
	                $title= $amount.'折';
	            }
	            break;
	        default:
	            $amount = $coupon->get_amount();
	            $title= $symbo.$amount;
	            break;
	    }
	     
	    $subtitle = $coupon->get_description();
	    if(empty($subtitle)){
    	    if($coupon->get_excluded_product_categories()
    	        ||$coupon->get_excluded_product_ids()
    	        ||$coupon->get_product_categories()
    	        ||$coupon->get_product_ids()){
    	        $subtitle="指定商品使用";
    	    }
    	    else if($coupon->get_email_restrictions()){
    	        $subtitle="指定用户使用";
    	    }
    	    
    	    else if($coupon->get_minimum_amount()){
    	        $subtitle="最低消费{$symbo}".$coupon->get_minimum_amount().'使用';
    	    }
    	     
    	    else if('yes'==wc_string_to_bool($coupon->get_free_shipping())){
    	        $subtitle="免配送费";
    	    }
    	    
    	    else if($coupon->get_date_expires()){
    	        $subtitle="限时促销券";
    	    }
	    }
	    if(empty($subtitle)){
	        $subtitle='全场通用券';
	    }
	    return array(
	        'id'=>$coupon->get_id(),
	        'code'=>$coupon->get_code(),
	        'title'=>$title,
	        'subtitle'=>$coupon->get_description()?$coupon->get_description():$coupon-> $subtitle,
	        'is_free_shipping'=>$coupon->get_free_shipping(),
	        'description'=>$coupon->get_description()
	    );
	}
}

class WRest_Coupon_Model extends Abstract_WRest_Schema{
	/**
	 * {@inheritDoc}
	 * @see Abstract_XH_Model_Api::init()
	 */
	public function init()
	{
		$collate=$this->get_collate();
		global $wpdb;
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_coupon` (
					`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
					`coupon_id`  int(11) NOT NULL DEFAULT 0,
					`user_ID`  int(11) NOT NULL DEFAULT 0,
					`status` varchar(16) NOT NULL DEFAULT 'publish',
					`created_time`  int(11) NOT NULL DEFAULT 0,
					PRIMARY KEY (`id`)
				)
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
		
	}
}