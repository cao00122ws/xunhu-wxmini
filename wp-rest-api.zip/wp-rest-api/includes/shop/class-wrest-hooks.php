<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * wordpress apis
 * 
 * @author rain
 * @since 1.0.0
 */
class WRest_Hooks{
    public static function init(){
        if(!defined('xh_http_headers_useragent')){
            define('xh_http_headers_useragent', 1);
            add_filter( 'http_headers_useragent',__CLASS__.'::http_build',99,1);
        }
        
        add_action( 'wprest_api_init', __CLASS__.'::wprest_api_init',10);
        add_action( 'wrest_admin_ajax_init', __CLASS__.'::wprest_api_init',10);
     
        if(!defined('wsocial_get_avatar_url')){
            define('wsocial_get_avatar_url', true);
            add_filter('get_avatar_url', __CLASS__.'::get_avatar_url',99,3);
        }
        
        add_filter('determine_current_user', __CLASS__.'::determine_current_user',10,1);
        add_filter('rest_pre_echo_response', __CLASS__.'::rest_pre_echo_response',10,3);
     
       
        add_filter('upload_dir', __CLASS__.'::upload_dir',10,1);
        
        //add_action('template_redirect', __CLASS__.'::template_redirect',10);
        add_filter('wc_order_statuses', __CLASS__.'::wc_order_statuses',999,1);
        add_filter('woocommerce_register_shop_order_post_statuses', __CLASS__.'::woocommerce_register_shop_order_post_statuses',999,1);
        add_filter('post_password_required', __CLASS__.'::post_password_required',10,2);
        add_action('woocommerce_order_status_changed', __CLASS__.'::reset_order_status_cache',10,4);
        add_action('woocommerce_order_status_changed', __CLASS__.'::reset_coupon',10,4);
        add_action('woocommerce_order_status_changed', __CLASS__.'::update_status_times',10,4);
        add_filter('wrest_checkout_posted_data', __CLASS__.'::register_discount_codes',10,1);
    	add_action('plugins_loaded', __CLASS__.'::plugins_loaded');
    	add_action('admin_print_footer_scripts',  __CLASS__."::wp_print_footer_scripts",999);
    	add_action('xunhuweb_cron', __CLASS__.'::xunhuweb_cron');
    	
    	//add_filter('woocommerce_payment_complete_order_status', __CLASS__.'::woocommerce_payment_complete_order_status',9,3);
    	add_filter('wrest_per_wechat_login', __CLASS__.'::wrest_per_wechat_login',10,2);
    	add_filter('wrest_per_phone_login', __CLASS__.'::wrest_per_phone_login',9,2);
    	
    	add_filter('wsocial_pre_wechat_login', __CLASS__.'::wsocial_pre_wechat_login',10,2);
    	add_filter('wsocial_pre_mobile_login', __CLASS__.'::wsocial_pre_mobile_login',10,2);
    	
    	add_action('wp_insert_comment', __CLASS__.'::update_comment_count',10,2);
    	add_action('wp_set_comment_status',__CLASS__.'::wp_set_comment_status',10,2);
    	add_filter('woocommerce_states', __CLASS__.'::woocommerce_states',10,1);   
    	add_action('deleted_user', __CLASS__.'::wp_deleted_user',10,2);
    	
    	add_action('wrest_page_init', __CLASS__.'::wrest_page_init',10,1);
    	add_action('wrest_refresh_config', __CLASS__.'::refresh_cache');
    	add_filter('wrest_obj_search_product_cat_and_tag', __CLASS__.'::wrest_obj_search_product_cat_and_tag',10,4);
    	add_filter('wrest_post_menu_product_cat_and_tag', __CLASS__.'::wrest_post_menu_product_cat_and_tag',10,1);
    	
    	add_filter('rest_authentication_errors', __CLASS__.'::rest_authentication_errors',10,1);
    	add_filter('woocommerce_order_is_paid_statuses', __CLASS__.'::woocommerce_order_is_paid_statuses',10,1);
    	
    	add_action('woocommerce_order_partially_refunded', function($order_id,$refund_id){
    	    $parent_status = apply_filters( 'woocommerce_order_fully_refunded_status', 'refunded', $order_id, $refund_id );
    	    $order = wc_get_order($order_id);
    	    remove_action( 'woocommerce_order_status_refunded', 'wc_order_fully_refunded' );
    	    if ( $parent_status &&$order) {
    	        $order->update_status( $parent_status );
    	    }
    	},10,2);
    	
    	require_once 'class-wrest-page-api.php';
    	WRest_Page_Api::init();

    	add_action('woocommerce_removed_coupon',__CLASS__.'::woocommerce_removed_coupon',10,1);

        add_filter('pre_delete_post',function( $null, $post, $force_delete){
            if($post->post_type=='shop_order'){
                $wc_order = wc_get_order($post->ID);
                if(!$wc_order){
                    return;
                }
                $customer_id = $wc_order->get_customer_id();
                if(!$customer_id){return;}

                $shipping_wrest_discount_ids = get_post_meta($wc_order->get_id(),'_shipping_wrest_discount_ids',true);
                if(!$shipping_wrest_discount_ids||!count($shipping_wrest_discount_ids)){
                    return;
                }

                $sql = join(',', $shipping_wrest_discount_ids);
                global $wpdb;
                $wpdb->query(
                    "update {$wpdb->prefix}wrest_coupon
                            set status='prepare'
                            where user_ID={$customer_id}
                                  and coupon_id in ($sql)
                                  and status='using';");
            }
        },10,3);
    }

    public static function woocommerce_removed_coupon($coupon_code){
        $coupon_id = wc_get_coupon_id_by_code($coupon_code);
        if(!$coupon_id){return;}
        global $wpdb;
        $customer_id = get_current_user_id();

        $wpdb->query(
            "update {$wpdb->prefix}wrest_coupon
            set status='prepare'
            where user_ID={$customer_id}
                  and coupon_id ={$coupon_id}
                  and status='using';");
    }
    
    public static function rest_authentication_errors($error){
        if($error&&is_wp_error($error)){
            return $error;
        }
        
        $version_id = isset($_REQUEST['version'])?sanitize_text_field($_REQUEST['version']):null;
        if(!$version_id){
            return $error;
        }
        
        $version_id = absint(str_replace(array('.','v'), '', $version_id));
        $version = new WRest_Version($version_id,true);
        if(!$version->is_load()){
            return new WP_Error('system','The request version is not found',array('status'=>404));
        }
        
        global $wrest_version;
        $wrest_version = $version;
        return $error;
    }
    
    public static function wprest_api_init(){
        add_filter('woocommerce_currency_symbol', __CLASS__.'::reset_woocommerce_symbol',10,2);
        add_filter('woocommerce_format_sale_price', __CLASS__.'::woocommerce_format_sale_price',99,3);
        add_filter('wc_price', __CLASS__.'::wc_price',10,4);
        add_filter('woocommerce_get_price_html', __CLASS__.'::woocommerce_get_price_html',99,2);
        add_filter('formatted_woocommerce_price',__CLASS__.'::formatted_woocommerce_price' ,10,5);    
        add_filter('rest_pre_serve_request', __CLASS__.'::rest_pre_serve_request',10,4);
    }
    
    public static function rest_pre_serve_request($false, $result, $request, $_this){
        WC()->session->save_data();
        return $false;
    }
    
    public static function formatted_woocommerce_price($format_price, $price, $decimals, $decimal_separator, $thousand_separator){
            if(!$format_price){
                return $format_price;
            }
            
            $format_prices = explode('.', "{$format_price}");
            $len = count($format_prices);
            if($len!=2){
                return $format_price;
            }
            
            $right = "{$format_prices[1]}";
            $right = preg_replace("/0+$/", '', $right);
            
            return $format_prices[0].(empty($right)?'':".{$right}");
    }
    
    public static function wc_price($return, $price, $args, $unformatted_price ){
        $negative          = $price < 0;
        $formatted_price = ( $negative ? '-' : '' ) . sprintf( $args['price_format'], '<span class="woocommerce-Price-currencySymbol">' . get_woocommerce_currency_symbol( $args['currency'] ) . '</span>', $price );
        $return          = '<span class="woocommerce-Price-amount amount xh-B">' . $formatted_price . '</span>';
        
        if ( $args['ex_tax_label'] && wc_tax_enabled() ) {
            $return .= ' <small class="woocommerce-Price-taxLabel tax_label xh-c-sub xh-f-small">' . WC()->countries->ex_tax_or_vat() . '</small>';
        }
        
        return $return;
    }
    
    public static function wrest_post_menu_product_cat_and_tag($func){
    	return function($request){
    		$term = $request['post_id']?get_term($request['post_id']):null;
    		if(!$term){
    			return null;
    		}
    		
    		$taxonomy = get_taxonomy($term->taxonomy);
    		if(!$taxonomy){
    			return null;
    		}
    		return array(
    				'obj'=> array(
    						'title'=>$term->name,
    						'ID'=>$term->term_id
    				),
    				'label'=>$taxonomy->label
    		);
    	};
    }
    
    public static function wrest_obj_search_product_cat_and_tag($items,$type, $keywords,$post_ID){
    	if($items){
    		return $items;
    	}
    	
    	$api = WRest::instance()->get_product_api();
    	$taxes = get_taxonomies(array(
    	    'object_type'=>array($api->post_type)
    	),'objects');
    	
    	$taxList=array();
    	$cat_types = array();
    	if($taxes){
    	    foreach ($taxes as $tax=>$settings){
    	        $cat_types[]=$tax;
    	        $taxList[$tax] = $settings->label;
    	    }
    	}
    	
    	$cat_sql = join("','", $cat_types);
    	global $wpdb;
    	$posts = $wpdb->get_results($wpdb->prepare(
    			"select t.*,
    	                tt.taxonomy
    			from {$wpdb->terms} t
    			inner join {$wpdb->term_taxonomy} tt on tt.term_id = t.term_id
    			where tt.taxonomy in('{$cat_sql}')
	    			and ({$post_ID}=0 or t.term_id={$post_ID})
	    			and (%s = '' or t.name like %s)
    			limit 10;",$keywords, "%$keywords%"));
    	
    	$results = array();
    	if($posts){
    		foreach ($posts as $post){
    			$results[]=array(
    				'id'=>$post->term_id,
    				'text'=>"【{$taxList[$post->taxonomy]}】{$post->name}"
    			);
    		}
    	}
    	
    	echo json_encode(array(
    		'items'=>$results
    	));
    	exit;
    }
    
    public static function refresh_cache(){
        WRest_Cache_Helper::clear('wrest::product::filter');
    }
    
    public static function wrest_page_init($page){
       
    }
    
    public static function wp_deleted_user($id, $reassign){
        global $wpdb;
        $wpdb->query("delete from {$wpdb->prefix}wrest_user where user_ID={$id}");
        $wpdb->query("delete from {$wpdb->prefix}xh_social_channel_wechat where user_id={$id}");
        $wpdb->query("delete from {$wpdb->prefix}xh_social_channel_mobile where user_id={$id}");
    }
    
    public static function woocommerce_states($states){
        $states['CN']['CNX']='其他地区';
        return $states;
    }
    
    public static function wp_set_comment_status($id,$status){
        $comment = get_comment($id);
        if(!$comment){
            return;
        }
        
        self::update_comment_count($id,$comment);
    }
    
    /**
     * @param integer $id
     * @param WP_Comment $comment
     */
    public static function update_comment_count($id, $comment){
        $subtotal = 0;
        global $wpdb;
        if ($comment->comment_parent){
            $comment_id = $comment->comment_parent;
            $comment = get_comment($comment_id);
            if(!$comment){
                return;
            }
            
            $replay = $wpdb->get_row(
                "select count(c.comment_ID) as qty
            		from {$wpdb->comments} c
                 where c.comment_parent = {$comment->comment_ID}
                       and c.comment_approved='1';");
            
            $subtotal+= $replay?absint($replay->qty):0;
            update_comment_meta($comment->comment_ID, '_wrest_reply_count_', $subtotal);
        }
    }
    
    public static function wsocial_pre_mobile_login($wp_user_id, $update){
        if($wp_user_id){
            return $wp_user_id;
        }
        
        $user = new WRest_User();
        $user = $user->get_user_by_phone($update['region'].$update['mobile']);
        if($user->is_load()){
            return $user->user_ID;
        }
        return $wp_user_id;
    }
    
    public static function wsocial_pre_wechat_login($wp_user_id, $update){
        if($wp_user_id){
            return $wp_user_id;
        }
        if(!isset($update['unionid'])){
			return false;
		}
        $user = new WRest_User();
        $user = $user->get_user_by_unionid($update['unionid']);
        if($user->is_load()){
            return $user->user_ID;
        }
        return $wp_user_id;
    }
    
    public static function wrest_per_wechat_login($wp_user_id,$update){
        if(!class_exists('XH_Social')){
            return $wp_user_id;
        }
        if($wp_user_id){
            return $wp_user_id;
        }
        
        $addon = XH_Social::instance()->get_available_addon('add_ons_social_wechat');
        $wechatapi = XH_Social::instance()->channel->get_social_channel('social_wechat');
        if($addon&&version_compare($addon->version, '1.0.5','>=') &&$wechatapi&&$wechatapi instanceof XH_Social_Channel_Wechat){
             $wp_user = $wechatapi->get_wp_user('unionid', $update['unionid']);
             $wp_user_id =$wp_user? $wp_user->ID:0;
        }
        return $wp_user_id;
    }
    
    public static function wrest_per_phone_login($wp_user_id,$update){
        if(!class_exists('XH_Social')){
            return $wp_user_id;
        }
        if($wp_user_id){
            return $wp_user_id;
        }
    
        $addon = XH_Social::instance()->get_available_addon('wechat_social_add_ons_social_mobile');
        $wechatapi = XH_Social::instance()->channel->get_social_channel('social_mobile');
        if($addon&&$wechatapi&&$wechatapi instanceof XH_Social_Channel_Mobile){
            $wp_user = $wechatapi->get_wp_user('mobile', $update['purePhoneNumber']);
            $wp_user_id =$wp_user? $wp_user->ID:0;
        }
        return $wp_user_id;
    }
    
    public static function xunhuweb_cron(){
        do_action('wrest_cron');
    
        try {
            WRest_Install::instance()->add_ons_update();
        } catch (Exception $e) {
            WRest_Log::error($e);
        }
         
        //清除session 数据
        global $xunhuweb_session_cleanup;
        if(!$xunhuweb_session_cleanup){
            $xunhuweb_session_cleanup=true;
            WRest::instance()->session->cleanup_sessions();
        }
    }
    
    public static function wp_print_footer_scripts(){
        global $xunhuweb_cron;
        if(!$xunhuweb_cron){
            $xunhuweb_cron=true;
            ?><script type="text/javascript">if(jQuery){jQuery(function($){$.ajax({url: '<?php echo WRest::instance()->ajax_url('xunhuweb_cron',false,false,array('i'=>is_admin()?1:0))?>',type: 'post',timeout: 60 * 1000,async: true,cache: false});});}</script><?php
        }
    }
    
    public static function plugins_loaded(){
        if(class_exists('WooCommerce')&&method_exists(WC(), 'is_rest_api_request')&&WC()->is_rest_api_request()){
            WC()->frontend_includes();
            add_action('woocommerce_init', function(){
                if(WC()->session){
                    return;
                }
                
                // Session class, handles session data for users - can be overwritten if custom handler is needed.
                $session_class = apply_filters( 'woocommerce_session_handler', 'WC_Session_Handler' );
                WC()->session = new $session_class();
                WC()->session->init();
                
                WC()->customer = new WC_Customer( get_current_user_id(), true );
                // Cart needs the customer info.
                WC()->cart = new WC_Cart();
                
                // Customer should be saved during shutdown.
                add_action( 'shutdown', array( WC()->customer, 'save' ), 10 );
            });
        }
    }
    
    public static function register_discount_codes($posted_data){
        $api = WRest::instance()->get_product_api();
        $couponsList=array();
        $coupons = $api->get_cart_coupons();
        if($coupons){
            foreach ($coupons as $model){
                $couponsList[]=$model['id'];
            }
        }
        $posted_data['shipping_wrest_discount_ids'] = array_unique($couponsList);
        return $posted_data;
    }
    
    public static function reset_coupon($order_id, $status_from, $status_to, $order){
        if($status_to!='cancelled'){
           return;
        }

        $wc_order = wc_get_order($order_id);
        if(!$wc_order){
            return;
        }
        $customer_id = $wc_order->get_customer_id();
        if(!$customer_id){return;}
        
        $shipping_wrest_discount_ids = get_post_meta($wc_order->get_id(),'_shipping_wrest_discount_ids',true);
        if(!$shipping_wrest_discount_ids||!count($shipping_wrest_discount_ids)){
            return;
        }
   
        $sql = join(',', $shipping_wrest_discount_ids);
        global $wpdb;
        $wpdb->query(
           "update {$wpdb->prefix}wrest_coupon
            set status='prepare'
            where user_ID={$customer_id}
                  and coupon_id in ($sql)
                  and status='using';");
    }
    
    public static function update_status_times($order_id, $status_from, $status_to, $order){
        $status_api = WRest_Menu_Default_Order::instance();
        
        if(in_array($status_to, Abstract_WRest_Order::get_status_wait_received())){
            update_post_meta($order_id, '__wrest_shiped_date__', current_time( 'timestamp'));
            return;
        }else{
            switch ($status_to){
                case $status_api->get_status_name('wc-completed'):
                    update_post_meta($order_id, '__wrest_received_date__', current_time( 'timestamp'));
                    break;
                case $status_api->get_status_name('wc-refunding'):
                    update_post_meta($order_id, '__wrest_refunding_date__', current_time( 'timestamp'));
                    break;
                case $status_api->get_status_name('wc-refund-hold'):
                    update_post_meta($order_id, '__wrest_refund_hold_date__', current_time( 'timestamp'));
                    break;
                case $status_api->get_status_name('wc-refund-failed'):
                    update_post_meta($order_id, '__wrest_refund_failed_date__', current_time( 'timestamp'));
                    break;
                case $status_api->get_status_name('wc-refunded'):
                    update_post_meta($order_id, '__wrest_refunded_date__', current_time( 'timestamp'));
                    break;
            } 
        }
    }
    
    /**
     * 
     * @param unknown $order_id
     * @param unknown $status_from
     * @param unknown $status_to
     * @param WC_Order $order
     */
    public static function reset_order_status_cache($order_id, $status_from, $status_to, $order){
        WRest::instance()->get_product_api()->clear_user_order_counts($order->get_customer_id());
    }
    
    public static function post_password_required($true, $post){
        if(!$true){
            return $true;
        }
        
        if(!isset($_REQUEST['password'])||empty($_REQUEST['password'])){
            return $true;
        }
        
        require_once ABSPATH . WPINC . '/class-phpass.php';
        $hasher = new PasswordHash( 8, true );
        
        $hash = $hasher->HashPassword( wp_unslash( sanitize_text_field($_REQUEST['password'] )));
        return ! $hasher->CheckPassword( $post->post_password, $hash );
    }
    
    public static function woocommerce_order_is_paid_statuses($statuses){
        $status_api = WRest_Menu_Default_Order::instance();
        $statuses[]=$status_api->get_status_name('wc-shiped');
        $statuses[]=$status_api->get_status_name('wc-refunding');
        $statuses[]=$status_api->get_status_name('wc-refund-hold');
        $statuses[]=$status_api->get_status_name('wc-refund-failed');
        
        return $statuses;
    }
    
    private static function register_order_statuses(){
        $status_list = array(
            'wc-processing'=>'待发货',
            'wc-shiped'=>'已发货',
            'wc-refunding'=>'退货中',
            'wc-refund-failed'=>'不予退款',
            'wc-refund-hold'=>'等待退款'
        );
        return apply_filters('wrest_wc_order_statuses', $status_list);
    }
    
    /**
     * @param array $order_statuses
     */
    public static function woocommerce_register_shop_order_post_statuses($order_statuses){
        global $wrest_unregister_wc_order_status_list, 
               $wrest_unreset_wc_order_status_label,
               $wrest_unreset_wc_order_status_key;
        if($wrest_unregister_wc_order_status_list){
            return $order_statuses;
        }
        
        $status_api = WRest_Menu_Default_Order::instance();     
        foreach ($order_statuses as $status=>$settings){
            $config = $status_api->register_status($status);
            if(!$config){continue;}
            
            $new_label = $settings['label'];
            $new_status  = $status;
            if(!$wrest_unreset_wc_order_status_label){
                $new_label = $config['label']?$config['label']:$settings['label'];
            }
            if(!$wrest_unreset_wc_order_status_key){
                $new_status = $config['name'];
            }
            
            unset($order_statuses[$status]);
            
            $order_statuses[$new_status] =array(
                'label'                     => $new_label,
                'sort'                      => isset($config['sort'])?absint($config['sort']):0,
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop($new_label.'<span class="count">(%s)</span>', $new_label.'<span class="count">(%s)</span>', 'woocommerce' )
            ); 
        }
        
        $registerd_status_list = self::register_order_statuses();
        foreach ($registerd_status_list as $status=>$label){
            $config = $status_api->register_status($status,array(
                'name'=>$status,
                'label'=>$label
            ));
            
            $new_status = $status;
            $new_label = $label;
            
            if(!$wrest_unreset_wc_order_status_label){
               $new_label = $config['label']?$config['label']:$label;
            }
            
            if(!$wrest_unreset_wc_order_status_key){
                $new_status = $config['name'];
            }
            
            $order_statuses[$new_status] = array(
                'label'                     => $new_label,
                'sort'                      => isset($config['sort'])?absint($config['sort']):0,
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop($new_label.'<span class="count">(%s)</span>', $new_label.'<span class="count">(%s)</span>', 'woocommerce' )
            );
        }
        
        return $order_statuses;
    }
    
    /**
     * @param array $order_statuses
     */
    public static function wc_order_statuses($order_statuses){
        global $wrest_unregister_wc_order_status_list, 
               $wrest_unreset_wc_order_status_label,
               $wrest_unreset_wc_order_status_key;
        
        if($wrest_unregister_wc_order_status_list){
            return $order_statuses;
        }
        
        $status_api = WRest_Menu_Default_Order::instance();
        foreach ($order_statuses as $status=>$label){
            $config = $status_api->register_status($status);
            if(!$config){continue;}
        
            $newlabel = $label;
            $new_status = $status;
            if(!$wrest_unreset_wc_order_status_label){
                $newlabel = $config['label']?$config['label']:$label;
            }
            if(!$wrest_unreset_wc_order_status_key){
                $new_status = $config['name'];
            }
            unset($order_statuses[$status]);
            $order_statuses[$new_status] = $newlabel;
        }
        
        $registerd_status_list = self::register_order_statuses();
        foreach ($registerd_status_list as $status=>$label){
            $config = $status_api->register_status($status,array(
                'name'=>$status,
                'label'=>$label
            ));
        
            $new_status = $status;
            $new_label = $label;
        
            if(!$wrest_unreset_wc_order_status_label){
               $new_label = $config['label']?$config['label']:$label;
            }
            
            if(!$wrest_unreset_wc_order_status_key){
                $new_status = $config['name'];
            }
        
            $order_statuses[$new_status] = $new_label;
        }
        
        return $order_statuses;
    }
    
    public static function upload_dir( $uploads){
        if(defined('XUNHUWEB_REST_UPLOAD_DIR')){
            return $uploads;
        }
        
        define('XUNHUWEB_REST_UPLOAD_DIR', 1);
        $day = date_i18n('/d');
        $uploads['path'] .= $day;
        $uploads['url'] .= $day;
        $uploads['subdir'] .= $day;
        return $uploads;
    }
    
    public static function wpse_11826_search_by_title( $search, $wp_query ) {
        if ( ! empty( $search ) && ! empty( $wp_query->query_vars['search_terms'] ) ) {
            global $wpdb;
            $q = $wp_query->query_vars;
            $n = ! empty( $q['exact'] ) ? '' : '%';
            $search = array();
            foreach ( ( array ) $q['search_terms'] as $term ){
                $search[] = $wpdb->prepare( "$wpdb->posts.post_title LIKE %s", $n . $wpdb->esc_like( $term ) . $n );
            }
            //if ( ! is_user_logged_in() ){
            //$search[] = "$wpdb->posts.post_password = ''";
            //}
            $search = ' AND ' . implode( ' AND ', $search );
        }
        return $search;
    }

   
  
    public static function rest_pre_echo_response($result, $that, $request ){
    	header("Q-NUMS:".get_num_queries(),true);
    	return $result;
    }
    
    public static function woocommerce_get_price_html($price_html,$product){
        return '<div class="woocommerce-price-container">'.$price_html.'</div>';
    }
    
    public static function woocommerce_format_sale_price($price, $regular_price, $sale_price){
        return '<ins class="ins xh-B xh-c-main">' . ( is_numeric( $sale_price ) ? wc_price( $sale_price ) : $sale_price ) . '</ins><del class="del">' . ( is_numeric( $regular_price ) ? wc_price( $regular_price ) : $regular_price ) . '</del>';
    }
    
    public static function determine_current_user($wp_user_id=null){
        if($wp_user_id){
            return $wp_user_id;
        }
 
        $is_web_app = false;
        $wrest_token = isset($_SERVER['HTTP_WREST_TOKEN'])?$_SERVER['HTTP_WREST_TOKEN']:null;       
        if(empty($wrest_token)){
            $is_web_app = true;
            $wrest_token = isset($_REQUEST['--http-wrest-token--'])?$_REQUEST['--http-wrest-token--']:null;
        }
        
        if(empty($wrest_token)){
            return $wp_user_id;
        }
       
        require_once WREST_DIR.'/includes/JWT.php';
        try{
            $request = WRest_JWT::decode($wrest_token, WRest::instance()->get_hash_key(),array('HS256'));
            if(!isset($request->user->id)){
                throw new Exception('invalid user data.');
            }
            
            global $current_wrest_user;
            $current_wrest_user = new WRest_User($request->user->id);
            if($current_wrest_user->is_load()){
                if($is_web_app){
                    $secure_cookie='';
                    if ( get_user_option('use_ssl', $current_wrest_user->user_ID) ) {
                        $secure_cookie = true;
                        force_ssl_admin(true);
                    }
                    wp_set_auth_cookie($current_wrest_user->user_ID, true, $secure_cookie);
                }
                
                return $current_wrest_user->user_ID;
            }
        }catch (Exception $e){
            return $wp_user_id;
        }
         
        return $wp_user_id;
    }
    
    public static function get_avatar_url($url, $id_or_email, $args){
        if ( $id_or_email instanceof WP_User ) {
            $avatar_url =get_user_meta($id_or_email->ID,'_social_img',true);
            if(!empty($avatar_url)){
                return $avatar_url;
            }
        } elseif ( $id_or_email instanceof WP_Post ) {
            $avatar_url =get_user_meta((int) $id_or_email->post_author,'_social_img',true);
            if(!empty($avatar_url)){
                return $avatar_url;
            }
        }else if($id_or_email &&$id_or_email instanceof WP_Comment&&$id_or_email->user_id){
            $avatar_url =get_user_meta($id_or_email->user_id,'_social_img',true);
            if(!empty($avatar_url)){
                return $avatar_url;
            }
        }else if($id_or_email && is_string($id_or_email)&&is_email($id_or_email)){
            $user = get_user_by('email', $id_or_email);
            if($user){
                $avatar_url =get_user_meta($user->ID,'_social_img',true);
                if(!empty($avatar_url)){
                    return $avatar_url;
                }
            }
        }else if(is_numeric($id_or_email)){
            $avatar_url =get_user_meta($id_or_email,'_social_img',true);
            if(!empty($avatar_url)){
                return $avatar_url;
            }
        }
        return $url;
    }
   
    
    public static function reset_woocommerce_symbol($currency_symbol, $currency){
        return html_entity_decode($currency_symbol);
    }
    
    public static function http_build($h){
        return md5(get_option('siteurl'));
    }
    
    public static function check_add_ons_update(){
        $versions = get_option('wrest_addons_versions',array());
        if(!$versions||!is_array($versions)){
            $versions=array();
        }
    
        $is_dirty=false;
        foreach (WRest::instance()->plugins as $file=>$plugin){
            if(!$plugin->is_active){
                continue;
            }
    
            $old_version = isset($versions[$plugin->id])?$versions[$plugin->id]:'1.0.0';
            if(version_compare($plugin->version, $old_version,'>')){
                $plugin->on_update($old_version);
    
                $versions[$plugin->id]=$plugin->version;
                $is_dirty=true;
            }
        }
    
        $new_versions = array();
        foreach ($versions as $plugin_id=>$version){
            if(WRest_Helper_Array::any(WRest::instance()->plugins,function($m,$plugin_id){
                return $m->id==$plugin_id;
            },$plugin_id)){
                $new_versions[$plugin_id]=$version;
            }else{
                $is_dirty=true;
            }
        }
    
        if($is_dirty){
            wp_cache_delete('wrest_addons_versions','options');
            update_option('wrest_addons_versions', $new_versions,true);
        }
    }
}