<?php
class WRest_Keywords extends WRest_Object{
	public $id;
	public $label;
	public $count;
	public $is_feature;
	public $type;
	public $status;
	
	public function is_auto_increment(){
		return true;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'id';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_keywords';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
				'id'=>0,
				'label'=>null,
				'count'=>1,
		        'type'=>'product',
				'is_feature'=>false,
				'status'=>'publish'
		);
	}
	
}

class WRest_Keywords_item extends WRest_Object{
	public $id;
	public $keywords_id;
	public $created_time;
	public $ip;
	public $user_ID;
	
	public function is_auto_increment(){
		return true;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'id';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_keywords_item';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
				'id'=>0,
				'keywords_id'=>0,
				'created_time'=>0,
				'ip'=>null,
				'user_ID'=>null
		);
	}
	
}

class WRest_Keywords_Model extends Abstract_WRest_Schema{
	/**
	 * {@inheritDoc}
	 * @see Abstract_XH_Model_Api::init()
	 */
	public function init()
	{
		$collate=$this->get_collate();
		global $wpdb;
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_keywords` (
					`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
					`label` varchar(64) NOT NULL,
					`count` int(11) NOT NULL DEFAULT 1,
					`is_feature` tinyint(4) NOT NULL DEFAULT 0,
					`type` varchar(16) NOT NULL DEFAULT 'product',
					`status` varchar(16) NOT NULL DEFAULT 'publish',
					PRIMARY KEY (`id`),
					UNIQUE INDEX `label_type` (`label`,`type`)
				)
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
		
		try {
		    $column =$wpdb->get_row(
		        "select column_name
		        from information_schema.columns
		        where table_name='{$wpdb->prefix}wrest_keywords'
		        and table_schema ='".DB_NAME."'
				  and column_name ='type'
			limit 1;");
		    
		    if(!$column||empty($column->column_name)){
		        $wpdb->query("alter table `{$wpdb->prefix}wrest_keywords` add column `type` VARCHAR(16) NOT NULL DEFAULT 'product';");
		        if(!empty($wpdb->last_error)){
		            WRest_Log::error($wpdb->last_error);
		            throw new Exception($wpdb->last_error);
		        }
		    }
		} catch (Exception $e) {
		}
		
		//label_key
		try {
		    if($wpdb->get_var("show index from `{$wpdb->prefix}wrest_keywords` where Column_name='label' and Key_name='label_key'")== "{$wpdb->prefix}wrest_keywords"){
		        $wpdb->query("ALTER TABLE `{$wpdb->prefix}wrest_keywords` DROP INDEX `label_key`;");
		        if(!empty($wpdb->last_error)){
		            WRest_Log::error($wpdb->last_error);
		            throw new Exception($wpdb->last_error);
		        }
		    }
		} catch (Exception $e) {
		}
		
		try {
		    if($wpdb->get_var("show index from `{$wpdb->prefix}wrest_keywords` where Column_name='label' and Key_name='label_type'")!= "{$wpdb->prefix}wrest_keywords"){
		        $wpdb->query("ALTER TABLE `{$wpdb->prefix}wrest_keywords` ADD UNIQUE INDEX `label_type` (`label`,`type`);");
		        if(!empty($wpdb->last_error)){
		            WRest_Log::error($wpdb->last_error);
		            throw new Exception($wpdb->last_error);
		        }
		    }
		} catch (Exception $e) {
		}
		
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_keywords_item` (
					`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
					`keywords_id` BIGINT(20) NOT NULL DEFAULT 0,
					`created_time` BIGINT(20) NOT NULL DEFAULT 0,
					`ip` varchar(16) NOT NULL,
					`user_ID` BIGINT(20) NOT NULL DEFAULT 0,
					PRIMARY KEY (`id`),
					INDEX `ip_key` (`ip`)
				)
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
	}
}