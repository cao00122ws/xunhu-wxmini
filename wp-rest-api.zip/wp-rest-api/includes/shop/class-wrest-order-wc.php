<?php
class WRest_Order_WC extends Abstract_WRest_Order{
	public function __construct($post_ID_or_order){
		if(is_numeric($post_ID_or_order)){
			$this->order = wc_get_order($post_ID_or_order);
		}else if($post_ID_or_order instanceof WP_Post){
			$this->order = wc_get_product($post_ID_or_order->ID);
		}else if($post_ID_or_order instanceof WC_Order){
			$this->order = $post_ID_or_order;
		}
	}
	
	public function permission_check(){
		if(!$this->is_load()){return false;}
		
		if(!current_user_can( 'view_order',$this->get_order()->get_id())){
			return false;
		}
		
		return $this;
	}
	
	
	public function to_simple($version){
	    if(!$this->is_load()){
	        return null;
	    }
	    
	    $is_can_cancel = in_array( $this->order->get_status(), array( 'pending', 'failed'));
	    if(in_array($this->order->get_status(),array('processing'))){
	        $order_paid_date = $this->order->get_date_paid();
	        $now = current_time( 'timestamp');
	        $apiset = new WRest_Menu_Store_Order($version);
	        $enable_refund_when_processing = floatval($apiset->get_option('enable_refund_when_processing'));
	        $is_can_cancel = $order_paid_date&&($now-($order_paid_date->getOffsetTimestamp() +round($enable_refund_when_processing*60*60))<=0);
	    }
	    
	    $is_can_refund = false;
	    $api_status = WRest_Menu_Default_Order::instance();
	    $status_completed = $api_status->get_status_name('wc-completed');
	    
	    if(in_array($this->order->get_status(),array($status_completed))){
	        $order_shiped_time = absint(get_post_meta($this->order->get_id(),'__wrest_shiped_date__',true));
	        if(!$order_shiped_time){
	            $order_shiped_time = $this->get_order()->get_date_paid()?$this->get_order()->get_date_paid()->getOffsetTimestamp():0;
	        }
	        $now = current_time( 'timestamp');
	        $apiset = new WRest_Menu_Store_Order($version);
	        $enable_refund_when_received = floatval($apiset->get_option('enable_refund_when_received'));
	        $is_can_refund = $order_shiped_time&&($now-($order_shiped_time +round($enable_refund_when_received*60*60))<=0);
	    }
	    
	    $status_refund_hold = $api_status->get_status_name('wc-refund-hold');
	    $status_refund_failed = $api_status->get_status_name('wc-refund-failed');
	    $status_refunded = $api_status->get_status_name('wc-refunded');
	    $status_refunding = $api_status->get_status_name('wc-refunding');
	    
	    $order_statuses = wc_get_order_statuses();
		$orderInfo = array(
		    'id'=>$this->order->get_id(),
			'address_model' =>get_post_meta($this->order->get_id(),'_shipping_wrest_address_model',true),
		    'status'=>$this->order->get_status(),
		    'status_text'=>isset($order_statuses["wc-{$this->order->get_status()}"])?$order_statuses["wc-{$this->order->get_status()}"]:'',
		    'total'=>Abstract_WRest_Doamin::format_price( $this->order->get_total() ),
		    'item_count'=>$this->order->get_item_count(),
		    'currency'=>$this->order->get_currency(),
		    'currency_symbol'=>get_woocommerce_currency_symbol($this->order->get_currency()),
		    'order_date'=>$this->order->get_date_created()->date_i18n('m/d H:i'),
		    'date_paid'=>$this->order->get_date_paid()?$this->order->get_date_paid()->date_i18n('m/d H:i'):null,
		    'is_can_pay'=>$this->order->needs_payment(),
		    'is_paid'=>$this->order->is_paid(),
		    'is_can_refunded'=>$is_can_refund,
		    'is_can_cancel'=>$is_can_cancel,
		    'is_can_received'=>in_array($this->order->get_status(),Abstract_WRest_Order::get_status_wait_received()),
		    'is_can_comment'=>in_array($this->order->get_status(),array($status_completed))&&get_post_meta($this->get_order()->get_id(),'wrest_order_comment',true)!='1',
			'is_can_refund_m'=> in_array($this->order->get_status(), array($status_refund_hold,$status_refunded)),
			
			'is_can_refund_failed'=> in_array($this->order->get_status(), array($status_refund_failed)),
			
		    'items'=>array()
		);
		
		$orderInfo['actions'] = array();

		if(!(isset($orderInfo['actions_clear'])&&$orderInfo['actions_clear']) && $orderInfo['is_can_pay']){
		    $orderInfo['actions']['is_can_pay'] = array(
		        'title'=>'立即支付',
		        'type'=>'primary',
		
		        'function'=>'onRePayOrder'
		    );
		}
		
// 		if($orderInfo['is_can_cancel']){
// 		    $orderInfo['actions']['is_can_cancel'] = array(
// 		        'title'=>'取消订单',
// 		        'type'=>'default',
		
// 		        'dialog_title'=>$this->order->is_paid()?'当前订单已支付，确定要取消？':'当前订单未支付，确定要取消订单吗？',
// 		        'dialog_confirm'=>'确定取消',
// 		        'dialog_cancel'=>'暂不取消',
// 		        'function'=>'dialog',
		
// 		        'action'=>'/payment/v1/order/cancel'
// 		    );
// 		}
		
		if($orderInfo['is_can_refund_failed']){
		    $orderInfo['actions']['is_can_refund_failed'] = array(
		        'title'=>'不予退款',
		        'type'=>'primary',
		        'function'=>'open-type',
		        'action'=>'contact'
		    );
		}
		
// 		if($orderInfo['is_can_refunded']&&!$orderInfo['is_can_comment']){
// 		    $orderInfo['actions']['is_can_refunded'] = array(
// 		        'title'=>'申请退货',
// 		        'type'=>'default',
		
// 		        'function'=>'navigate',
// 		        'action'=>'/package_a/pages/order/refund/index?id='.$this->get_order()->get_id()
// 		    );
// 		}
		
		if($orderInfo['is_can_refund_m']){
		    $orderInfo['actions']['is_can_refund_m'] = array(
		        'title'=>'退款详情',
		        'type'=>'primary',
		
		        'function'=>'navigate',
		        'action'=>'/package_a/pages/order/refund-m/index?id='.$this->get_order()->get_id()
		    );
		}
		
		if($orderInfo['is_can_received']){
		    $orderInfo['actions']['is_can_received'] = array(
		        'title'=>'确认收货',
		        'type'=>'primary',
		
		        'dialog_title'=>'我已收到商品，确认完成订单？',
		        'dialog_confirm'=>'确定',
		        'dialog_cancel'=>'取消',
		        'function'=>'dialog',
		
		        'action'=>'/payment/v1/order/received'
		    );
		}
		
		if($orderInfo['is_can_comment']){
		    $orderInfo['actions']['is_can_comment'] = array(
		        'title'=>'立即评论',
		        'type'=>'primary',
		
		        'function'=>'navigate',
		        'action'=>'/package_a/pages/order/order-comment/index?id='.$this->get_order()->get_id()
		    );
		}
		
		$previewImage = null;
		$summary = null;
		$orderItems = $this->order->get_items('line_item');
		if($orderItems){
		    $hidden_order_itemmeta = apply_filters(
		        'woocommerce_hidden_order_itemmeta', array(
		            '_qty',
		            '_tax_class',
		            '_product_id',
		            '_variation_id',
		            '_line_subtotal',
		            '_line_subtotal_tax',
		            '_line_total',
		            '_line_tax',
		            'method_id',
		            'cost',
		            '_reduced_stock',
		        )
		    );
		    	
		    foreach ($orderItems as $item_id=>$item){
		        $item instanceof WC_Order_Item_Product;
		        $product = new WRest_Product_WC($item->get_product());
		        $meta_data = $item->get_formatted_meta_data( '' ) ;
		       
		        $subtitle = '';
		        if($meta_data){
		            $index = 0;
		            foreach ( $meta_data as $meta_id => $meta ){
		               if ( in_array( $meta->key, $hidden_order_itemmeta, true ) ) {
		                   continue;
		               }
		               if ($index++ != 0) {
		                   $subtitle .= " ";
		               }
		               $subtitle.='"'.strip_tags(wc_clean($meta->display_value)).'"';
		            }
		        }
		
		        $simple = $product->to_simple($version,'thumbnail');
        		if(!$previewImage){
        		    $previewImage =$simple['image'];
        		}
        		if($summary){
        		    $summary.="。";
        		}
        		
        		$summary.=$simple['title']." x {$item->get_quantity()}";
		        $orderInfo['items'][]=array(
		            'id'=>$item->get_id(),
		            'quantity'=>$item->get_quantity(),
		            'subtotal'=>Abstract_WRest_Doamin::format_price($item->get_subtotal()),
		            'item_total'=>Abstract_WRest_Doamin::format_price($this->order->get_item_total( $item, false, true )),
		            'product'=>$simple,
		            'title'=>$item->get_name(),
		            'subtitle'=>$subtitle
		        );
		    }
		}
		
		$orderInfo['previewImage'] = $previewImage;
		$orderInfo['summary'] = $summary;
		
		$orderInfo =  apply_filters('wrest_order_simple', $orderInfo,$this);
		$new_actions = array();
		foreach ($orderInfo['actions'] as $action=>$settings){
		    if(!$orderInfo[$action]){
		        continue;
		    }
		    $new_actions[$action] = $settings;
		    break;
		}
		$orderInfo['actions'] = $new_actions;
		return $orderInfo;
	}
	
	public function process_payment_check(){
		if(!$this->is_load()){
			return false;
		}
		
		if($this->order->is_paid()){
			return true;
		}
		
		$payment_method = $this->get_payment_method();
		if(!$payment_method){
			return false;
		}
		
		try{
			$order_id = $this->order->get_id();
			$transaction_id = null;
			
			if($payment_method instanceof Abstract_WRest_WC_Payment_Gateway
			    && $payment_method->process_payment_query($order_id,$transaction_id)){
				$this->order->payment_complete($transaction_id);
			}
			return true;
		}catch (Exception $e){
			WRest_Log::error($e);
			return false;
		}
	}
	
	/**
	 *
	 * @return Abstract_WRest_WC_Payment_Gateway
	 */
	public function get_payment_method(){
		if(!$this->is_load()){
			return null;
		}
		
		return WRest_Domain_WC::get_available_payment_gateway($this->order->get_payment_method());
	}

	public function to_detail($version){
		if(!$this->is_load()){
			return null;
		}
		
		$hold_stock_minutes       = min(array(
				absint(get_option( 'woocommerce_hold_stock_minutes', 0 )),
				30
		));
		$time_created = $this->order->get_date_created()->getOffsetTimestamp();
		$time_now =  current_time( 'timestamp');
		
		$states = WC()->countries->get_states( $this->order->get_billing_country() );
		
		//此处，gateway需要获取所有，不仅限于app
		$available_gateways = WC()->payment_gateways->get_available_payment_gateways();
		$gateway = $available_gateways&&isset($available_gateways[$this->order->get_payment_method()])?$available_gateways[$this->order->get_payment_method()]:null;
		$order_statuses = wc_get_order_statuses();
		
		$is_can_cancel = in_array( $this->order->get_status(), array( 'pending', 'failed'));
		if(in_array($this->order->get_status(),array('processing'))){
		    $order_paid_date = $this->order->get_date_paid();
		    $now = current_time( 'timestamp');
		    $apiset = new WRest_Menu_Store_Order($version);
		    $enable_refund_when_processing = floatval($apiset->get_option('enable_refund_when_processing'));
		    $is_can_cancel = $order_paid_date&&($now-($order_paid_date->getOffsetTimestamp() +round($enable_refund_when_processing*60*60))<=0);
		}
		
		$api_status = WRest_Menu_Default_Order::instance();
		$status_refund_failed = $api_status->get_status_name('wc-refund-failed');
		$status_refund_hold = $api_status->get_status_name('wc-refund-hold');
		$status_refunded = $api_status->get_status_name('wc-refunded');
		$status_completed = $api_status->get_status_name('wc-completed');
		$status_refunding = $api_status->get_status_name('wc-refunding');
		
		$is_can_refund = false;
		if(in_array($this->order->get_status(),array($status_completed))){
		    $order_shiped_time = absint(get_post_meta($this->order->get_id(),'__wrest_shiped_date__',true));
		    if(!$order_shiped_time){
		        $order_shiped_time = $this->get_order()->get_date_paid()?$this->get_order()->get_date_paid()->getOffsetTimestamp():0;
		    }
		    $now = current_time( 'timestamp');
		    $apiset = new WRest_Menu_Store_Order($version);
		    $enable_refund_when_received = floatval($apiset->get_option('enable_refund_when_received'));
		    $is_can_refund = $order_shiped_time&&($now-($order_shiped_time +round($enable_refund_when_received*60*60))<=0);
		}
		$order_config = new WRest_Menu_Store_Order($version);
		$rates = $this->order->get_taxes();
		$rates =$rates&&count($rates)? array_values($rates):null;
		$rate_value = null;
		 if($rates&&count($rates)&&$rates[0] instanceof WC_Order_Item_Tax) {
		     $rate_value = $rates[0]->get_tax_total();
		 }
		$orderInfo =  array(
				'id'=>$this->order->get_id(),
				'status'=>$this->order->get_status(),
				'status_text'=>isset($order_statuses['wc-'.$this->order->get_status()])?$order_statuses['wc-'.$this->order->get_status()]:'',
				'date_expired'=>$this->order->needs_payment()?($hold_stock_minutes*60-($time_now-$time_created)):0,
				'date_created'=>$this->order->get_date_created()->date_i18n('Y-m-d H:i'),
				'address_model' =>get_post_meta($this->order->get_id(),'_shipping_wrest_address_model',true),
				'date_paid'=>$this->order->get_date_paid()?$this->order->get_date_paid()->date_i18n('Y-m-d H:i'):null,
				'total_fee'=>Abstract_WRest_Doamin::format_price($this->order->get_total()),
				'currency'=>$this->order->get_currency(),
				'customer_note'=>$this->order->get_customer_note(),
				'currency_symbol'=>get_woocommerce_currency_symbol($this->order->get_currency()),
				'shipping_fee'=>Abstract_WRest_Doamin::format_price($this->order->get_shipping_total() ),
				'discount_fee'=>Abstract_WRest_Doamin::format_price($this->order->get_discount_total() ),
				'rate_fee'=>Abstract_WRest_Doamin::format_price($rate_value?$rate_value:0),
				'shipping_method_title'=>$this->order->get_shipping_method(),
				'needs_shipping_address'=>$this->order->needs_shipping_address(),
				'payment_method_title'=>$this->order->get_payment_method_title(),
				'payment_method_icon'=>$gateway?$gateway->icon:'',
				'needs_shipping_address'=>$this->order->needs_shipping_address(),
		        'is_can_query_payment'=>WRest_Domain_WC::is_available_payment_gateway($gateway)&&$this->order->needs_payment(),
				'is_can_cancel'=>$is_can_cancel,
				'is_can_refund_m'=> in_array($this->order->get_status(), array($status_refund_failed,$status_refunding,$status_refund_hold,$status_refunded)),
				'is_can_pay'=>$this->order->needs_payment(),
		        'is_can_refunded'=>$is_can_refund,
		        'is_can_received'=>in_array($this->order->get_status(),Abstract_WRest_Order::get_status_wait_received()),
		        'is_can_comment'=>in_array($this->order->get_status(),array($status_completed))&&get_post_meta($this->get_order()->get_id(),'wrest_order_comment',true)!='1',
		        'is_can_refund_failed'=> in_array($this->order->get_status(), array($status_refund_failed)),
		        'tips'=>WRest_Helper_String::towxml($order_config->get_option('order_detail_tips')),
		        'items'=>array(),
				'has_shipping'=>$this->has_shipping(),
				'billing'=>array(
						'first_name'=>$this->order->get_billing_first_name(),
						'last_name' => $this->order->get_billing_last_name(),
						'company' => $this->order->get_billing_company(),
						'country' => $this->order->get_billing_country(),
						'address_1' => $this->order->get_billing_address_1(),
						'address_2' =>$this->order->get_billing_address_2(),
						'city' => $this->order->get_billing_city(),
						'state' => $states&&isset($states[$this->order->get_billing_state()])?html_entity_decode($states[$this->order->get_billing_state()]):$this->order->get_billing_state() ,
						'postcode' => $this->order->get_billing_postcode(),
						'phone' => $this->order->get_billing_phone(),
						'email' => $this->order->get_billing_email()
				),
				'notes'=>array()
		);
		
		$has_idcard = class_exists('WC_Sinic')&&WC_Sinic::instance()->get_available_addon('wc_sinic_add_ons_idcard');
		if($has_idcard){
		    $_username = get_post_meta($this->order->get_id(),'_billing_idcard_username',true);
		    $_idcard = get_post_meta($this->order->get_id(),'_billing_idcard_no',true);
		    
		    if($_username&&strlen($_username)>1){
		        $len = mb_strlen($_username,'utf-8')-1;
		        $_username = mb_substr($_username, 0,1,'utf-8');
		        while ($len-->0){
		            $_username.='*';
		        }
		    }
		    if($_idcard&&strlen($_idcard)>3){
		        $_idcard = substr($_idcard, 0,3).'******'.substr($_idcard,-2);
		    }
		    $orderInfo['idcard'] =array(
		        'username' => $_username,
		        'no' => $_idcard
		    );
		}
		
		
		$payment_method = $this->get_payment_method();
		if($payment_method){
		    ob_start();
		    do_action( 'woocommerce_thankyou_' . $this->get_order()->get_payment_method(), $this->get_order()->get_id() );
		    $thankyou_page = ob_get_clean();
		    $orderInfo['thankyou_page'] = WRest_Helper_String::towxml($thankyou_page);
		}
		
		$orderInfo['actions'] = array();
		
		if($orderInfo['is_can_cancel']){
		    $orderInfo['actions']['is_can_cancel'] = array(
		        'title'=>'取消订单',
		        'type'=>'default',
		        
		        'dialog_title'=>$this->order->is_paid()?'当前订单已支付，确定要取消？':'当前订单未支付，确定要取消订单吗？',
		        'dialog_confirm'=>'确定取消',
		        'dialog_cancel'=>'暂不取消',
		        'function'=>'dialog',
		        
		        'action'=>'/payment/v1/order/cancel'
		    );
		}

		if($orderInfo['is_can_pay']){
		    $orderInfo['actions']['is_can_pay'] = array(
		        'title'=>'立即支付',
		        'type'=>'primary',
		        
		        'function'=>'onRePayOrder'
		    );
		}

		if($orderInfo['is_can_refunded']){
		    $orderInfo['actions']['is_can_refunded'] = array(
		        'title'=>'申请退货',
		        'type'=>'default',
		        
		        'function'=>'navigate',
		        'action'=>'/package_a/pages/order/refund/index?id='.$this->get_order()->get_id()
		    );
		}

		if($orderInfo['is_can_refund_m']){
		    $orderInfo['actions']['is_can_refund_m'] = array(
		        'title'=>'退款详情',
		        'type'=>'primary',
		
		        'function'=>'navigate',
		        'action'=>'/package_a/pages/order/refund-m/index?id='.$this->get_order()->get_id()
		    );
		}
		
		if($orderInfo['is_can_received']){
		    $orderInfo['actions']['is_can_received'] = array(
		        'title'=>'确认收货',
		        'type'=>'primary',
		        
		        'dialog_title'=>'我已收到商品，确认完成订单？',
		        'dialog_confirm'=>'确定',
		        'dialog_cancel'=>'取消',
		        'function'=>'dialog',
		        
		        'action'=>'/payment/v1/order/received'
		    );
		}
		if($orderInfo['is_can_comment']){
		    $orderInfo['actions']['is_can_comment'] = array(
		        'title'=>'立即评论',
		        'type'=>'primary',
		
		        'function'=>'navigate',
		        'action'=>'/package_a/pages/order/order-comment/index?id='.$this->get_order()->get_id()
		    );
		}
		
		$notes = $this->order->get_customer_order_notes();
		if($notes){
		  foreach ($notes as $note){
		      $orderInfo['notes'][] = array(
		          'date'=>date('m/d H:i',strtotime($note->comment_date)),
		          'content'=>$note->comment_content
		      );
		  }
		}
		
		$orderItems = $this->order->get_items('line_item');
		if($orderItems){
			$hidden_order_itemmeta = apply_filters(
				'woocommerce_hidden_order_itemmeta', array(
					'_qty',
					'_tax_class',
					'_product_id',
					'_variation_id',
					'_line_subtotal',
					'_line_subtotal_tax',
					'_line_total',
					'_line_tax',
					'method_id',
					'cost',
					'_reduced_stock',
				)
			);
			
			foreach ($orderItems as $item_id=>$item){
				$item instanceof WC_Order_Item_Product;
				$product = new WRest_Product_WC($item->get_product());
				$meta_data = $item->get_formatted_meta_data( '' ) ;
				$subtitle = '';
		        if($meta_data){
		            $index = 0;
		            foreach ( $meta_data as $meta_id => $meta ){
		               if ( in_array( $meta->key, $hidden_order_itemmeta, true ) ) {
		                   continue;
		               }
		               if ($index++ != 0) {
		                   $subtitle .= " ";
		               }
		               $subtitle.='"'.strip_tags(wc_clean($meta->display_value)).'"';
		            }
		        }
		
		
		        $orderInfo['items'][]=array(
		            'id'=>$item->get_id(),
		            'quantity'=>$item->get_quantity(),
		            'subtotal'=>Abstract_WRest_Doamin::format_price($item->get_subtotal()),
		            'item_total'=>Abstract_WRest_Doamin::format_price($this->order->get_item_total( $item, false, true ) ),
		            'product'=>$product->to_simple($version,'thumbnail'),
		            'title'=>$item->get_name(),
		            'subtitle'=>$subtitle
		        );
			}
		}
		
		return apply_filters('wrest_order_info', $orderInfo,$this);
	}

	public function has_shipping(){
	    return apply_filters('wrest_has_shipping_api', false,$this) ;
    }

	public function get_shipping(){
	    return apply_filters('wrest_get_shipping',false,$this) ;
    }
}
