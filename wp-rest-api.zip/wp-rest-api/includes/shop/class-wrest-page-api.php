<?php
class WRest_Page_Api{
    public static function init(){
        
        add_action('init', __CLASS__.'::register_post_types');
        add_action('wrest_flush_rewrite_rules', __CLASS__.'::register_post_types');
        add_action('manage_posts_extra_tablenav', __CLASS__.'::manage_posts_extra_tablenav',10,1);
        
        add_action('admin_init', __CLASS__.'::admin_init',10);
       // add_action("save_post_wrest_page", __CLASS__.'::save_meta_box_data',10,3);
    }
    
//     public static function save_meta_box_data($post_ID, $post, $update){
//         if ( ! current_user_can( 'edit_post',$post_ID)  ){
//             return;
//         }
//        
//         if ( ! isset( $_POST['__wrest_content_hidden__'] ) || ! wp_verify_nonce( $_POST['__wrest_content_hidden__'], plugin_basename( __FILE__ ) ) ){
//             return;
//         }
//        
//         update_post_meta($post_ID, '__wrest_required_login__', isset($_POST['__wrest_required_login__'])?$_POST['__wrest_required_login__']:'no');
//     }
    
    public static function admin_init(){
        add_meta_box('wrest-metabox-content','内容',__CLASS__.'::meta_box_html','wrest_page','normal', 'high' );
    }
    
    public static function register_post_types(){
        register_post_type('wrest_page',
            array(
                'labels' => array(
                    'name' => '小程序页',
                    'singular_name' =>'小程序页',
                    'add_new' => '新增',
                    'add_new_item' =>'新增页面',
                    'edit' =>  '编辑',
                    'edit_item' => '编辑页面',
                    'new_item' => '新页面',
                    'menu_name'=>'小程序页',
                    'view' => '查看',
                    'view_item' =>'查看页面',
                    'search_items' => '搜索',
                    'not_found' => '未找到页面',
                    'not_found_in_trash' =>'回收站中暂无页面',
                    'parent' => '父级页面'
                ),
                //决定自定义文章类型在管理后台和前端的可见性
                'public' => true,
                'menu_position' => 60,
                'exclude_from_search '=>true,
                'publicly_queryable'=>false,
                'hierarchical'=>false,
                'supports' => array( 'title','comments', 'thumbnail', /*'excerpt', 'editor','page-attributes'*/ ),
                'has_archive' => false,
                'show_in_menu'=>WRest_Admin::menu_tag
            ));
    }
    
    public static function meta_box_html(){
        global $post;
        wp_nonce_field( plugin_basename( __FILE__ ), '__wrest_content_hidden__' );
        ?>
        <h5>页面内容</h5>
        <?php 
        
        $api = new WRest_Page_Content($post);	
        $api->admin_options();
    }
    
    public static function manage_posts_extra_tablenav($which){
        global $typenow,$wp_query;
        if( 'top' != $which||$typenow!='wrest_page'){
            return;
        }
        
        if(!$wp_query->posts){
            ?>
            <style type="text/css">
                .wp-list-table.posts{display:none;}
            </style>
            <?php 
        }
        ?>
        <table class="wp-list-table widefat fixed striped">
        	<thead>
            	<tr>
            		<td id="cb" class="manage-column column-cb check-column">
                		<input type="checkbox" disabled />	
            		</td>
            		<th scope="col" id="title" class="manage-column column-title column-primary sortable desc">
            			<a>
            				<span>系统默认</span>
            			</a>
            		</th>
            		<th scope="col" id="comments" class="manage-column column-comments num sortable desc"><a href="#"><span><span class="vers comment-grey-bubble" title="评论"><span class="screen-reader-text">评论</span></span></span><span class="sorting-indicator"></span></a></th>
            		<th scope="col" id="date" class="manage-column column-date sortable asc">
            			<a>
            				<span>状态</span>
            			</a>
            		</th>
            	</tr>
        	</thead>
        	<tbody id="the-list">
        		<?php foreach (WRest_Menu_Shoppage_Settings::instance()->menus() as $menu){
        		    ?>
        		    <tr class="iedit author-self level-0 type-wrest_page status-publish hentry">
            			<th scope="row" class="check-column">	
            			<input type="checkbox" disabled />		
                		</th>
                		<td class="title column-title has-row-actions column-primary page-title">
                			
                			<strong><a class="row-title" href="<?php echo admin_url('admin.php?page=wrest_page_default&section=menu_store_settings&sub='.$menu->id)?>"><?php echo $menu->title?></a></strong>
                			<div class="row-actions">
                				<span class="edit"><a href="<?php echo admin_url('admin.php?page=wrest_page_default&section=menu_store_settings&sub='.$menu->id)?>" aria-label="编辑“123”">编辑</a></span>
            				</div>
            			</td>
            			<td class="comments column-comments" data-colname="评论">		
            				<div class="post-com-count-wrapper">
        						<span aria-hidden="true">—</span>
        						<span class="screen-reader-text">无评论</span>
        						<span class="post-com-count post-com-count-pending post-com-count-no-pending">
        							<span class="comment-count comment-count-no-pending" aria-hidden="true">0</span>
        							<span class="screen-reader-text">无评论</span>
        						</span>		
    						</div>
    					</td>
            			<td class="date column-date">已发布</td>	
        			</tr>
        		    <?php 
        		}?>
    		</tbody>
        </table>
        <?php 
    }
}

class WRest_Page_Content extends Abdtract_WRest_XCX_Setting_Menu{
    /**
     * 
     * @var WP_Post
     */
    private $post;
    
    public function __construct($post){
        $this->id = $post->ID;
        $this->post = $post;
        $this->enable_edit = true;
    }
    /**
     * {@inheritDoc}
     * @see Abdtract_WRest_XCX_Setting_Menu::get_template_type()
     */
    public function get_template_type()
    {
        return $this->post->post_type;
    }

    public function has_templates(){
        return false;
    }
    
    public function admin_options(){
        $version_obj = null;
        $fields = $this->process_admin_header($version_obj,true);
        if(!$version_obj){return;}
        ?>
        <div class="container">
            <?php 
                if($this->has_templates()&&count($fields)<=1||(isset($_REQUEST['template'])&&$_REQUEST['template']=='1')){
                    $this->template_view($version_obj);
                }else{
                    $this->admin_options_content($version_obj);
                }
    	    ?>
        </div>
    	<?php 
    }
    
    public function get_config_data($version = null,&$version_obj=null){
        $version_obj=WRest_Version::get_newest_version();        
        $fields = get_post_meta($this->post->ID, '__wrest_content__',true);       
        if(!$fields||!is_array($fields)){return array();}
        return $fields;
    }
    
    public function save_config($version,$fields){
        update_post_meta($this->post->ID, '__wrest_content__', $fields);
        return WRest_Error::success();
    }
    
    public function app_view_actions($version_obj,$config){
        ?>
        <div style="display:none;">
			<?php parent::app_view_actions($version_obj,$config);?>
		</div>
		<script type="text/javascript">
			$('#publish').click(function(){
				if($(this).attr('wrest-submit')){
					$(this).removeAttr('wrest-submit');
					return true;
				}
				
				window.templateView.submit({
					'key':'publish'
				},function(m){
					$('#publish').attr('wrest-submit',true).click();
				});
				return false;
			});
		</script>
        <?php 
    }
}