<?php
class WRest_Posts{
    public static function get_posts($version,$query=array()){
        $args = array(
            'post_type'=>'post',
            'no_found_rows'=>true
        );
        
        if(isset($query['post__in'])&&is_array($query['post__in'])&&count($query['post__in'])){
            $args['post__in'] = $query['post__in'];
            $args['orderby'] = 'post__in';
        }
        
        if(isset($query['post__in'])&&is_array($query['post__in'])&&count($query['post__in'])){
            $args['post__in'] = $query['post__in'];
            $args['orderby'] = 'post__in';
        }
        
        if(isset($query['category__in'])&&is_array($query['category__in'])&&count($query['category__in'])){
            $args['category__in'] = $query['category__in'];
        }

        if(isset($query['tag__in'])&&is_array($query['tag__in'])&&count($query['tag__in'])){
            $args['tag__in'] = $query['tag__in'];
        }
        
        if(isset($query['posts_per_page'])){
            $args['posts_per_page'] = intval($query['posts_per_page']);
        }
        
        if(isset($query['sort'])&&$query['sort']){
            switch ($query['sort']){
                case 'default';
                default:
                    break;
                case 'comment_count_desc':
                    $args['orderby'] = 'comment_count';
                    $args['order'] = 'DESC';
                    break;
                case 'publish_date_desc':
                    $args['orderby'] = 'date';
                    $args['order'] = 'DESC';
                    break;
                case 'publish_date_asc':
                    $args['orderby'] = 'date';
                    $args['order'] = 'ASC';
                    break;
                case 'random':
                    $args['orderby'] = 'rand';
                    break;
            }
        }
        
        $wp_query = new WP_Query($args);
        $results = array();
        while ($wp_query->have_posts()){
            $wp_query->the_post();
            global $post;
            
            $thumbnail = null;
            $post_thumbnail_id = get_post_thumbnail_id( $post );
        	if (  $post_thumbnail_id ) {
        		$src = wp_get_attachment_image_src($post_thumbnail_id,'full');
        		if($src&&count($src)>=3){
        		    $thumbnail=array();
        		    $thumbnail['url'] = $src[0];
        		    $thumbnail['width'] = $src[1];
        		    $thumbnail['height'] = $src[2];
        		}
        	}
            $results[]=array(
                'ID'=>get_the_ID(),
                'title'=>get_the_title(),
                'comment_count'=>absint($post->comment_count),
                'date'=>get_the_time('Y-m-d',$post),
                'thumbnail'=>$thumbnail
            );
        }
        wp_reset_postdata();
        return $results;
    }
}