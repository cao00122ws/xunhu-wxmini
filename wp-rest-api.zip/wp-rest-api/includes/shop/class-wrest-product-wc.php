<?php
require_once 'class-wrest-domain-wc.php';
require_once 'class-wrest-order-wc.php';

class WRest_Product_WC extends Abstract_WRest_Product{

	public function __construct($post_ID_or_product){
		if(is_numeric($post_ID_or_product)){
			$this->product = wc_get_product($post_ID_or_product);
		}else if($post_ID_or_product instanceof WP_Post){
			$this->product = wc_get_product($post_ID_or_product->ID);
		}else if($post_ID_or_product instanceof WC_Product){
			$this->product = $post_ID_or_product;
		}
	}
	
	/**
	 * 
	 * {@inheritDoc}
	 * @see Abstract_WRest_Product::to_simple()
	 */
	public function to_simple($version,$image_size='woocommerce_single'){
		if(!$this->product){return null;}
		//$day = absint(WRest_Menu_Store_Layout::instance()->get_field($version,'WRest_Template_Layout_Products')->get_option('new_days',3));
		$base = new WRest_Menu_Store_Base($version);
		$enable_sale_qty = $base->get_option('enable_sale_qty');
		$sale_qty = 'no';
		if('yes'==$enable_sale_qty){
		    $sale_qty=absint($this->product->get_total_sales());
		}
		
		$info = array(
				'id'=>$this->product->get_id(),
		        'parent_id'=>$this->product->get_parent_id(),
		        'type'=>$this->product->get_type(),
				'title'=>$this->product->get_title(),
		        'is_in_stock'=>$this->product->is_in_stock(),
		        'total_sales'=>$sale_qty,
		        'is_purchasable'=>$this->product->is_purchasable(),
				'image'=>$this->get_product_image($image_size),
		        'price'=>$this->product->get_price(),
				'price_html'=>WRest_Helper_String::towxml($this->product->get_price_html()),
		        'price_html1'=>$this->product->get_price_html(),
				'is_featured'=>$this->product->is_featured(),
				'is_on_sale'=>$this->product->is_on_sale(),
		        'sku'=>$this->product->get_sku(),
    		    'max_qty'=>$this->product->get_max_purchase_quantity(),
    		    'min_qty'=>$this->product->get_min_purchase_quantity(),
		        'weight'=>round($this->product->get_weight(),2),
				'is_new'=>$this->product->get_date_created()->getOffsetTimestamp()>(current_time( 'timestamp' )-3*24*60)
		);
		
		return apply_filters('wrest_product_simple', $info,$this);
	}
	
	private function get_comments($limit){
	    $comments = WRest_Cache_Helper::get("ID:{$this->product->get_id()}", 'product:comments');
	    if($comments){
	        return $comments;
	    }
	    
	    $api = new WRest_Comment($this->product->get_id());
	    $comments = $api->get_comments(1,$limit);
	    WRest_Cache_Helper::set("ID:{$this->product->get_id()}",$comments, 'product:comments');
	    return $comments;
	}
	
	private function get_upsells($version){
	    $upsellids =$this->product->get_upsell_ids(); 
	    $upsells=array();
	    if($upsellids){
	        foreach ($upsellids as $product_id){
	            $product = new WRest_Product_WC($product_id);
	            if(!$product->is_load()){
	                continue;
	            }
	    
	            $upsells[]=$product->to_simple($version,'woocommerce_single');
	        }
	    }
	    
	    $upsells_array = array();
	    $sdk = isset($_REQUEST['sdk'])?wc_clean($_REQUEST['sdk']):null;
	    if($sdk&&version_compare($sdk, '1.0.1','>=')){
	        $model = 'small';
	        return self::to_list_mode($model, $upsells);
	    }else{
	        foreach ($upsells as $item){
				$product = new WRest_Product_WC($item);
				if(!$product->is_load()){continue;}
				$upsells_array[]=$product->to_simple($version,'woocommerce_single');
	        }
	    }
	    
	    return $upsells_array;
	}
	
	public function to_detail($version){
		if(!$this->product){return null;}
		$stock_quantity = $this->product->get_stock_quantity();

		$time_now =  current_time( 'timestamp', true );
		$date_on_sale_from = $this->product->get_date_on_sale_from(  );
		$date_on_sale_from=$date_on_sale_from?$date_on_sale_from->getOffsetTimestamp():null;
		
		$date_on_sale_to = $this->product->get_date_on_sale_to(  );
		$date_on_sale_to=$date_on_sale_to?$date_on_sale_to->getOffsetTimestamp():null;
		
		$date_on_sale = null;
		if(
			(
				$this->product instanceof WC_Product_Simple
					||$this->product instanceof WC_Product_Variation
			)
			&& '' !== (string) $this->product->get_sale_price(  )
				&& $this->product->get_regular_price(  ) > $this->product->get_sale_price(  )){
			if($date_on_sale_from&&$time_now<$date_on_sale_from){
				$date_on_sale = array(
						'time'=>date('m月d日  00时',$date_on_sale_from),
						'text'=>'开始促销'
				);
			}else if($date_on_sale_to&&$time_now<$date_on_sale_to&&$this->product->is_on_sale()){
				$date_on_sale = array(
						'time'=>date('m月d日  00时',$date_on_sale_to),
						'text'=>'结束促销'
				);
			}
		}
	
		$base = new WRest_Menu_Store_Base($version);
		$enable_sale_qty = $base->get_option('enable_sale_qty');
		$sale_qty = 'no';
		if('yes'==$enable_sale_qty){
		    $sale_qty=absint($this->product->get_total_sales());
		}
		$tax_class = $this->product->get_tax_class();
		$rates = WC_Tax::calc_tax(  $this->product->get_price(), WC_Tax::get_rates( $tax_class ) );
		$rates = $rates&&is_array($rates)&&count($rates)?array_values($rates):null;
		$info = array(
				'id'=>$this->product->get_id(),
		        'parent_id'=>$this->product->get_parent_id(),
				'type'=>$this->product->get_type(),
				'title'=>$this->product->get_title(),
				'short_description'=>WRest_Helper_String::towxml(apply_filters( 'woocommerce_short_description',$this->product->get_short_description())),
		        'total_sales'=>$sale_qty,
				//是否有库存
				'is_in_stock'=>$this->product->is_in_stock(),
				'is_purchasable'=>$this->product->is_purchasable(),
				//'saleDesc'=>$saleDesc,
				//剩余库存
				'stock_quantity'=>$stock_quantity,
				'sku'=>$this->product->get_sku(),
				'max_qty'=>$this->product->get_max_purchase_quantity(),
				'min_qty'=>$this->product->get_min_purchase_quantity(),
		        'currency_symbol'=>get_woocommerce_currency_symbol(),
		        'rate'=>$rates?round($rates[0],2):null,
				'weight'=>round($this->product->get_weight(),2),
				//总销售
				//'total_sales'=>$total_sales,
				//已售比例
				//'saledPercent'=>$saledPercent,
				'date_on_sale'=>$date_on_sale,
		        'password_required'=>post_password_required($this->product->get_id()),
				//可能你喜欢的产品
				'upsells'=>$this->get_upsells($version),
				'image'=>$this->get_product_image('full'),
				'content_images'=>$this->get_content_images(),
				'video_source'=>get_post_meta($this->product->get_id(),'__wrest_preview_video__',true),
				//是否在打折
				'is_on_sale'=>$this->product->is_on_sale(),
				'is_featured'=>$this->product->is_featured(),
		        'purchase_note'=>$base->get_option('pro_purchase_note'),
				'the_content'=>WRest_Helper_String::towxml(wp_kses_post( wpautop(do_shortcode($this->product->get_description()) ))) ,
				'comment'=>$this->get_comments(6),
		        'gallerys'=>$this->get_gallery_images(),
				'price_html'=>WRest_Helper_String::towxml($this->product->get_price_html()),
		        'sale_price'=>round($this->product->get_price(),2),
				'regular_price'=>round($this->product->get_regular_price(),2) ,
				'needPassword'=>post_password_required($this->product->get_id()),
				'coupons'=>$this->get_coupons(),
				'intro_attributes'=>$this->get_attributes()
		);
		
		$this->get_shareInfo($version,$info);
		$sdk = isset($_REQUEST['sdk'])?wc_clean($_REQUEST['sdk']):null;
		if(!$sdk){
		    $related_products =  wc_get_related_products( $this->get_product()->get_id(), 30, $this->product->get_upsell_ids());		   
		    $related_product_list = array();
		    if($related_products){
		        foreach ($related_products as $item){
		            $product = new WRest_Product_WC($item);
		            if(!$product->is_load()){continue;}
		            $related_product_list[]=$product->to_simple($version,'woocommerce_single');
		        }
		    }
		    $info['sameSells'] = $related_product_list;
		}
		
		$att = $this->get_available_variations();
		if($att){
			$info['available_variations'] = $att['available_variations'];
			$info['attributes1'] = $att['attributes1'];
		}
		
		$info['YITH_WCWL'] = true;
		$info['isFav']=WRest_Wishlist::is_in_wishlist($this->product->get_id(), 'product');
		
		return apply_filters('wrest_product_detail', $info,$this);
	}
	
// 	private function get_post_content(){
// 	    global $post;
// 	    if(!$post){
// 	        $post = get_post($this->product->get_id());
// 	    }
// 	    ob_start();
// 	    the_content();
// 	    return ob_get_clean();
// 	}
	
	public function get_available_variations(){
		if(!$this->product instanceof WC_Product_Variable){
			return null;
		}
		
		$get_variations = count( $this->product->get_children() ) <= apply_filters( 'woocommerce_ajax_variation_threshold', 30, $this->product );
		$available_variations = $get_variations ? $this->product->get_available_variations() : false;
		
		$attributes =  $this->product->get_variation_attributes();
		$attributes_new1 = array();
		$index=0;
		if($attributes){
			foreach ($attributes as $name=>$options){
				$item = array();
				
				if(taxonomy_exists( $name )){
					$terms = wc_get_product_terms( $this->product->get_id(), $name, array(
							'fields' => 'all',
					));
					
					foreach ( $terms as $term ) {
						if ( in_array( $term->slug, $options, true ) ) {
							$isSellOut = true;
							if($available_variations){
								foreach ($available_variations as $var){
									$pop = "attribute_".strtolower(urlencode($name));
									$t = isset($var["attributes"][$pop])?$var["attributes"][$pop]:null;
									if(is_null($t)||$t===''||$t==$term->slug){
										$isSellOut = false;
										break;
									}
								}
							}
							
							$item[$term->slug]=array(
									'name'=>apply_filters( 'woocommerce_variation_option_name', $term->name ),
									'isSellOut'=>$isSellOut
							);
						}
					}
					
				}else{
					foreach ($options as $option){
						$isSellOut = true;
						if($available_variations){
							foreach ($available_variations as $var){
								$pop = "attribute_".strtolower(urlencode($name));
								$t = isset($var["attributes"][$pop])?$var["attributes"][$pop]:null;
								if(is_null($t)||$t===''||$t==$option){
									$isSellOut = false;
									break;
								}
							}
						}
						$item[$option]=array(
								'name'=>$option,
								'isSellOut'=>$isSellOut
						);
					}
				}
				
				$attributes_new1[$name] = array(
						'title'=>wc_attribute_label($name),
						'index'=>$index++,
						'options'=>$item
				);
			}
		}
		
		foreach ($available_variations as $index=>$var){
		    $available_variations[$index]['price_html'] = WRest_Helper_String::towxml($var['price_html']);
		}
		
		return array(
				'available_variations'=>$available_variations,
				'attributes1'=>$attributes_new1
		);
	}
	
	private function get_shareInfo($version,&$info){
	    $goodsShareConfig = array();
	    $goodsShare = new WRest_Menu_Store_Goods_Share($version);
	    $goodsShareConfig['goodsShare_brand_name'] = $goodsShare->get_option('name');
	    $goodsShareConfig['goodsShare_brand_logo'] = $goodsShare->get_option('logo');
	    $goodsShareConfig['goodsShare_brand_contact'] = $goodsShare->get_option('contact');
	    $category_list = trim($goodsShare->get_option('category_list'));
	    if(empty($category_list)){
	        $category_list = '服装';
	    }
	    
	    $goodsShareConfig['goodsShare_category_list'] = explode(',', $category_list);
	    $poi_listArray=array();
	    $poi_list = $goodsShare->get_option('poi_list');
	    if(!empty($poi_list)){
	        foreach (explode("\r\n", $poi_list) as $store){
	            $item = explode(',', trim($store));
	            if(count($item)!=6){
	                continue;
	            }
	            $radius = absint($item[2]);
	    
	            $re = array(
	                'longitude'=>round($item[0],3),
	                'latitude'=>round($item[1],3),
	                'business_name'=>$item[3],
	                'branch_name'=>$item[4],
	                'address'=>$item[5]
	            );
	            if($radius>0){
	                if($radius>5){$radius=5;}
	                $re['radius'] = $radius;
	            }
	            $poi_listArray[]=$re;
	        }
	    }
	    $goodsShareConfig['goodsShare_poi_list'] =$poi_listArray;
	    $imgs = array();
	    
	    if($info['gallerys']){
	        foreach ($info['gallerys'] as $img){
	            if ($img['full'] && $img['full']['url']){
	                $imgs[]=$img['full']['url'];
	            }
	        }
	    }
	    
	    if (!count($imgs)||!count( $goodsShareConfig['goodsShare_category_list'])){
	          return;
	    }
	    
	    $shareinfo=array(
	        'item_code'=>"product-{$info['id']}",
	        'title'=>$info['title'],
	        'category_list'=>$goodsShareConfig['goodsShare_category_list'],
	        'image_list'=>$imgs,
	        'src_mini_program_path'=>"/package_a/pages/product/detail/index?id={$info['id']}",
	        'brand_info'=>array(
	            'name'=>$goodsShareConfig['goodsShare_brand_name'],
	            'logo'=>$goodsShareConfig['goodsShare_brand_logo']?$goodsShareConfig['goodsShare_brand_logo']['url']:'',
	            'name'=>$goodsShareConfig['goodsShare_brand_contact']
	        )
	    );
	    
	    $sku_list =array(
	        'sku_id'=>$info['sku']?$info['sku']:"p-{$info['id']}",
	        'price'=>absint($info['sale_price'] * 100),
	        'original_price'=>absint($info['regular_price'] * 100),
	        'status'=>$info['is_on_sale']?1:2
	    );
	    
	    if($goodsShareConfig['goodsShare_poi_list']){
	        $sku_list['poi_list'] = $goodsShareConfig['goodsShare_poi_list'];
	    }
	    
	    $sku_attr_list=array();
	    if ($info['intro_attributes']&&count($info['intro_attributes'])){
	        foreach ($info['intro_attributes'] as $attr){
	            if(!$attr['values']||!count($attr['values'])){
	                continue;
	            }
	            
	            $val = '';
	            foreach ($attr['values'] as $v){
	                if($val){
	                    $val.=',';
	                }
	                $val.=$v;
	            }
	            
	            $sku_attr_list[]=array(
	                'name'=>$attr['title'],
	                'value'=>$val
	            );
	        }
	    }
	    
	    if(count($sku_attr_list)){
	        $sku_list['sku_attr_list'] = $sku_attr_list;
	    }
	    
	    $shareinfo['sku_list']=array(
	       $sku_list 
	    );
	    
	    $info['shareInfo'] = $shareinfo;
	}
	
	private function get_attributes(){
		if(!$this->product){return null;}
		$product =$this->product;
		
		$attributes = array_filter( $product->get_attributes(), 'wc_attributes_array_filter_visible' );
		$display_dimensions = apply_filters( 'wc_product_enable_dimensions_display', $product->has_weight() || $product->has_dimensions());
		
		$atts = array();
		if($display_dimensions && $product->has_weight()){
			$atts[]=array(
					'title'=>__( 'Weight', 'woocommerce' ),
					'values'=>array(
					    html_entity_decode(trim(strip_tags(wc_format_weight( $product->get_weight()))))
					)
			);
		}
		
		if ( $display_dimensions && $product->has_dimensions() ){
			$atts[]=array(
					'title'=>__( 'Dimensions', 'woocommerce' ),
					'values'=>array(
					    html_entity_decode(trim(strip_tags(wc_format_dimensions( $product->get_dimensions( false )))))
					)
			);
		}
		
		if($attributes){
			foreach ($attributes as $attribute){
				$values = array();
				
				if ( $attribute->is_taxonomy() ) {
					$attribute_taxonomy = $attribute->get_taxonomy_object();
					$attribute_values = wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'all' ) );
					
					foreach ( $attribute_values as $attribute_value ) {
						$value_name = trim(strip_tags( $attribute_value->name ));
						
						//if ( $attribute_taxonomy->attribute_public ) {
						//$values[] = '<a href="' . esc_url( get_term_link( $attribute_value->term_id, $attribute->get_name() ) ) . '" rel="tag">' . $value_name . '</a>';
						//} else {
						$values[] = html_entity_decode($value_name);
						//}
					}
				} else {
					$values = $attribute->get_options();
					
					foreach ( $values as &$value ) {
						$value = html_entity_decode(trim(strip_tags($value)));
					}
				}
				
				$atts[]=array(
						'title'=>wc_attribute_label( $attribute->get_name()),
						'values'=>$values
				);
			}
		}
		
		return $atts;
	}
	private function get_product_image($size = 'woocommerce_thumbnail',$placeholder=true){
		if(!$this->product){return null;}
		$product = $this->product;
		$image =null;
		if ( has_post_thumbnail( $product->get_id() ) ) {
			$image = self::get_post_thumbnail($product->get_id(),$size);
		} elseif ( ( $parent_id = wp_get_post_parent_id( $product->get_id() ) ) && has_post_thumbnail( $parent_id ) ) { // @phpcs:ignore Squiz.PHP.DisallowMultipleAssignments.Found
			$image = self::get_post_thumbnail($parent_id,$size);
		}
		
		if ( !$image&& $placeholder ) {
			return array(
					'url'=>wc_placeholder_img_src(),
					'width'=>300,
					'height'=>300,
			);
		}
		
		return $image;
	}
	
	private function get_coupons(){
		if ( ! wc_coupons_enabled() ) {
			return false;
		}
		
		$wp_query = new WP_Query(array(
				//只需要ids
				'fields'=>'ids',
				'post_type'=>'shop_coupon',
				'post_status'=>'publish',
				'no_found_rows'=>true,
				'posts_per_page'=>20,
				'meta_query'=>array(
					array(
							'relation' => 'AND',
							array(
									'key' => '_wrest_public_', //(字符串) - 自定义字段的键
									'value' => 'yes', //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
									'type' => 'CHAR', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
									'compare' => '=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
							),
					)
// 				    array(
// 				        'relation' => 'OR',
// 				        array(
// 				            'key' => 'date_expires', //(字符串) - 自定义字段的键
// 				            'value' =>0,
// 				            'type'=>'NUMERIC',
// 				            'compare' => '=',
// 				        ),
// 				        array(
// 				            'key' => 'date_expires', //(字符串) - 自定义字段的键
// 				            'value' =>current_time( 'timestamp'), //(字符串/数组) - 自定义字段的值 (注意：数组的支持仅限于一个比较值： 'IN', 'NOT IN', 'BETWEEN', or 'NOT BETWEEN')
// 				            'type' => 'NUMERIC', //(字符串) -自定义字段类型，可用的值有：'NUMERIC', 'BINARY', 'CHAR', 'DATE', 'DATETIME', 'DECIMAL', 'SIGNED', 'TIME', 'UNSIGNED'，默认为    'CHAR'
// 				            'compare' => '>=' //(字符串) - 测试的操作，可用的值有： '=', '!=', '>', '>=', '<', '<=', 'LIKE', 'NOT LIKE', 'IN', 'NOT IN', 'BETWEEN', 'NOT BETWEEN'. 默认为：'='
// 				        ),
// 				    )
				)
		));
	
		if(!$wp_query->posts){
			return false;
		}
		
		$coupons = array();
		foreach ($wp_query->posts as $post_ID){
			$coupon = new WC_Coupon( $post_ID );
			if(!$coupon->get_id()){
				continue;
			}
			
			$coupons[]=$coupon;
		}
		
		foreach ( $coupons as $coupon ) {
		    switch ( $coupon->get_discount_type() ) {
		        case 'fixed_product':
		            $coupon->sort = 1;
		            break;
		        case 'percent':
		            $coupon->sort = 2;
		            break;
		        case 'fixed_cart':
		            $coupon->sort = 3;
		            break;
		        default:
		            $coupon->sort = 0;
		            break;
		    }
		
		    // Allow plugins to override the default order.
		    $coupon->sort = apply_filters( 'woocommerce_coupon_sort', $coupon->sort, $coupon );
		}
		
		uasort( $coupons,function ( $a, $b ) {
    		if ( $a->sort === $b->sort ) {
    			if ( $a->get_limit_usage_to_x_items() === $b->get_limit_usage_to_x_items() ) {
    				if ( $a->get_amount() === $b->get_amount() ) {
    					return $b->get_id() - $a->get_id();
    				}
    				return ( $a->get_amount() < $b->get_amount() ) ? -1 : 1;
    			}
    			return ( $a->get_limit_usage_to_x_items() < $b->get_limit_usage_to_x_items() ) ? -1 : 1;
    		}
    		return ( $a->sort < $b->sort ) ? -1 : 1;
	    });
		
		if(!count($coupons)){
		    return false;
		}
		
		$has_queue = array();
		if(is_user_logged_in()){
		    $user_ID = get_current_user_id();
		    $has_queue = get_user_meta($user_ID,'__wrest_coupon_queue',true);
		    if(!$has_queue||!is_array($has_queue)){
		        $has_queue=array();
		    }
		}
		add_filter('woocommerce_product_coupon_types', function($types){
		    $types[]='fixed_cart';
		    return $types;
		},10,1 );
		$active_coupons=array();
		foreach ($coupons as $coupon){
		    $expire_date = $coupon->get_date_expires();
		    if($expire_date&&$expire_date->getOffsetTimestamp()<current_time( 'timestamp')){
		        continue;
		    }
		    if(!$coupon->is_valid_for_product($this->product)){
		        continue;
		    }
		    
		    $item =WRest_Coupon::to_detail($coupon);
		    $item['isIncluded']=false;
		    if(in_array($coupon->get_id(), $has_queue)){
		        $item['isIncluded'] = true;
		    }
		    $active_coupons[]=$item;
		}
		
		return $active_coupons;
	}
	
	private function get_gallery_images($main_image=false){
		if(!$this->product){return null;}
		
		$product = $this->product;
		//$flexslider        = (bool) apply_filters( 'woocommerce_single_product_flexslider_enabled', get_theme_support( 'wc-product-gallery-slider' ) );
		//$gallery_thumbnail = wc_get_image_size( 'gallery_thumbnail' );
		//$thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
		$image_size        = apply_filters( 'woocommerce_gallery_image_size', 'woocommerce_single' );		
		$full_size         = apply_filters( 'woocommerce_gallery_full_size', apply_filters( 'woocommerce_product_thumbnails_large_size', 'full' ) );
		
		$attachment_ids = array();
		$gallery_images = array();
		$post_thumbnail_id = $product->get_image_id();
		if($post_thumbnail_id){
			$attachment_ids[]=$post_thumbnail_id;
		}
		
		$gallery_ids = $product->get_gallery_image_ids();
		if ( $gallery_ids  ) {
			foreach ( $gallery_ids as $attachment_id ) {
				$attachment_ids[]=$attachment_id;
			}
		}
		
		if(!count($attachment_ids)){
		    $post_thumbnail_id = $product->get_image_id();
		    if($post_thumbnail_id){
		        $attachment_ids[]=$post_thumbnail_id;
		    }
		}
		
		$attachment_ids = array_unique($attachment_ids);
		
		foreach($attachment_ids as $post_thumbnail_id){
			//$thumbnail_src     = wp_get_attachment_image_src( $post_thumbnail_id, $thumbnail_size );
			$image_src          = wp_get_attachment_image_src( $post_thumbnail_id, $image_size );
			$full_src          = wp_get_attachment_image_src( $post_thumbnail_id, $full_size );
			$gallery_images[]=array(
// 					'thumbnail'=>array(
// 							'url'=>$thumbnail_src&&count($thumbnail_src)>0?$thumbnail_src[0]:null,
// 							'width'=>$thumbnail_src&&count($thumbnail_src)>1?$thumbnail_src[1]:0,
// 							'height'=>$thumbnail_src&&count($thumbnail_src)>2?$thumbnail_src[2]:0,
// 					),
					'image'=>array(
							'url'=>$image_src&&count($image_src)>0?$image_src[0]:null,
							'width'=>$image_src&&count($image_src)>1?$image_src[1]:0,
							'height'=>$image_src&&count($image_src)>2?$image_src[2]:0,
					),
					'full'=>array(
							'url'=>$full_src&&count($full_src)>0?$full_src[0]:null,
							'width'=>$full_src&&count($full_src)>1?$full_src[1]:0,
							'height'=>$full_src&&count($full_src)>2?$full_src[2]:0,
					)
			);
		}
		
		if(count($attachment_ids)==0){
			$url = wc_placeholder_img_src( 'woocommerce_single' ) ;
			//$thumbnail_dimensions = wc_get_image_size( $thumbnail_size );
			//$image_dimensions = wc_get_image_size( $image_size );
			//$full_dimensions = wc_get_image_size( $full_size );
			$gallery_images[]=array(
// 					'thumbnail'=>array(
// 							'url'=>$url,
// 							'width'=>200,
// 							'height'=>200,
// 					),
					'image'=>array(
							'url'=>$url,
							'width'=>300,
							'height'=>300,
					),
					'full'=>array(
							'url'=>$url,
							'width'=>500,
							'height'=>500,
					)
			);
		}
		return $gallery_images;
	}
	
	private function get_content_images($main_image=false){
		if(!$this->product){return null;}
		$product = $this->product;
		//$flexslider        = (bool) apply_filters( 'woocommerce_single_product_flexslider_enabled', get_theme_support( 'wc-product-gallery-slider' ) );
		//$gallery_thumbnail = wc_get_image_size( 'gallery_thumbnail' );
		//$thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
		$image_size        = 'full';//apply_filters( 'woocommerce_gallery_image_size', $flexslider || $main_image ? 'woocommerce_single' : $thumbnail_size );
		$full_size         = apply_filters( 'woocommerce_gallery_full_size', apply_filters( 'woocommerce_product_thumbnails_large_size', 'full' ) );
		
		$gallery_ids = get_post_meta($this->product->get_id(),'_wrest_the_content_',true);
		$attachment_ids = $gallery_ids?explode(',', $gallery_ids):array();
		$gallery_images = array();
		foreach($attachment_ids as $post_thumbnail_id){
			//$thumbnail_src     = wp_get_attachment_image_src( $post_thumbnail_id, $thumbnail_size );
			$image_src          = wp_get_attachment_image_src( $post_thumbnail_id, $image_size );
			$full_src          = wp_get_attachment_image_src( $post_thumbnail_id, $full_size );
			$gallery_images[]=array(
			// 					'thumbnail'=>array(
					// 							'url'=>$thumbnail_src&&count($thumbnail_src)>0?$thumbnail_src[0]:null,
					// 							'width'=>$thumbnail_src&&count($thumbnail_src)>1?$thumbnail_src[1]:0,
					// 							'height'=>$thumbnail_src&&count($thumbnail_src)>2?$thumbnail_src[2]:0,
					// 					),
					'image'=>array(
							'url'=>$image_src&&count($image_src)>0?$image_src[0]:null,
							'width'=>$image_src&&count($image_src)>1?$image_src[1]:0,
							'height'=>$image_src&&count($image_src)>2?$image_src[2]:0,
					),
					'full'=>array(
							'url'=>$full_src&&count($full_src)>0?$full_src[0]:null,
							'width'=>$full_src&&count($full_src)>1?$full_src[1]:0,
							'height'=>$full_src&&count($full_src)>2?$full_src[2]:0,
					)
			);
		}
		return $gallery_images;
	}
}

