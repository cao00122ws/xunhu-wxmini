<?php
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

/**
 * Social Admin
 *
 * @since 1.0.0
 * @author ranj
 */
class WRest_Settings_Default_Basic_Default extends Abstract_WRest_Settings{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     * @return WRest_Settings_Default_Basic_Default
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='settings_default_basic_default';
        $this->title='常规设置';
		//$this->description="推荐搭配插件：1.ti-woocommerce-wishlist(产品收藏)2.YITH WooCommerce Ajax Product Filter,3.YITH WooCommerce Brands";
        $this->init_form_fields();
    }

    public function init_form_fields(){
        $this->form_fields = array(
            'subtitle_base'=>array(
                'title'=>'账户设置',
                'type'=>'subtitle'
            ),
            'appid'=>array(
                'type'=>'text',
                'title'=>'小程序APPID'
            ),
            'appsecret'=>array(
                'type'=>'password',
                'title'=>'小程序APPSECRET'
            ),
            'txmapkey'=>array(
                'type'=>'password',
                'title'=>'腾讯地图开发者密钥',
                'default'=>'THNBZ-NKLKI-IZPGM-5IC66-S6QBJ-5XBFD',
                'description'=>'部分功能需要使用腾讯地图组件，请<a href="https://lbs.qq.com/console/key.html" target="_blank">申请开通密钥</a>,且勾选“地图组件”'
            ),
            'package_weight'=>array(
                'type'=>'text',
				'default'=>0.7,
                'title'=>'包裹重量(kg)'
            ),
            'package_weight_fa'=>array(
                'type'=>'text',
				'default'=>0.5,
                'title'=>'包裹计重阀值'
            ),
            'img_company'=>array(
                'type'=>'image',
                'title'=>'公司介绍图'
            ),
            'msg_page_coupon'=>array(
                'type'=>'textarea',
                'default'=>'请预先绑定好邮箱，以便接收优惠券',
                'title'=>'(优惠券页)消息提示'
            ),
            'msg_page_phone_v'=>array(
                'type'=>'textarea',
                'default'=>'根据海关相关规定，请您务必确认该手机号持有人与实名认证的收货人姓名一致，属于本人身份证注册的手机号。如使用不实或非本人手机号下单，将会导致订单无法顺利通过，一切后果将全部自行承担。',
                'title'=>'(手机绑定页)消息提示'
            )
        );
    }
}
?>