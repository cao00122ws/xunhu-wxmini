<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * WRest_Shortcodes class
 *
 * @category    Class
 */
class WRest_Shortcodes {

	/**
	 * Init shortcodes.
	 */
	public static function init() {
		$shortcodes = array(
		    
		);
		
		$shortcodes =apply_filters('wrest_shortcodes', $shortcodes);
		foreach ( $shortcodes as $shortcode => $function ) {
			add_shortcode( apply_filters( "wrest_shortcode_{$shortcode}", $shortcode ), $function );
		}
	}
	
	
}
