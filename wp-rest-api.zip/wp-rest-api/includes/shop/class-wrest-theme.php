<?php

class WRest_Theme extends WRest_Object{
	public $tid;
	public $is_system;
	public $title;
	public $content;
	
	public function is_auto_increment(){
		return false;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'tid';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_theme';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
				'tid'=>'',
		        'title'=>'',
		        'is_system'=>false,
				'content'=>null
		);
	}
	
	public static $default_themes=array(
        'blue'=>array(
          'title'=>'深蓝',
          'content'=>array(
                'main'=>array(
                    'primary'=>'#2d8cf0',
                    'light_primary'=>'#5cadff',
                    'dark_primary'=>'#2b85e4'
                ),
                'alert'=>array(
                    'info'=>'#2d8cf0',
                    'success'=>'#19be6b',
                    'warning'=>'#ff9900',
                    'error'=>'#ed3f14'
                ),
                'content'=>array(
                    'title'=>'#1c2438',
                    'content'=>'#495060',
                    'sub_color'=>'#80848f',
                    'disabled'=>'#bbbec4',
                    'border'=>'#dddee1',
                    'divider'=>'#e9eaec',
                    'background'=>'#f8f8f9'
                ),
            )
        )  
	);
}

class WRest_Theme_Model extends Abstract_WRest_Schema{
	/**
	 * {@inheritDoc}
	 * @see Abstract_XH_Model_Api::init()
	 */
	public function init()
	{
		$collate=$this->get_collate();
		global $wpdb;
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_theme` (
					`tid` varchar(32) NOT NULL,
					`title` varchar(128) NOT NULL,
					`is_system` TINYINT(1) NOT NULL DEFAULT 0,
					`content` TEXT NULL DEFAULT NULL,
					PRIMARY KEY (`tid`)
				)
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
		
		foreach (WRest_Theme::$default_themes as $tid=>$config ){
		    $blue = new WRest_Theme($tid);
		    if(!$blue->is_load()){
		        $blue->tid =$tid;
		        $blue->title =$config['title'];
		        $blue->is_system = true;
		        $blue->content=maybe_serialize($config['content']);
		        $error = $blue->insert();
		        if(!WRest_Error::is_valid($error)){
		            throw new Exception($error->to_json());
		        }
		    }
		}
	}
}