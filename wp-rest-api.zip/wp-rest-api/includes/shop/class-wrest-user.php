<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WRest_User extends WRest_User_Object{
    public $role;
    public $openid;
    public $unionid;
    public $nickname;
    public $img;
    
    /**
     * {@inheritDoc}
     * @see WRest_Object::get_table_name()get_user_by_openid
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wrest_user';
    }

    public function get_nickname(){
        $nickname =  json_decode($this->nickname,true);
        return $nickname&&is_array($nickname)?$nickname['value']:'';
    }
    
    public function get_openid(){
        return isset($this->openid)?$this->openid:'';
    }
    
    public function set_nickname($nickname){
        $this->nickname = json_encode(array(
            'value'=>$nickname
        ));
    }
    /**
     * {@inheritDoc}
     * @see WRest_Object::get_propertys()
     */
    public function get_propertys()
    {
        // TODO Auto-generated method stub
        return array(
            'user_ID'=>null,
            'openid'=>null,
            'unionid'=>null,
            'nickname'=>null,
            'sex'=>null,
            'province'=>null,
            'city'=>null,
            'country'=>null,
            'img'=>null,
            'role'=>'customer',
            'phone'=>null
        );
    }
    
    public function reset_userdata($user_ID=0,$unionid=null,$openid=null,$phone=null){
        global $wpdb;
        $table_name ="{$wpdb->prefix}".$this->get_table_name();
        
        $sql = "delete from {$table_name} where user_ID<>{$user_ID} ";
        
        $where = '';
        if($unionid){
            if($where){
                $where.=' or ';
            }else{
                $where.=' and (';
            }
            $where .= $wpdb->prepare("unionid=%s", $unionid);
        }
        if($openid){
            if($where){
                $where.=' or ';
            }else{
                $where.='and (';
            }
            $where .= $wpdb->prepare(" openid=%s", $openid);
        }
        
        if($phone){
             if($where){
                $where.=' or ';
            }else{
                $where.=' and (';
            }
            $where .= $wpdb->prepare(" phone=%s", $phone);
        }
        
        if($where){
            $where.=')';
        }
        $wpdb->query($sql.$where);
    }
    
    /**
     * 
     * @param string $unionid
     * @return WRest_User
     */
    public function get_user_by_unionid($unionid){
        if(empty($unionid)){
           return new WRest_User();
        }
        
        global $wpdb;
        $table_name ="{$wpdb->prefix}".$this->get_table_name();
    
        $entity = $wpdb->get_row($wpdb->prepare(
           "select *
            from $table_name t
        	inner join {$wpdb->users} p on p.ID = t.user_ID
            where t.unionid=%s
            limit 1;", $unionid));
    
        return new WRest_User($entity);
    }
    
    public function get_user_by_openid($openid){
        if(empty($unionid)){
            return new WRest_User();
        }
    
        global $wpdb;
        $table_name ="{$wpdb->prefix}".$this->get_table_name();
    
        $entity = $wpdb->get_row($wpdb->prepare(
            "select *
            from $table_name t
            inner join {$wpdb->users} p on p.ID = t.user_ID
            where t.openid=%s
            limit 1;", $openid));
    
        return new WRest_User($entity);
    }
    
    /**
     *
     * @param string $phone
     * @return WRest_User
     */
    public function get_user_by_phone($phone){
        if(empty($unionid)){
            return new WRest_User();
        }
    
        global $wpdb;
        $table_name ="{$wpdb->prefix}".$this->get_table_name();
    
        $entity = $wpdb->get_row($wpdb->prepare(
            "select *
            from $table_name t
            inner join {$wpdb->users} p on p.ID = t.user_ID
            where t.phone=%s
            limit 1;", $phone));
    
        return new WRest_User($entity);
    }
}

class WRest_User_Model extends Abstract_WRest_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_user` (
                `user_ID` INT(11) NOT NULL,
                `phone` varchar(32) NULL DEFAULT NULL,
                `openid` varchar(128) NOT NULL,
                `unionid` varchar(128) NOT NULL,
                `nickname` varchar(128) NULL DEFAULT NULL,
                `sex` varchar(128) NULL DEFAULT NULL,
                `province` varchar(128) NULL DEFAULT NULL,
                `city` varchar(128) NULL DEFAULT NULL,
                `country` varchar(128) NULL DEFAULT NULL,
                `img` varchar(512) NULL DEFAULT NULL,
                `role` varchar(16) NOT NULL default 'customer',
                PRIMARY KEY (`user_ID`),
                UNIQUE INDEX `unionid` (`unionid`),
                UNIQUE INDEX `phone` (`phone`),
                UNIQUE INDEX `openid` (`openid`)
            )
            $collate;");

        if(!empty($wpdb->last_error)){
            WRest_Log::error($wpdb->last_error);
            //throw new Exception($wpdb->last_error);
        }
        
        try {
            $column =$wpdb->get_row(
                "select column_name
                from information_schema.columns
                where table_name='{$wpdb->prefix}wrest_user'
                and table_schema ='".DB_NAME."'
				  and column_name ='role'
			limit 1;");
            
            if(!$column||empty($column->column_name)){
                $wpdb->query("alter table `{$wpdb->prefix}wrest_user` add column `role` varchar(16) NOT NULL default 'customer';");
            }
            
            if(!empty($wpdb->last_error)){
                WRest_Log::error($wpdb->last_error);
                //throw new Exception($wpdb->last_error);
            }
        } catch (Exception $e) {
        }
        
        try {
            $column =$wpdb->get_row(
                "select column_name
                from information_schema.columns
                where table_name='{$wpdb->prefix}wrest_user'
                    and table_schema ='".DB_NAME."'
				    and column_name ='phone'
			    limit 1;");
        
            if(!$column||empty($column->column_name)){
                $wpdb->query("alter table `{$wpdb->prefix}wrest_user` add column `phone` varchar(32) NULL default NULL;");
            }
        
            if(!empty($wpdb->last_error)){
                WRest_Log::error($wpdb->last_error);
                //throw new Exception($wpdb->last_error);
            }
        } catch (Exception $e) {
        }
    }
}
?>