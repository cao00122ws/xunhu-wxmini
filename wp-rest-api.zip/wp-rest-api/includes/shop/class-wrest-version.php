<?php
class WRest_Version extends WRest_Object{
	public $id;
	public $content;
	public $created_time;
	public $status;
	public function is_auto_increment(){
		return true;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'id';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_version';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
			'id'=>0,
			'content'=>null,
			'created_time'=>0,
		    'status'=>'draft'
		);
	}
	
	public function get_status_html(){
	    switch ($this->status){
	        case 'draft':
	            return '<span>草稿</span>';
	        case 'publish':
	            return '<span style="color:green;">已发布</span>';
	        default:
	            return $this->status;
	    }
	}
	
	public function get_version_code(){
	    $v = $this->id;
	   
		return "v".join('.', str_split($v));
	}
	
	public function get_download_url(){
	    return WREST_URL."/output/{$this->get_version_code()}.zip";
	}
	
	public function get_download_file(){
	    return WREST_DIR."/output/{$this->get_version_code()}.zip";
	}
	
    public static function get_newest_version(){
        global $wpdb;
        
        $version = $wpdb->get_row(
           "select v.*
            from {$wpdb->prefix}wrest_version v
            order by v.id desc
            limit 1;");
        
        return $version?new WRest_Version($version):null;
    }
    
	public static function save_config($page,$version=null, $config=array()){
	    $obj = null;
	    self::get_config($page,$version,$obj);
		if(!$version){
		    if(!$obj){
		        $v = new WRest_Version();
		        $v->content = json_encode(array(
		            $page=>$config
		        ));
		        $v->created_time = current_time( 'timestamp' );
		        $v->status = 'draft';
		        return $v->insert();
		    }
		}
			
		if(!$obj){
			return WRest_Error::err_code(404);
		}
		
		$_config = json_decode($obj->content,true);
		if(!$_config||!is_array($_config)){$_config=array();}
		
		$_config[$page] = $config;
		
		return $obj->update(array(
			'content'=>json_encode($_config)
		));
	}
	
	/**
	 * 
	 * @param string $page
	 * @param string $version
	 * @param WRest_Version $version_obj
	 */
	public static function get_config($page,$version=null,&$version_obj = null){
		global $wpdb;
		$version_obj = $version
                		&&$version instanceof WRest_Version
                		&&$version->is_load()?$version:null;
		if(!$version_obj){
    		if($version&&is_numeric($version)){
    			$version_obj =  new WRest_Version(absint($version));
    			if(!$version_obj->is_load()){
    			    $version_obj=null;
    			    return array();
    			}
    		}
		}
		
		if(!$version_obj){
		    $version_obj = WRest_Version::get_newest_version();
		}
		
		if(!$version_obj||!$version_obj->is_load()){
		    $version_obj=null;
		    return array();
		}
		
		$configMap = $version_obj->content?json_decode($version_obj->content,true):null;
		$fields = $configMap&&is_array($configMap)&&isset($configMap[$page])?$configMap[$page]:array();		
		if(!$fields||!is_array($fields)){
		    $fields = array();
		}
		
		return $fields;
	}
}

class WRest_Version_Model extends Abstract_WRest_Schema{
	/**
	 * {@inheritDoc}
	 * @see Abstract_XH_Model_Api::init()
	 */
	public function init()
	{
		$collate=$this->get_collate();
		global $wpdb;
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_version` (
					`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
					`content` TEXT NULL DEFAULT NULL,
					`status` varchar(16) NOT NULL DEFAULT 'publish',
					`created_time`  int(11) NOT NULL DEFAULT 0,
					PRIMARY KEY (`id`)
				)
				AUTO_INCREMENT=100
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
		
	}
}