<?php
/**
 * 
 * @author Administrator
 * 兼容 yith-woocommerce-wishlist
 *    ti-woocommerce-wishlist
 * 
 */
class WRest_Wishlist extends WRest_Object{
    const MAX_NUM=200;
	public $id;
	public $obj_id;
	public $obj_type;
	public $user_id;
	public $created_time;
	public function is_auto_increment(){
		return true;
	}
	
	/**
	 * 获取主键名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_primary_key(){
		return 'id';
	}
	
	/**
	 * 获取表名称
	 * @return string
	 * @since 1.0.0
	 */
	public function get_table_name(){
		return 'wrest_wishlist';
	}
	
	/**
	 * 获取属性集合(含默认值)
	 * @return array
	 * @since 1.0.0
	 */
	public function get_propertys(){
		return array(
			'id'=>0,
			'obj_id'=>null,
		    'obj_type'=>null,
		    'user_id'=>null,
			'created_time'=>0
		);
	}
	
	public static function is_in_wishlist($obj_id,$obj_type){
	    if(!is_user_logged_in()){
	        return false;
	    }
	    
	    $user_ID = get_current_user_id();    
	    $hook = apply_filters('wrest_is_in_wishlist', null,$obj_id,$obj_type);
	    if(!is_null($hook)){
	        return $hook;
	    }
	    
	    if(defined('YITH_WCWL')&&class_exists('YITH_WCWL')&&$obj_type=='product'){
	        return YITH_WCWL()->is_product_in_wishlist($obj_id);
	    }
	    
	    if(function_exists('tinv_get_option')&&$obj_type=='product'){
	    	$wl       = new TInvWL_Wishlist( TINVWL_PREFIX);
	    	$wishlist = $wl->add_user_default();
	    	$wishlist = apply_filters( 'tinvwl_addtowishlist_wishlist', $wishlist );
	    	if ( empty( $wishlist ) ) {
	    		return new WP_Error('SYSTEM-ERROR','系统内部错误！',array('status'=>500));
	    	}
	    	
	    	$wlp = new TInvWL_Product( $wishlist, TINVWL_PREFIX );
	    	return $wlp->check_product($obj_id);
	    }
	    
	    $wishlist =  get_user_meta($user_ID,"__wrest_fav_{$obj_type}",true);
	    if(!$wishlist||!is_array($wishlist)){
	        $wishlist = array();
	    }
	    
	    return in_array($obj_id, $wishlist);
	}
	
	public static function remove_wishlist($obj_id,$obj_type){
	    if(!is_user_logged_in()){
	        return new WP_Error('unauthorized','用户未登录!',array('status'=>501));
	    }
	    
	    $result = apply_filters('wrest_remove_wishlist', null,$obj_id,$obj_type);
	    if(!is_null($result)){
	        return $result;
	    }
	    
	    $user_id = get_current_user_id();
	    $prod_id = $obj_id;
	    global $wpdb;
	    if(defined('YITH_WCWL')&&class_exists('YITH_WCWL')&&$obj_type=='product'){
	        $sql = "DELETE FROM {$wpdb->yith_wcwl_items} WHERE user_id = %d AND prod_id = %d";
	        $sql_args = array(
	            $user_id,
	            $prod_id
	        );
	        
	        if( empty( $wishlist_id ) ){
	            $wishlist_id = YITH_WCWL()->generate_default_wishlist( get_current_user_id() );
	        }
	        
	        $wishlist = YITH_WCWL()->get_wishlist_detail( $wishlist_id );
	        YITH_WCWL()->last_operation_token = $wishlist['wishlist_token'];
	        
	        $sql .= " AND wishlist_id = %d";
	        $sql_args[] = $wishlist_id;
	        
	        $result = $wpdb->query( $wpdb->prepare( $sql, $sql_args ) );
	        if ( $result ) {
	            if( YITH_WCWL()->last_operation_token ) {
	                delete_transient( 'yith_wcwl_wishlist_count_' . YITH_WCWL()->last_operation_token );
	            }
	        
	            if( $user_id ) {
	                delete_transient( 'yith_wcwl_user_default_count_' . $user_id );
	                delete_transient( 'yith_wcwl_user_total_count_' . $user_id );
	            }
	        
	            return new WP_REST_Response(array(
	                'isFav'=>false
	            ));
	        }
	        return new WP_Error('SYSTEM-ERROR',__( 'An error occurred while removing products from the wishlist', 'yith-woocommerce-wishlist' ),array('status'=>500));
	    }
	    
	    if(function_exists('tinv_get_option')&&$obj_type=='product'){
	    	$wl       = new TInvWL_Wishlist( TINVWL_PREFIX);
	    	$wishlist = $wl->add_user_default();
	    	$wishlist = apply_filters( 'tinvwl_addtowishlist_wishlist', $wishlist );
	    	if ( empty( $wishlist ) ) {
	    		return new WP_Error('SYSTEM-ERROR','系统内部错误！',array('status'=>500));
	    	}
	    	
	    	$wlp = new TInvWL_Product( $wishlist, TINVWL_PREFIX );
	    	
	    	if($wlp->remove_product_from_wl(0,$prod_id)){
	    		return new WP_REST_Response(array(
	    				'isFav'=>true
	    		));
	    	}
	    	return new WP_Error('SYSTEM-ERROR','系统内部错误！',array('status'=>500));
	    }
	    
	    $wpdb->query("delete from {$wpdb->prefix}wrest_wishlist where obj_id={$obj_id} and obj_type='{$obj_type}' and user_id={$user_id};");
	    $max_num = self::MAX_NUM;
	    $query = $wpdb->get_results(
	        "select w.obj_id
	         from {$wpdb->prefix}wrest_wishlist w
	         inner join {$wpdb->posts} p on p.ID = w.obj_id
	         where p.post_type='product'
	               and p.post_status='publish'
	               and w.user_id={$user_id}
	         order by w.created_time desc
	         limit {$max_num};");
	    $newwishlist=array();
	    if($query){
	        foreach ($query as $item){
	            $newwishlist[]=$item->obj_id;
	        }
	    }
	    update_user_meta($user_id,"__wrest_fav_{$obj_type}",$newwishlist);
	    return new WP_REST_Response(array(
	        'isFav'=>false
	    ));
	}
	
	public static function count($obj_type){
	    if(!is_user_logged_in()){
	        return 0;
	    }
	    
	    $hook = apply_filters('wrest_wishlist_count', null,$obj_type);
	    if(!is_null($hook)){
	        return $hook;
	    }
	    
	    if(defined('YITH_WCWL')&&class_exists('YITH_WCWL')&&$obj_type=='product'){
	       return YITH_WCWL()->count_all_products();
	    }
	    
	    $user_ID = get_current_user_id();
	    if(function_exists('tinv_get_option')&&$obj_type=='product'){
	    	$wl       = new TInvWL_Wishlist( TINVWL_PREFIX);
	    	$wishlist = $wl->add_user_default();
	    	$wishlist = apply_filters( 'tinvwl_addtowishlist_wishlist', $wishlist );
	    	if ( empty( $wishlist ) ) {
	    		return 0;
	    	}
	    	
	    	$wlp = new TInvWL_Product( $wishlist, TINVWL_PREFIX );
	    	global $wpdb;
	    	$query = $wpdb->get_row(
	    		   "select count(ti.ID) as qty
	    			from {$wpdb->prefix}tinvwl_items ti
	    			where ti.wishlist_id={$wlp->wishlist_id()};");
	    	return $query?absint($query->qty):0;
	    }
	    
	    $wishlist =  get_user_meta($user_ID,"__wrest_fav_{$obj_type}",true);
	    if(!$wishlist||!is_array($wishlist)){
	        $wishlist = array();
	    }
	    return count($wishlist);
	}
	
	public static function add_wishlist($obj_id,$obj_type){
	    if(!is_user_logged_in()){
	        return new WP_Error('unauthorized','用户未登录!',array('status'=>501));
	    }
	     
	    $result = apply_filters('wrest_add_wishlist', null,$obj_id,$obj_type);
	    if(!is_null($result)){
	        return $result;
	    }
	    
	    $user_id = get_current_user_id();
	    $prod_id = $obj_id;
	     
	    global $wpdb;
	    if(defined('YITH_WCWL')&&class_exists('YITH_WCWL')&&$obj_type=='product'){
	        global $sitepress;
	        $wishlist_id=null;
	        if( defined('ICL_SITEPRESS_VERSION') ) {
	            $prod_id = yit_wpml_object_id( $prod_id, 'product', true, $sitepress->get_default_language() );
	        }
	        
	        if( $prod_id == false ){
	            return new WP_Error('NOT-found',__( 'An error occurred while adding products to the wishlist.', 'yith-woocommerce-wishlist' ),array('status'=>404));
	        }
	        
	        $insert_args = array(
                'prod_id' => $prod_id,
                'user_id' => $user_id,
                'quantity' => 1,
                'dateadded' =>  date_i18n( 'Y-m-d H:i:s' )
            );
        
            $result = $wpdb->insert( $wpdb->yith_wcwl_items, $insert_args );
            if( $result ){
                if( YITH_WCWL()->last_operation_token ) {
                    delete_transient( 'yith_wcwl_wishlist_count_' . YITH_WCWL()->last_operation_token );
                }
        
                if( $user_id ) {
                    delete_transient( 'yith_wcwl_user_default_count_' . $user_id );
                    delete_transient( 'yith_wcwl_user_total_count_' . $user_id );
                }
                do_action( 'yith_wcwl_added_to_wishlist', $prod_id, $wishlist_id, $user_id );
                return new WP_REST_Response(array(
                    'isFav'=>true
                ));
            }
        
            return new WP_Error('SYSTEM-ERROR',__( 'An error occurred while adding products to wishlist.', 'yith-woocommerce-wishlist' ),array('status'=>500));
	    }
	    
	    if(function_exists('tinv_get_option')&&$obj_type=='product'){
	    	$form                 = apply_filters( 'tinvwl_addtowishlist_prepare_form', filter_input( INPUT_POST, 'form', FILTER_DEFAULT, FILTER_FORCE_ARRAY ) );
	    	if ( empty( $form ) ) {
	    		$form = array();
	    	}
	    	
	    	$quantity       = 1;
	    	$wl       = new TInvWL_Wishlist( TINVWL_PREFIX);
	    	$wishlist = $wl->add_user_default();
	    	$wishlist = apply_filters( 'tinvwl_addtowishlist_wishlist', $wishlist );
	    	if ( empty( $wishlist ) ) {
	    		return new WP_Error('SYSTEM-ERROR','系统内部错误！',array('status'=>500));
	    	}
	    	
	    	$wlp = new TInvWL_Product( $wishlist, TINVWL_PREFIX );
	    	
	    	if($wlp->add_product( apply_filters( 'tinvwl_addtowishlist_add', array(
	    			'product_id' => $prod_id,
	    			'quantity'   => $quantity,
	    	)))){
	    		return new WP_REST_Response(array(
	    				'isFav'=>true
	    		));
	    	}
	    	
	    	return new WP_Error('SYSTEM-ERROR','系统内部错误！',array('status'=>500));
	    }
	    
	    $wishlist = new WRest_Wishlist();
	    $wishlist->obj_id = $prod_id;
	    $wishlist->obj_type = $obj_type;
	    $wishlist->created_time = current_time( 'timestamp');
	    $wishlist->user_id = $user_id;
	    $error = $wishlist->insert();
	    if(!WRest_Error::is_valid($error)){
	        return $error;
	    }
	    $max_num = self::MAX_NUM;
	    $query = $wpdb->get_results(
	        "select w.obj_id
	         from {$wpdb->prefix}wrest_wishlist w
	         inner join {$wpdb->posts} p on p.ID = w.obj_id
	         where p.post_type='product'
	               and p.post_status='publish'
	               and w.user_id={$user_id}
	         order by w.created_time desc
	         limit {$max_num};");
	    $newwishlist=array();
	    if($query){
	        foreach ($query as $item){
	            $newwishlist[]=$item->obj_id;
	        }
	    }
	    update_user_meta($user_id,"__wrest_fav_{$obj_type}",$newwishlist);
	    return new WP_REST_Response(array(
	        'isFav'=>true
	    ));
	}
	
	public static function get_wishlist($pageIndex,$pageSize,$obj_type){
	    $result = apply_filters('wrest_get_wishlist', false,$pageIndex,$pageSize,$obj_type);
	    if($result!==false){
	        return $result;
	    }
	    
	    if($pageIndex<1){$pageIndex = 1;}
	   
	    if(!is_user_logged_in()){
	        return new WP_Error('NOT-log-in','未登录！',array('status'=>501));
	    }
	    if(defined('YITH_WCWL')&&class_exists('YITH_WCWL')&&$obj_type=='product'){
    	    global $wpdb;
    	    $user_id = get_current_user_id();
    	    $sql = "select count(p.ID) as qty
            	    from {$wpdb->prefix}yith_wcwl w
            	    inner join {$wpdb->posts} p on p.ID = w.prod_id
            	    where p.post_type='product'
                	    and p.post_status='publish'
                	    and w.user_id={$user_id}";
    	    $query = $wpdb->get_row($sql);
    	    
    	    $total_qty = $query?absint($query->qty):0;
    	     
    	    $start = ($pageIndex-1)*$pageSize;
    	     
    	    $sql =  "select p.ID
            	    from {$wpdb->prefix}yith_wcwl w
            	    inner join {$wpdb->posts} p on p.ID = w.prod_id
            	    where p.post_type='product'
                	    and p.post_status='publish'
                	    and w.user_id={$user_id}";
    	    
    	    $items = $wpdb->get_results(
    	        $sql
    	        ." order by w.dateadded desc
    	        limit {$start},{$pageSize};"
    	    );
    	    $results = array();
    	    if($items){
    	        foreach ($items as $item){
    	            $results[]=$item->ID;
    	        }
    	    }
    	    
    	    return array(
    	        'items'=>$results,
    	        'total_count'=>$total_qty
    	    );
	    }
	   
	    if(function_exists('tinv_get_option')&&$obj_type=='product'){
	    	$wl       = new TInvWL_Wishlist( TINVWL_PREFIX);
	    	$wishlist = $wl->add_user_default();
	    	$wishlist = apply_filters( 'tinvwl_addtowishlist_wishlist', $wishlist );
	    	if ( empty( $wishlist ) ) {
	    		return 0;
	    	}
	    	
	    	$wlp = new TInvWL_Product( $wishlist, TINVWL_PREFIX );
	    	global $wpdb;
	    	$query = $wpdb->get_row(
	    		   "select count(ti.ID) as qty
	    			from {$wpdb->prefix}tinvwl_items ti
					inner join {$wpdb->posts} p on p.ID = ti.product_id
        	        where p.post_type='{$obj_type}'
            	      and p.post_status='publish'
            	      and ti.wishlist_id={$wlp->wishlist_id()};");
	    	$total_qty = $query?absint($query->qty):0;
	    	$start = ($pageIndex-1)*$pageSize;
	    	
	    	$sql =  "select p.ID
	    			from {$wpdb->prefix}tinvwl_items ti
					inner join {$wpdb->posts} p on p.ID = ti.product_id
        	        where p.post_type='{$obj_type}'
            	      	  and p.post_status='publish'
            	      	  and ti.wishlist_id={$wlp->wishlist_id()}";
	    	
	    	$items = $wpdb->get_results(
	    			$sql
	    			." order by ti.date desc
	    			limit {$start},{$pageSize};"
	    	);
	    	
	    	$results = array();
	    	if($items){
	    		foreach ($items as $item){
	    			$results[]=$item->ID;
	    		}
	    	}
	    	
	    	return array(
	    			'items'=>$results,
	    			'total_count'=>$total_qty
	    	);
	    }
	    
	    global $wpdb;
	    $user_id = get_current_user_id();
	    $sql = "select count(p.ID) as qty
        	    from {$wpdb->prefix}wrest_wishlist w
        	    inner join {$wpdb->posts} p on p.ID = w.obj_id
        	    where p.post_type='{$obj_type}'
        	          and w.obj_type='{$obj_type}'
            	      and p.post_status='publish'
            	      and w.user_id={$user_id}";
	    $query = $wpdb->get_row($sql);
	    $max_num = self::MAX_NUM;
	    $total_qty = $query?absint($query->qty):0;
	    if($total_qty>$max_num){$total_qty=$max_num;}
	    $start = ($pageIndex-1)*$pageSize;
	    
	    $sql =  "select p.ID
	             from {$wpdb->prefix}wrest_wishlist w
        	     inner join {$wpdb->posts} p on p.ID = w.obj_id
        	     where p.post_type='{$obj_type}'
        	          and w.obj_type='{$obj_type}'
            	      and p.post_status='publish'
            	      and w.user_id={$user_id}";
	    	
	    $items = $wpdb->get_results(
	        $sql
	        ." order by w.created_time desc
	        limit {$start},{$pageSize};"
	    );
	    
	    $results = array();
	    if($items){
	        foreach ($items as $item){
	            $results[]=$item->ID;
	        }
	    }
	    
	    return array(
	        'items'=>$results,
	        'total_count'=>$total_qty
	    );
	}
}

class WRest_Wishlist_Model extends Abstract_WRest_Schema{
	/**
	 * {@inheritDoc}
	 * @see Abstract_XH_Model_Api::init()
	 */
	public function init()
	{
		$collate=$this->get_collate();
		global $wpdb;
		$wpdb->query(
				"CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wrest_wishlist` (
					`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
					`obj_id` BIGINT(20) NOT NULL DEFAULT 0,
					`user_id` BIGINT(20) NOT NULL DEFAULT 0,
					`obj_type` VARCHAR(32) NOT NULL DEFAULT 'post',
					`created_time` int(11) NOT NULL DEFAULT 0,
					PRIMARY KEY (`id`)
				)
				$collate;");
		
		if(!empty($wpdb->last_error)){
			WRest_Log::error($wpdb->last_error);
			throw new Exception($wpdb->last_error);
		}
		
	}
}