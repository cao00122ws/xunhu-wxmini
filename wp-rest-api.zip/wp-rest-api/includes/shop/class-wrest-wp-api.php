<?php
if (! defined('ABSPATH')) {
    exit();
}

/**
 * wordpress apis
 *
 * @author rain
 * @since 1.0.0
 */
class WRest_WP_Api
{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WRest_WP_Api
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     *
     * @return WRest - Main instance.
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    private function __construct()
    {}
    
    public function copyDir($dirSrc,$dirTo){
        if(!$dirSrc||!@is_dir($dirSrc)){
            throw new Exception("插件加载失败：目录无权限读取或不存在({$dirSrc})");
        }
    
        if(!$dirTo||(!@is_dir($dirTo)&&!@mkdir($dirTo,0777,true))){
            throw new Exception("插件加载失败：目录无权限读写({$dirTo})");
        }
    
        $handle = @opendir($dirSrc);
        try {
            while (($item = @readdir($handle)) !== false) {
                if ($item == '.' || $item == '..'){
                    continue;
                }
                 
                $_source = $dirSrc . '/' . $item;
                $_dest = $dirTo . '/' . $item;
                
                if (@is_file($_source)){
                    if(!@copy($_source, $_dest)){
                        throw new Exception("插件加载失败：目录拷贝失败({$_source})");
                    }   
                }
                if (@is_dir($_source)){
                    $this->copyDir($_source, $_dest);
                }
            }
        } catch (Exception $e) {
        }
        
        @closedir($handle);
    }
    
    public function removeDir($dir) {
        //先删除目录下的文件：
        $dh=@opendir($dir);
        if(!$dh){
            return true;
        }
         
        while (($file=@readdir($dh))!==false) {
            if(!$file||$file=="." || $file=="..") {
                continue;
            }
    
            $fullpath=$dir."/".$file;
            if(!@is_dir($fullpath)) {
                if(!@unlink($fullpath)){
                    return false;
                }
            } else {
                if(!$this->removeDir($fullpath)){
                    return false;
                }
            }
        }
         
        @closedir($dh);
        return @rmdir($dir);
    }
    
    public function get_version($request){
        $version_id = absint(str_replace(array('.','v'), '', $request->get_param('version')));
        $version = new WRest_Version($version_id,true);
        if(!$version->is_load()){
            return new WP_Error('system','The request version is not found',array('status'=>404));
        }
        return $version;
    }
    
    public function get_smallprogram_base_dir($file = '/'){
        if(strpos($file, '/')!==0){
            $file ="/{$file}";
        }
        return WREST_DIR."/output/v2".$file;
    }
    
    public function convert_remoteimage_to_local($remote_image_url,$basedir){
        if(!$remote_image_url){
            throw new Exception("读取远程文件失败：文件地址不能为空");
        }
        if(!$basedir){
            throw new Exception("读取远程文件失败：本地文件地址不能为空");
        }
         
        if(substr($basedir, -1)!=='/'){
            $basedir.='/';
        }
         
        if(strpos($basedir, '/')!==0){
            $basedir='/'.$basedir;
        }
         
        $localdir = $this->get_smallprogram_base_dir($basedir);
        if(!@is_dir($localdir)){
        	if(!@mkdir($localdir,0777,true)){
                throw new Exception("读取远程文件失败：本地文件目录创建失败,{$localdir}");
            }
        }
        if(stripos($remote_image_url, 'http://')===0&&stripos($remote_image_url, 'https://')===0){
            throw new Exception("读取远程文件失败：文件地址类型异常，{$remote_image_url}");
        }
        $info = pathinfo($remote_image_url);
        $basename = $info&&is_array($info)&&isset($info['basename'])&&$info['basename']?$info['basename']:null;
        if(!$basename){
            throw new Exception("读取远程文件失败：文件名读取失败，{$remote_image_url}");
        }
        
        $basenames = explode('?', $basename);
        $basename = $basenames[0];
        if(empty($basename)){
            throw new Exception("读取远程文件失败：文件名信息异常，{$remote_image_url}");
        }
        
        $p = strpos($basename, '.');
        if($p!==false){
            $basename = md5($remote_image_url).substr($basename, $p);
        }else{
            $basename = md5($remote_image_url);
        }
        
        $localpath = $this->get_smallprogram_base_dir($basedir.$basename);
        if(@file_exists($localpath)){
           @unlink($localpath);
        }
         
        $img = null;
        $real_path = str_replace(home_url('/'), str_replace('\\', '/', ABSPATH), $remote_image_url);
        if(@file_exists($real_path)){
            $img = @file_get_contents($real_path);
        }
        
        if(!$img){
            try {
                $img = WRest_Helper_Http::http_get($remote_image_url,false,null,10);
            } catch (Exception $e) {
                throw new Exception("读取远程文件失败：{$remote_image_url}，网络异常：".$e->getMessage());
            }
        }
        
        if(!$img){
            throw new Exception("读取远程文件失败：{$remote_image_url}");
        }
         
        if(!@file_put_contents($localpath, $img)){
            throw new Exception("文件写入失败：{$localpath}");
        }
         
        return $basedir.$basename;
    }
    
    /**
     * @since 1.0.0
     */
    public function get_plugin_settings_url()
    {
        return admin_url("admin.php?page=wrest_page_add_ons");
    }

    /**
     * 判断当前用户是否允许操作
     * 
     * @param array $roles   
     * @deprecated 1.0.0 Use get_user_by()         
     * @since 1.0.0
     */
    public function capability($roles = array('administrator'))
    {
        _deprecated_function( __FUNCTION__, '1.0.0', "capability('roles')" );
      
        global $current_user;
        if (! is_user_logged_in()) {}
        
        if (! $current_user->roles || ! is_array($current_user->roles)) {
            $current_user->roles = array();
        }
        
        foreach ($roles as $role) {
            if (in_array($role, $current_user->roles)) {
                return true;
            }
        }
        return false;
    }

   
    /**
     *
     * @since 1.0.9
     * @param array $request            
     * @param bool $validate_notice            
     * @return bool
     */
    public function ajax_validate( $request, $hash, $validate_notice = true)
    {
        if (is_null($hash)||empty($hash)||WRest_Helper::generate_hash($request, WRest::instance()->get_hash_key()) != $hash) {
            return false;
        }

        return true;
    }

    /**
     * 设置错误
     * 
     * @param string $key            
     * @param string $error            
     * @since 1.0.5
     */
    public function set_wp_error($key, $error)
    {
        WRest::instance()->session->set("error_{$key}", $error);
    }

    /**
     * 清除错误
     * 
     * @param string $key            
     * @param string $error            
     * @since 1.0.5
     */
    public function unset_wp_error($key)
    {
        WRest::instance()->session->__unset("error_{$key}");
    }

    /**
     * 获取错误
     * 
     * @param string $key            
     * @param string $error            
     * @since 1.0.5
     */
    public function get_wp_error($key, $clear = true)
    {
        $cache_key = "error_{$key}";
        $session = WRest::instance()->session;
        $error = $session->get($cache_key);
        if ($clear) {
            $this->unset_wp_error($key);
        }
        return $error;
    }
    public function wp_success($msg = null, $include_header_footer = true, $exit = true)
    {
        WRest_Temp_Helper::set('atts', array(
            'msg' => $msg,
            'include_header_footer' => $include_header_footer
        ), 'templete');
    
        ob_start();
        require WRest::instance()->WP->get_template(WREST_DIR, 'wp-success.php');
        echo ob_get_clean();
        if ($exit) {
            exit();
        }
    }
    /**
     * wp die
     * 
     * @param Exception|WRest_Error|WP_Error|string|object $err            
     * @since 1.0.0
     */
    public function wp_die($err = null, $include_header_footer = true, $exit = true)
    {
        WRest_Temp_Helper::set('atts', array(
            'err' => $err,
            'include_header_footer' => $include_header_footer
        ), 'template');
        
        ob_start();
        require WRest::instance()->WP->get_template(WREST_DIR, 'wp-die.php');
        echo ob_get_clean();
        if ($exit) {
            exit();
        }
    }

    /**
     * 获取插件列表
     * 
     * @return NULL|Abstract_WRest_Add_Ons[]
     */
    public function get_plugin_list_from_system()
    {
        $content_dir = WP_CONTENT_DIR;
        $base_dirs = array(
            str_replace('\\', '/', $content_dir).'/wrestization/add-ons/',
            str_replace('\\', '/', $content_dir).'/wp-rest-api/add-ons/',
            WREST_DIR . '/add-ons/'
        );
        
        $plugins = array();
        
        $include_files = array();
        
        foreach ($base_dirs as $base_dir) {
            try {
                if (! is_dir($base_dir)) {
                    continue;
                }
                
                $handle = opendir($base_dir);
                if (! $handle) {
                    continue;
                }
             
                try {
                    while (($file = readdir($handle)) !== false) {
                        
                        if (empty($file) || $file == '.' || $file == '..' || $file == 'index.php') {
                            continue;
                        } 
                        if (in_array($file, $include_files)) {
                            continue;
                        }
                        // 排除多个插件目录相同插件重复includ的错误
                        $include_files[] = $file;
                        
                        try {
                            if (strpos($file, '.') !== false) {
                                if (stripos($file, '.php') === strlen($file) - 4) {
                                    $file = str_replace("\\", "/", $base_dir . $file);
                                }
                            } else {
                                $file = str_replace("\\", "/", $base_dir . $file . "/init.php");
                            }
                           
                            if (file_exists($file)) {
                                $add_on = null;
                                
                                if (isset(WRest::instance()->plugins[$file])) {
                                    // 已安装
                                    $add_on = WRest::instance()->plugins[$file];
                                } else {
                                    // 未安装
                                    $add_on = require_once $file;
                                    
                                    if ($add_on && $add_on instanceof Abstract_WRest_Add_Ons) {
                                        $add_on->is_active = false;
                                        WRest::instance()->plugins[$file] = $add_on;
                                    } else {
                                        $add_on = null;
                                    }
                                }
                                
                                if ($add_on) {
                                    $plugins[$file] = $add_on;
                                }
                            }
                        } catch (Exception $e) {}
                    }
                } catch (Exception $e) {}
                
                closedir($handle);
            } catch (Exception $e) {}
        }
        
        return $plugins;
    }

    /**
     *
     * @param string $dir            
     * @param string $template_name            
     * @param mixed $params            
     * @return string
     */
    public function requires($dir, $template_name, $params = null,$require=false)
    {
        if (! is_null($params)) {
            WRest_Temp_Helper::set('atts', $params, 'templates');
        }
        $dir =apply_filters('wrest_require_dir', $dir,$template_name);
        if($require){
            return require $this->get_template($dir, $template_name);
        }else{
            ob_start();
            require $this->get_template($dir, $template_name);
            return ob_get_clean();
        }
    }

    /**
     *
     * @param string $page_template_dir            
     * @param string $page_template            
     * @return string
     * @since 1.0.0
     */
    public function get_template($page_template_dir, $page_template)
    {
        if (file_exists(STYLESHEETPATH . '/wp-rest-api/' . $page_template)) {
            return STYLESHEETPATH . '/wp-rest-api/' . $page_template;
        }
        
        return apply_filters('wrest_get_template', $page_template_dir . '/templates/' . $page_template,$page_template_dir, $page_template);
    }
    
}