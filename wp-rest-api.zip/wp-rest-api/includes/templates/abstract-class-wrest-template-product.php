<?php
abstract class Abstract_WRest_Template_Product extends Abstract_WRest_Template{
    public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);
    
        $this->title ="商品";
        $product_api = WRest::instance()->get_product_api();
        $this->init_form_fields( array(
            'modal'=>array(
                'title'=>'商品布局',
                'type'=>'select',
                'default'=>'small',
                'options'=>$this->get_modals()
            )
        ));
    }
    
    public function get_modals(){
        return array(
            'big'=>'大图',
            'small'=>'小图',
            '1big2small'=>'一大两小',
            'detail'=>'详细列表',
            'oneline3'=>'一行三个（幻灯片）',
            'swip'=>'横向滑动',
        );
    }
    
    protected function get_product_list($image_size){
        $cacheKey = $this->get_template_cache_key();
        $productList = WRest_Cache_Helper::get($cacheKey, 'wrest::product::list');
        if(!$productList){
            $api = WRest::instance()->get_product_api();
            $productListQuery =  $api->get_product_list($this->version,$this->get_config(),$image_size);
            $productList = $productListQuery?$productListQuery['items']:array();
            WRest_Cache_Helper::set($cacheKey, $productList,  'wrest::product::list');
        }
        return $productList;
    }
    
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
         
        $api = WRest::instance()->get_product_api();
    
        switch ($config['modal']){
            case 'swip':
                $config_item = $config;
                $config_item['items'] = $this->get_product_list('gallery_thumbnail');
                $config_item['id']=WRest_Helper::generate_unique_id();
    
                $templates[] = $config_item;
                break;
            case 'detail':
                $items =$this->get_product_list('gallery_thumbnail');
                if($items){
                    foreach ($items as $item){
                        $config_item = $config;
                        $config_item['item'] = $item;
                        
                        $templates[] = $config_item;
                    }
                }
                break;
            case 'big':
                $items =$this->get_product_list('full');
                if($items){
                    foreach ($items as $item){
                        $config_item = $config;
                        $config_item['item'] = $item;
                        $config_item['id']=WRest_Helper::generate_unique_id();
                        $templates[] = $config_item;
                    }
                }
                break;
            case 'small':
                $config_item = null;
                $items =$this->get_product_list('woocommerce_single');
                if($items){
                    for($index=0;$index<count($items);$index++){
                        if($index%2==0){
                            $config_item = $config;
                            $config_item['id']=WRest_Helper::generate_unique_id();
                            $config_item['left']=$items[$index];
                            $config_item['right'] = null;
                        }else if($index%2==1){
                            $config_item['right']=$items[$index];
                            $templates[] = $config_item;
                            $config_item = null;
                        }
                    }
    
                    if($config_item){
                        $templates[] = $config_item;
                    }
                }
                //012 345
                break;
            case '1big2small':
                $items =$this->get_product_list('woocommerce_single');
                if(!$items){return;}
                $config_item=null;
                for($index=0;$index<count($items);$index++){
                    if($index%3==0){
                        $config_item = $config;
                        $config_item['modal'] = 'big';
                        $config_item['item'] = $items[$index];
                        $config_item['id']=WRest_Helper::generate_unique_id();
                        $templates[] = $config_item;
                        $config_item=null;
                    }else if(($index+2)%3==0){
                        $config_item = $config;
                        $config_item['id']=WRest_Helper::generate_unique_id();
                        $config_item['modal'] = 'small';
                        $config_item['left']=$items[$index];
                        $config_item['right'] = null;
                    }else if(($index+2)%3==1){
                        $config_item['modal'] = 'small';
                        $config_item['right']=$items[$index];
                        $config_item['id']=WRest_Helper::generate_unique_id();
                        $templates[] = $config_item;
                        $config_item = null;
                    }
                }
    
                if($config_item){
                    $templates[] = $config_item;
                }
    
                break;
            case 'oneline3':
                $sdk = $request->get_param('sdk');
//                 if($sdk&&version_compare($sdk, '1.0.1','>=')){
//                     $items =$this->get_product_list('gallery_thumbnail');
//                     if(!$items){return;}
//                     $lines = array();
//                     $line = null;
//                     $config_item = null;
                    
//                     for($index=0;$index<count($items);$index++){
//                         if($index%3==0){
//                             $config_item = $config;
//                             $config_item['id']=WRest_Helper::generate_unique_id();
//                             $config_item['left']=$items[$index];
//                             $config_item['middle'] = null;
//                             $config_item['right'] = null;
//                         }else if($index%3==1){
//                             $config_item['middle']=$items[$index];
//                         }else if($index%3==2){
//                             $config_item['right']=$items[$index];
                            
//                             if(!$line){
//                                 $line = array();
//                                 $line[]=$config_item;
//                             }else{
//                                 $line[]=$config_item;
//                                 $lines[]=$line;
//                                 $line=null;
//                             }
                            
//                             $config_item = null;
//                         }
//                     }
                    
//                     if($config_item){
//                         if(!$line){
//                             $line = array($config_item);
//                         } else{
//                             $line[]=$config_item;
//                         }
//                     }
                    
//                     if($line){
//                         $lines[]=$line;
//                     }
                    
//                     $config['items'] = $lines;
//                     $theme = new WRest_Menu_Store_Theme($this->version);
//                     $theme_size = absint($theme->get_option('size'));
                    
//                     $height = 0;
                    
//                     //图片高度
//                     $height += round((750 - $theme_size / 2 * 4) / 3,2);
                    
//                     //p15
//                     $height += $theme_size/2;
//                     //标题
//                     $height += 2 * round(absint($theme->get_option('fontsize_sub')) * WRest_Menu_Store_Theme::get_lineheight(),2);
//                     //mT15
//                     $height += $theme_size / 2;
//                     //价格
//                     $height += 70;
//                     //p15
//                     $height += $theme_size / 2;
                    
//                     //显示两行
//                     $count = 0;
//                     foreach ($config['items'] as $line){
//                         $count = max(array($count,count($line)));
//                     }
                    
//                     $height *= $count;
                    
//                     //首尾p15
//                     $height += ($theme_size / 2);
//                     $config['swiperHeight'] = $height;
                    
//                     $templates[] = $config;
//                 }else{
                    $items =$this->get_product_list('gallery_thumbnail');
                    if(!$items){return;}
                    $config_item = null;
                    
                    for($index=0;$index<count($items);$index++){
                        if($index%3==0){
                            $config_item = $config;
                            $config_item['id']=WRest_Helper::generate_unique_id();
                            $config_item['left']=$items[$index];
                            $config_item['middle'] = null;
                            $config_item['right'] = null;
                        }else if($index%3==1){
                            $config_item['middle']=$items[$index];
                        }else if($index%3==2){
                            $config_item['right']=$items[$index];
                            $templates[] = $config_item;
                            $config_item = null;
                        }
                    }
                    
                    if($config_item){
                        $templates[] = $config_item;
                    }
               // }
                
                
                break;
        }
    }
   
    public function __preview(){
        parent::__preview();
        
        $icon = new WRest_Menu_Store_Icon($this->version);
        $icon_cart_add = $icon->get_option('cart_add')
        ?>
        <script type="text/javascript">
    		(function($){
        		window.productView_<?php echo $this->get_template_key()?>=function(config,callback){
    				var request ={
    					config:JSON.stringify(config)
    				};
    				
    				jQuery.ajax({
    		            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'load_products','version'=>$this->version->id),true,true)?>',
    		            type: 'post',
    		            timeout: 60 * 1000,
    		            async: true,
    		            cache: false,
    		            data: request,
    		            dataType: 'json',
    		            beforeSend  : function (XMLHttpRequest) {
    		                XMLHttpRequest.setRequestHeader("request_type","ajax");
    		                $('#<?php echo $this->get_template_key() ?>').loading('show');
    		            },
    		            complete: function() {
    		            	$('#<?php echo $this->get_template_key() ?>').loading('hide');
    		            	window.templateView.loading=false;
    		            },
    		            success: function(m) {
    		            	if(m.errcode!=0){
    							return;
    						}
    						
    						var items = m.data;
    						var num = config.num;
    						var html = '<div class="rc-design-vue-preview rc-design-component-goods-list-preview" style="min-height:100px;">';
    						if(!items){items=[];}
    						var cart_img ='<?php echo $icon_cart_add&&is_array($icon_cart_add)&&isset($icon_cart_add['url'])?$icon_cart_add['url']:''?>';
    		            	switch(config.modal){
    							case 'big':
    								html+='<div class="cap-goods-list">\
    										<ul class="xh-column xh-w xh-column-c" >';
    											for(var index=0;index<items.length;index++){
    												if(index>=num){break;}
    												var item = items[index];
    												if(!item.image){item.image={url:'',width:0,height:0};}
    												html+='<li class="xh-panel xh-mT15 xh-mL15 xh-mR15" style="width:305px">\
																<div class="cap-goods-list__photo">\
        															<div class="cap-goods__img-wrap" style="width:305px;height:'+(305/item.image.width*item.image.height)+'px">\
        																<img class="cap-goods__img--cover" style="width:305px;height:'+(305/item.image.width*item.image.height)+'px" src="'+item.image.url+'">\
        															</div>\
    															</div>\
																<div class="xh-column xh-w">\
																	<h3 class="xh-row xh-c-main-i xh-f-main-i multi-ellipsis xh-H-sub-2 xh-m15" style="width:260px;">'+item.name+'</h3>\
																	<div class="xh-row xh-w" style="justify-content:space-between;">\
    																	<div class="xh-row xh-price-h-min single-ellipsis xh-m15" style="max-width:250px;">'+item.price_html+'</div>\
    																	<img src="'+cart_img+'" class="xh-m15" style="width:18px;height:18px;float:right; margin-right:5px;" />\
																	</div>\
																</div>\
    														</li>';
    											}
    								html+='</ul></div>';
    								break;
    							case 'small':
    								html+='<div class="cap-goods-list">';
                								for(var index=0;index<items.length;(index+=2)){
            										if(index>=config.num){break;}
            										
            										var left = items[index];
            										var right = (index+1)>=items.length?null:items[index+1];
                										
            										if(!left.image){left.image={url:'',width:0,height:0};}
            										if(right&&!right.image){right.image={url:'',width:0,height:0};}

            										html+='<ul class="xh-row xh-c xh-w-720 xh-mT15 xh-radius" style="justify-content:flex-start;align-items:flex-start;" >';
            										if(left){
            											html+='<li class="cap-goods-list__wrapper xh-column xh-panel xh-radius" style="width:'+((320-__config__.theme_size/2*3)/2)+'px">\
                    													<div class="cap-goods-list__photo">\
                    													<div class="cap-goods__img-wrap" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/left.image.width*left.image.height)+'px">\
                    														<img class="cap-goods__img--cover" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/left.image.width*left.image.height)+'px" src="'+left.image.url+'">\
                    													</div>\
                    												</div>\
                    												<div class="xh-column xh-w">\
                    													<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="max-width:130px;">'+left.name+'</div>\
                    													<div class="xh-row xh-price-h-min single-ellipsis xh-m15"  style="max-width:130px;">'+left.price_html+'</div>\
                    												</div>\
                    											</li>';
                									}
                									if(right){
                										html+='<li class="cap-goods-list__wrapper xh-column xh-panel xh-radius" style="margin-left:7px;width:'+((320-__config__.theme_size/2*3)/2)+'px">\
            													<div class="cap-goods-list__photo">\
            													<div class="cap-goods__img-wrap" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/right.image.width*right.image.height)+'px">\
            														<img class="cap-goods__img--cover" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/right.image.width*right.image.height)+'px" src="'+right.image.url+'">\
            													</div>\
            												</div>\
            												<div class="xh-column xh-w">\
            													<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="max-width:130px;">'+right.name+'</div>\
            													<div class="xh-row xh-price-h-min single-ellipsis xh-m15"  style="max-width:130px;">'+right.price_html+'</div>\
            												</div>\
            											</li>';
                    								}
            										html+='</ul>';
            									}
    									
    									html+='</div>';
    									break;
    							case '1big2small' :
    								html+='<div class="cap-goods-list">';
											for(var index=0;index<items.length;index+=3){
												if(index>=num){break;}
												var item = items[index];
												if(!item.image){item.image={url:'',width:0,height:0};}
												html+='<ul class="xh-column xh-w xh-column-c" >\
														  <li class="cap-goods-list__wrapper xh-panel xh-mT15 xh-mL15 xh-mR15" style="width:305px">\
    															<div class="cap-goods-list__photo">\
    																<div class="cap-goods__img-wrap" style="width:305px;height:'+(305/item.image.width*item.image.height)+'px">\
    																	<img class="cap-goods__img--cover" style="width:305px;height:'+(305/item.image.width*item.image.height)+'px" src="'+item.image.url+'">\
    																</div>\
    															</div>\
    															<div class="xh-column xh-w">\
    																<h3 class="xh-row xh-c-main-i xh-f-main-i multi-ellipsis xh-H-main-2 xh-m15" style="width:260px;">'+item.name+'</h3>\
    																<div class="xh-row xh-w" style="justify-content:space-between;">\
    																	<div class="xh-row xh-price-h-min single-ellipsis xh-m15" style="max-width:250px;">'+item.price_html+'</div>\
    																	<img src="'+cart_img+'" class="xh-m15" style="width:18px;height:18px;float:right; margin-right:5px;" />\
    																</div>\
    															</div>\
															</li>\
														</ul>';

												var left = (index+1)>=items.length?null:items[index+1];
        										var right = (index+2)>=items.length?null:items[index+2];
            										
        										if(left&&!left.image){left.image={url:'',width:0,height:0};}
        										if(right&&!right.image){right.image={url:'',width:0,height:0};}

        										html+='<ul class="xh-row xh-c xh-w-720 xh-mT15 xh-radius" style="justify-content:flex-start;align-items:flex-start;" >';
        										if(left){
        											html+='<li class="cap-goods-list__wrapper xh-column xh-panel xh-radius" style="width:'+((320-__config__.theme_size/2*3)/2)+'px">\
                													<div class="cap-goods-list__photo">\
                													<div class="cap-goods__img-wrap" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/left.image.width*left.image.height)+'px">\
                														<img class="cap-goods__img--cover" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/left.image.width*left.image.height)+'px" src="'+left.image.url+'">\
                													</div>\
                												</div>\
                												<div class="xh-column xh-w">\
                													<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="max-width:130px;">'+left.name+'</div>\
                													<div class="xh-row xh-price-h-min single-ellipsis xh-m15"  style="max-width:130px;">'+left.price_html+'</div>\
                												</div>\
                											</li>';
            									}
            									if(right){
            										html+='<li class="cap-goods-list__wrapper xh-column xh-panel xh-radius" style="margin-left:7px;width:'+((320-__config__.theme_size/2*3)/2)+'px">\
        													<div class="cap-goods-list__photo">\
        													<div class="cap-goods__img-wrap" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/right.image.width*right.image.height)+'px">\
        														<img class="cap-goods__img--cover" style="width:'+((320-__config__.theme_size/2*3)/2)+'px;height:'+(((320-__config__.theme_size/2*3)/2)/right.image.width*right.image.height)+'px" src="'+right.image.url+'">\
        													</div>\
        												</div>\
        												<div class="xh-column xh-w">\
        													<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="max-width:130px;">'+right.name+'</div>\
        													<div class="xh-row xh-price-h-min single-ellipsis xh-m15"  style="max-width:130px;">'+right.price_html+'</div>\
        												</div>\
        											</li>';
                								}
        										html+='</ul>';
											}
									html+='</div>';
									break;	
    							case 'detail':
    								html+='<div class="cap-goods-list xh-panel">\
    										<ul class="cap-goods-list__container cap-goods-list__container--list cap-goods-list__container--card">';
    									
    										for(var index=0;index<items.length;index++){
    											if(index>=config.num){break;}
    											var item = items[index];
    											if(!item.image){item.image={url:'',width:0,height:0};}
    											html+='<li class="xh-row xh-w750 xh-panel xh-solid-b">\
        													<img src="'+item.image.url+'" style="width:90px;height:90px;" />\
            												<div class="xh-column xh-w xh-mL15" style="justify-content:space-between;">\
                												<div class="xh-row xh-sub xh-c-main xh-f-sub xh-w">\
                    								                <span class=" multi-ellipsis xh-H-sub-2" >'+item.name+'</span>\
                    								            </div>\
                    								            <view class="xh-row xh-mT15 xh-w" style="justify-content:flex-start;">\
                        							                <div class="xh-row xh-price-h-min single-ellipsis">'+item.price_html+'</div>\
                        							                <div class="xh-row" style="flex:1;justify-content:flex-end;">\
                        							                <img src="'+cart_img+'" class="xh-m15" style="width:18px;height:18px;float:right; margin-right:5px;" />\
                    							                </div>\
                    							            </div>\
        											   </li>';
    										}
    								html+='</ul></div>';
    								break;
    							case 'oneline3':
    								html+='<div class="cap-goods-list">';
    								for(var index=0;index<items.length;(index+=3)){
										if(index>5){break;}
										
										var left = items[index];
										var middle = (index+1)>=items.length?null:items[index+1];
										var right = (index+2)>=items.length?null:items[index+2];
    										
										if(left&&!left.image){left.image={url:'',width:0,height:0};}
										if(middle&&!middle.image){middle.image={url:'',width:0,height:0};}
										if(right&&!right.image){right.image={url:'',width:0,height:0};}
										
										html+='<ul class="xh-row xh-c xh-w-720 xh-mT15 xh-radius" style="justify-content:flex-start;align-items:flex-start;" >';
										if(left){
											html+='<li class="cap-goods-list__wrapper xh-column xh-panel xh-radius" style="width:'+((320-__config__.theme_size/2*4)/3)+'px">\
														<div class="cap-goods-list__photo">\
        													<div class="cap-goods__img-wrap" style="width:'+((320-__config__.theme_size/2*4)/3)+'px;height:'+(((320-__config__.theme_size/2*4)/3)/left.image.width*left.image.height)+'px">\
        														<img class="cap-goods__img--cover" style="width:'+((320-__config__.theme_size/2*4)/3)+'px;height:'+(((320-__config__.theme_size/2*4)/3)/left.image.width*left.image.height)+'px" src="'+left.image.url+'">\
        													</div>\
        												</div>\
        												<div class="xh-column xh-w">\
        													<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="width:81px">'+left.name+'</div>\
        													<div class="xh-row xh-price-h-min single-ellipsis xh-m15" style="max-width:80px;">'+left.price_html+'</div>\
        												</div>\
        											</li>';
    									}
										if(middle){
											html+='<li class="cap-goods-list__wrapper xh-column xh-panel xh-radius" style="margin-left:7px;width:'+((320-__config__.theme_size/2*4)/3)+'px">\
    													<div class="cap-goods-list__photo">\
        													<div class="cap-goods__img-wrap" style="width:'+((320-__config__.theme_size/2*4)/3)+'px;height:'+(((320-__config__.theme_size/2*4)/3)/middle.image.width*middle.image.height)+'px">\
        														<img class="cap-goods__img--cover" style="width:'+((320-__config__.theme_size/2*4)/3)+'px;height:'+(((320-__config__.theme_size/2*4)/3)/middle.image.width*middle.image.height)+'px" src="'+middle.image.url+'">\
        													</div>\
        												</div>\
        												<div class="xh-column xh-w">\
        													<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="width:81px">'+middle.name+'</div>\
        													<div class="xh-row xh-price-h-min single-ellipsis xh-m15" style="max-width:80px;">'+middle.price_html+'</div>\
        												</div>\
        											</li>';
    									}
    									if(right){
    										html+='<li class="cap-goods-list__wrapper xh-column xh-panel xh-radius" style="margin-left:7px;width:'+((320-__config__.theme_size/2*4)/3)+'px">\
    													<div class="cap-goods-list__photo">\
        													<div class="cap-goods__img-wrap" style="width:'+((320-__config__.theme_size/2*4)/3)+'px;height:'+(((320-__config__.theme_size/2*4)/3)/right.image.width*right.image.height)+'px">\
        														<img class="cap-goods__img--cover" style="width:'+((320-__config__.theme_size/2*4)/3)+'px;height:'+(((320-__config__.theme_size/2*4)/3)/right.image.width*right.image.height)+'px" src="'+right.image.url+'">\
        													</div>\
        												</div>\
        												<div class="xh-column xh-w">\
        													<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="width:81px">'+right.name+'</div>\
        													<div class="xh-row xh-price-h-min single-ellipsis xh-m15" style="max-width:80px;">'+right.price_html+'</div>\
        												</div>\
        											</li>';
        								}
										html+='</ul>';
									}
							
        							html+='</div>';
        							break;
    							case 'swip':
    								html+='<div class="cap-goods-list">\
    										<ul class="cap-goods-list__container cap-goods-list__container--three cap-goods-list__container--simple nowrap">';
    							
    									for(var index=0;index<items.length;index++){
    										if(index>=config.num){break;}
    										var item = items[index];
    										if(!item.image){item.image={url:'',width:0,height:0};}
    										html+='<li class="cap-goods-list__wrapper xh-panel '+(index>0?'xh-mL15':'')+'">\
    													<div class="cap-goods-list__photo">\
															<div class="cap-goods__img-wrap" style="padding-top: 100%;">\
																<div data-lazy-log="1" class="cap-goods__img--cover" style="padding-top: 100%; background-image: url('+item.image.url+');"></div>\
															</div>\
														</div>\
														<div class="xh-column xh-w">\
    														<div class="xh-row xh-c-main xh-f-sub multi-ellipsis xh-H-sub-2 xh-w xh-m15" style="width:73px;margin-top:0;">'+item.name+'</div>\
    														<div class="xh-row xh-price-h-min single-ellipsis xh-m15" style="max-width:73px;margin-top:0;">'+item.price_html+'</div>\
														</div>\
    												</li>';
    										}
    							
    								html+='</ul></div>';
    								break;
    							}
    					html+='</div>';
    					
    					callback(html);
    	            },
    	            error:function(e){
    	            	console.error(e.responseText);
    	            }
    	         });
            	};
    		})(jQuery);
    	</script>
        <?php 
    } 
}