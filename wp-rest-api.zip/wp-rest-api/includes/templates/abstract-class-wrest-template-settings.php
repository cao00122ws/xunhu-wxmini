<?php
abstract class Abstract_WRest_Template_Settings{
    public $id;
    public $title;
    public $description;
    public $type;
    public $fields = array();
    
    /**
     * @var WRest_Version
     */
    public $version ;
    private $config = array();
    
    public function __construct($version,$id=0,$config = array()){
        $this->version  = $version;
        $this->id = $id;
        $this->config = $config;
        $this->type = strtolower(get_called_class());
        
    }

    public function get_config(){
        $config = array();
        foreach ($this->fields as $fieldkey=>$settings){
            if($settings['type']=='subtitle'){continue;}
            $config[$fieldkey] = $this->get_option($fieldkey);
        }
        
        return $config;
    }
    
    /**
     * @param WP_REST_Request $request
     * @return array
     */
    public function to_json(&$templates, $request){
    	$config = $this->get_config();
    	$config['type']=$this->type;
    	
    	$templates[] = $config;
    }
    
    public function generate_nav_url($key){
        
    }
    
    public function init_form_fields($fields){
        $basefields = array(
            'title_common'=>array(
                'title'=>'通用设置',
                'type'=>'subtitle'
            ),
            'auth_type'=>array(
                'title'=>'登录显示',
                'type'=>'select',
                'default'=>'default',
                'options'=>array(
                    'default'=>'无限制',
                    'before'=>'登陆前显示',
                    'after'=>'登陆后显示',
                )
            )
        );
        
        $this->fields =array_merge($basefields,$fields);
    }

    public function get_option($field,$default = null){
        if(isset($this->config[$field])){
        	if(is_null($this->config[$field])||$this->config[$field]===''){
        		return $default;
        	}
            return $this->config[$field];
        }
         
        if(isset($this->fields[$field]['default'])){
            return $this->fields[$field]['default'];
        }
         
        return $default;
    }

    public function get_template_key($cat=null){
        $id =  esc_attr("t{$this->type}_t_{$this->id}");
        if($cat){
            $id.="_{$cat}";
        }
        return $id;
    }
    
    public function get_field_key($field_key){
        return esc_attr("{$this->type}_{$this->id}_field_{$field_key}");
    }
    
    public function get_custom_attribute_html($data) {
        $custom_attributes = array ();
    
        if (! empty ( $data ['custom_attributes'] ) && is_array ( $data ['custom_attributes'] )) {
            	
            foreach ( $data ['custom_attributes'] as $attribute => $attribute_value ) {
                $custom_attributes [] = esc_attr ( $attribute ) . '="' . esc_attr ( $attribute_value ) . '"';
            }
        }
    
        return implode ( ' ', $custom_attributes );
    }
    
    public function generate_text_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'description' => '',
            'custom_attributes' => array ()
        );
        
        $data = wp_parse_args ( $data, $defaults );
        
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
						<input type="text" placeholder="<?php echo esc_attr($data['placeholder']); ?>" class="zent-input <?php echo esc_attr($data['class'])?>" style="<?php echo esc_attr($data['css'])?>" id="<?php echo $field;?>" onblur="window.<?php echo $field?>.onblur();" value="<?php echo esc_attr($this->get_option($key))?>"  <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?> />	
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					onblur:function(){
						console.info('blur:<?php echo $key ?>');
						$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
					},
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_description_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title'=>'介绍：',
            'field-class' => '',
            'description'=>'描述...'
        );
    
        $data = wp_parse_args ( $data, $defaults );
    
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					get_value:function(){
						return null;
					},
					set_value:function(val){
						
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_emoji_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'field-class'=>'',
            'default'=>'',
            'description' => '',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
    
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
						<?php 
            			require_once WREST_DIR.'/includes/emoji-editor/class-emoji-editor.php';
                		WRest_Emoji_Editor::editor($this->get_option($key,$data['default']),$field,$data['custom_attributes']);
                		?>	
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
					}
				};
				
				$(document).bind("on_emoji_editor_<?php echo $field?>_change",function(){
					$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
				});
			})(jQuery);
		</script>
        <?php 
    }
        
    public function generate_integer_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'description' => '',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
    
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
						<input type="text" placeholder="<?php echo esc_attr($data['placeholder']); ?>" class="zent-input <?php echo esc_attr($data['class'])?>" style="<?php echo esc_attr($data['css'])?>" id="<?php echo $field;?>" onblur="window.<?php echo $field?>.onblur();" value="<?php echo esc_attr($this->get_option($key))?>"  <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?> />	
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					onblur:function(){
						console.info('blur:<?php echo $key ?>');
						$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
					},
					get_value:function(){
						var val = $.trim($('#<?php echo $field?>').val());
						if(val===''){return '';}

						var num = parseInt(val);
						if(isNaN(num)){
							return '';
						}
						return num;
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_map_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'description' => '',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $value = $this->get_option($key);
        if(!$value||!is_array($value)){
            $value = array();
        }
         
        $path = isset($value['path'])?$value['path']:'';
        $lat = isset($value['lat'])?$value['lat']:'39.916527';
        $lng = isset($value['lng'])?$value['lng']:'116.397128';
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
						<?php 
                    	$api = WRest_Settings_Default_Basic_Default::instance();
                    	$mapkey = $api->get_option('txmapkey');
                    	if(empty($mapkey)){
                    	    ?>
                    	    <div style="pending:30px;"><span style="color:red;">腾讯地图组件，请</span><a href="https://lbs.qq.com/console/key.html" target="_blank">申请开通密钥</a><span style="color:red;">,且勾选“地图组件”</span></div>
                    	    <?php 
                    	}else{
                    	    ?>
                    	    <div  style="display:flex;flex-direction:column">
                			<div style="display:flex;flex-direction:row">
                				<input value="<?php echo esc_attr($path)?>" class="input-text wide-input <?php echo esc_attr( $data['class'] ); ?>" type="text" name="<?php echo $field?>" id="<?php echo $field?>" placeholder="请输入详细地址" style="min-width:400px;" />
                				<button type="button" id="btn-<?php echo $field?>-p">定位</button>
                				<input value="<?php echo esc_attr($lat)?>" type="hidden" id="<?php echo $field?>-latitude" name="<?php echo $field?>-latitude" />
                				<input value="<?php echo esc_attr($lng)?>" type="hidden" id="<?php echo $field?>-longitude" name="<?php echo $field?>-longitude" />
                			</div>
                			<div id="<?php echo $field?>-map" style="min-width:600px;min-height:300px;"></div>
    						</div>
        					<script type="text/javascript">
        						(function($){
        							window.<?php echo $field?>Map={
        								initMap:function(position){
        							        var latitude = position?position.latitude:39.916527;
        							        var longitude = position?position.longitude:116.397128;
        							        
        						        	var center = new qq.maps.LatLng(latitude,longitude);
        						        	window.<?php echo $field?>Map.map = new qq.maps.Map(document.getElementById('<?php echo $field?>-map'),{
        								        center: center,
        								        zoom: 13
        								    });
        								    
        						        	if(!window.<?php echo $field?>Map.marker){
        						        		window.<?php echo $field?>Map.marker = new qq.maps.Marker({
        							                map:window.<?php echo $field?>Map.map,
        							                draggable: true,
        							                position: center
        							            });
        										
        						        		qq.maps.event.addListener(window.<?php echo $field?>Map.marker, 'position_changed', function() {
        					        		        var posi =window.<?php echo $field?>Map.marker.getPosition();
        					        		        $('#<?php echo $field?>-latitude').val(posi.lat);
        					        		        $('#<?php echo $field?>-longitude').val(posi.lng);
        					        		    });
        							        }
        						  
        						        	window.<?php echo $field?>Map.geocoder = new qq.maps.Geocoder({
        								        complete : function(result){
        								        	window.<?php echo $field?>Map.map.setCenter(result.detail.location);
        								        	window.<?php echo $field?>Map.marker.setPosition(result.detail.location);
        								        }
        								    });
        							    }
        							};
        
        							window.<?php echo $field?>Map.initMap({
        								latitude:'<?php echo $lat?>',
        								longitude:'<?php echo $lng?>'
        							});
        							
        							$('#btn-<?php echo $field?>-p').click(function(){
        								var path = $('#<?php echo $field?>').val();
        								if(!path){return;}
        								window.<?php echo $field?>Map.geocoder.getLocation(path);
        							});
        						})(jQuery);
        					</script>
                    	    <?php 
                    	}
                    	?>	
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					get_value:function(){
						return {
							path:$.trim($('#<?php echo $field?>').val()),
							lat:$('#<?php echo $field?>-latitude').val(),
							lng:$('#<?php echo $field?>-longitude').val()
						};
					},
					set_value:function(val){
						
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_link_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'description' => '参数配置请参考<a href="https://www.wpweixin.net/blog/2742.html#question-link"  target="_blank">常见问题 - 链接参数配置</a>',
            'custom_attributes' => array ()
        );
		
        $data = wp_parse_args ( $data, $defaults );
        $theval =$this->get_option($key);
        $val = $theval&&is_array($theval)?$theval:array(
            'url'=>$theval,
            'params'=>null
        );
        ?>
        <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
            <div class="zent-design-editor__control-group-container">
                <div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
                <div class="zent-design-editor__control-group-control">
                    <div class="zent-input-wrapper">
                        <select class="zent-input <?php echo esc_attr($data['class'])?>" style="<?php echo esc_attr($data['css'])?>" id="<?php echo $field;?>" onchange="window.<?php echo $field?>.onblur();" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?> >
                        	<option value="">--选择--</option>
                        <?php
                            foreach (self::getRedirectPages() as $group=>$settings){
                                ?>
                                <optgroup label="<?php echo esc_attr($settings['title'])?>">
                                	<?php foreach ($settings['options'] as $link=>$label){
                                	    ?><option value="<?php echo esc_attr($link);?>" <?php echo $link==$val['url']?'selected':'';?> ><?php echo esc_html($label);?></option><?php
                                	}?>
                                </optgroup>
                                <?php 
                            }
                        ?>
                        </select>
                        <input type="text" placeholder="参数" value="<?php echo esc_attr(isset($val['params'])?$val['params']:'')?>" id="<?php echo $field;?>_params"/>
                    </div>
                    <div><?php echo $data['description'];?></div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            (function($){
                window.<?php echo $field?>={
                    onblur:function(){
                        $(document).trigger("on_<?php echo $this->get_template_key()?>_change");
                    },
                    get_value:function(){
                        return {
							url:$('#<?php echo $field?>').val(),
							params:$('#<?php echo $field;?>_params').val()
                        };
                    },
                    set_value:function(val){
                        if(typeof val=='object'){
							$('#<?php echo $field;?>').val(val.url);
							$('#<?php echo $field;?>_params').val(val.params);
                        }
                    }
                };
            })(jQuery);
        </script>
        <?php
    }

    public function generate_subtitle_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'description' => '',
            'hr' => false
        );
        
        $data = wp_parse_args ( $data, $defaults );
        
        if($data['hr']){
            ?><hr/><?php 
        }
        ?>
        <h5 style="font-weight: bold;font-size:14px;"><?php echo $data['title']?></h5>
        <div><?php echo $data['description']?></div>
        <div style="clear:both;"></div>
        <script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					get_value:function(){
						return null;
					},
					set_value:function(val){
						
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_editor_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'description'=>''
        );
        
        $data = wp_parse_args ( $data, $defaults );
        
        ?>
          <div class="zent-design-editor__control-group">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
					 <script id="<?php echo $field;?>" type="text/plain"><?php echo $this->get_option($key)?></script>
						
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				var ue = UE.getEditor('<?php echo $field;?>');
				window.<?php echo $field?>={
					ue : ue,
					ueReady:false,
					onblur:function(){
						$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
					},
					get_value:function(){
						if(!this.ueReady){
							return $('#<?php echo $field;?>').html();
						}else{
							return this.ue.getContent();
						}
					},
					set_value:function(val){
						if(!this.ueReady){
							$('#<?php echo $field;?>').html(val) 
						}else{
							this.ue.setContent(val);
						}
					}
				};
				ue.addListener( 'ready', function( editor ) {
					window.<?php echo $field?>.ueReady=true;
				});
				ue.on('afterautosave',function(){
					window.<?php echo $field?>.onblur();
			    })
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_hidden_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
           
        );
    
        $data = wp_parse_args ( $data, $defaults );
    
        ?><input type="hidden" id="<?php echo $field;?>" name="<?php echo $field;?>" value="<?php echo esc_attr($this->get_option($key))?>"/>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					onblur:function(){
						$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
					},
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_textarea_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'description' => '',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
    
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
						<textarea rows="2" placeholder="<?php echo esc_attr($data['placeholder']); ?>" class="zent-input <?php echo esc_attr($data['class'])?>" style="<?php echo esc_attr($data['css'])?>" id="<?php echo $field;?>" onblur="window.<?php echo $field?>.onblur();" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?>><?php echo esc_textarea($this->get_option($key))?></textarea>	
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					onblur:function(){
						$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
					},
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
     
    public function generate_position_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'required'=>false,
            'max-width'=>750,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'description' => '<h5>提示：</h5>
                              <ol>
                                  <li>宽：默认750(宽只支持数值（单位rpx），不支持百分比),高度：自适应伸缩</li>
                                  <li>偏移量只支持数值（单位rpx），不支持百分比</li>
                               </ol>',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        if(!$val||!is_array($val)){
            $val = array();
        }
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper" style="display:flex;flex-direction:column;">
						<div style="display:flex;flex-direction:row;align-items:center;">
                			浮动设置:&nbsp;&nbsp;&nbsp;<select id="<?php echo $field?>-position">
                				<?php if(!$data['required']){
                				    ?><option value="">不浮动</option><?php 
                				}?>
                				
                				<option value="fixed">固定位置</option>
                			</select>
            			</div>
                			
						<div style="display:flex;flex-direction:column;" id="<?php echo $field?>-position-fields">
                			<div style="margin-top:15px;">
                				<div style="display:flex;flex-direction:row;align-items:center;">
                        			横向位置:&nbsp;&nbsp;&nbsp;<select id="<?php echo $field?>-w">
                        				<option value="left">居左</option>
                        				<option value="center">居中</option>
                        				<option value="right">居右</option>
                        			</select>
                        			&nbsp;&nbsp;&nbsp;,偏移量(rpx):&nbsp;&nbsp;&nbsp;
                        			<input type="text" id="<?php echo $field?>-w-len" placeholder="偏移量(rpx)" style="width:60px;" />
                    			</div>
                			</div>
                			
                			<div style="margin-top:15px;">
                				<div style="display:flex;flex-direction:row;align-items:center;">
                        			竖向位置:&nbsp;&nbsp;&nbsp;<select id="<?php echo $field?>-h">
                        				<option value="top">顶部</option>
                        				<option value="center">居中</option>
                        				<option value="bottom">底部</option>
                        			</select>
                        			&nbsp;&nbsp;&nbsp;,偏移量(rpx):&nbsp;&nbsp;&nbsp;
                        			<input type="text" id="<?php echo $field?>-h-len" placeholder="偏移量(rpx)" style="width:60px;" />
                    			</div>
                			</div>
                			
                			<div style="margin-top:15px;">
        						<div style="display:flex;flex-direction:row;align-items:center;">
        							层级(z-index):&nbsp;&nbsp;&nbsp;<input type="tel" id="<?php echo $field?>-zindex" placeholder="0" style="width:60px;" />
        							
        						</div>
                			</div>
                			
        					<div style="margin-top:15px;">
        						<div style="display:flex;flex-direction:row;align-items:center;">
        							显示宽度:&nbsp;&nbsp;&nbsp;<input type="text" id="<?php echo $field?>-width" placeholder="宽" style="width:60px;" />
        							(rpx)
        						</div>
                			</div>
            			</div>	
					</div>
					<div style="margin-top:15px;"><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field?>-position').change(function(){
					switch($(this).val()){
						case 'fixed':
							$('#<?php echo $field?>-position-fields').slideDown();
							break;
						default:
							$('#<?php echo $field?>-position-fields').slideUp()
							break;
					}
				});
				window.<?php echo $field?>={
					get_value:function(){
						var position = $('#<?php echo $field?>-position').val();
						var val = {
							position:position
						};

						switch(position){
							case 'fixed':
								val.w = $('#<?php echo $field?>-w').val();
								val.h = $('#<?php echo $field?>-h').val();
								val.z_index = $.trim($('#<?php echo $field?>-zindex').val());
								val.w_len = $('#<?php echo $field?>-w-len').val();
								val.h_len = $('#<?php echo $field?>-h-len').val();
								val.width = $.trim($('#<?php echo $field?>-width').val());
							break;
						}
						return val;
					},
					set_value:function(val){
						if(typeof val!='object'){
							return;
						}
						
						$('#<?php echo $field?>-h').val(typeof val.h=='undefined'?'center':val.h);
						$('#<?php echo $field?>-w').val(typeof val.w=='undefined'?'center':val.w);

						$('#<?php echo $field?>-h-len').val(typeof val.h_len=='undefined'?'0':val.h_len);
						$('#<?php echo $field?>-w-len').val(typeof val.w_len=='undefined'?'0':val.w_len);
						$('#<?php echo $field?>-width').val(typeof val.width=='undefined'?'<?php echo $data['max-width']?>':val.width);
						$('#<?php echo $field?>-zindex').val(typeof val.z_index=='undefined'?'0':val.z_index);
						if(typeof val.position!='undefined'){
							$('#<?php echo $field?>-position').val(val.position);
						}
						$('#<?php echo $field?>-position').change();
					}
				};
				window.<?php echo $field?>.set_value(<?php echo $val?json_encode($val):'{}'?>);
				
				$(document).bind('on_wrest_app_ready',function(){
					$('#<?php echo $field?>-position').change();
					$('#<?php echo $field?>-h-len,#<?php echo $field?>-w-len,#<?php echo $field?>-width').keyup(function(){
						$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
					});
					$('<?php echo $field?>-position,#<?php echo $field?>-h,#<?php echo $field?>-w').change(function(){
						$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
					});
					
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_nav_select($page,$param){
        $str =  '<select class="editor-page" style="width:80px;"><option value="">--选择--</option>';
       foreach (self::getRedirectPages() as $group=>$settings){
           $str.='<optgroup label="'.$settings['title'].'">';
           foreach ($settings['options'] as $k=>$v){
               $str.='<option \'+('.$page.'==\''.$k.'\'?\'selected\':\'\')+\' value="'.$k.'">'.$v.'</option>';
           }
           $str.='</optgroup>';
       }
       $str.='</select>';
       $str.='<input type="text" class="editor-pageparam" value="\'+'.($param?$param:'').'+\'" placeholder="页面参数" style="width:80px;" />';
       $str.='<p>参数配置请参考<a href="https://www.wpweixin.net/blog/2742.html#question-link"  target="_blank">常见问题 - 链接参数配置</a></p>';
       return $str;
    }
    public static function reset_params($url,$params){
        if(!$params){
            return null;
        }
       
        if(ltrim($url,'/')=='pages/web-view/index'){
            return "id=".urlencode($params);
        }
        
        if(strpos($params, '=')===false){
            return "id={$params}";
        }else{
            return $params;
        }
    }
   
    public function reset_link($link){
        $version = $this->version;
        if(!$link||!is_array($link)){
            return $link;
        }
        
        $url=$params = null;
        if(isset($link['page'])){
            $url = isset($link['page'])?$link['page']:null;
            $params = isset($link['page_param'])?$link['page_param']:null;
        }else if(isset($link['url']) ){
            $url = isset($link['url'])?$link['url']:null;
            $params = isset($link['params'])?$link['params']:null;
        }
       
        if(empty($url)){
            return $link;
        }

        if(ltrim($url,'/')=='pages/login/index'){
            $url = 'package_c/pages/login/index';
        }
        
        $current_group = null;
        if($url=='custom'&&$params){
            $res = explode('?', $params);
            $url = $res[0];
            $params = count($res)>1?$res[1]:null;
            $current_group='link';
        }else{
            $pages = self::getRedirectPages();
            
            foreach ($pages as $group=>$settings){
                foreach ($settings['options'] as $k=>$label){
                    if(ltrim($k,'/')==ltrim($url,'/')){
                        $current_group=$group;
                        break;
                    }
                }
            } 
        }
        
        if(!$current_group){
            return $link;
        }
        
        if($current_group=='authorize'){
        	global $authorize_controllers_registered;
        	$authorize_controllers_registered = true;
        }
        
        switch ($current_group){
            case 'link':
                if($this->is_menu_in_navbar($version, $url)){
                    return array_merge($link,array(
                        '__bindtab__'=>'__common_event_tap__',
                        '__action__'=>'switchTab',
                        '__page_url__'=>strpos($url, '/')!==0?"/{$url}":$url,
                        '__page_params__'=>self::reset_params($url,$params)
                    ));
                }
                
                $sdk = isset($_REQUEST['sdk'])?$_REQUEST['sdk']:null;
                if($sdk&&version_compare($sdk, '1.0.2','<')){
                    if(ltrim($url,'/')=='package_c/pages/login/index'){
                        $url = 'pages/login/index';
                    }
                }
                
                return array_merge($link,array(
                    '__bindtab__'=>'__common_event_tap__',
                    '__action__'=>'navigate',
                    '__page_url__'=>strpos($url, '/')!==0?"/{$url}":$url,
                    '__page_params__'=>self::reset_params($url,$params)
                ));
            case 'open-data':
                $openData=null;
                if(strpos($url, 'open-data-')===0){
                    $openData =  substr($url, strlen('open-data-'));
                }

                $account_url = '/pages/account/index';
                if($this->is_menu_in_navbar($version, $account_url)){
                    return array_merge($link,array(
                        '__bindtab__'=>'__common_event_tap__',
                        '__action__'=>'switchTab',
                        '__page_url__'=>$account_url,
                        '__page_params__'=>null,
                        '__open_data__'=>$openData,
                        '__open_data_style__'=>$params
                    ));
                }
                
                return array_merge($link,array(
                    '__bindtab__'=>'__common_event_tap__',
                    '__action__'=>'navigate',
                    '__page_url__'=>$account_url,
                    '__page_params__'=>null,
                    '__open_data__'=>$openData,
                    '__open_data_style__'=>$params
                ));
            case 'event':
                $openType=null;
                if(strpos($url, 'open-type-')===0){
                    $openType =  substr($url, strlen('open-type-'));
                }
                
                return array_merge($link,array(
                    '__bindtab__'=>'__common_event_tap__',
                    '__action__'=>$url,
                    '__page_params__'=>$params,
                    '__open_type__'=>$openType
                ));
            default:
                $openType=null;
                if(strpos($url, 'open-type-')===0){
                    $openType =  substr($url, strlen('open-type-'));
                }
                
                return apply_filters('wrest-link-call', array_merge($link,array(
                    '__bindtab__'=>'__common_event_tap__',
                    '__action__'=>$url,
                    '__page_params__'=>$params,
                    '__open_type__'=>$openType
                )));
        }
    }
    
    public function generate_nav_attribute_start($section,$atts=null){
        $attStr = '';
        if(!$atts||!is_array($atts)){
            $atts=array();
        }
        if(!isset($atts['class'])){$atts['class']='';}
        if(!isset($atts['hover-class'])){$atts['hover-class']='';}
        $atts['class'].=' xh-btn-clear';
    
        foreach ($atts as $k=>$v){
            if(empty($v)){
                $attStr.=" {$k}";
            }else{
                $attStr.=" {$k}=\"".($v)."\" ";
            }
        }
        ?>
        <button <?php echo $attStr;?> show-message-card send-message-img bindgetuserinfo="__bindgetuserinfo__" bindgetphonenumber="__bindgetphonenumber__" open-type="{{<?php echo $section;?>.__open_type__?<?php echo $section;?>.__open_type__:''}}" bindtap="{{<?php echo $section;?>.__bindtab__?<?php echo $section;?>.__bindtab__:''}}" data-action="{{<?php echo $section;?>.__action__?<?php echo $section;?>.__action__:''}}" data-params="{{<?php echo $section;?>.__page_params__?<?php echo $section;?>.__page_params__:''}}" data-url="{{<?php echo $section;?>.__page_url__?<?php echo $section;?>.__page_url__:''}}">
    		<view class="xh-row xh-w xh-row-c" wx:if="{{<?php echo $section;?>.__open_data__}}">
        		<view class="single-ellipsis" style="overflow:hidden;{{<?php echo $section;?>.__open_data_style__?<?php echo $section;?>.__open_data_style__:''}}">
        			<open-data type="{{<?php echo $section;?>.__open_data__}}"></open-data>
        		</view>
    		</view>
        <?php 
    }
    
    public function generate_nav_attribute_end(){
        ?>
         </button>  
        <?php 
    }
    
    private function is_menu_in_navbar($version,$url){
        $layout = WRest_Menu_Store_Layout::instance();
        $menus =  $layout->get_navbar_field($version, 'items');
        if(!$menus){
            return false;
        }
        
        foreach ($menus as $menu){
            $page =$menu['page'];
            $pages = explode('?', $page);
             
            if(ltrim($pages[0],'/')==ltrim($url,'/')){
                return true;
            }
        }
        return false;
    }
    
    public static function getRedirectPages(){
        return apply_filters('wrest_redirect_pages', array(
            'link'=>array(
                'title'=>'跳转链接',
                'options'=>array(
                    '/pages/cart/index'=>'购物车',
                    '/pages/category/index'=>'分类聚合页',
                    '/pages/search/index'=>'商品搜索',
                    '/pages/account/index'=>'我的账户',
                    '/pages/email-bind/index'=>'邮箱绑定',
                    '/pages/my-coupon/index'=>'优惠券',
                    '/package_c/pages/login/index'=>'登录页面',
                    
                    '/package_a/pages/checkout/index'=>'结算页面',
                    '/package_a/pages/checkout/coupon/index'=>'优惠券选择页',
                    '/package_a/pages/category/index'=>'分类详情(参数必须)',
                    '/package_a/pages/product/detail/index'=>'产品详情(参数必须)',
                    '/package_a/pages/order/list/index'=>'订单列表', 
                    '/package_a/pages/order/detail/index'=>'订单详情(参数必须)',
                    '/package_a/pages/wishlist/index'=>'我的收藏',
                    '/package_a/pages/address/index'=>'配送地址',
                    
                    '/pages/article/list/index'=>'文章列表',
                    '/pages/article/detail/index'=>'文章详情(参数必须)',
                    '/pages/article/search/index'=>'文章搜索',
                    
                    '/pages/page/index'=>'小程序页(参数必须)',
                    '/pages/web-view/index'=>'浏览器(参数必须)',
                    'custom'=>'自定义小程序页面'
                )
            ),
            'event'=>array(
                'title'=>'点击事件',
                'options'=>array(
                    'open-type-contact'=>'客服会话',
                    'open-type-share'=>'页面分享',
                    'open-type-feedback'=>'意见反馈',
                    'navigateBack'=>'返回上一页',
                    'make-phone-call'=>'拨打电话',
                    'scan-code'=>'扫码二维码',
                    'navigate-to-miniProgram'=>'跳转小程序',
                    'navigate-back-miniProgram'=>'返回来源小程序',
                    'check-for-update'=>'检查版本更新',
                    'custom-red-bag'=>'领取优惠券',
                )
            ),
        	'authorize'=>array(
    			'title'=>'微信授权',
    			'options'=>array(
					'open-type-getUserInfo'=>'微信登录',
					'open-type-getPhoneNumber'=>'手机登录',
					'logout'=>'退出登录',
    			)
        	),
            'open-data'=>array(
                'title'=>'开放数据',
                'options'=>array(
                    'open-data-userNickName'=>'用户昵称',
                    'open-data-userAvatarUrl'=>'用户头像',
                    'open-data-userGender'=>'用户性别',
                    'open-data-userCity'=>'用户所在城市',
                    'open-data-userProvince'=>'用户所在省份',
                    'open-data-userCountry'=>'用户所在国家',
                )
            )
        ));
    }
    
    public static function getNavbarPages(){
        return array(
            '/pages/index/index'=>'店铺首页',
            '/pages/cart/index'=>'购物车',
            '/pages/category/index'=>'分类聚合页',
            
            
            '/pages/subcat/index'=>'分类详情(参数必须)',
            
            '/pages/product/detail/index'=>'产品详情(参数必须)',
            
            '/pages/search/index'=>'商品搜索',
            '/pages/account/index'=>'我的账户',
            
            '/pages/article/list/index'=>'文章列表',
            '/pages/article/detail/index'=>'文章详情(参数必须)',
            '/pages/article/search/index'=>'文章搜索',
            
            '/pages/page/index'=>'小程序页(参数必须)',
            '/pages/web-view/index'=>'浏览器(参数必须)',
            'custom'=>'自定义小程序页面(地址不能含参数)'
        );
    }
    
    public function generate_mult_image_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'max'=>'',
            'has_title'=>false,
            'field-class'=>'',
            'width'=>750,
            'height'=>350
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        $uid = WRest_Helper::generate_unique_id();
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="rc-design-editor-card rc-design-component-image-ad-editor-card">
						<div id="<?php echo $field ?>-items">
  							
						</div>
						 <div class="rc-design-component-image-ad-editor__add-ads-desc" id="<?php echo $field ?>-drag-tag" style="display:none;">拖动选中的图片广告可对其排序</div>
						<div class="rc-design-editor-card-add" id="<?php echo $field ?>-add-item">
							<div class="rc-design-component-image-ad-editor__add-image">
								<div class="rc-design-component-image-ad-editor__add-image-text"><i class="zenticon zenticon-plus rc-design-editor-card-add-icon"></i>添加一个背景图</div>
								<div class="rc-design-component-image-ad-editor__add-image-tip">建议尺寸 <?php echo $data['width']?>x<?php echo $data['height']?> 像素(图片名称不能含中文，支持jpg/jpeg、png、gif)<br/><span style="color:red;">（插入图片时，注意右下角选择图片尺寸，小尺寸会导致图片显示模糊）</span></div>
							</div>
						</div>
        			</div>
				</div>
			</div>
		</div>
		
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field ?>-add-item').click(function(){
					window.<?php echo $field?>.add_item();
				    return false;    
				});
			})(jQuery);
		    </script>
	        <script type="text/javascript">
				(function($){
					window.<?php echo $field;?>={
						container:'<?php echo $field ?>-items',
						items:<?php echo $val?json_encode($val):'[]'?>,
						onKeyup:function(){
							this.save();
							this.preview();
						},
						preview:function(){
							$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
						},
						get_value:function(){
							if(typeof this.__init__!='undefined'){
								this.save();
							}
							return this.items;
						},
						set_value:function(items){
							if(!items){items=[];}
							this.items = items;
							this.init();
						},
						save:function(){
							var items = [];
							$('#'+this.container+' .rc-design-editor-card-item').each(function(){
								var item = {
									url:$(this).find('.editor-image').attr('data-src'),
									width:$(this).find('.editor-image').attr('data-width'),
									height:$(this).find('.editor-image').attr('data-height'),
									page_title:$(this).find('.editor-page_title').val(),
									page:$(this).find('select.editor-page').val(),
									page_param:$(this).find('input.editor-pageparam').val()
								};
								items.push(item);
							});
							this.items = items;
						},
						init:function(){
							var $container = $('#'+this.container).empty();
							var html = '';

							if(this.items.length==0){
								$('#<?php echo $field ?>-drag-tag').css('display','none');		
							}else{
								$('#<?php echo $field ?>-drag-tag').css('display','block');
							}
							
							for(var index = 0 ;index<this.items.length;index++){
								var img = this.items[index];
								if(!img.url){img.url='';}
								if(!img.page){img.page='';}
								if(!img.page_param){img.page_param='';}
								
								html+='<div class="rc-design-editor-card-item" draggable="true" style="cursor:move" id="rc-design-editor-card-item-<?php echo $uid?>-'+index+'">\
          								<div class="rc-design-component-editor_subentry-item clearfix">\
          									<div class="rc-design-common-choice-image-component image-editor">\
          										<div class="has-choosed-image">\
												<div class="thumb-image editor-image" data-src="'+img.url+'" data-width="'+img.width+'" data-height="'+img.height+'" style="background-image:url('+img.url+');background-repeat: no-repeat;background-position:center center;background-size: cover;width:80px;height:80px;"></div>\
          											<span class="modify-image" onclick="<?php echo $field;?>.change_img('+index+');" title="插入图片时，注意右下角选择图片尺寸，小尺寸会导致图片显示模糊">更换图片</span>\
          										</div>\
          									</div>\
          									<div class="subentry-item-editor-form-content">\
              									<div style="<?php echo $data['has_title']?'':'display:none;'?>" class="zent-design-editor__control-group <?php echo $data['field-class']?>">\
          											<label class="zent-design-editor__control-group-container">\
          												<div class="zent-design-editor__control-group-label">标题：</div>\
          												<div class="zent-design-editor__control-group-control">\
          													<div class="zent-input-wrapper">\
          														<input type="text" class="editor-page_title" onblur="<?php echo $field;?>.onKeyup();" value="'+(img.page_title?img.page_title:'')+'" />\
          													</div>\
          												</div>\
          											</label>\
          										</div>\
          										<div class="zent-design-editor__control-group subentry-control-group">\
          											<label class="zent-design-editor__control-group-container">\
          												<div class="zent-design-editor__control-group-label">链接：</div>\
          												<div class="zent-design-editor__control-group-control">\
          													<div class="rc-choose-link-menu">\
          														<div class="zent-popover-wrapper rc-choose-link-menu-popover-wrapper" style="display: inline-block;">\
          															<?php echo $this->generate_nav_select('img.page','img.page_param')?>\
          														</div>\
          													</div>\
          												</div>\
          											</label>\
          										</div>\
          									</div>\
          								</div>\
          								<i class="zenticon zenticon-close-circle rc-design-editor-card-item-delete" onclick="<?php echo $field;?>.remove_img('+index+');"></i>\
          							</div>';
						}
						
						$container.html(html);
						$container.sortable({
							cursor:'move',
							tolerance:'pointer',
							update:function(event, ui){
								<?php echo $field;?>.save();
								<?php echo $field;?>.preview();
							}
					    });
					    this.__init__=true;
					},
					remove_img:function(index){
						if(confirm('确认删除？')){
							$('#rc-design-editor-card-item-<?php echo $uid?>-'+index).remove();
							this.save();				
							this.preview();
						}
					},
					change_img:function(index){
						window.__send_to_editor = window.send_to_editor;
						window.send_to_editor = function(html) {
							var $img = jQuery('img','<span>'+html+'</span>');
							if($img.length==0){
								alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
								return;
							}
							var url = $img.attr('src');
							var width = $img.attr('width');
							var height = $img.attr('height');

							if(!url){
								alert('图片路径信息获取失败！');
								return;
							}

							if(!width){
								alert('图片宽度信息获取失败！');
								return;
							}
							if(!height){
								alert('图片高度信息获取失败！');
								return;
							}
					     	$('#rc-design-editor-card-item-<?php echo $uid?>-'+index)
					    	.find('.editor-image')
					    	.css('background-image',"url("+url+")")
					    	.attr('data-src',url)
					    	.attr('data-width',width)
					    	.attr('data-height',height);
					    	
					    	<?php echo $field?>.save();				
					    	<?php echo $field?>.preview();
					    	window.send_to_editor = window.__send_to_editor;
					    }
					    wp.media.editor.open();
					    return false;    
					},
					add_item:function(){
						<?php if($data['max']){
						    ?>
						    if(<?php echo $field?>.items.length>=<?php echo absint($data['max'])?>){
								alert('最多只能添加<?php echo absint($data['max'])?>个！');
								return false;
							}
						    <?php 
						}?>

						window.__send_to_editor = window.send_to_editor;
						window.send_to_editor = function(html) {
							var $img = jQuery('img','<span>'+html+'</span>');
							if($img.length==0){
								console.log(html);
								alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
								return;
							}
							var url = $img.attr('src');
							var width = $img.attr('width');
							var height = $img.attr('height');

                            <?php echo $field?>.save();	
					    	<?php echo $field?>.items.push({
								url:url,
								width:width,
								height:height,
								page_title:'',
								page:null,
								page_param:''
						    });
					    	<?php echo $field?>.init();
					    	<?php echo $field?>.preview();
					    	
					    	window.send_to_editor = window.__send_to_editor;
					    }
					    wp.media.editor.open();
					    return false;    
					}
				};

				$(document).bind('on_wrest_app_ready',function(){
					<?php echo $field?>.init();
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_canvas_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'width'=>400,
            'description' => '',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        if(!$val||!is_array($val)){$val=array();}
    
        ?>
        <div id="<?php echo $field ?>-container" class="zent-design-editor__control-group rc-design-component-image-ad-hotarea-subentry-control-group <?php echo $data['field-class']?>"></div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					_data:<?php echo $val?json_encode($val):'{}'?>,
					init:function(){
						this.__preUploadBg();
						this.__canvas();
					},
					__canvas:function(){
						if(typeof this._data.bg=='undefined'||!this._data.bg){
							return;
						}

						if(this._data.bg){
    						if(!window.min_wrest_app_body_height){
    							window.min_wrest_app_body_height = this._data.bg.height*320/this._data.bg.width;
    						}else{
    							window.min_wrest_app_body_height = Math.max(window.min_wrest_app_body_height,(this._data.bg.height*320/this._data.bg.width));
        					}
						}
						
						var $container = $('#<?php echo $field ?>-container').empty();
						$container.html(
							'<div class="zent-design-editor__control-group-container">\
								<div class="zent-design-editor__control-group-control">\
									<div class="rc-design-editor-card rc-design-component-image-ad-editor-card">\
										<div class="rc-design-editor-card-item" draggable="true" style="opacity: 1;">\
											<div id="<?php echo $field?>-canvas-outer" style="border:dashed 1px #d2d2d2;display:flex;align-items:center;justify-content:center;">\
												<div class="rc-design-component-hot-area-image-editor" id="<?php echo $field?>-canvas" style="margin: 50px;position:relative;width:<?php echo $data['width']?>px;height:'+(this._data.bg.height*<?php echo $data['width']?>/this._data.bg.width)+'px;-webkit-user-drag:none;background:url('+this._data.bg.url+') no-repeat;background-size:100% 100%;border:solid 1px #f4f4f4;"></div>\
											</div>\
    										<div class="rc-design-component-hot-area-image-editor__modify-image" style="margin-top:10px;">\
    											<a href="javascript:void(0);" onclick="window.<?php echo $field?>.add_hot();" class="zent-btn">新增点击区域</a>\
		    									<a href="javascript:void(0);" onclick="window.<?php echo $field?>.change_img();" class="zent-btn-primary zent-btn">更换背景图</a>\
		    								</div>\
		    								<div class="rc-design-component-hot-area-image-editor__modify-image" style="margin-top:5px;">\
    											提示：1.可点击区域可添加多个、可拉伸、可随意拖动位置。2.背景图一定要按照尺寸上传原图\
    	    								</div>\
    									</div>\
    								</div>\
    								<i class="zenticon zenticon-close-circle rc-design-editor-card-item-delete"></i>\
    							</div>\
    						</div>'
						);

						if(!this._data.items){return;}
						$container.attr('hots',JSON.stringify(this._data.items));
						for(var index in this._data.items){
							this._add_hot(this._data.items[index]);
						}
					},
					__initCursor:function(id){
						$('#'+id).draggable({
							containment:'#<?php echo $field?>-canvas-outer',
							 stop: function( event, ui ) {
								var posi = ui.position;
								ui.helper.attr('attr-left',posi.left);
								ui.helper.attr('attr-top',posi.top);
							 }
						})
						.resizable({
							minHeight:30,
							maxHeight:this._data.bg.height*(<?php echo $data['width']?>+50)/this._data.bg.width,
							maxWidth:<?php echo $data['width']?>+50,
							minWidth:50,
							stop: function( event, ui ) {
								var size = ui.size;
								ui.helper.attr('attr-width',size.width);
								ui.helper.attr('attr-height',size.height);
							}
						});
					},
			    	_add_hot:function(item){
			    		var id = '<?php echo $field?>-hot-'+(new Date()).getTime();
			    		if(!item){
				    		item={
    							left:0,
    							top:0,
    							width:0,
    							height:0,
    							link:{
        							url:'',
        							params:''
            					}
    					    };
						}
			    		if(!item.link){item.link={url:'',params:''};}
			    		if(item.top<0){
			    			item.top=0;
				    	}
				    	if(this._data.bg){
    			    		if(item.top>(this._data.bg.height*(<?php echo $data['width']?>+50)/this._data.bg.width)){
    			    			item.top = (this._data.bg.height*(<?php echo $data['width']?>+50)/this._data.bg.width);
    				    	}
				    	}

			    		if(item.left<0){
			    			item.left=0;
				    	}
			    		if(item.left>(<?php echo $data['width']?>+50)){
			    			item.left = (<?php echo $data['width']?>+50);
				    	}

			    		var width = item.width?item.width:87;
			    		var height = item.height?item.height:87;
			    		
						$('#<?php echo $field?>-canvas').append(
							'<div id="'+id+'" attr-width="'+width+'" attr-height="'+height+'" attr-left="'+item.left+'" attr-top="'+item.top+'" class="hotarea-rnd <?php echo $field?>-hot-item" style="position: absolute; user-select: auto; touch-action: none; display: inline-block; top: '+(item.top)+'px; left: '+(item.left)+'px; box-sizing: border-box; width: '+(width)+'px; height: '+(height)+'px;cursor:move;">\
								<div class="hotarea">\
								<div class="hotarea-text">链接：<div>\
								<div><?php echo $this->generate_nav_select('item.link.url','item.link.params')?></div>\
							</div>\
							<div class="hotarea-close" onclick="window.<?php echo $field?>.remove_hot(\''+id+'\')">×</div>\
						</div>');
						this.__initCursor(id);
				    },
					add_hot:function(){
						this._add_hot(null);
					},
					remove_hot:function(id){
						if(confirm('确定执行删除？')){
							$('#'+id).remove();
						}
					},
					__preUploadBg:function(){
						if(typeof this._data.bg!='undefined'&&this._data.bg){
							return;
						}
						var $container = $('#<?php echo $field ?>-container').empty();
						$container.html(
							'<div class="zent-design-editor__control-group-container">\
    		            		<div class="zent-design-editor__control-group-control">\
    		            			<div class="rc-design-editor-card rc-design-component-image-ad-editor-card">\
    		            				<div class="rc-design-editor-card-add" id="<?php echo $field ?>-add-img">\
    		            					<div class="rc-design-component-image-ad-editor__add-image">\
    		            						<div class="rc-design-component-image-ad-editor__add-image-hotarea-text">\
    		            							<i class="zenticon zenticon-plus rc-design-editor-card-add-icon"></i>\
    		            							添加一个背景图\
    		            						</div>\
    		            						<div class="rc-design-component-image-ad-editor__add-image-tip">\
    		                						<div style="color:red;">固定宽度 750 像素, 高度 1000 像素以内</div>\
    		                						<div>单张图片大小 200kb 以内</div>\
                            						<br/>\
                    								<span style="color:red;">（插入图片时，注意右下角选择图片尺寸，小尺寸会导致图片显示模糊）</span>\
    		                					</div>\
    		            					</div>\
    		            				</div>\
    		            			</div>\
    		            		</div>\
    		            	</div>');
		            	
		            	$('#<?php echo $field ?>-add-img').click(function(){
		            		window.__send_to_editor = window.send_to_editor;
							window.send_to_editor = function(html) {
								var $img = jQuery('img','<span>'+html+'</span>');
								if($img.length==0){
									alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
									return;
								}
								var url = $img.attr('src');
								var width = $img.attr('width');
								var height = $img.attr('height');

								if(!url){
									alert('图片路径信息获取失败！');
									return;
								}

								if(!width){
									alert('图片宽度信息获取失败！');
									return;
								}
								if(!height){
									alert('图片高度信息获取失败！');
									return;
								}
								
								window.<?php echo $field?>._data.bg={
									url:url,
									width:width,
									height:height
	    						};
						    	
						    	window.send_to_editor = window.__send_to_editor;
						    	window.<?php echo $field?>.init();
						    	$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
						    }
						    wp.media.editor.open();
						    return false; 
    		            });
					},
					change_img:function(){
						window.__send_to_editor = window.send_to_editor;
						window.send_to_editor = function(html) {
							var $img = jQuery('img','<span>'+html+'</span>');
							if($img.length==0){
								alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
								return;
							}
							var url = $img.attr('src');
							var width = $img.attr('width');
							var height = $img.attr('height');

							if(!url){
								alert('图片路径信息获取失败！');
								return;
							}

							if(!width){
								alert('图片宽度信息获取失败！');
								return;
							}
							if(!height){
								alert('图片高度信息获取失败！');
								return;
							}
							
							window.<?php echo $field?>._data.bg={
								url:url,
								width:width,
								height:height
    						};
					    	
					    	window.send_to_editor = window.__send_to_editor;
					    	window.<?php echo $field?>.init();
					    	$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
					    }
					    wp.media.editor.open();
					    return false; 
					},
					get_value:function(){
						var items = [];
						$('.<?php echo $field?>-hot-item').each(function(){
							
							items.push({
								link:{
									url:$(this).find('.editor-page').val(),
									params:$(this).find('.editor-pageparam').val()
								},
								left:$(this).attr('attr-left'),
								top:$(this).attr('attr-top'),
								width:$(this).attr('attr-width'),
								height:$(this).attr('attr-height')
							});
						});
						
						this._data.items = items;
						return this._data;
					},
					set_value:function(val){
						if(typeof val=='string'){
							this._data = JSON.parse(val);
						}else if(typeof val=='object'){
							this._data = val;
						}
						
						if(!this._data ){
							this._data ={};
						}
						this.init();
					}
				};
				window.<?php echo $field?>.init();
				$(document).bind('on_wrest_app_ready',function(){
					$('#the-app-body').css('min-height',window.min_wrest_app_body_height+'px');
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_navbar_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'max'=>null,
            'field-class'=>'',
            'width'=>32,
            'height'=>32,
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $uid = WRest_Helper::generate_unique_id();
        $val = $this->get_option($key);
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="rc-design-editor-card rc-design-component-image-ad-editor-card">
						<div id="<?php echo $field ?>-items">
  							
						</div>
						<div class="rc-design-component-image-ad-editor__add-ads-desc" id="<?php echo $field ?>-drag-tag" style="display:none;">拖动选中的菜单可对其排序</div>
						<div class="rc-design-editor-card-add"  id="<?php echo $field ?>-add-item">
							<div class="rc-design-component-image-ad-editor__add-image">
								<div class="rc-design-component-image-ad-editor__add-image-text"><i class="zenticon zenticon-plus rc-design-editor-card-add-icon"></i>添加一个菜单</div>
								<div class="rc-design-component-image-ad-editor__add-image-tip">建议图标尺寸<?php echo $data['width']?>x<?php echo $data['height']?>像素(图片名称不能含中文，仅支持jpg/jpeg、png)</div>
							</div>
						</div>
        			</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
	    	(function($){
				$('#<?php echo $field ?>-add-item').click(function(){
					window.<?php echo $field?>.add_item();
				    return false;    
				});
		    })(jQuery);

	    </script>
        <script type="text/javascript">
			(function($){
				window.<?php echo $field;?>={
					container:'<?php echo $field ?>-items',
					items:<?php echo $val?json_encode($val):'[]'?>,
					onKeyup:function(){
						this.preview();
					},
					preview:function(){
						$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
					},
					get_value:function(){
						this.save();
						return this.items;
					},
					set_value:function(items){
						if(!items){items=[];}
						this.items = items;
						this.init();
					},
					save:function(){
						var items = [];
						$('#'+this.container+' .rc-design-editor-card-item').each(function(){
							var item = {
								icon:{
									url:$(this).find('.editor-image.unselected').attr('data-src'),
									width:$(this).find('.editor-image.unselected').attr('data-width'),
									height:$(this).find('.editor-image.unselected').attr('data-height')
								},
								icon_selected:{
									url:$(this).find('.editor-image.selected').attr('data-src'),
									width:$(this).find('.editor-image.selected').attr('data-width'),
									height:$(this).find('.editor-image.selected').attr('data-height')
								},
								page_title:$(this).find('input.editor-page_title').val(),
								page:$(this).find('select.editor-page').val(),
								page_param:$(this).find('input.editor-pageparam').val()
							};
							items.push(item);
						});
						this.items = items;
					},
					init:function(){
						var $container = $('#'+this.container).empty();
						var html = '';
						if(this.items.length==0){
							$('#<?php echo $field ?>-drag-tag').css('display','none');		
						}else{
							$('#<?php echo $field ?>-drag-tag').css('display','block');
						}
						for(var index = 0 ;index<this.items.length;index++){
							var item = this.items[index];
							var icon = item.icon?item.icon:{url:'',width:0,height:0};
							var icon_selected = item.icon_selected?item.icon_selected:{url:'',width:0,height:0};
							
							if(!item.page){item.page='';}
							if(!item.page_title){item.page_title='';}
							if(!item.page_param){item.page_param='';}
							html+='<div class="rc-design-editor-card-item" draggable="true" style="cursor:move" id="rc-design-editor-card-item-<?php echo $uid?>-'+index+'">\
      								<div class="rc-design-component-editor_subentry-item clearfix">\
      									<div class="rc-design-common-choice-image-component image-editor">\
      										<div class="has-choosed-image" style="overview:hidden;">\
      											<div class="thumb-image editor-image unselected" data-src="'+icon.url+'" data-width="'+icon.width+'" data-height="'+icon.height+'" style="background-image:url('+icon.url+');background-repeat: no-repeat;background-position:center center;background-size: cover;width:80px;height:80px;"></div>\
      											<span class="modify-image" onclick="<?php echo $field;?>.change_img('+index+',\'unselected\');">更换(未选中)图片</span>\
      										</div>\
          									<div class="has-choosed-image" style="overview:hidden;">\
      											<div class="thumb-image editor-image selected" data-src="'+icon_selected.url+'" data-width="'+icon_selected.width+'" data-height="'+icon_selected.height+'" style="background-image:url('+icon_selected.url+');background-repeat: no-repeat;background-position:center center;background-size: cover;width:80px;height:80px;"></div>\
      											<span class="modify-image" onclick="<?php echo $field;?>.change_img('+index+',\'selected\');">更换(选中)图片</span>\
      										</div>\
      									</div>\
      									<div class="subentry-item-editor-form-content">\
      										<div class="zent-design-editor__control-group <?php echo $data['field-class']?>">\
      											<label class="zent-design-editor__control-group-container">\
      												<div class="zent-design-editor__control-group-label">菜单标题：</div>\
      												<div class="zent-design-editor__control-group-control">\
      													<div class="zent-input-wrapper">\
      														<input type="text" class="editor-page_title" onblur="<?php echo $field;?>.onKeyup();" value="'+(item.page_title?item.page_title:'')+'" />\
      													</div>\
      												</div>\
      											</label>\
      										</div>\
      										<div class="zent-design-editor__control-group subentry-control-group">\
      											<label class="zent-design-editor__control-group-container">\
      												<div class="zent-design-editor__control-group-label">链接：</div>\
      												<div class="zent-design-editor__control-group-control">\
      													<div class="rc-choose-link-menu">\
      														<div class="zent-popover-wrapper rc-choose-link-menu-popover-wrapper" style="display: inline-block;">\
      														<?php echo $this->generate_nav_select('item.page','item.page_param')?>
      														</div>\
      													</div>\
      												</div>\
      											</label>\
      										</div>\
      									</div>\
      								</div>\
      								<i class="zenticon zenticon-close-circle rc-design-editor-card-item-delete" onclick="<?php echo $field;?>.remove_img('+index+');"></i>\
      							</div>';
						}
						
						$container.html(html);
						$container.sortable({
							cursor:'move',
							tolerance:'pointer',
							update:function(event, ui){
								<?php echo $field;?>.save();
								<?php echo $field;?>.preview();
							}
					    });
					},
					remove_img:function(index){
						if(confirm('确认删除？')){
							$('#rc-design-editor-card-item-<?php echo $uid?>-'+index).remove();
							this.save();				
							this.preview();
						}
					},
					change_img:function(index,selected){

						window.__send_to_editor = window.send_to_editor;
						window.send_to_editor = function(html) {
							 var selector = '.editor-image.'+selected;
							var $img = jQuery('img','<span>'+html+'</span>');
							if($img.length==0){
								console.log(html);
								alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
								return;
							}
							var url = $img.attr('src');
							var width = $img.attr('width');
							var height = $img.attr('height');

							if(!url){
								alert('图片路径信息获取失败！');
								return;
							}

							if(!width){
								alert('图片宽度信息获取失败！');
								return;
							}
							if(!height){
								alert('图片高度信息获取失败！');
								return;
							}
							$('#rc-design-editor-card-item-<?php echo $uid?>-'+index)
					    	.find(selector)
					    	.attr('data-src',url)
					    	.css('background-image',"url("+url+")")
					    	.attr('data-width',width)
					    	.attr('data-height',height);
					    	
					    	<?php echo $field?>.save();				
					    	<?php echo $field?>.preview();
					    	window.send_to_editor = window.__send_to_editor;
					    }
						
					    wp.media.editor.open();
					    return false;    
					},
					add_item:function(){
						<?php if($data['max']){?>
						    if(<?php echo $field?>.items.length>=<?php echo absint($data['max'])?>){
								alert('最多只能添加<?php echo absint($data['max'])?>个！');
								return false;
							}
					    <?php }?>
					    window.__send_to_editor = window.send_to_editor;
						window.send_to_editor = function(html) {
							var $img = jQuery('img','<span>'+html+'</span>');
							if($img.length==0){
								alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
								return;
							}
							var url = $img.attr('src');
							var width = $img.attr('width');
							var height = $img.attr('height');

							if(!url){
								alert('图片路径信息获取失败！');
								return;
							}

							if(!width){
								alert('图片宽度信息获取失败！');
								return;
							}
							if(!height){
								alert('图片高度信息获取失败！');
								return;
							}
                            <?php echo $field?>.save();	
					    	
					    	<?php echo $field?>.items.push({
						    	icon:{
						    		url:url,
									width:width,
									height:height
							    },
							    icon_selected:{
						    		url:url,
									width:width,
									height:height
							    },
								
								page_title:'',
								page:null,
								page_param:''
						    });
					    	<?php echo $field?>.init();
					    	<?php echo $field?>.preview();
					    	window.send_to_editor = window.__send_to_editor;
					    }
						
					    wp.media.editor.open();
					    return false;    
					}
				};

				$(document).bind('on_wrest_app_ready',function(){
					<?php echo $field?>.init();
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_color_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'default'=>null,
            'field-class'=>'',
            'description' => ''
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $color = $this->get_option($key);
        $default_color = $data['default'];
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper"  style="display: inline;">
						<div class="zent-color-picker" tabindex="0">
							<div id="<?php echo $field?>-picker" data-float="1" class="zent-color-picker__text" style="background-color: #<?php echo esc_attr($color)?>;"></div>
						</div>	
						<input type="text" id="<?php echo $field;?>" value="<?php echo esc_attr($color)?>" style="width:60px;"/>
						<a href="javascript:void(0);" id="<?php echo $field?>-reset">重置</a>
					</div>
					
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field?>-reset').click(function(){
					var hex = '<?php echo $default_color;?>';
					$('#<?php echo $field;?>').val(hex);
					$('#<?php echo $field?>-picker').css('background-color','#'+hex).colpickSetColor(hex);
				});

				$('#<?php echo $field;?>').click(function(){
					var hex = $(this).val();
					
					$('#<?php echo $field;?>').val(hex);
					if(!hex){
						$('#<?php echo $field?>-picker').css('background-color','#fff');
						return;
					}
					
					$('#<?php echo $field?>-picker').css('background-color','#'+hex).colpickSetColor(hex);
				});

				$('#<?php echo $field;?>').keyup(function(){
					window.<?php echo $field?>.set_value($(this).val());
				});
				
				window.<?php echo $field?>={
					timeout:null,
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field;?>').val(val);
						$('#<?php echo $field;?>').click();
					}
				};
				
				$('#<?php echo $field?>-picker').colpick({
				    layout:'full',
				    submit:0,
				    color:'<?php echo $color ?>',
				    colorScheme:'light',
				    onChange:function(hsb,hex,rgb,el,bySetColor) {
				    	$('#<?php echo $field;?>').val(hex);
						$('#<?php echo $field?>-picker').css('background-color','#'+hex);

						if(window.<?php echo $field?>.timeout){
							clearTimeout(window.<?php echo $field?>.timeout);
						}
						window.<?php echo $field?>.timeout = setTimeout(function(){
							 $(document).trigger("on_<?php echo $this->get_template_key()?>_change");
						},1000);
					   
				    }})
    				.keyup(function(){
    				    $(this).colpickSetColor(this.value);
    			    });
			})(jQuery);
		</script>
        <?php 
    }
    
    
    public function generate_scale_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'symbol'=>'%',
            'field-class'=>'',
            'description' => ''
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        ?>
        <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
						<span id="<?php echo $field?>-title"><?php echo esc_html($val)?><?php echo $data['symbol']?></span>
						<div>
							<input type="hidden" id="<?php echo $field?>" value="<?php echo esc_attr($val)?>" />	
							<div id="<?php echo $field?>-view" class="jquery-view_panel">
                                <span class="r">100</span>0
                                <div class="jquery-view" >
                                    <div class="jquery-view-step"></div>
                                	<span class="jquery-view-btn"></span>
                                </div>
                            </div>
                        </div>	
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field?>-view').formScale(function(m){
    				var per = (m*100).toFixed(0);
					$('#<?php echo $field?>').val(per);
					$('#<?php echo $field?>-title').text(per+'<?php echo $data['symbol']?>');
					window.<?php echo $field?>.onblur();
    			});
    			
				window.<?php echo $field?>={
					timeout:null,
					onblur:function(){
						if(window.<?php echo $field?>.timeout){
							clearTimeout(window.<?php echo $field?>.timeout);
						}
						window.<?php echo $field?>.timeout = setTimeout(function(){
							 $(document).trigger("on_<?php echo $this->get_template_key()?>_change");
						},1000);
					},
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field;?>').val(val);
						var width = $('#<?php echo $field?>-view').css('width','200px').width();
		    			var per = (val*0.01*width).toFixed(0);
		    			$('#<?php echo $field?>-title').text(val+'<?php echo $data['symbol']?>');
		    			$('#<?php echo $field?>-view .jquery-view-step').css('width',per+'px');
		    			$('#<?php echo $field?>-view .jquery-view-btn').css('left',per+'px');
					}
				};
				
				$(document).bind('on_wrest_app_ready',function(){
					<?php if($val){
						?>
						window.<?php echo $field?>.set_value(<?php echo absint($val)?>);
						<?php 
					}?>
				});
				
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_video_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'field-class'=>'',
            'description' => ''
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div>
						<textarea id="<?php echo $field ?>"  style="width:300px;height:50px;cursor:pointer;" placeholder="请输入视频地址"><?php echo esc_textarea($val)?></textarea>
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					remove:function(){
						if(!confirm('确认删除？')){return false;}

						$('#<?php echo $field?>-views').val('');
						$('#<?php echo $field?>').val('');
					},
					show:function(data){
						$('#<?php echo $field?>-views').val(data);
						$('#<?php echo $field?>').val(data);
						
					},
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						this.show(val);
					}
				};

				$('#<?php echo $field?>-views').blur(function(){
					$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
				});
				$(document).bind('on_wrest_app_ready',function(){
					<?php if($val){
						?>
						window.<?php echo $field?>.show('<?php echo esc_attr($val);?>');
						<?php 
					}?>
				});
				
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_image_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'width'=>60,
            'height'=>60,
            'local'=>false,
            'field-class'=>'',
            'description' => ''
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div>
						<input type="hidden" id="<?php echo $field ?>" value="<?php echo esc_attr($val?json_encode($val):'')?>" />
						<img src="" onclick="window.<?php echo $field ?>.upload();" id="<?php echo $field?>-views" style="min-width:80px;min-height:80px;max-width:120px;max-height:120px;border:solid 1px #d1d1d1;cursor:pointer;max-width:50px;max-height:50px;"/>	
						<a href="javascript:void(0);" onclick="window.<?php echo $field?>.remove();">删除</a>	
					</div>
					<div><?php echo $data['description'];?>(图片名称不能含中文，支持jpg/jpeg、png、gif)</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					remove:function(){
						if(!confirm('确认删除？')){return false;}

						$('#<?php echo $field?>-views').attr('src','<?php echo $defaults&&isset($defaults['url'])&&$defaults['url']?$defaults['url']:""?>');
						$('#<?php echo $field?>').val(JSON.stringify(<?php echo $defaults&&isset($defaults['url'])&&$defaults['url']?json_encode($defaults):'[]';?>));
					},
					show:function(data){
						if(!data
							||typeof data.url=='undefined'
							||typeof data.width=='undefined'
							||typeof data.height=='undefined'
						){
							$('#<?php echo $field?>-views').attr('src','');
							$('#<?php echo $field?>').val('');
							return;
						}
						
						$('#<?php echo $field?>-views').attr('src',data.url);
						$('#<?php echo $field?>').val(JSON.stringify(data));
						
					},
					upload:function(){
						window.__send_to_editor = window.send_to_editor;
						window.send_to_editor = function(html) {
							var $img = jQuery('img','<span>'+html+'</span>');
							if($img.length==0){
								alert('图片信息获取失败(请不要选择“创建相册”进行插入图片)！');
								return;
							}
							var url = $img.attr('src');
							var width = $img.attr('width');
							var height = $img.attr('height');

							if(!url){
								alert('图片路径信息获取失败！');
								return;
							}

							if(!width){
								alert('图片宽度信息获取失败！');
								return;
							}
							if(!height){
								alert('图片高度信息获取失败！');
								return;
							}
							window.<?php echo $field?>.show({
								url:url,
								width:width,
								height:height
						    });
						    
							$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
					    	window.send_to_editor = window.__send_to_editor;
					    }

					    wp.media.editor.open();
					    return false;    
					},
					get_value:function(){
						var val = $.trim($('#<?php echo $field?>').val());
						var img = val?$.parseJSON(val):null;
						return img&&typeof img.url!='undefined'&&img.url?img:null;
					},
					set_value:function(val){
						this.show(val);
					}
				};
				$(document).bind('on_wrest_app_ready',function(){
					<?php if($val&&is_array($val)){?>
						var data = <?php echo json_encode($val);?>;
						window.<?php echo $field?>.show(data);
						<?php 
					}?>
				});
				
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_checkbox_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'label'=>'',
            'field-class'=>'',
            'description' => ''
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					
						<input id="<?php echo $field?>" type="hidden" value="<?php echo esc_attr($val)?>"/> 
						<label class="zent-checkbox-wrap <?php echo $val=='yes'?'zent-checkbox-checked':'';?>" id="<?php echo $field?>-checkbox">
							<span class="zent-checkbox"><span class="zent-checkbox-inner"></span>
								<input type="checkbox" value="on">
							</span>
							<span class="label"><?php echo $data['label'];?></span>
						</label>		
					
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field?>-checkbox,#<?php echo $field?>-checkbox .label').click(function(){
        			var $this = $('#<?php echo $field?>-checkbox');
					if($this.hasClass('zent-checkbox-checked')){
						$this.removeClass('zent-checkbox-checked');
						$('#<?php echo $field?>').val('no');
					}else{
						$this.addClass('zent-checkbox-checked');
						$('#<?php echo $field?>').val('yes');
					}
					$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
        		});
        		
				window.<?php echo $field?>={
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
						$('#<?php echo $field?>-checkbox').click();
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    public function generate_checkbox_list_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'label'=>'',
            'field-class'=>'',
            'description' => '',
            'options'=>array()
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        if(!$val||!is_array($val)){
            $val=array();
        }
        if(!$data['options']){
            $data['options']=array();
        }
        if( $data['options']&&!is_array( $data['options'])&&is_callable( $data['options'])){
             $data['options']=call_user_func( $data['options']);
        }
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<?php foreach ($data['options'] as $k=>$v){
					    ?>
    					<label data-val="<?php echo esc_attr($k);?>" class="wrest-checkboxlist-<?php echo $field;?> zent-checkbox-wrap <?php echo in_array($k,$val)?'zent-checkbox-checked':'';?>">
    						<span class="zent-checkbox"><span class="zent-checkbox-inner"></span>
    							<input type="checkbox" value="on">
    						</span>
    						<span class="label"><?php echo $v;?></span>
    					</label>	
					    <?php 
					}?>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				$('.wrest-checkboxlist-<?php echo $field;?>').click(function(){
        			var $this = $(this);
					if($this.hasClass('zent-checkbox-checked')){
						$this.removeClass('zent-checkbox-checked');
					}else{
						$this.addClass('zent-checkbox-checked');
					}
					
					$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
        		});
				$('.wrest-checkboxlist-<?php echo $field;?> .label').click(function(){
        			var $this = $(this).parent('.wrest-checkboxlist-<?php echo $field;?>');
					if($this.hasClass('zent-checkbox-checked')){
						$this.removeClass('zent-checkbox-checked');
					}else{
						$this.addClass('zent-checkbox-checked');
					}
					
					$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
        		});
				window.<?php echo $field?>={
					get_value:function(){
						var options = [];
						$('.wrest-checkboxlist-<?php echo $field;?>.zent-checkbox-checked').each(function(){
							options.push($(this).data('val'));
						});
						return options;
					},
					set_value:function(val){
						if(!val||typeof val!='object'){
							return;
						}

						$('.wrest-checkboxlist-<?php echo $field;?>').removeClass('zent-checkbox-checked');
						for(var p in val){
							var v = val[p];
							$('.wrest-checkboxlist-<?php echo $field;?>[data-val='+v+']').addClass('zent-checkbox-checked');
						}
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    public function generate_select_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'label'=>'',
            'call'=>null,
            'field-class'=>'',
            'selected-class'=>'zent-radio-checked',
            'description' => '',
            'options'=>array()
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $val = $this->get_option($key);
        if(!is_array($data['options'])&&is_callable($data['options'])){
            $data['options'] = call_user_func($data['options']);
        }
        if(!$data['call']){
            $data['call']=function($k,$v,$current){
                ?>
			    <label data-type="<?php echo esc_attr($k)?>" class="zent-radio-wrap option-item <?php echo $current==$k?'zent-radio-checked':'';?>">
					<span class="zent-radio">
						<span class="zent-radio-inner"></span>
						<input type="radio">
					</span>
					<span><?php echo $v;?></span>
				</label>
			    <?php 
            };
        }
        $class = esc_attr($data['selected-class']);
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
				
						<input id="<?php echo $field?>" type="hidden" value="<?php echo esc_attr($val)?>"/> 
    					<div class="zent-radio-group" id="<?php echo $field?>-options">
    				  <?php foreach ($data['options'] as $k=>$v){
    						    if(!$val){$val=$k;}
    						    call_user_func_array($data['call'], array($k,$v,$val));
    						}?>
    					</div>	
					
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field?>-options .option-item').click(function(){
					$('#<?php echo $field?>-options .option-item.<?php echo $class?>').removeClass('<?php echo $class?>');
					$(this).addClass('<?php echo $class?>');
					$('#<?php echo $field?>').val($(this).data('type'));
					$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
				});
        		
				window.<?php echo $field?>={
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
						$('#<?php echo $field?>-options .option-item[data-type='+val+']').click();
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_mult_select_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'field-class'=>'',
            'description' => '',
            'placeholder'=>'',
            'options'=>null
        );
        if(!is_array($data['options'])&&is_callable($data['options'])){
            $data['options'] = call_user_func($data['options']);
        }
        
        $data = wp_parse_args ( $data, $defaults );
        $values = $this->get_option($key);
         if(!$values||!is_array($values)){$values=array();}   
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper">
						<div style="display:flex;flex-direction:row;flex-wrap:wrap;">
						<?php 
						foreach ($data['options'] as $key=>$label){
						    ?><label style="margin:10px;"><input value="<?php echo esc_attr($key);?>" class="<?php echo $field?>-item" type="checkbox" <?php echo in_array($key, $values)?'checked':'';?> /> <?php echo $label;?></label><?php 
						}
						?>
						</div>
					</div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				window.<?php echo $field?>={
					get_value:function(){
						var values = [];
						 $('.<?php echo $field?>-item:checked').each(function(){
							 values.push($(this).val());
						});

						return values;
					},
					set_value:function(val){
						
					}
				};
				
				$('.<?php echo $field?>-item').change(function(){
					$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
				});
				
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_posts_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'post_type'=>'post',
        	'label'=>null,
            'field-class'=>'',
            'description' => '',
            'placeholder'=>'',
            'call'=>null
        );
        
        $data = wp_parse_args ( $data, $defaults );
        $taxonomy = get_taxonomy($data['post_type']);
        $label = $data['post_type'];
        
        if(!empty($data['label'])){
        	$label = $data['label'];
        }else{
        	if($taxonomy){
        		$label = $taxonomy->label;
        	}else{
        		global $wp_post_types;
        		$label = $wp_post_types&&isset($wp_post_types[$data['post_type']])?$wp_post_types[$data['post_type']]->label:$data['post_type'];
        	}
        }
        $menu_configs = $this->get_option($key);
        if(!$menu_configs||!is_array($menu_configs)){
            $menu_configs = array();
        }
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
    			
				<div class="zent-design-editor__control-group-control">
						<?php if(!defined('xunhuweb-menu-edit')){
						    define('xunhuweb-menu-edit', 1);
						    ?>
						    <script type='text/javascript' src='<?php echo WREST_URL?>/assets/js/nav-menu.js?v=2'></script>
                             <link rel="stylesheet"  href='<?php echo WREST_URL?>/assets/css/nav-menus.css' type='text/css' />
                             <link rel="stylesheet" type="text/css" href="<?php echo WREST_URL?>/assets/css/emotion_editor.css"/>
                             <script type='text/javascript'>
                                /* <![CDATA[ */
                                var navMenuL10n = {"noResultsFound":"\u672a\u627e\u5230\u7ed3\u679c\u3002","warnDeleteMenu":"\u60a8\u5c06\u6c38\u4e45\u5220\u9664\u6240\u9009\u83dc\u5355\u3002\n\u70b9\u51fb\u201c\u53d6\u6d88\u201d\u505c\u6b62\uff0c\u70b9\u51fb\u201c\u786e\u5b9a\u201d\u5220\u9664\u3002","saveAlert":"\u79bb\u5f00\u8fd9\u4e2a\u9875\u9762\uff0c\u60a8\u6240\u505a\u7684\u66f4\u6539\u5c06\u4e22\u5931\u3002","untitled":"\uff08\u65e0\u6807\u7b7e\uff09"};
                                var menus = {"oneThemeLocationNoMenus":"","moveUp":"\u4e0a\u79fb\u4e00\u9879","moveDown":"\u4e0b\u79fb\u4e00\u9879","moveToTop":"\u4e0a\u79fb\u5230\u9876","moveUnder":"\u79fb\u81f3%s\u4e0b","moveOutFrom":"\u4ece%s\u79fb\u51fa","under":"%s\u4e0b","outFrom":"%s\u4e4b\u5916","menuFocus":"%1$s\u3002%3$s\u4e2a\u83dc\u5355\u9879\u4e4b%2$s\u3002","subMenuFocus":"%1$s\u3002%3$s\u83dc\u5355\u4e2d\u7684\u7b2c%2$d\u9879\u3002"};
                                /* ]]> */
                            </script>
                            <style type="text/css">
                                .menu-item-depth-1{margin-left:0!important;}
                                .wrest-search{width:200px;}
                            </style>
						    <?php 
						}?>
					 	
                       
                        <div class="nav-menus-php">
                         	<ul class="menu ui-sortable" id="<?php echo $field?>-menu-to-edit">
                         		<?php if($menu_configs){
                         		    foreach ($menu_configs as $post_ID){
                         		        echo $this->generate_posts_item_html(array(
                         		            'post_id'=>$post_ID,
                         		            'post_type'=>$data['post_type'],
                         		        	'label'=>$data['label']
                         		        ));
                         		    }
                         		}?>
                         	</ul>
                         </div>
                          <h2 class="xh-mT15"><button class="button" id="<?php echo $field?>-btn-add-menu" type="button">新增<?php echo $label?>项</button></h2>
                        <div class="xh-mT15 xh-c-sub xh-f-sub"><?php echo $data['description'];?></div>
                         <hr/>
                         <script type="text/javascript">
                         	jQuery(function($){
                         		$(document).bind('on_wechat_menu_position_change',function(){
    								$('#<?php echo $field?>-menu-to-edit .menu-item.menu-item-depth-0').each(function(){
    									var $submenu = $(this).next('.menu-item.menu-item-depth-1');
    									if($submenu.length>0){
    										$('#menu-'+$(this).data('context')+'-content').hide();
    									}else{
    										$('#menu-'+$(this).data('context')+'-content').show();
    									}
    								});
    							});
    							
    							$(document).trigger('on_wechat_menu_position_change');
    							
    							var navMenu = xunhuwebNavMenu($('#<?php echo $field?>-menu-to-edit'));
    							 
    							$('#<?php echo $field?>-btn-add-menu').click(function(){
    								$('#wpbody-content').loading();
        							$.ajax({
        								url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_admin",'tab'=>'create_post_item','post_type'=>$data['post_type']),true,true)?>',
        								type:'post',
        								timeout:120*1000,
        								async:true,
        								cache:false,
        								data:{
            								label:'<?php echo esc_attr($data['label'])?>',
            							},
        								dataType:'json',
        								complete:function(){
        									$('#wpbody-content').loading('hide');
        								},
        								success:function(e){
        									if(e.errcode!=0){
        										alert(e.errmsg);
        										return;
        									}
        									
        									navMenu.addMenuItemToBottom(e.data);
        									$( document.body ).trigger( 'wrest-enhanced-select-init');
        								},
        								error:function(e){
        									console.error(e.responseText);
        									alert('系统异常，请重试！');
        								}
        							});
    							});
    							
    							window.<?php echo $field?>={
									get_value:function(){
										var post_IDs = [];
										$('#<?php echo $field?>-menu-to-edit li.menu-item').each(function(){
											var post_id = $(this).find('.post-item').val();
											if(post_id){
												post_IDs.push(post_id);
											}
										});
										
										return post_IDs;
									},
									set_value:function(val){
										
									}
								};

    							$(document).bind('on_wrest_app_ready',function(){
    								if(!document.wrest_enhanced_select_inited){
    									document.wrest_enhanced_select_inited= true;
    									$( document.body ).trigger( 'wrest-enhanced-select-init');
    								}
    							});
    							
                             });
    					</script>
				</div>
				
			</div>
			
		</div>
        <?php 
    }
    
    public function generate_posts_item_html($config = null){
        return WRest::instance()->WP->requires(WREST_DIR, 'wechat/post-edit.php',array(
            'request'=>$config,
            'context'=>WRest_Helper::generate_unique_id()
        ));
    }
}