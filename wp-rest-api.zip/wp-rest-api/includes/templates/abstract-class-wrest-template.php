<?php
require_once 'abstract-class-wrest-template-settings.php';
abstract class Abstract_WRest_Template extends Abstract_WRest_Template_Settings{
    public $group ='body';
    public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);
    }
  
    public function generate_wxml_item($section_id,$section_index){
        
    }
    
    public function reset_imgurl($url){
        if(!$url){
            return $url;
        }
        
        if(is_array($url)&&isset($url['url'])){
            if(strpos($url['url'], '?')===false){
                $url['url'] .=  '?wrest-version='.$this->version->get_version_code();
            }else{
                $url['url'] .= '&wrest-version='.$this->version->get_version_code();
            }
            
            return $url;
        }
        
        if(!is_string($url)){
            return $url;
        }
        
        if(strpos($url, '?')===false){
            return $url.'?wrest-version='.$this->version->get_version_code();
        }
        
        return $url.'&wrest-version='.$this->version->get_version_code();
    }
    
    public function get_template_cache_key(){
        $cacheKey = $this->version->get_version_code();
        $config = $this->get_config();
        foreach ($config as $key=>$val){
            $cacheKey.="{$key}=";
            if(is_array($val)){
                foreach ($val as $item){
                    if(is_string($item)||is_numeric($item)||is_bool($item)){
                        $cacheKey.="{$item},";
                    }
                }
            }else if(is_string($val)||is_numeric($val)||is_bool($val)){
                $cacheKey.=$val;
            }
            $cacheKey.=";";
        }
         
        return md5($cacheKey);
    }
    
    public function __scripts(){
        ?>
        <script type="text/javascript">
        	(function($){
        		window.<?php echo $this->get_template_key()?>={};
            	window.<?php echo $this->get_template_key()?>.config=function(){
            		var config = {
						type:'<?php echo get_called_class();?>'
                    };
                    
    		       try{
    		    	   <?php foreach ($this->fields as $key=>$field){ ?>
		            	config.<?php echo $key?> = window.<?php echo $this->get_field_key($key)?>.get_value();
		        		<?php }?>
        		   }catch(e){
					  alert(e);
					  throw e;
            	   }
    		        return config;
                }
            })(jQuery);
		</script>
        <?php 
    }
    
    public function __preview(){
        ?>
        <div id="<?php echo $this->get_template_key('preview')?>" class="zent-design-preview-controller__drag-handle"></div>  
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    public function __actions(){
    	?>
    	<div id="<?php echo $this->get_template_key('remove')?>" class="zent-popover-wrapper zent-pop-wrapper zent-design-preview-controller__action-btn-delete" style="display: inline-block;">
            <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" class="zent-design-preview-controller__icon-delete">
	            <g fill="none" fill-rule="evenodd">
		            <circle cx="10" cy="10" r="10"></circle>
		            <path fill="#FFF" d="M13.75 7.188l-.937-.938L10 9.063 7.188 6.25l-.938.937L9.062 10 6.25 12.812l.937.938L10 10.938l2.812 2.812.938-.937L10.938 10"></path>
	            </g>
            </svg>
        </div>	
        <script type="text/javascript">
			(function($){
				$('#<?php echo $this->get_template_key('remove')?>').click(function(){
					if(confirm('确定删除？')){
						$('#<?php echo $this->get_template_key()?>').remove();
					}
				});
			})(jQuery);
		</script>				
    	<?php 
    }
    
    public function __edit(){
    	if(count($this->fields)==0){
    		return;
    	}
    	?>
    	<div class="zent-design-editor-item">
        	<div class="rc-design-component-config-editor">
        		<div class="rc-design-editor-component-title">
                  	<span class="rc-design-editor-component-title__name" style="font-weight:bolder"><?php echo $this->title?></span>
                  	<span class="rc-design-editor-component-title__msg"></span>
               </div>
               <div style="margin:15px;">
                  	<?php echo $this->description ?>
               </div>
               <?php 
               	foreach ($this->fields as $key=>$field){
               		$type = isset($field['type'])&&$field['type']?$field['type']:'text';
               		
               		if(!method_exists($this,"generate_{$type}_html")){
               		    continue;
               		}
               		
               		call_user_func_array(array($this,"generate_{$type}_html"), array($key,$field));
               	}
               ?>
          </div>
       </div>
    	<?php 
    }
    
    /**
     * 
     * @param Abdtract_WRest_XCX_Setting_Menu $page
     */
    public function render($page){
        $this->__scripts();
    	?>
    	<div class="zent-design-preview-item <?php echo $this->type ?>" id="<?php echo $this->get_template_key()?>" data-id="<?php echo "{$this->type}_{$this->id}";?>">
            <div class="zent-design-preview-controller zent-design-preview-controller--editable zent-design-preview-controller--highlight zent-design-preview-controller--dragable">
      		<?php 
            	$this->__preview();
            	if($page->enable_edit){
            	    $this->__actions();
            	}
            ?>
          </div> 
          <?php $this->__edit(); ?>
        </div>
        <script type="text/javascript">
        	(function($){
        		$(document).bind('on_wrest_app_ready',function(){
        			$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
            	});
            })(jQuery);
		</script>
    	<?php 
    }
}