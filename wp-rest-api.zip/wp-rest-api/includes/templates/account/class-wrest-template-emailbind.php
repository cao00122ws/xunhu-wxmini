<?php
class WRest_Template_Emailbind extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="邮箱绑定";
        $this->init_form_fields( array(
            'icon'=>array(
                'title'=>'图标',
                'type'=>'image',
                'width'=>80,
                'height'=>80,
                'default'=>array(
                    'width'=>80,
                    'height'=>80,
                    'url'=>WREST_URL.'/assets/images/icon/page/emailbind.png'
                )
            ),
            'title'=>array(
                'title'=>'标题',
                'type'=>'text',
                'default'=>'我的邮箱'
            ),
            'border_top'=>array(
                'title'=>'上边线',
                'type'=>'checkbox'
            ),
            'border_bottom'=>array(
                'title'=>'下边线',
                'type'=>'checkbox'
            )
        ));
    }

    /**
     * @param $templates
     * @param WP_REST_Request $request
     * @return array|void
     */
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['id']=WRest_Helper::generate_unique_id();

        global $current_user;
        if(!empty($current_user->user_email)){
            $config['subtitle'] = $current_user->user_email;
        }

        $config['icon'] = $this->reset_imgurl($config['icon']);
        $config['link']=$this->reset_link( array(
            'page'=>'pages/email-bind/index'
        ));
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
         $this->generate_nav_attribute_start("{$section_id}.link",array(
            'wx:if'=>"{{".$section_id.".type=='".$this->type."'}}",
            'class'=>'xh-panel xh-w',
            'hover-class'=>'xh-panel-hover'
        ));
        ?>
        <view class="xh-row xh-pL30 xh-pR15 container xh-panel xh-w-750 {{<?php echo $section_id;?>.border_top=='yes'?' xh-solid-t':''}}" hover-class="xh-panel-hover">
            <view class="xh-row xh-w xh-pT30 xh-pB30 {{<?php echo $section_id;?>.border_bottom=='yes'?' xh-solid-b':''}}" style="justify-content:space-between;">
                <view class="left">
                    <image class="xh-nav-icon xh-mR30" src="{{<?php echo $section_id;?>.icon?<?php echo $section_id;?>.icon.url:''}}" mode="widthFix" />
                    <view class="xh-c-main xh-f-main single-ellipsis xh-mw-345" >{{<?php echo $section_id;?>.title}}</view>
                </view>

                <view class="right">
                    <view class="sub-title xh-f-sub single-ellipsis xh-mw-345 {{<?php echo $section_id;?>.subtitle?'xh-c-sub':'xh-c-price'}}">{{<?php echo $section_id;?>.subtitle?<?php echo $section_id;?>.subtitle:'待绑定'}}</view>
                </view>
            </view>
        </view>
        <?php
        $this->generate_nav_attribute_end();
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
					var config = window.<?php echo $this->get_template_key()?>.config();
					var border_top='';
					if(config.border_top=='yes'){
						border_top=';border-top:solid 1px #f4f4f4;';
					}console.log(config);
					var border_bottom='';
					if(config.border_bottom=='yes'){
						border_bottom=';border-bottom:solid 1px #f4f4f4;';
					}

    				var iconHtml=config.icon&&config.icon.url?'<img src="'+config.icon.url+'" alt="" style="width:25px;height:25px">&nbsp;':'';
                    var title=config.title?config.title:'我的邮箱';
                    var subtitle=config.subtitle?config.subtitle.replace('{0}','x'):'';

                    var html='<div class="rc-design-vue-preview rc-design-component-link-preview xh-panel" style="'+border_top+border_bottom+';padding: 5px 10px;display:flex;flex-direction:row;align-items:center;justify-content: space-between;min-height:30px;">' +
                                '<div style="display:flex;align-items:center;">' +
                                    iconHtml +
                                    '<span class="xh-c-main xh-f-main">'+title+'</span>' +
                                '</div>' +
                                '<div style="display:flex;align-items:center;justify-content:right;">' +
                                    '<span class="xh-c-sub xh-f-sub">'+subtitle+'</span>&nbsp;' +
                                    '<img src="<?php echo WREST_URL.'/assets/images/woocommerce/right.png';?>" alt="" style="width:16px;height:16px">' +
                                '</div>' +
                            '</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}