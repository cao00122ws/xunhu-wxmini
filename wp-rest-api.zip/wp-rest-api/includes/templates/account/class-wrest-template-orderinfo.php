<?php
class WRest_Template_Orderinfo extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="订单信息";
        $this->init_form_fields( array(
           
        ));
    }
    
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['id']=WRest_Helper::generate_unique_id();
       
        $config['items'] =$this->get_order_status_list();
        $config['order_status_count'] = count($config['items']);
 
        $templates[] = $config;
    }
    
    public function get_order_status_list(){
        $counts =is_user_logged_in()? WRest::instance()->get_product_api()->get_user_order_counts():array(); 
        $status_array = Abstract_WRest_Order::get_status_group($counts);
        $status_list=array();
        foreach ($status_array as $status=>$statusSet){
            $statusSet['icon'] =  WREST_URL."/assets/images/v2/icon/order/{$status}.png";  
            $status_list[$status] =$statusSet;
        }
        
        return $status_list;
    }
    
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
         <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-panel xh-w">
            <view wx:if="{{!<?php echo $section_id;?>.order_status_count||<?php echo $section_id;?>.order_status_count<=5}}" class="xh-row xh-p30 order-status-container xh-w">
                <view class="order-status" wx:for="{{<?php echo $section_id;?>.items}}" wx:key="{{index}}" bindtap="__nav__" data-action="navigate" data-url="/package_a/pages/order/list/index?status={{index}}">
                    <badge num="{{item.count}}" right="{{5}}" top="{{-5}}">
                    	<icon-button icon="{{item.icon}}" title="{{item.label}}" />
                    </badge>
                </view>
            </view>
            <scroll-view scroll-x wx:else class="order-status-container-scroll xh-p30 xh-w">
                <view class="order-status" wx:for="{{<?php echo $section_id;?>.items}}" wx:key="{{index}}" bindtap="__nav__" data-action="navigate" data-url="/package_a/pages/order/list/index?status={{index}}">
                   	<badge num="{{item.count}}" right="{{5}}" top="{{-5}}">
                    	<icon-button icon="{{item.icon}}" title="{{item.label}}" />
                    </badge>
                </view>
            </scroll-view>
    	</view>
        <?php 
    }
        
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
					var config = window.<?php echo $this->get_template_key()?>.config();
					var border_top='';
					if(config.border_top=='yes'){
						border_top=';border-top:solid 1px #f4f4f4;';
					}console.log(config);
					var border_bottom='';
					if(config.border_bottom=='yes'){
						border_bottom=';border-bottom:solid 1px #f4f4f4;';
					}

	    			
					var html = '<div class="rc-design-vue-preview rc-design-component-image-text-nav-preview" style="'+border_top+border_bottom+';">';
				
    				html += '<div class="cap-image-ad">';
    				html+='<div class="cap-image-ad__image-nav" style="padding:10px 0;overflow-x: hidden; background-color: rgb(255, 255, 255);text-align:center;">';

    				<?php 
    				foreach($this->get_order_status_list() as $status=>$settings){
    				    ?>
    				    html+='<div class="image-wrapper" style="width: 64px; margin-right: 0px;">\
        						<a href="javascript:;" class="cap-image-ad__link cap-image-ad__link--image-nav">\
        							<div class="cap-image-ad__image" style="height: 30px; width: 30px; background-image: url(<?php echo isset($settings['icon'])?$settings['icon']:''?>);"></div>\
        							<h3 class="cap-image-ad__nav-title"><?php echo esc_html($settings['label'])?></h3>\
        						</a>\
        					</div>';
    				    <?php 
    				}?>
					html+='</div>';
					
					html+='</div>';
            	
    				html+='</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    public function generate_order_status_list_html($key,$data){
    	$field = $this->get_field_key ( $key );
    	$defaults = array (
    			'title' => '',
    			'post_type'=>'post',
    			'label'=>null,
    			'field-class'=>'',
    			'description' => '',
    			'placeholder'=>'',
    			'call'=>null
    	);
    	
    	$data = wp_parse_args ( $data, $defaults );
    	
    	$menu_configs = $this->get_option($key);
    	if(!$menu_configs||!is_array($menu_configs)){
    		$menu_configs = array();
    	}
    	?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
    			
				<div class="zent-design-editor__control-group-control">
						<?php if(!defined('xunhuweb-menu-edit')){
						    define('xunhuweb-menu-edit', 1);
						    ?>
						    <script type='text/javascript' src='<?php echo WREST_URL?>/assets/js/nav-menu.js?v=2'></script>
                             <link rel="stylesheet"  href='<?php echo WREST_URL?>/assets/css/nav-menus.css' type='text/css' />
                             <link rel="stylesheet" type="text/css" href="<?php echo WREST_URL?>/assets/css/emotion_editor.css"/>
                             <script type='text/javascript'>
                                /* <![CDATA[ */
                                var navMenuL10n = {"noResultsFound":"\u672a\u627e\u5230\u7ed3\u679c\u3002","warnDeleteMenu":"\u60a8\u5c06\u6c38\u4e45\u5220\u9664\u6240\u9009\u83dc\u5355\u3002\n\u70b9\u51fb\u201c\u53d6\u6d88\u201d\u505c\u6b62\uff0c\u70b9\u51fb\u201c\u786e\u5b9a\u201d\u5220\u9664\u3002","saveAlert":"\u79bb\u5f00\u8fd9\u4e2a\u9875\u9762\uff0c\u60a8\u6240\u505a\u7684\u66f4\u6539\u5c06\u4e22\u5931\u3002","untitled":"\uff08\u65e0\u6807\u7b7e\uff09"};
                                var menus = {"oneThemeLocationNoMenus":"","moveUp":"\u4e0a\u79fb\u4e00\u9879","moveDown":"\u4e0b\u79fb\u4e00\u9879","moveToTop":"\u4e0a\u79fb\u5230\u9876","moveUnder":"\u79fb\u81f3%s\u4e0b","moveOutFrom":"\u4ece%s\u79fb\u51fa","under":"%s\u4e0b","outFrom":"%s\u4e4b\u5916","menuFocus":"%1$s\u3002%3$s\u4e2a\u83dc\u5355\u9879\u4e4b%2$s\u3002","subMenuFocus":"%1$s\u3002%3$s\u83dc\u5355\u4e2d\u7684\u7b2c%2$d\u9879\u3002"};
                                /* ]]> */
                            </script>
                            <style type="text/css">
                                .menu-item-depth-1{margin-left:0!important;}
                                .wrest-search{width:200px;}
                            </style>
						    <?php 
						}?>
					 	
                       
                        <div class="nav-menus-php">
                         	<ul class="menu ui-sortable" id="<?php echo $field?>-menu-to-edit">
                         		<?php if($menu_configs){
                         		    foreach ($menu_configs as $item){
                         		    	echo $this->generate_order_status_item_html($item);
                         		    }
                         		}?>
                         	</ul>
                         </div>
                          <h2 class="xh-mT15"><button class="button" id="<?php echo $field?>-btn-add-menu" type="button">新增订单状态项</button></h2>
                        <div class="xh-mT15 xh-c-sub xh-f-sub"><?php echo $data['description'];?></div>
                         <hr/>
                         <script type="text/javascript">
                         	jQuery(function($){
                         		$(document).bind('on_wechat_menu_position_change',function(){
    								$('#<?php echo $field?>-menu-to-edit .menu-item.menu-item-depth-0').each(function(){
    									var $submenu = $(this).next('.menu-item.menu-item-depth-1');
    									if($submenu.length>0){
    										$('#menu-'+$(this).data('context')+'-content').hide();
    									}else{
    										$('#menu-'+$(this).data('context')+'-content').show();
    									}
    								});
    							});
    							
    							$(document).trigger('on_wechat_menu_position_change');
    							
    							var navMenu = xunhuwebNavMenu($('#<?php echo $field?>-menu-to-edit'));
    							 
    							$('#<?php echo $field?>-btn-add-menu').click(function(){
    								$('#wpbody-content').loading();
        							$.ajax({
        								url:'<?php echo WRest::instance()->ajax_url(array('action'=>"wrest_admin",'tab'=>'create_order_status_item'),true,true)?>',
        								type:'post',
        								timeout:120*1000,
        								async:true,
        								cache:false,
        								data:{
            								label:'<?php echo esc_attr($data['label'])?>',
            							},
        								dataType:'json',
        								complete:function(){
        									$('#wpbody-content').loading('hide');
        								},
        								success:function(e){
        									if(e.errcode!=0){
        										alert(e.errmsg);
        										return;
        									}
        									
        									navMenu.addMenuItemToBottom(e.data);
        									$( document.body ).trigger( 'wrest-enhanced-select-init');
        								},
        								error:function(e){
        									console.error(e.responseText);
        									alert('系统异常，请重试！');
        								}
        							});
    							});
    							
    							window.<?php echo $field?>={
									get_value:function(){
										var orderStatusList = [];
										$('#<?php echo $field?>-menu-to-edit li.menu-item').each(function(){
											var $icon = $(this).find('.icon');
											if(!$icon.attr('src')){
												alert('订单状态需要一个图标！');
												throw '订单状态需要一个图标！';
											}
											
											orderStatusList.push({
												title:$.trim($(this).find('.page-title').html()),
												status:$(this).find('.post-item').val(),
												icon:$icon.attr('src')?{
													url:$icon.attr('src'),
													width:$icon.data('width'),
													height:$icon.data('height')
												}:null
											});
										});
										
										return orderStatusList;
									},
									set_value:function(val){
										
									}
								};

    							$(document).bind('on_wrest_app_ready',function(){
    								if(!document.wrest_enhanced_select_inited){
    									document.wrest_enhanced_select_inited= true;
    									$( document.body ).trigger( 'wrest-enhanced-select-init');
    								}
    							});
    							
                             });
    					</script>
				</div>
				
			</div>
			
		</div>
        <?php 
    }
    
    public function generate_order_status_item_html($config = null){
    	return WRest::instance()->WP->requires(WREST_DIR, 'wechat/order-status.php',array(
    			'request'=>$config,
    			'context'=>WRest_Helper::generate_unique_id()
    	));
    }
}