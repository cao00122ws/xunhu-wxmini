<?php
class WRest_Template_Userinfo extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="用户信息";
       
        $this->init_form_fields( array(
            'background_img'=>array(
                'title'=>'背景',
                'type'=>'image',
                'width'=>750,
        		'height'=>350,
        		'default'=>array(
        				'url'=>WREST_URL.'/assets/images/icon/page/usercenter-bg.jpg',
        				'width'=>750,
        				'height'=>350
        		)
            ),
            'txt_color'=>array(
                'title'=>'文字颜色',
                'type'=>'color',
                'default'=>'ffffff'
            ),
            'nav_height'=>array(
                'title'=>'面板高度',
                'type'=>'integer',
                'default'=>'140'
            )
        ));
    }
    /**
     * @param WP_REST_Request $request
     * @return array
     */
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['id']=WRest_Helper::generate_unique_id();
//         $sdk = $request->get_param('sdk');
//         if(!$sdk){
//             $config['background_img'] = array(
//                 'url'=>WREST_URL.'/assets/images/icon/page/usercenter-bg.jpg',
//                 'width'=>750,
//                 'height'=>350
//             );
//             $config['txt_color'] = 'ffffff';
//             $config['height'] = '350';
//         }
        if(!isset($config['nav_height'])||$config['nav_height']<170){$config['nav_height'] = 170;}
        global $current_wrest_user;
        if(!$current_wrest_user){
             $current_wrest_user= new WRest_User(get_current_user_id());
        }
        if($current_wrest_user->is_load()){
            $config['userInfo'] = array(
                'display_name'=>$current_wrest_user->get_nickname(),
                'headimgurl'=>$current_wrest_user->img
            );
        }
        $config['background_img'] = $this->reset_imgurl($config['background_img']);
        //声明需要获取code

        $config['authorize_url'] = $this->reset_link( array(
            'url'=>'package_c/pages/login/index'
        ));
        
        $config['refresh_url']= $this->reset_link( array(
            'url'=>'open-type-getUserInfo',
            'params'=>'refresh'
        ));
        
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="navigationBar-BackgroundColor xh-w-750 xh-row xh-pL30 xh-pR15 xh-pT30 xh-pB30 xh-column-c" style="position:relative;height:{{<?php echo $section_id;?>.nav_height}}rpx">
			<?php 
			$this->generate_nav_attribute_start("{$section_id}.authorize_url",array(
			   "class"=>"xh-row xh-w",
			    "style"=>"z-index:2;background:transparent;",
			    "wx:if"=>"{{!".$section_id.".userInfo}}"
			));
			?>
            	<image src="{{config.apiAssets}}/images/icon/page/unauthorized.png" class="xh-mR30" style="width:110rpx;height:110rpx;border-radius:110rpx;" />
                <view class="xh-column" style="width:500rpx;">
                    <text class="xh-f-big navigationBar-Textcolor" style="{{<?php echo $section_id;?>.txt_color?('color:#'+<?php echo $section_id;?>.txt_color):''}}">未登录</text>
                    <text class="xh-solid xh-f-small xh-pL15 xh-pR15 xh-active-b xh-c-active xh-active-border" style="border-radius:30rpx;">立即登录</text>
                </view>
            <?php 
            $this->generate_nav_attribute_end();
           
			$this->generate_nav_attribute_start("{$section_id}.refresh_url",array(
			    "class"=>"xh-row xh-w",
			    "style"=>"z-index:2;background:transparent;",
			    "wx:else"=>null
			));
			?>
                <image src="{{__section__.userInfo.headimgurl?__section__.userInfo.headimgurl:(config.apiAssets+'/images/icon/page/unauthorized.png')}}" class="xh-mR30" style="width:110rpx;height:110rpx;border-radius:110rpx;" />
                <view class="xh-column" style="width:500rpx;">
                    <text class="xh-f-big navigationBar-Textcolor single-ellipsis" style="max-width:500rpx;{{<?php echo $section_id;?>.txt_color?('color:#'+<?php echo $section_id;?>.txt_color):''}}">{{__section__.userInfo.display_name}}</text>
                    <text class="xh-solid xh-f-small xh-pL15 xh-pR15 xh-active-b xh-c-active xh-active-border" style="border-radius:30rpx;">更新资料</text>
                </view>
                
           <?php $this->generate_nav_attribute_end();?>
           
           	<image wx:if="{{<?php echo $section_id;?>.background_img}}" mode="aspectFill" src="{{<?php echo $section_id;?>.background_img.url}}" style="width:750rpx;height:{{<?php echo $section_id;?>.nav_height}}rpx;position:absolute;left:0;top:0;;" />
         </view> 
        <?php 
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

                    var html='<div class="rc-design-vue-preview rc-design-component-shop-banner-preview">\
                                <div class="cap-shop-banner cap-shop-banner--type-0" >\
                                    <div class="cap-shop-banner__cover" style="background-image: url('+(config.background_img?config.background_img.url:'')+');">\
                                    	<div class="cap-shop-banner__cover-mask"></div>\
                                	</div>\
                                	<div class="cap-shop-banner__inner" style="top:60px">\
                                		<div class="cap-shop-banner__content">\
                                        	<div class="cap-shop-banner__logo">\
                                        		<img style="border-radius:50%;" src="<?php echo WREST_URL?>/assets/images/icon/page/unauthorized.png" >\
                                    		</div>\
                                    		<div class="cap-shop-banner__right-content">\
                                    			<h3 style="color:#'+config.txt_color+'">用户234</h3>\
                                    		</div>\
                                    	</div>\
                                	</div>\
                                 </div>\
                        	</div>';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}