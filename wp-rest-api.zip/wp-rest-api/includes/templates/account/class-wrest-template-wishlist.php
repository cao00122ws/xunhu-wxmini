<?php
class WRest_Template_Wishlist extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="产品收藏";
        $this->init_form_fields( array(
            'icon'=>array(
                'title'=>'图标',
                'type'=>'image',
                'width'=>80,
                'height'=>80,
                'default'=>array(
                    'width'=>80,
                    'height'=>80,
                    'url'=>WREST_URL.'/assets/images/icon/page/wishlist.png'
                )
            ),
            'title'=>array(
                'title'=>'标题',
                'type'=>'text',
                'default'=>'我的收藏'
            ),
            'subtitle'=>array(
                'title'=>'标题',
                'type'=>'text',
                'default'=>'{0}个商品'
            ),
            'border_top'=>array(
                'title'=>'上边线',
                'type'=>'checkbox'
            ),
            'border_bottom'=>array(
                'title'=>'下边线',
                'type'=>'checkbox'
            )
        ));
    }
    /**
     * @param WP_REST_Request $request
     * @return array
     */
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['id']=WRest_Helper::generate_unique_id();
        
        $config['wishlist_count'] =WRest_Wishlist::count('product');
        $config['subtitle'] = $config['wishlist_count']>0?str_replace('{0}', $config['wishlist_count'], $config['subtitle']):"无";
        $config['icon'] = $this->reset_imgurl($config['icon']);
        $config['link']=$this->reset_link( array(
            'page'=>'/package_a/pages/wishlist/index'
        ));
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
         $this->generate_nav_attribute_start("{$section_id}.link",array(
            'wx:if'=>"{{".$section_id.".type=='".$this->type."'}}",
            'class'=>'xh-panel xh-w',
            'hover-class'=>'xh-panel-hover'
        ));
        
        ?><navigation cls="xh-w" title="{{<?php echo $section_id;?>.title}}" icon="{{<?php echo $section_id;?>.icon?<?php echo $section_id;?>.icon.url:''}}" subtitle="{{<?php echo $section_id;?>.subtitle}}" border_top="{{<?php echo $section_id;?>.border_top=='yes'}}" border_bottom="{{<?php echo $section_id;?>.border_bottom=='yes'}}" /><?php 
       
        $this->generate_nav_attribute_end();
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
					var config = window.<?php echo $this->get_template_key()?>.config();
					var border_top='';
					if(config.border_top=='yes'){
						border_top=';border-top:solid 1px #f4f4f4;';
					}console.log(config);
					var border_bottom='';
					if(config.border_bottom=='yes'){
						border_bottom=';border-bottom:solid 1px #f4f4f4;';
					}

    				var iconHtml=config.icon&&config.icon.url?'<img src="'+config.icon.url+'" alt="" style="width:25px;height:25px">&nbsp;':'';
                    var title=config.title?config.title:'我的收藏';
                    var subtitle=config.subtitle?config.subtitle.replace('{0}','x'):'';

                    var html='<div class="rc-design-vue-preview rc-design-component-link-preview xh-panel" style="'+border_top+border_bottom+';padding: 5px 10px;display:flex;flex-direction:row;align-items:center;justify-content: space-between;min-height:30px;">' +
                                '<div style="display:flex;align-items:center;">' +
                                    iconHtml +
                                    '<span class="xh-c-main xh-f-main">'+title+'</span>' +
                                '</div>' +
                                '<div style="display:flex;align-items:center;justify-content:right;">' +
                                    '<span class="xh-c-sub xh-f-sub">'+subtitle+'</span>&nbsp;' +
                                    '<img src="<?php echo WREST_URL.'/assets/images/woocommerce/right.png';?>" alt="" style="width:16px;height:16px">' +
                                '</div>' +
                            '</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}