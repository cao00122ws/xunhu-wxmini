<?php
class WRest_Template_Authorize_Btn_Login extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="微信授权";
       
        $this->fields = array(
            'modal'=>array(
                'title'=>'登录方式',
                'type'=>'select',
                'default'=>'open-type-getUserInfo',
                'options'=>array(
                    'open-type-getUserInfo'=>'微信登录',
                    'open-type-getPhoneNumber'=>'手机登录',
                )
            ),
            'text'=>array(
                'title'=>'按钮文字',
                'type'=>'text',
                
                'default'=>'微信授权'
            ),
            'color_background'=>array(
                'title'=>'按钮背景颜色',
                'type'=>'color',
                'default'=>''
            ),
            'color_txt'=>array(
                'title'=>'按钮文字颜色',
                'type'=>'color',
                'default'=>''
            ),
            'width'=>array(
                'title'=>'按钮宽度(%)',
                'type'=>'scale',
                'default'=>'100'
            )
        );
    }
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        
        $config['authorize_url'] = $this->reset_link( array(
            'url'=>$config['modal']?$config['modal']:'open-type-getUserInfo'
        ));
    
        $templates[] = $config;
    }
    public function generate_wxml_item($section_id,$section_index){
        $this->generate_nav_attribute_start("{$section_id}.authorize_url",array(
            'wx:if'=>"{{".$section_id.".type=='".$this->type."'}}",
        	"class"=>"xh-btn xh-btn-primary xh-btn-no-radius xh-w",
        		'hover-class'=>'xh-btn-primary-hover',
        		'style'=>"{{".$section_id.".color_background?('background-color:#'+".$section_id.".color_background):''}};{{".$section_id.".color_txt?('color:'+".$section_id.".color_txt):''}};{{".$section_id.".width?('width:'+".$section_id.".width):''}}"
        ));?>{{<?php echo $section_id;?>.text?<?php echo $section_id;?>.text:'微信登录'}} <?php $this->generate_nav_attribute_end();
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    			
    				var html = '<div class="cap-search-box">\
                					<div class="cap-search-box__view" style="padding: 0px; top: 0px;">\
                        				<div class="cap-search">\
                            				<div class="cap-search__filed cap-search__filed--rect" >\
                								<div class="van-cell van-field" style="text-align:center;">\
                									<button class="van-field__control" style="width:'+config.width+'%;margin-left:auto;margin-right:auto;text-align: center;color:#'+config.color_txt+';background-color:#'+config.color_background+';border:0;box-shadow: none;">'+config.text+'</button>\
                								</div>\
                							</div>\
                        				</div>\
                        			</div>\
                        		</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}