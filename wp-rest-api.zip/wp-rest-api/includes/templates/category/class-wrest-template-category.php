<?php
class WRest_Template_Category extends Abstract_WRest_Template_Product{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->group = 'footer';
        $this->title ="分类、标签聚合";
       
        $this->fields =array_merge( array(
            'settings_filter'=>array(
                'title'=>'商品类型设置',
                'type'=>'subtitle'
            ),
            'taxonomys'=>array(
                'title'=>'选择商品类型',
                'default'=>array(
                    WRest::instance()->get_product_api()->cat_type
                ),
                'type'=>'mult_select',
                'options'=>function(){
                    $options = array(
                       
                    );
                    
                    $taxes = get_taxonomies(array(
                        'object_type'=>array(WRest::instance()->get_product_api()->post_type)
                    ),'objects');
                    global $wpdb;
                    $attribute_taxonomies = $wpdb->get_results( 'SELECT attribute_name, attribute_id FROM ' . $wpdb->prefix . 'woocommerce_attribute_taxonomies' );
                    
                    	$attribute_taxonomies1 = wc_get_attribute_taxonomies();
					
                    if($taxes){
                        foreach ($taxes as $tax=>$settings){
                            if($tax=='product_type'){
                                continue;
                            }
                            
                            $is_att = false;
                            if($attribute_taxonomies){
                                foreach ($attribute_taxonomies as $tt){
                                    if("pa_{$tt->attribute_name}"==$tax){
                                        $is_att = true;
                                        break;
                                    }
                                }
                            }
                            if($is_att){
                                continue;
                            }
                            $options[$tax] =$settings->label;
                        }
                    }
                    
					if($attribute_taxonomies1){
						foreach($attribute_taxonomies1 as $tax){
							$options["pa_{$tax->attribute_name}"] = empty($tax->attribute_label)?$tax->attribute_name:$tax->attribute_label;
						}
					}
					
                    
                    return $options;
                },
            ),
        	'only_cats'=>array(
    			'title'=>'商品筛选',
    			'type'=>'posts',
    			'post_type'=>'product_cat_and_tag',
        	    'label'=>'商品',
    			'description'=>'筛选商品，按先后顺序排序。(注意：多级分类布局下不会显示不含子类的分类或标签)'
        	),
            'filters'=>array(
                'title'=>'过滤条件',
                'type'=>'product_filter',
                'description'=>'筛选商品，按先后顺序排序。(注意：多级分类布局下不会显示不含子类的分类或标签)'
            ),
            'style'=>array(
                'title'=>'页面布局',
                'type'=>'select',
                'default'=>'list',
                
                'selected-class'=>'active',
                'options'=>array(
                    'list'=>array(
                        'title'=>'列表',
                        'img'=>WREST_URL.'/assets/images/woocommerce/settings/cat1.jpg'
                    ),
                    'dj'=>array(
                        'title'=>'二级分类',
                        'img'=>WREST_URL.'/assets/images/woocommerce/settings/cat2.jpg'
                    ),
                    'sj'=>array(
                        'title'=>'三级分类',
                        'img'=>WREST_URL.'/assets/images/woocommerce/settings/cat5.jpg'
                    ),
                    'wm'=>array(
                        'title'=>'外卖模式',
                        'img'=>WREST_URL.'/assets/images/woocommerce/settings/cat3.jpg'
                    ),
                    'ss'=>array(
                        'title'=>'多标签',
                        'img'=>WREST_URL.'/assets/images/woocommerce/settings/cat4.jpg'
                    )
                ),
                'call'=>function($k,$v,$current){
          		    ?>
                  	<div data-type="<?php echo $k;?>" class="rc-design-select-templates option-item <?php echo $k==$current?'active':'';?>">
						<div class="rc-design-select-templates__image-block">
							<img src="<?php echo $v['img']?>" width="90px" height="64px" alt="temp">
						</div>
						<div class="rc-design-select-templates__title"><?php echo $v['title']?></div>
					</div>
                   <?php 
                }
             )
            ),$this->fields
        );
    }
  
    private function filter_filters(){
        $api = WRest::instance()->get_product_api();
        $filters = $api->get_product_filters($this->version);
        if(!$filters||!is_array($filters)){
            return $filters;
        }

        $_filters = $this->get_option('filters');
        if(is_null($_filters)|| !is_array($_filters)){
            return $filters;
        }

        $new_filters = array();
        foreach ($filters as $k=>$v){
            if(in_array($k,$_filters)){
                $new_filters[$k]=$v;
            }
        }

        return $new_filters;
    }

    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
       
        $api = WRest::instance()->get_product_api();
        

        
        switch ($config['style']){
        	case 'list':
        	case 'wm':
                $cats = $api->get_product_cats($this->version,$config['taxonomys'],$config['only_cats']);
                $filters = $this->filter_filters();
                $sorts = $api->get_product_sorts();
                $config['_filters'] = $filters;
                $config['_sorts'] = $sorts;

        		$sdk = $request->get_param('sdk');
        		if($sdk&&version_compare($sdk, '1.0.1','>=')&&$config['style']=='list'){
        			$catArray = array(
        					array(
        							'term_id' => 0,
        							'name' => '全部',
        							'children' => null
        					)
        			);
        			$current_cat_id = 0;
        			if(isset($cats['items1'])&&$cats['items1']){
        				foreach ($cats['items1'] as $term_id=>$cat){
        				    $current_cat_id = $term_id;
        					$catArray[]=$cat;
        				}
        			}
        			$cats['current_cat_id'] = $current_cat_id;
        			$cats['items1'] = $catArray;
        			$config['_cats'] = $cats;
        		}else{
        			$config['_cats'] = $cats;
        		}
        		break;
        	case 'dj':
                $cats = $api->get_product_cats($this->version,$config['taxonomys'],$config['only_cats']);
                $filters = $this->filter_filters();
                $sorts = $api->get_product_sorts();
                $config['_filters'] = $filters;
                $config['_sorts'] = $sorts;

        		$catArray = array();
        		if($cats['items1']){
        			foreach ($cats['items1'] as $item){
        				if(!isset($item['children1'])||!count($item['children1'])){
        					continue;
        				}
        				$catArray[]=$item;
        			}
        		}
        		$cats['items1'] = $catArray;
        		$current_cat_id = 0;
        		if($cats['items']){
        		    foreach ($cats['items'] as $term_id=>$c){
        		        $current_cat_id = $term_id;
        		    }
        		}
        		
        		$cats['current_cat_id'] = $current_cat_id;
        		$config['_cats'] = $cats;
        		break;
            case 'sj':
                $cats = $api->get_product_cats($this->version,$config['taxonomys'],$config['only_cats'],true);
                $filters = $this->filter_filters();
                $sorts = $api->get_product_sorts();
                $config['_filters'] = $filters;
                $config['_sorts'] = $sorts;

                $catArray = array();
                if($cats['items1']){
                    foreach ($cats['items1'] as $item){
                        if(!isset($item['children1'])||!count($item['children1'])){
                            continue;
                        }
                        $catArray[]=$item;
                    }
                }

                $cats['items1'] = $catArray;
                $current_cat_id = 0;
                if($cats['items']){
                    foreach ($cats['items'] as $term_id=>$c){
                        $current_cat_id = $term_id;
                    }
                }

                $cats['current_cat_id'] = $current_cat_id;
                $config['_cats'] = $cats;
                break;
        	case 'ss':
                $cats = $api->get_product_cats($this->version,$config['taxonomys'],$config['only_cats']);
                $filters = $this->filter_filters();
                $sorts = $api->get_product_sorts();
                $config['_filters'] = $filters;
                $config['_sorts'] = $sorts;

        	    include_once WREST_DIR.'/includes/pinyin/pinyin.php';
        	    $group = array();
                for($i=ord('A');$i<=ord('Z');$i++){
                    $group[chr($i)]=array() ;
                }
                $group['其它'] =array();
                
        	    if(isset($cats['items1'])&&$cats['items1']){
        	        foreach ($cats['items1'] as $term_id=>$cat){
        	            $pin = WRest_Pinyin::getShortPinyin($cat['name']);
        	            if(empty($pin)){
        	                $pin = $cat['name'];
        	            }
        	            
        	            if(empty($pin)){
        	                continue;
        	            }
        	            
        	            $F = strtoupper($pin[0]);
        	            if(isset($group[$F])){
        	                $group[$F][]=$cat;
        	            }else{
        	                $group['其它'][]=$cat;
        	            }
        	        }
        	    }
        	    
        	    $groupList = array();
        	    foreach ($group as $k=>$items){
        	       if(count($items)) {
        	           $groupList[]=array(
        	               'group'=>$k,
        	               'items'=>$items
        	           );
        	       }
        	    }
        	    
        	    $config['_cats'] = $groupList;
        	    break;
        }
        $config['api'] = "cat:{$config['style']}";
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
    	$pub = new WRest_Menu_Store_Pub($this->version);
         ?>
         <block wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type?>'}}">
            <cat-Fit wx:if="{{<?php echo $section_id;?>.style=='list'}}" navHeight="{{navHeight}}" catObj="{{<?php echo $section_id;?>._cats}}" sortArr="{{<?php echo $section_id;?>._sorts}}" filterArr="{{<?php echo $section_id;?>._filters}}" scrollTop="{{<?php echo $section_id;?>._scrollTop}}" bindfilter="onFooterChange">
    		    <view slot="content" class="xh-column xh-w">
        		    <pro-list items="{{<?php echo $section_id;?>.items}}" cart="{{cart}}" bindonCartChange="onCartChange" />
        		    <view wx:if="{{<?php echo $section_id;?>._isDataLoading}}" class="xh-row xh-w xh-row-c xh-p30 xh-column-c xh-c-sub xh-f-sub"><image src="{{config.apiAssets}}/images/v2/icon/loading-small.gif" style="width:30rpx;height:30rpx;" class="xh-mR15 " />努力加载中...</view>
                	<view wx:if="{{!<?php echo $section_id;?>._isDataLoading&&<?php echo $section_id;?>._isNoneData&&<?php echo $section_id;?>._pageIndex==1}}" class="xh-row xh-t-c xh-row-c xh-p30 xh-f-sub xh-c-main xh-w">抱歉，未能找到商品!</view>  
            	</view>
            </cat-Fit>
             
             <cat-dj height="{{<?php echo $section_id;?>._height}}" wx:elif="{{<?php echo $section_id;?>.style=='dj'}}" catObj="{{<?php echo $section_id;?>._cats}}"/>
             <cat-sj height="{{<?php echo $section_id;?>._height}}" wx:elif="{{<?php echo $section_id;?>.style=='sj'}}" catObj="{{<?php echo $section_id;?>._cats}}"/>
             <cat-ss height="{{<?php echo $section_id;?>._height}}" wx:elif="{{<?php echo $section_id;?>.style=='ss'}}" catObj="{{<?php echo $section_id;?>._cats}}"/>
             <cat-wm height="{{<?php echo $section_id;?>._height}}"  wx:elif="{{<?php echo $section_id;?>.style=='wm'}}" footer="{{<?php echo $section_id;?>}}" cart="{{cart}}" bindonCartChange="onCartChange" />
        </block>
         <?php 
    }
    
    public function __preview(){
        parent::__preview();
        $cats = WRest::instance()->get_product_api()->get_product_cats($this->version,$this->get_option('taxonomys'),$this->get_option('only_cats'));
        ?>
        <style type="text/css">
            .cat-wm .cap-goods-list__item{height:80px;}
            .cat-wm .cap-goods__img{width:80px!important;height:80px!important}
            .cat-wm .cap-goods-list__photo{width:80px!important;height:80px!important}
            .cat-wm .cap-goods__img-wrap{width:80px!important;height:80px!important}
        </style>
        <script type="text/javascript">
			(function($){
				
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
					var cats = <?php echo json_encode($cats);?>;
					
					switch(config.style){
    					case 'ss':
        						var html='<div style="max-height:400px;overflow:hidden;"><img src="<?php echo WREST_URL?>/assets/images/woocommerce/settings/cat4.jpg" style="width:320px;"/></div>';
        						$('#<?php echo $this->get_template_key('preview')?>').html(html);
    						break;
    					case 'list':
        					window.productView_<?php echo $this->get_template_key()?>(config,function(phtml){
        					   var html = '';
        					   html='<div style="max-height:400px;overflow:hidden;">\
            					   <div style="display:flex;flex-direction:column;color:#666;">\
                						<div style="display:flex;flex-direction:row;overview:hidden;" class="xh-bg-tab xh-c-main xh-f-main">';
                    						if(cats.items){
                        						var index = 0;
                								for(var id in cats.items){
                    								if(index>=4){continue;}
        											var cat = cats.items[id];
        											html+='<span style="text-align:center;margin:10px;width:80px;    white-space: nowrap;" class="'+(index++==0?'xh-c-active':'')+' single-ellipsis;">'+cat.name+'</span>';
                    							}
                        					}
                					html+='</div>';
            					html+='</div>';
        						html+=phtml;
        						html+='</div>';
        						$('#<?php echo $this->get_template_key('preview')?>').html(html);
        					});
    					break;
    					case 'dj':
    						var html = '<div style="max-height:400px;overflow:hidden;"><div style="display:flex;flex-direction:row;" class="xh-bg-tab">\
            								<ul style="list-style:none;">';
                        						if(cats.items){
                            						var index = 0;
                    								for(var id in cats.items){
                    									var cat = cats.items[id];
                    									html+='<li style="padding:10px;text-align:center;overflow:hidden;    white-space: nowrap;border-bottom:solid 1px #f2f2f2;width:80px" class="'+(index++==0?'xh-c-active':'')+' single-ellipsis xh-f-main xh-c-main">'+cat.name+'</li>';
                        							}
                            					}
                       					html += '</ul>\
                							<div class="xh-column" style="width:250px;" class="xh-bg">';
            								if(cats.items){
            									var index = 0;
                								for(var id in cats.items){
                									var cat = cats.items[id];
                									html += '<h5 style="padding:15px;white-space: nowrap;" class="xh-f-main xh-c-main">'+cat.name+'</h5>\
    												<div style="display:flex;flex-direction:row;flex-wrap:wrap">';
    													if(cat.children){
															for(var c in cat.children){
																var subcat = cat.children[c];
																html+='<div style="display:flex;flex-direction:column;width:50px;padding:10px;text-align:center;">\
		    														<img src="'+(subcat.icon)+'" style="width:50px;height:50px;" />\
		    														<div class="xh-c-main xh-f-sub xh-mT15">'+subcat.name+'</div>\
		    													</div>';
															}
        												}
    												html += '</div>';
    												break;
                    							}
                							}
            							 html += '</div>\
            							</div></div>';
    						$('#<?php echo $this->get_template_key('preview')?>').html(html);
    						break;
                        case 'sj':
                            var html = '<div style="max-height:400px;overflow:hidden;"><div style="display:flex;flex-direction:row;" class="xh-bg-tab">\
            								<ul style="list-style:none;">';
                            if(cats.items){
                                var index = 0;
                                for(var id in cats.items){
                                    var cat = cats.items[id];
                                    html+='<li style="padding:10px;text-align:center;overflow:hidden;    white-space: nowrap;border-bottom:solid 1px #f2f2f2;width:80px" class="'+(index++==0?'xh-c-active':'')+' single-ellipsis xh-f-main xh-c-main">'+cat.name+'</li>';
                                }
                            }
                            html += '</ul>\
                							<div class="xh-column" style="width:250px;" class="xh-bg">';
                            if(cats.items){
                                var index = 0;
                                for(var id in cats.items){
                                    var cat = cats.items[id];
                                    html += '<h5 style="padding:15px;white-space: nowrap;" class="xh-f-main xh-c-main">'+cat.name+'</h5>\
    												<div style="display:flex;flex-direction:row;flex-wrap:wrap">';
                                    if(cat.children){
                                        for(var c in cat.children){
                                            var subcat = cat.children[c];
                                            html+='<div style="display:flex;flex-direction:column;width:50px;padding:10px;text-align:center;">\
		    														<img src="'+(subcat.icon)+'" style="width:50px;height:50px;" />\
		    														<div class="xh-c-main xh-f-sub xh-mT15">'+subcat.name+'</div>\
		    													</div>';
                                        }
                                    }
                                    html += '</div>';
                                    break;
                                }
                            }
                            html += '</div>\
            							</div></div>';
                            $('#<?php echo $this->get_template_key('preview')?>').html(html);
                            break;
    					case 'wm':
    						config.modal='detail';
    						window.productView_<?php echo $this->get_template_key()?>(config,function(phtml){
    							var html = '<div style="max-height:400px;overflow:hidden;">\
        							<div style="display:flex;flex-direction:row;">\
    								<ul style="list-style:none;" class="xh-bg-tab">';
                						if(cats.items){
                    						var index = 0;
            								for(var id in cats.items){
            									var cat = cats.items[id];
            									html+='<li style="padding:10px;text-align:center;overflow:hidden;border-bottom:solid 1px #f2f2f2;white-space: nowrap;" class="'+(index++==0?'xh-active-c':'')+' xh-f-main xh-c-main">'+cat.name+'</li>';
                							}
                    					}
               					html += '</ul>\
        							<div class="cat-wm" style="display:flex;flex-direction:column;background-color:#fff;width:250px;">';

               					html+=phtml;
    							 html += '</div>\
    							</div></div>';


 	    						$('#<?php echo $this->get_template_key('preview')?>').html(html);
        					});
    						
    						break;
    				}
				});
			})(jQuery);
		</script>
        <?php 
    }

    public function generate_product_filter_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'placeholder' => '',
            'description' => '',
            'custom_attributes' => array ()
        );

        $data = wp_parse_args ( $data, $defaults );
        $f = $this->get_option($key);
        if(!$f||!is_array($f)){
            $f = null;
        }
        ?>
        <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
            <div class="zent-design-editor__control-group-container">
                <div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
                <div class="zent-design-editor__control-group-control">
                    <div class="zent-input-wrapper">
                        <?php
                        $api = WRest::instance()->get_product_api();
                        $filters = $api->get_product_filters($this->version);
                        ?>
                        <ul style="list-style:none;">
                            <?php foreach ($filters as $k=>$item){
                                ?><li><label><input type="checkbox" value="<?php echo $k?>" <?php echo is_null($f)||in_array($k,$f)?'checked':'';?> name="product-filters" class="product-filters" /> <?php echo $item['title']?></label></li><?php
                            }?>
                        </ul>

                    </div>

                </div>
            </div>
        </div>
        <script type="text/javascript">
            (function($){
                window.<?php echo $field?>={
                    get_value:function(){
                        let filterIds = [];
                        $('.product-filters:checked').each(function(){
                            filterIds.push($(this).val());
                        });
                        return filterIds;
                    },
                    set_value:function(val){
                    }
                };
            })(jQuery);
        </script>
        <?php
    }
}