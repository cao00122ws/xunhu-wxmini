<?php
class WRest_Template_AlertAd extends Abstract_WRest_Template{
	public function __construct($version,$id=0,$config = array()){
		parent::__construct($version,$id,$config);
		
		$this->title ="弹窗广告";
		
		$this->init_form_fields(array(
			'modal'=>array(
				'title'=>'模版',
				'type'=>'select',
				'default'=>'imgtxt',
				'selected-class'=>'active',
				'options'=>array(
                    'img_row1_col2'=>array(
                        'title'=>'1行2个',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-row1-col2.png'
                    ),
                    'img_row1_col3'=>array(
                        'title'=>'1行3个',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-row1-col3.png'
                    ),
                    'img_row1_col4'=>array(
                        'title'=>'1行4个',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-row1-col4.png'
                    ),
                    'img_left2_right2'=>array(
                        'title'=>'2左2右',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-left2-right2.png'
                    ),
                    'img_left1_right2'=>array(
                        'title'=>'1左2右',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-left1-right2.png'
                    ),
                    'img_left1_right3'=>array(
                        'title'=>'1左3右',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-left1-right3.png'
                    ),
                    'img_top1_bottom2'=>array(
                        'title'=>'1上2下',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-top1-bottom2.png'
                    ),
                    'img_lines'=>array(
                        'title'=>'多行',
                        'img'=>WREST_URL.'/assets/images/woocommerce/magiccube-lines.png'
                    ),
				),
				'call'=>function($k,$v,$current){
					?>
                  	<div data-type="<?php echo $k;?>" class="rc-design-select-templates option-item <?php echo $k==$current?'active':'';?>">
      					<div class="rc-design-select-templates__image-block">
      						<img src="<?php echo $v['img']?>" width="90px" height="64px"/>
      					</div>
      					<div class="rc-design-select-templates__title"><?php echo $v['title']?></div>
      				</div>
		           <?php 
                }
            ),
            'background_img'=>array(
                'title'=>'背景图片(可选)',
            	'width'=>450,
            	'height'=>300,
                'type'=>'image',
                'description'=>'点击<a href="#" target="_blank">此处</a>下载素材'
            ),
            'position'=>array(
                'title'=>'内容位置',
            	'type'=>'select',
                'default'=>'flex-end',
            	'options'=>array(
            	   'flex-end'=>'底部',
            	   'center'=>'居中',
            	   'flex-start'=>'顶部'
                )
            ),
            'items'=>array(
                'title'=>'内容',
            	'width'=>100,
            	'height'=>100,
                'type'=>'mult_image'
            )
		));
	}

    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:elif="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" id="section-{{<?php echo $section_index?>}}" data-index="{{<?php echo $section_index?>}}" class="section" style="background-color:rgba(0, 0, 0, 0.3);position:fixed;top:0;left:0;width:750rpx;height:100%;z-index:1000;display:flex;justify-content:center;align-items:center;">
         	<view style="width:450rpx;{{<?php echo $section_id;?>.background_img?('min-height:'+(<?php echo $section_id;?>.background_img.height*(450/<?php echo $section_id;?>.background_img.width))+'rpx;'):''}}position:relative;display:flex;flex-direction:column;justify-content:{{<?php echo $section_id;?>.position?<?php echo $section_id;?>.position:'flex-end'}}" class="xh-card section-magiccube" >    
                 <image wx:if="{{<?php echo $section_id;?>.background_img}}" src="{{<?php echo $section_id;?>.background_img.url}}" style="width:450rpx;height:{{<?php echo $section_id;?>.background_img.height*(450/<?php echo $section_id;?>.background_img.width)}}rpx;position:absolute;top:0;left:0;"/>
                 
                 <view wx:if="{{<?php echo $section_id;?>.modal=='img_row1_col2'&&<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>=2}}" style="z-index:1;display:flex;flex-direction:row;align-items:center;" >
                 	<navigator url="{{<?php echo $section_id;?>.items[0].page?(<?php echo $section_id;?>.items[0].page+(<?php echo $section_id;?>.items[0].page_param?('?id='+<?php echo $section_id;?>.items[0].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[0].url}}"/>
                 	</navigator>
                 	
                 	<navigator url="{{<?php echo $section_id;?>.items[1].page?(<?php echo $section_id;?>.items[1].page+(<?php echo $section_id;?>.items[1].page_param?('?id='+<?php echo $section_id;?>.items[1].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[1].url}}"/>
                 	</navigator>
                 </view>
                 
                 <view wx:elif="{{<?php echo $section_id;?>.modal=='img_row1_col3'&&<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>=3}}" style="z-index:1;display:flex;flex-direction:row;align-items:center;" >
                 	<navigator url="{{<?php echo $section_id;?>.items[0].page?(<?php echo $section_id;?>.items[0].page+(<?php echo $section_id;?>.items[0].page_param?('?id='+<?php echo $section_id;?>.items[0].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:250rpx;height:{{<?php echo $section_id;?>.items[0].height*(250/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[0].url}}"/>
                 	</navigator>
                 	
                 	<navigator url="{{<?php echo $section_id;?>.items[1].page?(<?php echo $section_id;?>.items[1].page+(<?php echo $section_id;?>.items[1].page_param?('?id='+<?php echo $section_id;?>.items[1].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:250rpx;height:{{<?php echo $section_id;?>.items[0].height*(250/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[1].url}}"/>
                 	</navigator>
                 	
                 	<navigator url="{{<?php echo $section_id;?>.items[2].page?(<?php echo $section_id;?>.items[2].page+(<?php echo $section_id;?>.items[2].page_param?('?id='+<?php echo $section_id;?>.items[2].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:250rpx;height:{{<?php echo $section_id;?>.items[0].height*(250/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[2].url}}"/>
                 </navigator>
                 </view>
                 
                 <view wx:elif="{{<?php echo $section_id;?>.modal=='img_row1_col4'&&<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>=4}}" style="z-index:1;display:flex;flex-direction:row;align-items:center;" >
                 	<navigator url="{{<?php echo $section_id;?>.items[0].page?(<?php echo $section_id;?>.items[0].page+(<?php echo $section_id;?>.items[0].page_param?('?id='+<?php echo $section_id;?>.items[0].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:112.5rpx;height:{{<?php echo $section_id;?>.items[0].height*(112.5/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[0].url}}"/>
                 	</navigator>
                 	
                 	<navigator url="{{<?php echo $section_id;?>.items[1].page?(<?php echo $section_id;?>.items[1].page+(<?php echo $section_id;?>.items[1].page_param?('?id='+<?php echo $section_id;?>.items[1].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:112.5rpx;height:{{<?php echo $section_id;?>.items[0].height*(112.5/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[1].url}}"/>
                 	</navigator>
                 	
                 	<navigator url="{{<?php echo $section_id;?>.items[2].page?(<?php echo $section_id;?>.items[2].page+(<?php echo $section_id;?>.items[2].page_param?('?id='+<?php echo $section_id;?>.items[2].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:112.5rpx;height:{{<?php echo $section_id;?>.items[0].height*(112.5/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[2].url}}"/>
                 	</navigator>
                 	
                 	<navigator url="{{<?php echo $section_id;?>.items[3].page?(<?php echo $section_id;?>.items[3].page+(<?php echo $section_id;?>.items[3].page_param?('?id='+<?php echo $section_id;?>.items[3].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:112.5rpx;height:{{<?php echo $section_id;?>.items[0].height*(112.5/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[3].url}}"/>
                 	</navigator>
                 </view>
                 
                 <view wx:elif="{{<?php echo $section_id;?>.modal=='img_left2_right2'&&<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>=4}}" style="z-index:1;display:flex;flex-direction:row;align-items:center;" >
                 	<view style="display:flex;flex-direction:column;align-items:center;width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)*2}}rpx;">
                 		<navigator url="{{<?php echo $section_id;?>.items[0].page?(<?php echo $section_id;?>.items[0].page+(<?php echo $section_id;?>.items[0].page_param?('?id='+<?php echo $section_id;?>.items[0].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[0].url}}"/>
                 		</navigator>
                 		
                 		<navigator url="{{<?php echo $section_id;?>.items[1].page?(<?php echo $section_id;?>.items[1].page+(<?php echo $section_id;?>.items[1].page_param?('?id='+<?php echo $section_id;?>.items[1].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[1].url}}"/>
                 		</navigator>
                 	</view>
                 	
                 	<view style="display:flex;flex-direction:column;align-items:center;width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)*2}}rpx;">
                 		<navigator url="{{<?php echo $section_id;?>.items[2].page?(<?php echo $section_id;?>.items[2].page+(<?php echo $section_id;?>.items[2].page_param?('?id='+<?php echo $section_id;?>.items[2].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[2].url}}"/>
                 		</navigator>
                 		
                 		<navigator url="{{<?php echo $section_id;?>.items[3].page?(<?php echo $section_id;?>.items[3].page+(<?php echo $section_id;?>.items[3].page_param?('?id='+<?php echo $section_id;?>.items[3].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[3].url}}"/>
                 		</navigator>
                 	</view>
                 </view>
                 
                 <view wx:elif="{{<?php echo $section_id;?>.modal=='img_left1_right2'&&<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>=3}}" style="z-index:1;display:flex;flex-direction:row;align-items:center;" >
                 	<navigator url="{{<?php echo $section_id;?>.items[0].page?(<?php echo $section_id;?>.items[0].page+(<?php echo $section_id;?>.items[0].page_param?('?id='+<?php echo $section_id;?>.items[0].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[0].url}}"/>
                 	</navigator>
                 	
                 	<view style="display:flex;flex-direction:column;align-items:center;width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;">
                 		<navigator url="{{<?php echo $section_id;?>.items[1].page?(<?php echo $section_id;?>.items[1].page+(<?php echo $section_id;?>.items[1].page_param?('?id='+<?php echo $section_id;?>.items[1].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:225rpx;height:{{(<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width))/2}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[1].url}}"/>
                 		</navigator>
                 		
                 		<navigator url="{{<?php echo $section_id;?>.items[2].page?(<?php echo $section_id;?>.items[2].page+(<?php echo $section_id;?>.items[2].page_param?('?id='+<?php echo $section_id;?>.items[2].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:225rpx;height:{{(<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width))/2}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[2].url}}"/>
                 		</navigator>
                 	</view>
                 </view>
                 
                 <view wx:elif="{{<?php echo $section_id;?>.modal=='img_left1_right3'&&<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>=4}}" style="z-index:1;display:flex;flex-direction:row;align-items:center;" >
                 	<navigator url="{{<?php echo $section_id;?>.items[0].page?(<?php echo $section_id;?>.items[0].page+(<?php echo $section_id;?>.items[0].page_param?('?id='+<?php echo $section_id;?>.items[0].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[0].url}}"/>
                 	</navigator>
                 	<view style="display:flex;flex-direction:column;align-items:center;width:225rpx;height:{{<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width)}}rpx;">
                 		<navigator url="{{<?php echo $section_id;?>.items[1].page?(<?php echo $section_id;?>.items[1].page+(<?php echo $section_id;?>.items[1].page_param?('?id='+<?php echo $section_id;?>.items[1].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:225rpx;height:{{(<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width))/2}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[1].url}}"/>
                 		</navigator>
                 		
                 		<view style="display:flex;flex-direction:row;align-items:center;">
                     		<navigator url="{{<?php echo $section_id;?>.items[2].page?(<?php echo $section_id;?>.items[2].page+(<?php echo $section_id;?>.items[2].page_param?('?id='+<?php echo $section_id;?>.items[2].page_param):'')):''}}" open-type="navigate" hover-class="none">
                     		<image style="width:112.5rpx;height:{{(<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width))/2}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[2].url}}"/>
                     		</navigator>
                     		
                     		<navigator url="{{<?php echo $section_id;?>.items[3].page?(<?php echo $section_id;?>.items[3].page+(<?php echo $section_id;?>.items[3].page_param?('?id='+<?php echo $section_id;?>.items[3].page_param):'')):''}}" open-type="navigate" hover-class="none">
                     		<image style="width:112.5rpx;height:{{(<?php echo $section_id;?>.items[0].height*(225/<?php echo $section_id;?>.items[0].width))/2}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[3].url}}"/>
                     		</navigator>
                 		</view>
                 	</view>
                 </view>
                 
                 <view wx:elif="{{<?php echo $section_id;?>.modal=='img_top1_bottom2'&&<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>=3}}" style="z-index:1;display:flex;flex-direction:column;align-items:center;" >
                 	<navigator url="{{<?php echo $section_id;?>.items[0].page?(<?php echo $section_id;?>.items[0].page+(<?php echo $section_id;?>.items[0].page_param?('?id='+<?php echo $section_id;?>.items[0].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 	<image style="width:450rpx;height:{{<?php echo $section_id;?>.items[0].height*(450/<?php echo $section_id;?>.items[0].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[0].url}}"/>
                 	</navigator>
                 	
                 	<view style="display:flex;flex-direction:row;align-items:center;width:450rpx;height:{{<?php echo $section_id;?>.items[1].height*(225/<?php echo $section_id;?>.items[1].width)}}rpx;">
                 		<navigator url="{{<?php echo $section_id;?>.items[1].page?(<?php echo $section_id;?>.items[1].page+(<?php echo $section_id;?>.items[1].page_param?('?id='+<?php echo $section_id;?>.items[1].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 			<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[1].height*(225/<?php echo $section_id;?>.items[1].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[1].url}}"/>
                 		</navigator>
                 		
                 		<navigator url="{{<?php echo $section_id;?>.items[2].page?(<?php echo $section_id;?>.items[2].page+(<?php echo $section_id;?>.items[2].page_param?('?id='+<?php echo $section_id;?>.items[2].page_param):'')):''}}" open-type="navigate" hover-class="none">
                 			<image style="width:225rpx;height:{{<?php echo $section_id;?>.items[1].height*(225/<?php echo $section_id;?>.items[1].width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{<?php echo $section_id;?>.items[2].url}}"/>
                 		</navigator>
                 	</view>
                 </view>
                 
                 <view wx:elif="{{<?php echo $section_id;?>.modal=='img_lines'}}" style="z-index:1;display:flex;flex-direction:column;align-items:center;" >
                 	<navigator wx:for="{{<?php echo $section_id;?>.items}}" url="{{item.page?(item.page+(item.page_param?('?id='+item.page_param):'')):''}}" open-type="navigate" hover-class="none">
                 		<image style="width:450rpx;height:{{item.height*(450/item.width)}}rpx;" mode="aspectFill" lazy-load="{{true}}" src="{{item.url}}"/>
                 	</navigator>
                 </view>
             </view>
         </view> 
        <?php 
    }
  
	public function __preview(){
		parent::__preview();
		?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

    				if(!config.items||config.items.length==0){
                        var html = '<div class="rc-design-react-preview rc-design-component-default-preview">'
						            +'<div class="rc-design-component-default-preview__text">点击编辑魔方</div>';
        			}else{
                        var html = '<div class="rc-design-vue-preview rc-design-component-cube-preview" style="display:flex;flex-direction:column;justify-content:'+config.position+';position:relative;'+(config.background_img?('min-height:'+(config.background_img.height*(320/config.background_img.width))+'px'):'')+'">';
						if(config.background_img){
							html+='<img style="width:320px;height:'+(config.background_img.height*(320/config.background_img.width))+'px;position:absolute;" src="'+config.background_img.url+'" />';
						}
                        
    				    switch (config.modal){
                            case 'img_row1_col2':
                                html+='<div class="cap-cube-wrap" style="z-index:1">'
                                        +'<div class="cap-cube" style="margin: 0px; width: 320px; height:'+(config.items[0].height*(160/config.items[0].width))+'px;">';
                                for(var index = 0 ;index<config.items.length&&index<3;index++){
                                    var img = config.items[index];
                                    if(!img.url){img.url='';}
                                   
                                    html+='<div colspan="160" rowspan="160" class="cap-cube__item" data-src="'+img.url+'" lazy="loaded" style="left: '+index*160+'px; top: 0px; height: '+(config.items[0].height*(160/config.items[0].width))+'px; width: 160px; margin: 0px; background-image: url('+img.url+');">' +
                                                '<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">' +
                                            '</div>';
                                }
                                html+='</div></div>';
                                break;
                            case 'img_row1_col3':
                                html+='<div class="cap-cube-wrap" style="z-index:1">'
                                        +'<div class="cap-cube" style="margin: 0px; width: 321px; height:  '+(config.items[0].height*(107/config.items[0].width))+'px;">';
                                for(var index = 0 ;index<config.items.length&&index<4;index++){
                                    var img = config.items[index];
                                    if(!img.url){img.url='';}
                                   
                                    html+='<div colspan="107" rowspan="107" class="cap-cube__item" data-src="'+img.url+'" lazy="loaded" style="left: '+index*107+'px; top: 0px; height: '+(config.items[0].height*(107/config.items[0].width))+'px; width: 107px; margin: 0px; background-image: url('+img.url+');">' +
                                        '<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">' +
                                        '</div>';
                                }
                                html+='</div></div>';
                                break;
                            case 'img_row1_col4':
                                html+='<div class="cap-cube-wrap" style="z-index:1">'
                                    +'<div class="cap-cube" style="margin: 0px; width: 320px; height: '+(config.items[0].height*(80/config.items[0].width))+'px;">';
                                for(var index = 0 ;index<config.items.length&&index<5;index++){
                                    var img = config.items[index];
                                    if(!img.url){img.url='';}
                                   
                                    html+='<div class="cap-cube__item" lazy="loaded" style="left: '+index*80+'px; top: 0px; height: '+(config.items[0].height*(80/config.items[0].width))+'px; width: 80px; margin: 0px; background-image: url('+img.url+');">' +
                                        '<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">' +
                                        '</div>';
                                }
                                html+='</div></div>';
                                break;
                            case 'img_left2_right2':
                                html+='<div class="cap-cube-wrap"  style="z-index:1">'
                                    +'<div class="cap-cube" style="margin: 0px; width: 320px; height:  '+(config.items[0].height*(160/config.items[0].width)*2)+'px;">';
                                for(var index = 0 ;index<config.items.length&&index<4;index++){
                                    var img = config.items[index];
                                    if(!img.url){img.url='';}
                                   
                                    html+='<div class="cap-cube__item" lazy="loaded" style="left: '+((index==1||index==3)?160:0)+'px; top: '+((index==2||index==3)?(config.items[0].height*(160/config.items[0].width)):0)+'px; height: '+(config.items[0].height*(160/config.items[0].width))+'px; width: 160px; margin: 0px; background-image: url('+img.url+');">' +
                                        '<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">' +
                                        '</div>';
                                }
                                html+='</div></div>';
                                break;
                            case 'img_left1_right2':
                                html+='<div class="cap-cube-wrap" style="z-index:1">'
                                    +'<div class="cap-cube" style="margin: 0px; width: 320px; height: '+(config.items[0].height*(160/config.items[0].width))+'px;">';
                                for(var index = 0 ;index<config.items.length&&index<3;index++){
                                    var img = config.items[index];
                                    if(!img.url){img.url='';}
                                   
                                    html+='<div class="cap-cube__item"lazy="loaded" style="left: '+((index==1||index==2)?160:0)+'px; top: '+(index==2?(config.items[0].height*(160/config.items[0].width)/2):0)+'px; height: '+(index==0?(config.items[0].height*(160/config.items[0].width)):(config.items[0].height*(160/config.items[0].width)/2))+'px; width: 160px; margin: 0px; background-image: url('+img.url+');">' +
                                        	'<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">' +
                                        '</div>';
                                }
                                html+='</div></div>';
                                break;
                            case 'img_left1_right3':
                                html+='<div class="cap-cube-wrap" style="z-index:1">'
                                    +'<div class="cap-cube" style="margin: 0px; width: 320px; height: '+(config.items[0].height*(160/config.items[0].width))+'px;">';
                                for(var index = 0 ;index<config.items.length&&index<4;index++){
                                    var img = config.items[index];
                                    if(!img.url){img.url='';}
                                   
                                    var left=160;
                                    if(index==0)left=0;
                                    if(index==3)left=240;
                                    html+='<div  class="cap-cube__item" data-src="'+img.url+'" lazy="loaded" ' +
                                            'style="left: '+left+'px; top: '+(index==2||index==3?(config.items[0].height*(160/config.items[0].width)/2):0)+'px; height: '+(index==0?(config.items[0].height*(160/config.items[0].width)):(config.items[0].height*(160/config.items[0].width)/2))+'px; width: '+((index==0||index==1)?160:80)+'px; margin: 0px; background-image: url('+img.url+');">' +
                                            '<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">' +
                                        '</div>';
                                }
                                html+='</div></div>';
                                break;
                            case 'img_top1_bottom2':
                                if(config.items.length<2){break;}
                                html+='<div class="cap-cube-wrap" style="z-index:1">'
                                    +'<div class="cap-cube" style="margin: 0px; width: 320px; height: '+(config.items[0].height*(320/config.items[0].width)+config.items[1].height*(160/config.items[1].width))+'px;">';
                                    for(var index = 0 ;index<config.items.length&&index<3;index++){
                                        var img = config.items[index];
                                        if(!img.url){img.url='';}
                                       
                                        html+='<div class="cap-cube__item" style="left: '+(index==2?160:0)+'px; top: '+(index==0?0:(config.items[0].height*(320/config.items[0].width)))+'px; height: '+(index==0?(config.items[0].height*(320/config.items[0].width)):(config.items[1].height*(160/config.items[1].width)))+'px; width: '+(index==0?320:160)+'px; margin: 0px; background-image: url('+img.url+');">' +
                                            '<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">' +
                                            '</div>';
                                    }
                                html+='</div></div>';
                                break;
                            case 'img_lines':
                                html+='<div class="cap-cube-wrap" style="z-index:1">';

                                for(var index = 0 ;index<config.items.length&&index<3;index++){
                                    var img = config.items[index];
                                    if(!img.url){img.url='';}
                                   
                                    html+='<div class="cap-cube" style="margin: 0px; width: 320px; height: '+(img.height*(320/img.width))+'px;">\
                                    		<div class="cap-cube__item" style="left:0px; top:0px; height:'+(img.height*(320/img.width))+'px; width: 320px; margin: 0px; background-image: url('+img.url+');">\
                                        		<img class="cap-cube__table-image--invisible" data-src="'+img.url+'" src="'+img.url+'" lazy="loaded">\
                                        	</div>\
                                           </div>';
                                }
                                
                                html+='</div>';
                                break;
                            case 'img_custom':
                                html='正在开发中，请静候';
                                break;
                        }
						html+='</div>';
            		}
    				html+='</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}