<?php
class WRest_Template_Blank extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="辅助空白";
       
        $this->init_form_fields( array(
            'height'=>array(
                'title'=>'空白高度(rpx)',
                'type'=>'integer',
                'default'=>'15'
            )
        ));
    }
   
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-row xh-w" style="height:{{<?php echo $section_id;?>.height}}rpx;"/>
        <?php 
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

                    var html='<div style="width:320px;height:'+config.height+'px;'+(config.background_color?('background-color:#'+config.background_color):'')+'" />';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}