<?php
class WRest_Template_Canvas extends Abstract_WRest_Template{
    public $canvasWidth = 400;
    public $maxWidth = 750;
    
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="画板";
       
        $this->init_form_fields( array(
            'item'=>array(
                'title'=>'绘图区域',
                'width'=>$this->canvasWidth,
                'type'=>'canvas'
            ),
            'posi'=>array(
                'title'=>'显示位置',
                'max-width'=>$this->maxWidth,
                'type'=>'position'
            )
        ));
    }
   
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        if(isset($config['item']['items'])&&$config['item']['items']){
            foreach ($config['item']['items'] as $index=>$item){
                $config['item']['items'][$index]['link'] = $this->reset_link($item['link']);
            }
        }
        
        if(isset($config['item']['bg'])){
            $config['item']['bg'] = $this->reset_imgurl($config['item']['bg']);
        }
        
        $config['prewidth'] = $this->canvasWidth;
        $config['width'] = $this->maxWidth;
       
        $templates[] = $this->reset_position_size($request, $config);
    }
    
    public function __actions(){
        ?>
    	<div id="<?php echo $this->get_template_key('remove')?>" class="zent-popover-wrapper zent-pop-wrapper zent-design-preview-controller__action-btn-delete" style="display: inline-block;">
            <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" class="zent-design-preview-controller__icon-delete">
	            <g fill="none" fill-rule="evenodd">
		            <circle cx="10" cy="10" r="10"></circle>
		            <path fill="#FFF" d="M13.75 7.188l-.937-.938L10 9.063 7.188 6.25l-.938.937L9.062 10 6.25 12.812l.937.938L10 10.938l2.812 2.812.938-.937L10.938 10"></path>
	            </g>
            </svg>
        </div>	
        <script type="text/javascript">
			(function($){
				$('#<?php echo $this->get_template_key('remove')?>').click(function(){
					if(confirm('确定删除？')){
						$('#<?php echo $this->get_template_key('preivew-fixed')?>').remove();
						$('#<?php echo $this->get_template_key()?>').remove();
					}
				});
			})(jQuery);
		</script>				
    	<?php 
    }
    
    /**
     * @param WP_REST_Request $request
     * @param array $config
     * @return string
     */
    private function reset_position_size($request,$config){
        if(!isset($config['item']['bg'])
            ||!$config['item']['bg']
            ||!isset($config['item']['bg']['width'])
            ||!isset($config['item']['bg']['height'])){
            return $config;
        }
        
        $bgWidth = absint($config['item']['bg']['width']);
        $bgHeight = absint($config['item']['bg']['height']);
        $width =$config['width'];
        $config['style'] = "width:{$width}rpx;height:".($bgHeight*$width/$bgWidth).'rpx;';
        
        $windowHeight = absint($request->get_param('windowHeight'));
        $windowWidth = absint($request->get_param('windowWidth'));
        if(!$windowHeight
            ||!$windowWidth
            ||!$bgWidth
            ||!$bgHeight){
            return $config;
        }
        
        if(!isset($config['posi'])||!$config['posi']||!is_array($config['posi'])){
            return $config;
        }
        
        if(!isset($config['posi']['position'])||!$config['posi']['position']){
            return $config;
        }
        
        $width = absint($config['posi']['width']);
        if($width>$this->maxWidth){$width=$this->maxWidth;}
        $config['width'] = $width<=0?$this->maxWidth:$width;
        
        if(!isset($config['posi']['h'])){$config['posi']['h']='bottom';}
        if(!isset($config['posi']['h_len'])){$config['posi']['h_len']='0';}else{$config['posi']['h_len']=intval($config['posi']['h_len']);}
        
        if(!isset($config['posi']['w'])){$config['posi']['w']='center';}
        if(!isset($config['posi']['w_len'])){$config['posi']['w_len']='0';}else{$config['posi']['w_len']=intval($config['posi']['w_len']);}
       
        $z_index = isset($config['posi']['z_index'])?absint($config['posi']['z_index']):0;
        $config['posi']['z_indexb'] = $z_index+4;
        $wxss = "position:{$config['posi']['position']};z-index:{$z_index};";
        
        $ratio = $windowWidth/750;
        
        switch ($config['posi']['h']){
            case 'top':
                $wxss.="top:{$config['posi']['h_len']}rpx;";
                break;
            case 'center':
                $wxss.="top:".round(($windowHeight-$bgHeight*($width*$ratio)/$bgWidth)/$ratio/2+$config['posi']['h_len'],2)."rpx;";
                break;
            case 'bottom':
                $wxss.="bottom:{$config['posi']['h_len']}rpx;";
                break;
        }
        
        switch ($config['posi']['w']){
            case 'left':
                $wxss.="left:{$config['posi']['w_len']}rpx;";
                break;
            case 'center':
                $wxss.="left:".round(($windowWidth-($width*$ratio))/$ratio/2+$config['posi']['w_len'],2)."rpx;";
                break;
            case 'right':
                $wxss.="right:{$config['posi']['w_len']}rpx;";
                break;
        }
        
        $config['style'] = $wxss."width:{$width}rpx;height:".($bgHeight*$width/$bgWidth).'rpx;';
        return $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'&&<?php echo $section_id;?>.item.bg}}" style="position:relative;{{<?php echo $section_id;?>.style}}" class="xh-row xh-w">
           <image src="{{<?php echo $section_id;?>.item.bg.url}}" style="width:{{<?php echo $section_id;?>.width}}rpx;height:{{<?php echo $section_id;?>.item.bg.height*<?php echo $section_id;?>.width/<?php echo $section_id;?>.item.bg.width}}rpx" model="aspectFit" lazy-load="{{true}}" />
           <block wx:if="{{<?php echo $section_id;?>.item.items}}">
               <?php 
               $this->generate_nav_attribute_start("item.link",array(
                   'wx:for'=>"{{".$section_id.".item.items}}",
                   'wx:key'=>'{{index}}',
                   'class'=>'xh-bg-clear',
                   'style'=>'width:{{item.width*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;height:{{item.height*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;position:absolute;left:{{item.left*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;top:{{item.top*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;z-index:{{('.$section_id.'.posi.z_indexb)}};'
               ));
               $this->generate_nav_attribute_end();
               ?>
           </block>
        </view>
        <?php 
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				var img =config.item&&config.item.bg?config.item.bg:'';
    				var html='';
    				if(!img||!img.url){
    					html='<div class="rc-design-vue-preview rc-design-component-image-ad-preview"><div class="cap-image-ad cap-image-ad--swipe"><div class="rc-design-react-preview rc-design-component-default-preview"><div><div class="rc-design-component-default-preview__title">点击编辑画板</div><div class="rc-design-component-default-preview__tip">建议宽度750像素</div></div></div></div></div>';	
        			}else{
                        var reset_position_wxss=function(config){
                        	var img =config.item&&config.item.bg?config.item.bg:'';
                        	if(!img){return '';}
                        	
                        	var bgWidth = img.width;
                        	var bgHeight = img.height;
                        	var windowWidth = 320;
                        	var windowHeight = $('#the-app-container').height();

                        	var style='width:'+windowWidth+'px;height:'+(bgHeight*windowWidth/bgWidth)+'px;';
                        	
                        	if(!config.posi||!config.posi.position){
								return style;
                            }

                        	var radio = 320/750;
							var width = config.posi.width?(radio*config.posi.width):windowWidth;
							style='width:'+width+'px;height:'+(bgHeight*width/bgWidth)+'px;';
							style+='position:absolute;z-index:'+(config.posi.z_index&&config.posi.z_index!='0'?config.posi.z_index:'-1')+';';
							
							var hlen = parseInt(config.posi.h_len);
							if(isNaN(hlen)){hlen=0;}
							
							var wlen = parseInt(config.posi.w_len);
							if(isNaN(wlen)){wlen=0;}
							
                        	switch(config.posi.h){
                        		case 'top':
                        			style+='top:'+(radio*hlen)+'px;';
                        			break;
                        		case 'center':
                        			style+='top:'+((windowHeight-(bgHeight*width/bgWidth))/2+radio*hlen)+'px;';
                            		break;
                        		case 'bottom':
                        			style+='bottom:'+(radio*hlen)+'px;';
                        			break;
                        	}

                        	switch(config.posi.w){
                        		case 'left':
                        			style+='left:'+(radio*wlen)+'px;';
                        			break;
                        		case 'center':
                        			style+='left:'+((windowWidth-width)/2+radio*wlen)+'px;';
                            		break;
                        		case 'right':
                        			style+='right:'+(radio*wlen)+'px;';
                        			break;
                        	}

                        	return style;
                        }
            			
        				html='<img src="'+img.url+'" style="'+reset_position_wxss(config)+'" />';
            		}	

            		if(config.posi&&config.posi.position){
               			 $('#<?php echo $this->get_template_key('preivew-fixed')?>').remove();
          				 $('#the-app-container').append('<div id="<?php echo $this->get_template_key('preivew-fixed')?>">'+html+'</div>');
          				 $('#<?php echo $this->get_template_key('preview')?>').html('<img src="<?php echo WREST_URL?>/assets/images/v2/product/e.png" style="width:320px;height:30px;border:solid 1px #f4f4f4;" />');
                	}else{
                		$('#<?php echo $this->get_template_key('preview')?>').html(html);
                    }
                   
				});
			})(jQuery);
		</script>
        <?php 
    }
    
    
}