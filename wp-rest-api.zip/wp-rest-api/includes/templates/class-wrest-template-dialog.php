<?php
class WRest_Template_Dialog extends Abstract_WRest_Template{
    public $canvasWidth = 400;
    public $maxWidth = 630;
    
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="弹窗广告";
        $this->description="提示：当前组件在一个页面内只能存在一个。";
        
        $this->init_form_fields( array(
            'item'=>array(
                'title'=>'绘图区域',
                'width'=>$this->canvasWidth,
                'type'=>'canvas'
            ),
            'posi'=>array(
                'title'=>'显示位置',
                'type'=>'position',
                'max-width'=>$this->maxWidth,
                'required'=>true,
                'default'=>array(
                    'w'=>'center',
                    'h'=>'center',
                    'w_len'=>0,
                    'h_len'=>-60,
                    'position'=>'fixed'
                ),
                'description'=>'<h5>提示：</h5>
                              <ol>
                                  <li>宽：最大为'.$this->maxWidth.'(宽只支持数值（单位rpx），不支持百分比),高度：自适应伸缩</li>
                                  <li>偏移量只支持数值（单位rpx），不支持百分比</li>
                               </ol>'
            ),
            'closeP'=>array(
                'title'=>'关闭按钮',
                'type'=>'select',
                'default'=>'bottom',
                'options'=>array(
                    'hidden'=>'不显示',
                    'TR'=>'顶部靠右',
                    'bottom'=>'底部居中'
                )
            ),
            'onlyNewUser'=>array(
                'title'=>'仅限新人显示',
                'type'=>'checkbox',
                'description'=>'未登录或最近3天内注册的用户可看'
            ),
            'showTime'=>array(
                'title'=>'显示次数',
                'type'=>'select',
                'options'=>array(
                    'none'=>'无限制',
                    'one'=>'仅显示一次',
                    'every-day'=>'每天仅显示一次'
                )
            ),
            'endDate'=>array(
                'title'=>'结束显示日期',
                'type'=>'text',
                'placeholder'=>'2019-12-20 15:00',
                'description'=>'格式：yyyy-MM-dd HH:ii'
            ),
            'times'=>array(
                'title'=>'显示时间段(可选)',
                'type'=>'text',
                'placeholder'=>'18:00-20:00',
                'description'=>'格式：HH:ii-HH:ii'
            )
        ));
    }
   
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        if(isset($config['item']['items'])&&$config['item']['items']){
            foreach ($config['item']['items'] as $index=>$item){
                $config['item']['items'][$index]['link'] = $this->reset_link( $item['link']);
            }
        }
        
        if(isset($config['item']['bg'])){
            $config['item']['bg'] = $this->reset_imgurl($config['item']['bg']);
        }
        
        $endDate = $config['endDate']?strtotime($config['endDate']):0;
        if($endDate&&(current_time( 'timestamp')-$endDate)>0){
            return;
        }
        
        $onlyNewUser = isset($config['onlyNewUser'])&&$config['onlyNewUser']=='Y';
        if($onlyNewUser){
            global $current_user;
            if(is_user_logged_in()&&$current_user->exists()){
                $now = current_time( 'timestamp');
                if($now-strtotime($current_user->user_registered)>3*24*60*60){
                    return;
                }
            }
        }
        
        $times = isset($config['times'])?$config['times']:null;
        if($times){
            $times = explode('-', $times);
            if(count($times)==2){
                $start = strtotime(date_i18n('Y-m-d ').$times[0]);
                $end = strtotime(date_i18n('Y-m-d ').$times[1]);
                $now = current_time( 'timestamp');
                if($now<$start||$now>$end){
                    return;
                }
            }
        }
        
        $config['prewidth'] = $this->canvasWidth;
        $templates[] = $this->reset_position_size($request, $config);
    }
    
    /**
     * @param WP_REST_Request $request
     * @param array $config
     * @return string
     */
    private function reset_position_size($request,$config){
        if(!isset($config['item']['bg'])
            ||!$config['item']['bg']
            ||!isset($config['item']['bg']['width'])
            ||!isset($config['item']['bg']['height'])){
            return $config;
        }
        
        $bgWidth = absint($config['item']['bg']['width']);
        $bgHeight = absint($config['item']['bg']['height']);
        
        $windowHeight = absint($request->get_param('windowHeight'));
        $windowWidth = absint($request->get_param('windowWidth'));
        if(!$windowHeight
            ||!$windowWidth
            ||!$bgWidth
            ||!$bgHeight){
                return $config;
        }
        
        $width = isset($config['posi']['width'])?absint($config['posi']['width']):0;
        $width = $width<=0?$this->maxWidth:$width;
        if($width>$this->maxWidth){$width=$this->maxWidth;}
        
        $config['width'] = $width;
        
        if(!isset($config['posi']['h'])){$config['posi']['h']='bottom';}
        if(!isset($config['posi']['h_len'])){$config['posi']['h_len']='0';}else{$config['posi']['h_len']=intval($config['posi']['h_len']);}
        
        if(!isset($config['posi']['w'])){$config['posi']['w']='center';}
        if(!isset($config['posi']['w_len'])){$config['posi']['w_len']='0';}else{$config['posi']['w_len']=intval($config['posi']['w_len']);}
       
        $wxss = "position:{$config['posi']['position']};";
        
        $ratio = $windowWidth/750;
        
        switch ($config['posi']['h']){
            case 'top':
                $wxss.="top:{$config['posi']['h_len']}rpx;";
                break;
            case 'center':
                $wxss.="top:".round(($windowHeight-$bgHeight*($width*$ratio)/$bgWidth)/$ratio/2+$config['posi']['h_len'],2)."rpx;";
                break;
            case 'bottom':
                $wxss.="bottom:{$config['posi']['h_len']}rpx;";
                break;
        }
        
        switch ($config['posi']['w']){
            case 'left':
                $wxss.="left:{$config['posi']['w_len']}rpx;";
                break;
            case 'center':
                $wxss.="left:".round(($windowWidth-($width*$ratio))/$ratio/2+$config['posi']['w_len'],2)."rpx;";
                break;
            case 'right':
                $wxss.="right:{$config['posi']['w_len']}rpx;";
                break;
        }
        
        $config['style'] = $wxss.'width:'.$width.'rpx;position:fixed;z-index:101;';
        $config['innerStyle'] = 'width:'.$width.'rpx;height:'.($bgHeight*$width/$bgWidth).'rpx;';
        return $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
    	$pub = new WRest_Menu_Store_Pub($this->version);
        ?>
        <block wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'&&<?php echo $section_id;?>.item.bg&&<?php echo $section_id;?>.show}}">
            <view bindtap="__tapOnDialogClose__" data-index="{{<?php echo $section_index?>}}" class="xh-dialog"  />
            <view style="{{<?php echo $section_id;?>.style}}" class="xh-column xh-column-c">
               <view style="position:relative;{{<?php echo $section_id;?>.innerStyle}}" >
                   <image src="{{<?php echo $section_id;?>.item.bg.url}}" style="width:{{<?php echo $section_id;?>.width}}rpx;height:{{<?php echo $section_id;?>.item.bg.height*<?php echo $section_id;?>.width/<?php echo $section_id;?>.item.bg.width}}rpx" model="aspectFit" lazy-load="{{true}}" />
                   <block wx:if="{{<?php echo $section_id;?>.item.items}}">
                       <?php 
                       $this->generate_nav_attribute_start("item.link",array(
                           'wx:for'=>"{{".$section_id.".item.items}}",
                           'wx:key'=>'{{index}}',
                           'class'=>'xh-bg-clear',
                           'style'=>'width:{{item.width*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;height:{{item.height*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;position:absolute;left:{{item.left*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;top:{{item.top*('.$section_id.'.width/'.$section_id.'.prewidth)}}rpx;z-index:102;'
                       ));
                       $this->generate_nav_attribute_end();
                       ?>
                   </block>
                    <image wx:if="{{<?php echo $section_id;?>.closeP=='TR'}}" src="{{config.apiAssets}}/images/v2/product/dialog-close-TR.png" style="z-index:102;position:absolute;right:-50rpx;top:-50rpx;width:64rpx;height:64rpx" bindtap="__tapOnDialogClose__" data-index="{{<?php echo $section_index?>}}" />
               </view>
               <image wx:if="{{<?php echo $section_id;?>.closeP=='bottom'}}" src="{{config.apiAssets}}/images/v2/product/dialog-close.png" style="z-index:102;width:64rpx;height:150rpx" bindtap="__tapOnDialogClose__" data-index="{{<?php echo $section_index?>}}" />
            </view>
        </block>
        <?php 
    }
    
    public function __actions(){
        ?>
    	<div id="<?php echo $this->get_template_key('remove')?>" class="zent-popover-wrapper zent-pop-wrapper zent-design-preview-controller__action-btn-delete" style="display: inline-block;">
            <svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" class="zent-design-preview-controller__icon-delete">
	            <g fill="none" fill-rule="evenodd">
		            <circle cx="10" cy="10" r="10"></circle>
		            <path fill="#FFF" d="M13.75 7.188l-.937-.938L10 9.063 7.188 6.25l-.938.937L9.062 10 6.25 12.812l.937.938L10 10.938l2.812 2.812.938-.937L10.938 10"></path>
	            </g>
            </svg>
        </div>	
        <script type="text/javascript">
			(function($){
				$('#<?php echo $this->get_template_key('remove')?>').click(function(){
					if(confirm('确定删除？')){
						$('#<?php echo $this->get_template_key('preivew-fixed')?>').remove();
						$('#<?php echo $this->get_template_key()?>').remove();
					}
				});
			})(jQuery);
		</script>				
    	<?php 
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				var img =config.item&&config.item.bg?config.item.bg:'';
    				var html='';
    				if(!img||!img.url){
    					html='<div class="rc-design-vue-preview rc-design-component-image-ad-preview" ><div class="cap-image-ad cap-image-ad--swipe"><div class="rc-design-react-preview rc-design-component-default-preview"><div><div class="rc-design-component-default-preview__title">点击编辑画板</div><div class="rc-design-component-default-preview__tip">建议宽度750像素</div></div></div></div></div>';	
    					$('#<?php echo $this->get_template_key('preview')?>').html(html);
    					return;
            		}
            		
                    var reset_position_wxss=function(config){
                    	var img =config.item&&config.item.bg?config.item.bg:'';
                    	if(!img){return '';}
                    	
                    	var bgWidth = img.width;
                    	var bgHeight = img.height;
                    	var radio = 320/750;
                    	var windowWidth = (config.width?config.width:750)*radio;
                    	var windowHeight = 555;

                    	var style='width:'+windowWidth+'px;height:'+(bgHeight*windowWidth/bgWidth)+'px;';
                    	
                    	if(!config.posi||!config.posi.position){
							return style;
                        }

                    	var radio = 320/750;
						var width = config.posi.width?(radio*config.posi.width):windowWidth;
						style='width:'+width+'px;height:'+(bgHeight*width/bgWidth)+'px;';
						style+='position:absolute;z-index:8;';
						
						var hlen = parseInt(config.posi.h_len);
						if(isNaN(hlen)){hlen=0;}
						
						var wlen = parseInt(config.posi.w_len);
						if(isNaN(wlen)){wlen=0;}
						
                    	switch(config.posi.h){
                    		case 'top':
                    			style+='top:'+(radio*hlen)+'px;';
                    			break;
                    		case 'center':
                    			style+='top:'+((windowHeight-(bgHeight*width/bgWidth))/2+radio*hlen)+'px;';
                        		break;
                    		case 'bottom':
                    			style+='bottom:'+(radio*hlen)+'px;';
                    			break;
                    	}

                    	switch(config.posi.w){
                    		case 'left':
                    			style+='left:'+(radio*wlen)+'px;';
                    			break;
                    		case 'center':
                    			style+='left:'+((windowWidth-width)/2+radio*wlen)+'px;';
                        		break;
                    		case 'right':
                    			style+='right:'+(radio*wlen)+'px;';
                    			break;
                    	}

                    	return style;
                    }
        			
    				html='<img src="'+img.url+'" style="'+reset_position_wxss(config)+';" />';
    				$('#<?php echo $this->get_template_key('preivew-fixed')?>').remove();
    				$('#app-dialog').append('<div id="<?php echo $this->get_template_key('preivew-fixed')?>" style="height:555px;position:relative;border:solid 1px #d4d4d4;width:320px;" class="xh-column xh-column-c"><h5><?php echo $this->title?></h5><div style="background:#f4f4f4;align-items:center;" class="xh-row xh-w xh-row-c">'+html+'</div></div>');
    				$('#<?php echo $this->get_template_key('preview')?>').html('<img src="<?php echo WREST_URL?>/assets/images/v2/product/e.png" style="width:320px;height:30px;border:solid 1px #f4f4f4;" />');
              		
				});
			})(jQuery);
		</script>
        <?php 
    }
}