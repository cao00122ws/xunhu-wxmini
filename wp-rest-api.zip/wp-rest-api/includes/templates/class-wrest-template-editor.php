<?php
class WRest_Template_Editor extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="富文本";
       
        $this->init_form_fields( array(
            'content'=>array(
                'title'=>'内容',
                'type'=>'editor',
                'default'=>'<p>点此编辑『富文本』内容 ——&gt;</p><p>你可以对文字进行<strong>加粗</strong>、<em>斜体</em>、<span style="text-decoration: underline;">下划线</span>、<span style="text-decoration: line-through;">删除线</span>、文字<span style="color: rgb(0, 176, 240);">颜色</span>、<span style="background-color: rgb(255, 192, 0); color: rgb(255, 255, 255);">背景色</span>、以及字号<span style="font-size: 20px;">大</span><span style="font-size: 14px;">小</span>等简单排版操作。</p><p>还可以在这里加入表格了</p><table><tbody><tr><td width="93" valign="top" style="word-break: break-all;">中奖客户</td><td width="93" valign="top" style="word-break: break-all;">发放奖品</td><td width="93" valign="top" style="word-break: break-all;">备注</td></tr><tr><td width="93" valign="top" style="word-break: break-all;">猪猪</td><td width="93" valign="top" style="word-break: break-all;">内测码</td><td width="93" valign="top" style="word-break: break-all;"><em><span style="color: rgb(255, 0, 0);">已经发放</span></em></td></tr><tr><td width="93" valign="top" style="word-break: break-all;">大麦</td><td width="93" valign="top" style="word-break: break-all;">积分</td><td width="93" valign="top" style="word-break: break-all;"><a href="javascript: void(0);" target="_blank">领取地址</a></td></tr></tbody></table><p style="text-align: left;"><span style="text-align: left;">也可在这里插入图片、并对图片加上超级链接，方便用户点击。</span></p>'
            )
        ));
    }
   
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['id']=WRest_Helper::generate_unique_id();
        $config['content']=WRest_Helper_String::towxml($config['content']);
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
         <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-w-750 xh-p15 xh-panel">
        	<HTML nodes="{{<?php echo $section_id;?>.content}}" />       
        </view>
        <?php 
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				
    				var html = '<div class="cap-richtext xh-panel" style="max-width:320px;overflow:hidden;" >'+config.content+'</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}