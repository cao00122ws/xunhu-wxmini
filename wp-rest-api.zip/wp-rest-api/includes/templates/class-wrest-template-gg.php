<?php
class WRest_Template_GG extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="Banner 广告";
       
        $this->init_form_fields( array(
            'unit_id'=>array(
                'title'=>'广告单元id',
                'type'=>'text',
                'description'=>'广告单元id，可在<a href="https://mp.weixin.qq.com" target="_blank">小程序管理后台</a>的流量主模块新建',
            ),
            'custom_css'=>array(
                'title'=>'自定义wxss',
                'type'=>'textarea',
                'description'=>'在此自定义广告组件的样式',
            )
        ));
    }
   
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-row xh-w-750 xh-p15" style="overflow:hidden;">
    		<ad wx:if="{{<?php echo $section_id;?>.unit_id}}" style="{{<?php echo $section_id;?>.custom_css?<?php echo $section_id;?>.custom_css:''}}" class="xh-ad" unit-id="{{<?php echo $section_id;?>.unit_id}}"></ad>
        </view>
        <?php 
    }
    
    public function __preview(){
        $theme = new WRest_Menu_Store_Theme($this->version);
        $border =$theme->get_option('border_'.$this->get_option('style'));
        $border=$border&&is_array($border)?$border:array();
        ?>
        <div id="<?php echo $this->get_template_key('preview')?>" class="zent-design-preview-controller__drag-handle min"></div>  

        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

                    var html='<img src="<?php echo WREST_URL?>/assets/images/common/gg.png?v=1" style="width:320px;height:66px;"/>';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}