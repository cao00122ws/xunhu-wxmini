<?php
class WRest_Template_Graphic_Navigation extends Abstract_WRest_Template{
	public function __construct($version,$id=0,$config = array()){
		parent::__construct($version,$id,$config);
		
		$this->title ="图文导航";
		
		$this->init_form_fields(array(
			'modal'=>array(
				'title'=>'模版',
				'type'=>'select',
				'default'=>'imgtxt',
			    'options'=>array(
			        'txt'=>'文字',
			        'imgtxt'=>'图文'
			    )
            ),
		    'pending'=>array(
		        'title'=>'图片 留白(rpx)',
		        'type'=>'integer',
		        'default'=>'0',
		        'description'=>'图片四周留白宽度(总宽度150)'
		    ),
            'items'=>array(
                'title'=>'内容',
            	'width'=>150,
            	'height'=>150,
                'has_title'=>true,
                'type'=>'mult_image'
            )
		));
	}

	public function to_json(&$templates, $request){
	    $config = $this->get_config();
	    $config['type']=$this->type;
	    if(isset($config['items'])&&$config['items']){
	        foreach ($config['items'] as $index=>$item){
	            $item = $this->reset_link( $item);
	            $config['items'][$index] = $this->reset_imgurl($item);
	        }
	    } 
	    
	    $templates[] = $config;
	}
	
    public function generate_wxml_item($section_id,$section_index){
        ?>
         <scroll-view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-panel xh-pT15 xh-pB15 xh-c-main xh-f-sub xh-w-750 xh-scroll"  scroll-x="{{<?php echo $section_id;?>.items&&<?php echo $section_id;?>.items.length>5}}" >
         	 <?php 
         	 $this->generate_nav_attribute_start("item",array(
         	     'wx:for'=>"{{".$section_id.".items}}",
         	     'wx:key'=>'{{index}}',
         	     'class'=>"xh-scroll-item xh-bg-clear",
         	     'style'=>"min-width:150rpx;"
         	 ));
         	 ?>
     	 	<view class="xh-column xh-column-c" style="width:{{750/<?php echo $section_id;?>.items.length}}rpx;">
        	   <image wx:if="{{item.url&&<?php echo $section_id;?>.modal=='imgtxt'}}" mode="aspectFill" lazy-load="{{true}}" src="{{item.url}}" style="width:{{150-(<?php echo $section_id;?>.pending?<?php echo $section_id;?>.pending:0)}}rpx;height:{{item.height*((150-(<?php echo $section_id;?>.pending?<?php echo $section_id;?>.pending:0))/item.width)}}rpx;" />
               <view wx:if="{{item.page_title}}" class="xh-mT15 xh-c-main xh-f-sub single-ellipsis xh-row xh-row-c">{{item.page_title}}</view> 
            </view>
             <?php  $this->generate_nav_attribute_end();?>
         </scroll-view>
        <?php 
    }
  
	public function __preview(){
		parent::__preview();
		?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

    				var html = '<div class="rc-design-vue-preview rc-design-component-image-text-nav-preview">';
    				if(config.items.length==0){
						html+='<div class="cap-image-ad__image-nav xh-panel" style="padding:10px 0;overflow-x: hidden;"><div class="image-wrapper" style="width: 80px; margin-right: 0px;"><a href="javascript:;" class="cap-image-ad__link cap-image-ad__link--image-nav" style="color: rgb(0, 0, 0);"><div class="cap-image-ad__image" lazy="loaded" style="height: 80px; width: 80px; background-image: url(<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png);"></div><h3 class="cap-image-ad__nav-title">导航一</h3></a></div><div class="image-wrapper" style="width: 80px; margin-right: 0px;"><a href="javascript:;" class="cap-image-ad__link cap-image-ad__link--image-nav" style="color: rgb(0, 0, 0);"><div class="cap-image-ad__image" lazy="loaded" style="height: 80px; width: 80px; background-image: url(<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png);"></div><h3 class="cap-image-ad__nav-title">导航二</h3></a></div><div class="image-wrapper" style="width: 80px; margin-right: 0px;"><a href="javascript:;" class="cap-image-ad__link cap-image-ad__link--image-nav" style="color: rgb(0, 0, 0);"><div class="cap-image-ad__image" lazy="loaded" style="height: 80px; width: 80px; background-image: url(<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png);"></div><h3 class="cap-image-ad__nav-title">导航三</h3></a></div><div class="image-wrapper" style="width: 80px; margin-right: 0px;"><a href="javascript:;" class="cap-image-ad__link cap-image-ad__link--image-nav" style="color: rgb(0, 0, 0);"><div class="cap-image-ad__image" lazy="loaded" style="height: 80px; width: 80px; background-image: url(<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png);"></div><h3 class="cap-image-ad__nav-title">导航四</h3></a></div></div>';
        			}else{
        				html += '<div class="cap-image-ad xh-panel">';
    						html+='<div class="cap-image-ad__image-nav" style="padding:10px 0;overflow-x: hidden;text-align:center;">';
    							
    						for(var index = 0 ;index<config.items.length;index++){
    							var img = config.items[index];
    							if(!img.url){img.url='';}
    							
    							html+='<div class="image-wrapper" style="width: 64px; margin-right: 0px;">\
    										<a href="javascript:;" class="cap-image-ad__link cap-image-ad__link--image-nav">\
    											'+(config.modal=='imgtxt'?('<div class="cap-image-ad__image" style="height: '+(60-(config.pending?config.pending/2:0))+'px; width: '+(60-(config.pending?config.pending/2:0))+'px;margin-bottom:7px; background-image: url('+img.url+');"></div>'):'')+'\
    											'+(img.page_title?('<div class="cap-image-ad__nav-title xh-mT15 xh-c-main xh-f-sub single-ellipsis xh-row xh-row-c">'+img.page_title+'</div>'):'')+'\
    										</a>\
    									</div>';
    						}
    						html+='</div>';
						html+='</div>';
            		}
    				html+='</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}