<?php
class WRest_Template_GZH extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="关注公众号";
        $this->description="提示：当前组件在一个页面内只能存在一个。";
        
        $this->init_form_fields( array(
            'description'=>array(
                'title'=>'注意事项：',
                'type'=>'description',
                'description'=>'<h5>开发者可在小程序内配置公众号关注组件，方便用户快捷关注公众号</h5>
                            <ol>
                                <li>使用组件前，需前往<a href="https://mp.weixin.qq.com" target="_blank">小程序后台</a>，在“设置”->“关注公众号”->“公众号关注组件”中设置要展示的公众号。<b>注：设置的公众号需与小程序主体一致。</b></li>
                                <li>当用户扫小程序码打开小程序时才能展示当前组件</li>
                                <li>每个页面只能配置一个当前组件</li>
                           </ol>',
            )
        ));
    }
   
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-row xh-w-750" style="overflow:hidden;">
    		<official-account></official-account>
        </view>
        <?php 
    }
    
    public function __preview(){
        $theme = new WRest_Menu_Store_Theme($this->version);
        $border =$theme->get_option('border_'.$this->get_option('style'));
        $border=$border&&is_array($border)?$border:array();
        ?>
        <div id="<?php echo $this->get_template_key('preview')?>" class="zent-design-preview-controller__drag-handle min"></div>  

        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

                    var html='<img src="<?php echo WREST_URL?>/assets/images/common/gzh.png?v=1" style="width:320px;height:70px;"/>';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}