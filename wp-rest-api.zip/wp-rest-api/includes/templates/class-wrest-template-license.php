<?php
class WRest_Template_License extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="版权信息";
        $this->group = 'bg';
        
        $this->init_form_fields(array(
            'title'=>array(
                'type'=>'emoji',
                'title'=>'标题',
                'default'=>'迅虎网络技术支持'
            ),
            'icon'=>array(
                'type'=>'image',
                'width'=>60,
                'height'=>60,
                'default'=>array(
                    'width'=>60,
                    'height'=>60,
                    'url'=>WREST_URL.'/assets/images/icon/page/xh.png'
                )
            )
        ));
    }
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['title'] = WRest_Emoji_Editor::html_to_text($config['title']);
        $config['icon'] = $this->reset_imgurl( $config['icon']);
        $templates[] = $config;
    }
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view class="xh-row xh-w xh-row-c xh-p30" wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}">
        	<image wx:if="{{<?php echo $section_id;?>.icon}}" src="{{<?php echo $section_id;?>.icon.url}}" lazy-load="{{true}}" mode="aspectFit" style="width:32rpx;height:32rpx;"/>
        	<view class="xh-c-placeholder xh-f-small xh-mL15" wx:if="{{<?php echo $section_id;?>.title}}">{{<?php echo $section_id;?>.title}}</view>
        </view>
        <?php 
    }
    
    public function __preview(){
        ?>
        <div id="<?php echo $this->get_template_key('preview')?>" class="zent-design-preview-controller__drag-handle min"></div>  
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

                    var html='<div style="display:flex;flex-direction:row;align-items:center;justify-content:center;padding:10px;"><img src="'+(config.icon?config.icon.url:'')+'" style="width:16px;height:16px;" /> <span style="margin-left:5px;" class="xh-c-placeholder xh-f-small">'+config.title+'</span></div>';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}