<?php
class WRest_Template_Line extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="辅助线";
       
        $this->init_form_fields( array(
            'style'=>array(
                'title'=>'样式',
                'type'=>'select',
                'default'=>'solid',
                'options'=>array(
                    'solid'=>'实线',
                    'dashed'=>'虚线'
                )
            )
        ));
    }
   
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-row xh-w-750 xh-pL30 xh-pR30 xh-{{<?php echo $section_id;?>.style}}-t" />
        <?php 
    }
    
    public function __preview(){
        $theme = new WRest_Menu_Store_Theme($this->version);
        $border =$theme->get_option('border_'.$this->get_option('style'));
        $border=$border&&is_array($border)?$border:array();
        ?>
        <div id="<?php echo $this->get_template_key('preview')?>" class="zent-design-preview-controller__drag-handle min"></div>  

        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

                    var html='<div style="width:320px;height:1px;padding-top:1px;padding-bottom:1px;border-bottom:'+config.style+' 1px #<?php echo isset($border['color'])?$border['color']:'d4d4d4';?>;"></div>';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}