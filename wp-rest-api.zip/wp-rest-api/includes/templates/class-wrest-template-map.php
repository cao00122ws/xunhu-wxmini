<?php
class WRest_Template_Map extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="地图";
       
        $this->init_form_fields( array(
            'psi'=>array(
                'title'=>'详细地址',
                'type'=>'map'
            ),
            'width'=>array(
                'title'=>'宽（rpx）',
                'type'=>'integer',
                'default'=>'750'
            ),
            'height'=>array(
                'title'=>'高（rpx）',
                'type'=>'integer',
                'default'=>'350'
            )
        ));
    }
   
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        if($config['psi']){
            $config['markers']=array(
                array(
                    'id'=>1,
                    'latitude'=>isset($config['psi']['lat'])?$config['psi']['lat']:null,
                    'longitude'=>isset($config['psi']['lng'])?$config['psi']['lng']:null,
                    'title'=>isset($config['psi']['path'])?$config['psi']['path']:null,
                )
            );
        }
        
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <map wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" show-compass enable-traffic longitude="{{<?php echo $section_id?>.psi.lng}}" latitude="{{<?php echo $section_id?>.psi.lat}}" scale="14" markers="{{<?php echo $section_id?>.markers}}" show-location style="width:{{<?php echo $section_id?>.width}}rpx; height:{{<?php echo $section_id?>.height}}rpx;" />
        <?php 
    }
    
    public function __preview(){
        $theme = new WRest_Menu_Store_Theme($this->version);
        $border =$theme->get_option('border_'.$this->get_option('style'));
        $border=$border&&is_array($border)?$border:array();
        ?>
        <div id="<?php echo $this->get_template_key('preview')?>" class="zent-design-preview-controller__drag-handle min"></div>  

        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

                    var html='<img src="<?php echo WREST_URL?>/assets/images/common/map.png?v=1" style="width:320px;height:130px;"/>';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}