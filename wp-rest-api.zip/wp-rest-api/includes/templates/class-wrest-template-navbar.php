<?php
class WRest_Template_Navbar extends Abstract_WRest_Template{
    private $_navbar;
	public function __construct($version,$id=0,$config = array()){
		parent::__construct($version,$id,$config);
		$this->title ="导航菜单";
		
	}
	
	public function to_json(&$templates, $request){
	    
	}
	
	public function __actions(){}
	public function __preview(){
		parent::__preview();
		$menu = new WRest_Menu_Store_Pub($this->version);
		$theme = new WRest_Menu_Store_Theme($this->version);
		$menus = $menu->get_option('menus');
		
		?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
					var color='<?php echo $theme->get_option('navbar_color')?>';
					var selectedColor='<?php echo $theme->get_option('navbar_selectedColor')?>';
					var menus = <?php echo $menus&&is_array($menus)?json_encode($menus):'[]';?>;
					var backgroundColor='<?php echo $theme->get_option('navbar_backgroundColor')?>';
    				var html='<div class="nav" style="margin-top:0px;">\
    				<div class="nav-editor clearfix">\
    					<div class="show">\
    						<div class="bottom">';
        					for(var index = 0;index<menus.length;index++){
        						var menu = menus[index];
        						if(!menu.icon_selected){
            						menu.icon_selected={
                    						url:'<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png',
                    						width:0,
                    						height:0
                    				};
                    			}
                    			
        						if(!menu.icon){
            						menu.icon={
                    						url:'<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png',
                    						width:0,
                    						height:0
                    				};
            					}
            					
        						var selected = index==0;
        						html+='<div class="icon-block" style="margin: 0px auto;width:'+(320/menus.length)+'px;background-color:#'+backgroundColor+'">';
        						if(selected){
        							html+='<div style="color:#'+selectedColor+'">\
            									<img src="'+menu.icon_selected.url+'" style="width:28px;height:28px;" />\
            									<div class="xh-row xh-row-c navbar-menu-item" style="overflow:hidden;flex-wrap:nowrap;wrap:nowrap;align-items:center;">'+menu.page_title+'</div>\
            								</div>';
        						}else{
        							html+='<div style="color:#'+color+'">\
            									<img src="'+menu.icon.url+'" style="width:28px;height:28px;" />\
            									<div class="xh-row xh-row-c navbar-menu-item" style="overflow:hidden;flex-wrap:nowrap;wrap:nowrap;align-items:center;">'+menu.page_title+'</div>\
            								</div>';
        						}
        						html+='</div>';
        					}
						
    				html+='</div>\
						</div>\
					</div>\
				</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}