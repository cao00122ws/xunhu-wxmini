<?php
class WRest_Template_NavT extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="标题(导航)";
       
        $this->init_form_fields( array(
            'icon'=>array(
                'title'=>'图标',
                'type'=>'image',
                'width'=>80,
                'height'=>80,
            ),
            'title'=>array(
                'title'=>'标题',
                'type'=>'emoji',
                'default'=>''
            ),
            'subtitle'=>array(
                'title'=>'副标题',
                'type'=>'emoji',
                'default'=>''
            ),
            'link'=>array(
                'title'=>'链接',
                'type'=>'link'
            ),
            'border_top'=>array(
                'title'=>'上边线',
                'type'=>'checkbox'
            ),
            'border_bottom'=>array(
                'title'=>'下边线',
                'type'=>'checkbox'
            )
        ));
    }
   
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['title'] = WRest_Emoji_Editor::html_to_text($config['title']);
        $config['subtitle'] = WRest_Emoji_Editor::html_to_text($config['subtitle']);
        $config['link'] = $this->reset_link( $config['link']);
        $config['icon'] = $this->reset_imgurl($config['icon']);
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        $this->generate_nav_attribute_start("{$section_id}.link",array(
            'wx:if'=>"{{".$section_id.".type=='".$this->type."'}}",
            'class'=>'xh-panel xh-w',
            'hover-class'=>'xh-panel-hover'
        ));
        
        ?><navT cls="xh-w" title="{{<?php echo $section_id;?>.title}}" icon="{{<?php echo $section_id;?>.icon?<?php echo $section_id;?>.icon.url:''}}" subtitle="{{<?php echo $section_id;?>.subtitle}}" border_top="{{<?php echo $section_id;?>.border_top=='yes'}}" border_bottom="{{<?php echo $section_id;?>.border_bottom=='yes'}}" /><?php 
       
        $this->generate_nav_attribute_end();
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				var iconHtml=config.icon&&config.icon.url?'<img src="'+config.icon.url+'" alt="" style="width:25px;height:25px">&nbsp;':'';
                    var title=config.title?config.title:'';
                    var subtitle=config.subtitle?config.subtitle:'';
					var border_top='';
					if(config.border_top=='yes'){
						border_top=';border-top:solid 1px #f4f4f4;';
					}console.log(config);
					var border_bottom='';
					if(config.border_bottom=='yes'){
						border_bottom=';border-bottom:solid 1px #f4f4f4;';
					}
            		
                    var html='<div class="rc-design-vue-preview rc-design-component-link-preview xh-panel" style="'+border_top+border_bottom+';padding: 5px 10px;display:flex;flex-direction:row;align-items:center;justify-content: space-between;min-height:30px;">' +
                                '<div style="display:flex;align-items:center;">' +
                                    iconHtml +
                                    '<span style="font-size:14px;" class="xh-c-main xh-f-main">'+title+'</span>' +
                                '</div>' +
                                '<div style="display:flex;align-items:center;justify-content:right;">' +
                                    '<span style="font-size:12px;" class="xh-c-sub xh-f-sub">'+subtitle+'</span>&nbsp;' +
                                    '<img src="<?php echo WREST_URL.'/assets/images/woocommerce/right.png';?>" alt="" style="width:16px;height:16px">' +
                                '</div>' +
                            '</div>';


    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}