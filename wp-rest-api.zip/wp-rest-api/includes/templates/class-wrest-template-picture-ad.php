<?php
class WRest_Template_Picture_Advertisement extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="图片广告";
        
        $this->init_form_fields( array(
            'modal'=>array(
                'title'=>'模版',
                'type'=>'select',
                'default'=>'carousel',
                
                'selected-class'=>'active',
                'options'=>array(
                    'carousel'=>array(
                        'title'=>'轮播海报',
                        'img'=>WREST_URL.'/assets/images/woocommerce/carousel.png'
                    ),
                    'onelineone'=>array(
                        'title'=>'1行1个',
                        'img'=>WREST_URL.'/assets/images/woocommerce/onelineone.png'
                    ),
                    'crossslipbig'=>array(
                        'title'=>'横向滑动 (大)',
                        'img'=>WREST_URL.'/assets/images/woocommerce/crossslipbig.png'
                    ),
                    'crossslipsmall'=>array(
                        'title'=>'横向滑动 (小)',
                        'img'=>WREST_URL.'/assets/images/woocommerce/crossslipsmall.png'
                    )
                ),
                'call'=>function($k,$v,$current){
          		    ?>
                  	<div data-type="<?php echo $k;?>" class="rc-design-select-templates option-item <?php echo $k==$current?'active':'';?>">
						<div class="rc-design-select-templates__image-block">
							<img src="<?php echo $v['img']?>" width="90px" height="64px" alt="temp">
						</div>
						<div class="rc-design-select-templates__title"><?php echo $v['title']?></div>
					</div>
                   <?php 
                }
            ),
            'items'=>array(
                'title'=>'内容',
                'type'=>'mult_image'
            )
        ));
    }

    
    public function to_json(&$templates,$request){
    	$config = $this->get_config();
    	$config['type']=$this->type;
    	
        switch ($config['modal']){
            case 'onelineone':
                if($config['items']){
                    foreach ($config['items'] as $item){
                        $config_item = $config;
                        
                        unset($config_item['items']);
                        $item = $this->reset_link( $item);
                        $config_item['item'] = $this->reset_imgurl($item);
                        $templates[] = $config_item;
                    }
                }
                break;
            case 'carousel':
            case 'crossslipbig':
            case 'crossslipsmall':
                if($config['items']){
                    foreach ($config['items'] as $index => $item){
                        $item = $this->reset_link($item);
                        $config['items'][$index] = $this->reset_imgurl($item);
                    }
                }
                
            	$templates[] = $config;
            	break;
        }
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <block wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}">
     	 	<swiper wx:if="{{<?php echo $section_id?>.modal=='carousel'&&<?php echo $section_id?>.items&&<?php echo $section_id?>.items.length>0}}" class="xh-w-750" style="height:{{750/<?php echo $section_id?>.items[0].width*<?php echo $section_id?>.items[0].height}}rpx;" indicator-dots="{{<?php echo $section_id?>.items.length > 1 ? true : false}}" circular autoplay interval="5000" duration="300">
                  <swiper-item wx:for="{{<?php echo $section_id?>.items}}" wx:key="{{index}}">
                     <?php 
                 	 $this->generate_nav_attribute_start("item",array(
                 	     'class'=>'xh-bg-clear'
                 	 ));
                 	 ?>
                      <image style="width:750rpx;height:{{750/<?php echo $section_id?>.items[0].width*<?php echo $section_id?>.items[0].height}}rpx;" src="{{item.url}}" lazy-load="{{true}}"/>
                     <?php $this->generate_nav_attribute_end()?>
                  </swiper-item>
            </swiper>
            
             <?php 
         	 $this->generate_nav_attribute_start("{$section_id}.item",array(
         	    'wx:if'=>"{{".$section_id.".modal=='onelineone'}}",
         	     'class'=>'xh-bg-clear'
         	 ));
         	 ?>
             <image src="{{<?php echo $section_id?>.item.url}}" class="xh-w-750" style="height:{{750/<?php echo $section_id?>.item.width*<?php echo $section_id?>.item.height}}rpx" lazy-load="{{true}}" />
             <?php $this->generate_nav_attribute_end()?>
             
        	 <scroll-view wx:elif="{{<?php echo $section_id?>.modal=='crossslipbig'}}" class="xh-scroll" scroll-x="true" >
            	<?php 
                 	 $this->generate_nav_attribute_start("item",array(
                 	     'wx:for'=>"{{".$section_id.".items}}",
                 	     'wx:key'=>"{{index}}",
                 	     'class'=>'xh-scroll-item xh-bg-clear'
                 	 ));
                 	 ?>
            	<image src="{{item.url}}" style="width:660rpx;height:{{item.height*660/item.width}}rpx;" lazy-load="{{true}}"  />
            	<?php $this->generate_nav_attribute_end()?>
             </scroll-view>
            
              <scroll-view wx:elif="{{<?php echo $section_id?>.modal=='crossslipsmall'}}" class="xh-scroll" scroll-x="true">
                 <?php 
                 	 $this->generate_nav_attribute_start("item",array(
                 	     'wx:for'=>"{{".$section_id.".items}}",
                 	     'wx:key'=>"{{index}}",
                 	     'class'=>'xh-scroll-item xh-bg-clear'
                 	 ));
                 	 ?>
                	<image src="{{item.url}}" style="width:450rpx;height:{{item.height*450/item.width}}rpx;"  lazy-load="{{true}}" />
                	<?php $this->generate_nav_attribute_end()?>
              </scroll-view>
         </block>
        <?php 
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    			
					var html = '<div class="rc-design-vue-preview rc-design-component-image-ad-preview">\
                    	<div class="cap-image-ad cap-image-ad--swipe" >';
					  if(!config.items||config.items.length==0){
						html+='<div class="rc-design-react-preview rc-design-component-default-preview"><div><div class="rc-design-component-default-preview__title">点击编辑图片广告</div><div class="rc-design-component-default-preview__tip">建议宽度750像素</div></div></div>';
					  }else{
						switch(config.modal){
							case 'carousel':
								html+='<div class="van-swipe" >\
										<div class="van-swipe__track" style="width: '+(320*config.items.length)+'px;height:'+(320/config.items[0].width*config.items[0].height)+'px;transition-duration: 500ms;">';
								var indicators = '';
								for(var index = 0 ;index<config.items.length;index++){
									var img = config.items[index];
									html+='<div class="van-swipe-item" style="width: 320px; height: 100%; transform: translateX(0px);">\
	                            				<div class="image-wrapper swipe-image-container">\
	                            					<div class="background-center" style="width: 100%; background-image: url('+img.url+'); background-size: contain;">\
	                            						<img src="'+img.url+'" alt="" class="transparent__img">\
	                            					</div>\
	                            				</div>\
	                            			</div>';
                        			if(indicators.length==0){
										indicators+='<i class="van-swipe__indicator van-swipe__indicator--active"></i>';
                            		}else{
                            			indicators+='<i class="van-swipe__indicator"></i>';
	                            	}
								}
								html+='</div>';
								if(config.items.length.length>1){
									html+='<div class="van-swipe__indicators">'+indicators+'</div>';
								}
								html+='</div>';
								break;
							case 'onelineone':
								html+='<ul>';
								for(var index = 0 ;index<config.items.length;index++){
									var img = config.items[index];
									html+='<li class="cap-image-ad__content top2end-img-container" style=" margin: 0px;"><div class="image-wrapper"><img alt="" class="cap-image-ad__image" src="'+img.url+'" lazy="loaded"></div></li>';
								}
								html+='</ul>';
								break;
							case 'crossslipbig':
								html+='<div class="cap-image-ad__slide" >';
								for(var index = 0 ;index<config.items.length;index++){
									var img = config.items[index];
									html+='<div class="image-wrapper" style="height: '+(img.height*(280/img.width))+'px;width: 280px; margin-right: 0px;" >\
											<img class="cap-image-ad__image" src="'+img.url+'" />\
										  </div>';
								}
											
								html+='</div>';
								break;
							case 'crossslipsmall':
								html+='<div class="cap-image-ad__slide slide-small">';
								for(var index = 0 ;index<config.items.length;index++){
									var img = config.items[index];
									html+='<div class="image-wrapper" style="height: '+(img.height*(140/img.width))+'px;width: 140px;  margin-right: 0px;">\
											<img alt="" class="cap-image-ad__image" src="'+img.url+'" />\
										  </div>';
								}
										
								html+='</div>';
								break;
						}
					  }
					  
					html+='</div>\
                 		</div>';
    				
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}