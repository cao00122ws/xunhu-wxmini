<?php
class WRest_Template_Posts extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="文章模块";
        $product_api = WRest::instance()->get_product_api();
        $this->init_form_fields(array(
        	'settings_filter'=>array(
        	    'title'=>'文章筛选',
        	    'type'=>'subtitle'
        	),
            'post__in'=>array(
                'title'=>'文章ID(多)',
                'type'=>'posts',
                'post_type'=> 'post',
                'description'=>'系统默认根据产品ID先后排序'
            ),
            'category__in'=>array(
        		'title'=>'文章分类',
        		'type'=>'posts',
        		'post_type'=> 'category'
        	),
        	'tag__in'=>array(
    			'title'=>'文章标签',
    			'type'=>'posts',
    			'post_type'=> 'tag'
        	),
        	'posts_per_page'=>array(
    			'title'=>'数量',
    			'type'=>'text',
    			'default'=>24
        	),
        	'sort'=>array(
    			'title'=>'排序',
    			'type'=>'select',
    			'options'=>array(
			        'default'=>'系统默认',
			        'comment_count_desc'=>'最多评论',
			        'publish_date_desc'=>'最新发布',
			        'publish_date_asc'=>'最早发布',
			        'random' =>'随机'
    			)
        	)
        ));
    }


    protected function get_posts(){
        $cacheKey = $this->get_template_cache_key();
        $posts = WRest_Cache_Helper::get($cacheKey, 'wrest::post::list');
        if(!$posts){
            $posts = WRest_Posts::get_posts($this->version,$this->get_config());
            WRest_Cache_Helper::set($cacheKey, $posts,  'wrest::post::list');
        }
        
        return $posts;
    }
    
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['items']=$this->get_posts(); 
        
        $templates[]=$config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
         <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-column xh-w-750 xh-pT30 xh-panel">
            <view wx:for="{{<?php echo $section_id;?>.items}}" wx:key="{{index}}" class="xh-column xh-w xh-column-c" bindtap="__nav__" data-action="navigate" data-url="/pages/article/detail/index?id={{item.ID}}">
                <image wx:if="{{item.thumbnail}}" src="{{item.thumbnail.url}}" mode="aspectFill" lazy-load="{{true}}" style="width:690rpx;height:250rpx;border-radius:10rpx;" />
                <view class="xh-w xh-mT15 xh-column xh-pL30 xh-pR30 xh-pB30" style="justify-content:flex-start;">
                    <view class="xh-c-main xh-f-main multi-ellipsis xh-w">{{item.title}}</view>
                </view>
            </view>
        </view>
        <?php 
    }
   
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
            (function($){
        		window.postView_<?php echo $this->get_template_key()?>=function(config,callback){
    				var request ={
    					config:JSON.stringify(config)
    				};
    				
    				jQuery.ajax({
    		            url: '<?php echo WRest::instance()->ajax_url( array('action'=>'wrest_admin','tab'=>'load_posts','version'=>$this->version->id),true,true)?>',
    		            type: 'post',
    		            timeout: 60 * 1000,
    		            async: true,
    		            cache: false,
    		            data: request,
    		            dataType: 'json',
    		            beforeSend  : function (XMLHttpRequest) {
    		                XMLHttpRequest.setRequestHeader("request_type","ajax");
    		                $('#<?php echo $this->get_template_key() ?>').loading('show');
    		            },
    		            complete: function() {
    		            	$('#<?php echo $this->get_template_key() ?>').loading('hide');
    		            	window.templateView.loading=false;
    		            },
    		            success: function(m) {
    		            	if(m.errcode!=0){
    							return;
    						}
    						
    						var items = m.data;
    						var num = config.num;
    						var html = '<div class="rc-design-vue-preview rc-design-component-goods-list-preview" style="min-height:100px;">';
    						if(!items){items=[];}
									html+='<div class="cap-goods-list">\
									<ul class="xh-column xh-w xh-column-c" >';
										for(var index=0;index<items.length;index++){
											if(index>=num){break;}
											var item = items[index];
											html+='<li class="xh-panel xh-mT15 xh-mL15 xh-mR15" style="width:320px">\
														<div class="xh-column xh-w">\
															<img src="'+(item.thumbnail?item.thumbnail.url:'')+'" style="width:320px;height:200px" />\
															<div class="xh-column xh-w xh-main-i xh-c-main-i xh-mT15 xh-pL15 xh-pR15 xh-pB15">'+item.title+'</div>\
														</div>\
													</li>';
										}
							html+='</ul></div>';
    							
    					html+='</div>';
    					
    					callback(html);
    	            },
    	            error:function(e){
    	            	console.error(e.responseText);
    	            }
    	         });
            	};
    		})(jQuery);
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
					var config = window.<?php echo $this->get_template_key()?>.config();
					window.postView_<?php echo $this->get_template_key()?>(config,function(html){
						$('#<?php echo $this->get_template_key('preview')?>').html(html);
					});
				});
			})(jQuery);
		</script>
        <?php 
    }
}