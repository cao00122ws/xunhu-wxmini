<?php
class WRest_Template_Product_List extends Abstract_WRest_Template_Product{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);
        $this->group = 'footer';
        $this->title ="商品列表";
    }

    public function generate_wxml_item($section_id,$section_index){
    	$pub = new WRest_Menu_Store_Pub($this->version);
        ?>
        <pro-Fit wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" navHeight="{{navHeight}}" sortArr="{{<?php echo $section_id;?>._sorts}}" filterArr="{{<?php echo $section_id;?>._filters}}" scrollTop="{{<?php echo $section_id;?>._scrollTop}}" bindfilter="onFooterChange">
	   		<view slot="content" class="xh-column xh-w">
    	   		<pro-list items="{{<?php echo $section_id;?>.items}}" cart="{{cart}}" bindonCartChange="onCartChange" />
    	   		<view wx:if="{{<?php echo $section_id;?>._isDataLoading}}" class="xh-row xh-w xh-row-c xh-p30 xh-column-c xh-c-sub xh-f-sub"><image src="{{config.apiAssets}}/images/v2/icon/loading-small.gif" style="width:30rpx;height:30rpx;" class="xh-mR15 " />努力加载中...</view>
            	<view wx:if="{{!<?php echo $section_id;?>._isDataLoading&&<?php echo $section_id;?>._isNoneData&&<?php echo $section_id;?>._pageIndex==1}}" class="xh-row xh-t-c xh-row-c xh-p30 xh-f-sub xh-c-main xh-w">抱歉，未能找到商品!</view>
       		</view>
       </pro-Fit>
       <?php 
    }
    
    public function get_modals(){
        return array(
            'big'=>'大图',
            'small'=>'小图',
            'detail'=>'详细列表',
            'oneline3'=>'一行三个'
        );
    }
    
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['api'] = "pro:list";
       
        $api = WRest::instance()->get_product_api();
        $cats = $api->get_product_cats($this->version,array(
            $api->cat_type
        ));
        $filters = $api->get_product_filters($this->version);
        $sorts = $api->get_product_sorts();
        
        $config['_filters'] = $filters;
        $config['_sorts'] = $sorts;
        
        $sdk = $request->get_param('sdk');
        if($sdk&&version_compare($sdk, '1.0.1','>=')){
            $catArray = array(
                array(
                    'term_id' => 0,
                    'name' => '全部',
                    'children' => null
                )
            );
            if(isset($cats['items1'])&&$cats['items1']){
                foreach ($cats['items1'] as $term_id=>$cat){
                    $catArray[]=$cat;
                }
            }
            $cats['items1'] = $catArray;
            $config['_cats'] = $cats;
        }else{
            $config['_cats'] = $cats;
        }
        
        $templates[] = $config;
    }
    
    public function __preview(){
        parent::__preview();
        $api = WRest::instance()->get_product_api();
        $cats = $api->get_product_cats($this->version,array(
            $api->cat_type
        ));
        ?>
        <style type="text/css">
            .cat-wm .cap-goods-list__item{height:80px;}
            .cat-wm .cap-goods__img{width:80px!important;height:80px!important}
            .cat-wm .cap-goods-list__photo{width:80px!important;height:80px!important}
            .cat-wm .cap-goods__img-wrap{width:80px!important;height:80px!important}
        </style>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
					var config = window.<?php echo $this->get_template_key()?>.config();
				
					window.productView_<?php echo $this->get_template_key()?>(config,function(phtml){
					   var html = '';
					   html='<div style="max-height:400px;overflow:hidden;">\
						   <div style="display:flex;flex-direction:column;color:#666;background-color:padding:30px;">';
        						
    					html+='<div style="display:flex;flex-direction:row;justify-content:space-between;" class="xh-bg-tab xh-c-main xh-f-main">\
									<div style="display:flex;align-items:center;">\
										<span style="margin:10px;">综合排序▼</span>\
                						<span style="margin:10px;">促销商品</span>\
                						<span style="margin:10px;">精选商品</span>\
            						</div>\
        					   </div>';	
    					html+='</div>';
						html+=phtml;
						html+='</div>';
						$('#<?php echo $this->get_template_key('preview')?>').html(html);
					});
				});
			})(jQuery);
		</script>
        <?php 
    }
}