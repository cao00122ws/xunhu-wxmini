<?php
class WRest_Template_Products extends Abstract_WRest_Template_Product{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="商品区块";
        $product_api = WRest::instance()->get_product_api();
        
        $this->fields =array_merge(array(
        	'settings_filter'=>array(
        	    'title'=>'商品筛选',
        	    'type'=>'subtitle'
        	),
            'post__in'=>array(
                'title'=>'指定商品(多选)',
                'type'=>'posts',
                'post_type'=> $product_api->post_type,
                'description'=>'系统默认根据产品ID先后排序'
            ),
            'category'=>array(
        		'title'=>'产品分类',
        		'post_type'=> $product_api->cat_type,
        		'type'=>'posts',
        	),
        	'tag'=>array(
        			'title'=>'产品标签',
        			'type'=>'posts',
        			'post_type'=> $product_api->tag_type
        	),
        	'featured'=>array(
        			'title'=>'精品推荐',
        			'type'=>'checkbox'
        	),
        	'onsale'=>array(
        			'title'=>'正在促销',
        			'type'=>'checkbox'
        	),
        	'limit'=>array(
        			'title'=>'数量',
        			'type'=>'text',
        			'default'=>24
        	),
        	'sort'=>array(
        			'title'=>'排序',
        			'type'=>'select',
        			'options'=>array(
        			        'default'=>'系统默认',
        			        'publish_date_desc'=>'最新发布',
        			        'modify_date_desc'=>'最近修改',
        					'average_rating_desc'=>'评分由高到低',
        					'average_rating_asc'=>'评分由低到高',
        			        'sale_qty_desc'=>'销量由高到低',
        			        'sale_qty_asc'=>'销量由低到高',
        			        'price_desc'=>'价格由高到低',
        			        'price_asc' =>'价格由低到高',
        			        'random' =>'随机'
        			)
        	)
        ),$this->fields);
    }

    public function generate_wxml_item($section_id,$section_index){
        ?>
        <block wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}">
          <view class="xh-mB15" wx:if="{{<?php echo $section_id;?>.modal=='big'||<?php echo $section_id;?>.modal=='small'||<?php echo $section_id;?>.modal=='oneline3'}}">
                <pro-big wx:if="{{<?php echo $section_id;?>.modal=='big'}}" item="{{<?php echo $section_id;?>.item}}" cart="{{cart}}" bindonCartChange="onCartChange" />
                <pro-small wx:elif="{{<?php echo $section_id;?>.modal=='small'}}" item="{{<?php echo $section_id;?>}}" cart="{{cart}}" />
                <pro-o3 wx:elif="{{<?php echo $section_id;?>.modal=='oneline3'}}" data="{{<?php echo $section_id;?>}}" cart="{{cart}}" />
          </view>
          
          <pro-detail wx:elif="{{<?php echo $section_id;?>.modal=='detail'}}" item="{{<?php echo $section_id;?>.item}}" cart="{{cart}}" bindonCartChange="onCartChange" />
		  <pro-swip wx:elif="{{<?php echo $section_id;?>.modal=='swip'}}" items="{{<?php echo $section_id;?>.items}}" cart="{{cart}}" />
		</block>
        <?php 
    }
   
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
					var config = window.<?php echo $this->get_template_key()?>.config();
					window.productView_<?php echo $this->get_template_key()?>(config,function(html){
						$('#<?php echo $this->get_template_key('preview')?>').html(html);
					});
				});
			})(jQuery);
		</script>
        <?php 
    }
}