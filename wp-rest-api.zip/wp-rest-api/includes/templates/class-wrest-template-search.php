<?php
class WRest_Template_Search extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="商品搜索";
       
        $this->init_form_fields( array(
            'placeholder'=>array(
                'title'=>'默认文本',
                'type'=>'emoji',
                'default'=>'搜索：商品'
            ),
            'cat'=>array(
                'title'=>'分类',
                'type'=>'checkbox',
                'default'=>'yes',
                'label'=>'显示'
            ),
            'sticky'=>array(
                'title'=>'漂浮效果',
                'default'=>'yes',
                'type'=>'checkbox'
            )
        ));
    }
   
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['placeholder'] = WRest_Emoji_Editor::html_to_text($config['placeholder']);
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>  <view wx:if="{{__section__.type=='wrest_template_search'}}" class="{{<?php echo $section_id;?>.sticky=='yes'?'sticky':''}} xh-w-750">
        		<search-bar placeholder="{{<?php echo $section_id;?>.placeholder}}" cat="{{<?php echo $section_id;?>.cat=='yes'}}" />
        	</view><?php 
    }
    
  
    public function __preview(){
        parent::__preview();
        $theme = new WRest_Menu_Store_Theme($this->version);
        $nav = new WRest_Menu_Store_Icon($this->version);
        $search = $nav->get_option('search');
        $search_cat = $nav->get_option('search_cat');
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				config.icon = <?php echo $search?json_encode($search):'null'?>;
    				config.icon_cat = <?php echo $search_cat?json_encode($search_cat):'null'?>;
    				
    				var html = '<div class="xh-row xh-panel xh-w-750">\
                					<div class="xh-row xh-bg  xh-m15  xh-p15 xh-c-placeholder xh-radius xh-w '+(config.cat=='yes'?'xh-pR15':'')+'"><img src="'+(config.icon?config.icon.url:'')+'" class="xh-pR15" style="width:16px;height:16px;" />'+config.placeholder+'</div>\
                					'+(config.cat=='yes'?('<img src="'+(config.icon_cat?config.icon_cat.url:'')+'" class=" xh-m15 " style="width:23px;height:23px;" />'):'')+'\
                        		</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}