<?php
class WRest_Template_Tab extends Abstract_WRest_Template{
        
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);
        $this->group ='tab';
        
        $this->title ="Tab导航";
        $this->description = "顶部Tab切换多个页面效果";
        $this->init_form_fields( array(
            'items'=>array(
                'title'=>'Tab项（程序页）',
                'type'=>'posts',
                'post_type'=> 'wrest_page',
        		'call'=>function($id){
        			$post = get_post($id);
        			if(!$post){
        				return null;
        			}
        			$std = new stdClass();
        			$std->ID = $post->ID;
        			$std->post_title = $post->post_title;
        			return $std;
        		}
            )
        ));
    }
   
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-row xh-w-750 xh-p15" >
    		<ad wx:if="{{<?php echo $section_id;?>.unit_id}}" style="{{<?php echo $section_id;?>.custom_css?<?php echo $section_id;?>.custom_css:''}}" class="xh-ad" unit-id="{{<?php echo $section_id;?>.unit_id}}"></ad>
        </view>
        <?php 
    }
    
    public function __preview(){
        $theme = new WRest_Menu_Store_Theme($this->version);
        $border =$theme->get_option('border_'.$this->get_option('style'));
        $border=$border&&is_array($border)?$border:array();
        ?>
        <div id="<?php echo $this->get_template_key('preview')?>" class="zent-design-preview-controller__drag-handle min"></div>  

        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

    				var html = '<div style="max-height:400px;overflow:hidden;">\
            				<div style="display:flex;flex-direction:row;" class="xh-bg-tab">\
        						<ul style="list-style:none;">\
                					<li style="padding:10px;text-align:center;overflow:hidden;white-space: nowrap;border-bottom:solid 1px #f2f2f2;width:80px" class="xh-c-active single-ellipsis xh-f-main xh-c-main">程序页一</li>\
                					<li style="padding:10px;text-align:center;overflow:hidden;white-space: nowrap;border-bottom:solid 1px #f2f2f2;width:80px" class=" single-ellipsis xh-f-main xh-c-main">程序页二</li>\
                					<li style="padding:10px;text-align:center;overflow:hidden;white-space: nowrap;border-bottom:solid 1px #f2f2f2;width:80px" class=" single-ellipsis xh-f-main xh-c-main">程序页三</li>\
                					<li style="padding:10px;text-align:center;overflow:hidden;white-space: nowrap;border-bottom:solid 1px #f2f2f2;width:80px" class=" single-ellipsis xh-f-main xh-c-main">程序页四</li>\
            					</ul>\
        						<div class="xh-column xh-row-c xh-column-c" style="width:250px;height:450px;" class="xh-bg">页面内容</div>\
    						</div>\
						</div>';
		$('#<?php echo $this->get_template_key('preview')?>').html(html);

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}