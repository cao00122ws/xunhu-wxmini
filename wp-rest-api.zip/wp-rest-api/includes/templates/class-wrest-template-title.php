<?php
class WRest_Template_Title extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="标题";
       
        $this->init_form_fields( array(
            'title'=>array(
                'title'=>'标题',
                'type'=>'emoji'
            ),
            'title_style'=>array(
                'title'=>'标题 样式',
                'type'=>'textarea',
                'placeholder'=>'color:#444;font-weight:bolder;'
            ),
            'subtitle'=>array(
                'title'=>'副标题',
                'type'=>'emoji'
            ),
            'subtitle_style'=>array(
                'title'=>'副标题 样式',
                'type'=>'textarea',
                'placeholder'=>'color:#d3d3d3;'
            ),
            'modal'=>array(
                'title'=>'显示位置',
                'type'=>'select',
                'default'=>'center',
                'options'=>array(
                    'flex-start'=>'居左显示',
                    'center'=>'居中显示',
                    'flex-end'=>'居右显示'
                )
            ),
            'border_top'=>array(
                'title'=>'上边线',
                'type'=>'checkbox',
                'default'=>'yes'
            ),
            'border_bottom'=>array(
                'title'=>'下边线',
                'type'=>'checkbox',
                'default'=>'yes'
            )
        ));
    }
   
    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        $config['title'] = WRest_Emoji_Editor::html_to_text($config['title']);
        $config['subtitle'] = WRest_Emoji_Editor::html_to_text($config['subtitle']);
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" class="xh-row xh-p30 xh-panel {{<?php echo $section_id;?>.border_bottom=='yes'?'xh-solid-b':''}} {{<?php echo $section_id;?>.border_top=='yes'?'xh-solid-t':''}}" style="justify-content:{{<?php echo $section_id;?>.modal}}">
        	<view class="xh-mw-690 xh-column xh-column-c">
            	<text wx:if="{{<?php echo $section_id;?>.title}}" style="{{<?php echo $section_id;?>.title_style}}" class="xh-c-main-i xh-f-main-i xh-B single-ellipsis">{{<?php echo $section_id;?>.title}}</text>
            	<text wx:if="{{<?php echo $section_id;?>.subtitle}}" style="{{<?php echo $section_id;?>.subtitle_style}}" class="xh-c-sub xh-f-small single-ellipsis">{{<?php echo $section_id;?>.subtitle}}</text>
        	</view>
        </view>
        <?php 
    }
    
  
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				var title='点击编辑『标题』';
    				var showMethod=0;
                    if(config.title!=''){
                    	title=config.title;
                      }
                    if(config.modal=='center') showMethod=1;
                    if(config.modal=='flex-end') showMethod=2;
                    var html='<div class="rc-design-vue-preview rc-design-component-title-preview xh-panel">' +
                                '<div class="cap-title cap-title--normal" style=" display:flex;flex-direction:row;justify-content: '+config.modal+';">' +
                                '<h2 class="cap-title__main xh-B xh-c-main-i xh-f-main-i" ><span style="'+(config.title_style?config.title_style:'')+'">'+title+'</span><span style="font-size:12px;margin-left:5px;'+(config.subtitle_style?config.subtitle_style:'')+'" class="xh-c-sub xh-f-sub">'+(config.subtitle?config.subtitle:'')+'</span></h2></div></div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}