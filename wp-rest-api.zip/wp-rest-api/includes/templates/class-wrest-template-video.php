<?php
class WRest_Template_Video extends Abstract_WRest_Template{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="视频";
       
        $this->init_form_fields( array(
            'video'=>array(
                'title'=>'视频(MP4)',
                'type'=>'video'
            ),
            'post'=>array(
                'title'=>'预览图',
                'type'=>'image',
                'description'=>'主要：预览图尺寸必须和视频尺寸一致'
            ),
            'width'=>array(
                'title'=>'宽度(rpx)',
                'type'=>'integer',
                'default'=>750,
                'description'=>'最大宽度为750rpx'
            ),
            'height'=>array(
                'title'=>'高(rpx)',
                'type'=>'integer',
                'default'=>250
            )
        ));
    }

    public function to_json(&$templates, $request){
        $config = $this->get_config();
        $config['type']=$this->type;
        if(!isset($config['post'])||!$config['post']){
            $config['showVideo']='Y';
        }
        
        $config['post'] = $this->reset_imgurl($config['post']);
        $templates[] = $config;
    }
    
    public function generate_wxml_item($section_id,$section_index){
        ?>
        <view wx:if="{{<?php echo $section_id;?>.type=='<?php echo $this->type;?>'}}" style="width:{{<?php echo $section_id;?>.width>750?750:<?php echo $section_id;?>.width}}rpx;height:{{<?php echo $section_id;?>.height}}rpx;overflow:hidden;position:relative;">
        	<video wx:if="{{<?php echo $section_id;?>.showVideo=='Y'}}" src="{{<?php echo $section_id;?>.video}}" autoplay controls style="width:{{<?php echo $section_id;?>.width>750?750:<?php echo $section_id;?>.width}}rpx;height:{{<?php echo $section_id;?>.height}}rpx;"/>
        	<block wx:if="{{<?php echo $section_id;?>.showVideo!='Y'&&<?php echo $section_id;?>.post}}">
            	<image bindtap="__tapOnVideoShow__" data-index="{{<?php echo $section_index?>}}" src="{{<?php echo $section_id;?>.post.url}}" style="width:{{<?php echo $section_id;?>.width>750?750:<?php echo $section_id;?>.width}}rpx;height:{{<?php echo $section_id;?>.height}}rpx;position:relative;top:0;left:0;z-index:2;" mode="aspectFit" />
            	<image bindtap="__tapOnVideoShow__" data-index="{{<?php echo $section_index?>}}" mode="aspectFit" style="position: absolute;top: 50%;left: 50%;width: 124rpx;height: 124rpx;transform: translate(-50%, -50%);z-index: 4;" src="{{config.apiAssets}}/images/icon/play.png" />
        	</block>
        </view>
        <?php 
    }
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
					if(!config.width){config.width=750;}
					if(!config.height){config.height=250;}
                    var html='<video style="width:'+(config.width/2)+'px;height:'+(config.height/2)+'px;" controls="controls" src="'+(config.video?config.video:'')+'"></video>';

    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}