<?php

class WRest_Template_Window extends Abstract_WRest_Template{
    public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);
        $this->title ="导航栏";
       
        $this->fields = array(
            'navigationBarTitleText'=>array(
            	'title'=>'导航栏标题',
                'type'=>'emoji'
            ),
            'requiredAuth'=>array(
                'title'=>'登录访问',
                'type'=>'checkbox'
            )
        );
    }

    public function __actions(){}
    
    public function __preview(){
        parent::__preview();
        $theme = new WRest_Menu_Store_Theme($this->version);
        ?>
        <script type="text/javascript">
        	(function($){
            	$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				config.navigationBarBackgroundColor='<?php echo $theme->get_option('navigationBar_BackgroundColor')?>';
    				config.navigationBarTextStyle='<?php echo $theme->get_option('navigationBar_TextStyle')?>';
    	
        			var header_style='background-color:#'+config.navigationBarBackgroundColor+';';
        			var title_style = 'color:'+(config.navigationBarTextStyle)+';';
        			switch(config.navigationBarTextStyle){
        				case 'black':
        			 		header_style+='background-image:url(<?php echo WREST_URL?>/assets/images/woocommerce/header-black.png)';
    				 	break;
    				 	default:
        				case 'white':
        					header_style+='background-image:url(<?php echo WREST_URL?>/assets/images/woocommerce/header.png)';
        				break;
        			}

        			var html = '<div style="'+header_style+'" class="rc-design-component-config-preview rc-design-component-config-preview--wechat" >\
                        			<div style="'+title_style+'" class="rc-design-component-config-preview__title">'+config.navigationBarTitleText+'</div>\
                            	</div>';
                	
        	    	$('#<?php echo $this->get_template_key('preview')?>').html(html);
    			});
            })(jQuery);
		</script>
        <?php 
    }
}