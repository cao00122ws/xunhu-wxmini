<?php
abstract class Abstract_WRest_Template_Layout extends Abstract_WRest_Template{
	public function to_json(&$templates, $request){
		$config = $this->get_config();
		$config['type']=$this->type;
		$templates[] = $config;
	}
	abstract function getConfigId();
	public function __preview(){
		parent::__preview();
		?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				var html = '<div class="cap-search-box__view" style="background: #ffffff; padding-right: 15px;height:40px; top: 0px;text-align:center;font-weight:bold;">\
    					<?php echo $this->title;?>\
    					</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}