<?php

class WRest_Template_Layout_Body extends Abstract_WRest_Template_Layout{
    public function __construct($version,$id=0,$config = array()){
    	parent::__construct($version,$id,$config);
    
        $this->title ="主题";
       
        $this->fields = array(
                'theme'=>array(
                    'title'=>'主题',
                    'type'=>'theme',
                    'default'=>'blue'
                ),
            	'icon_loading'=>array(
            		'title'=>'图标：加载中',
            		'type'=>'image',
            		'width'=>44,
            		'height'=>44,
            	    'local'=>true,
            		'default'=>array(
            				'url'=>WREST_URL.'/assets/images/logo.png',
            				'width'=>64,
            		        //本地加载
            		        'local'=>'Y',
            				'height'=>64
            		)
            	),
                'custom_css'=>array(
                    'title'=>'自定义全局样式',
                    'type'=>'textarea',
                    'css'=>'min-height:200px',
                    'placeholder'=>'view{color:#444;font-size:20rpx}',
                    'description'=>'注意：样式规则遵循wxss写法，错误的css会导致小程序无法运行'
                )
        );
    }
    
    public function getConfigId(){
    	return "common";
    }
    
    public function generate_theme_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'class' => '',
            'field-class'=>'',
            'css' => '',
            'description' => ''
        );
        
        $data = wp_parse_args ( $data, $defaults );
        global $wpdb;
        $system_themes = $wpdb->get_results(
                    "select *
                     from {$wpdb->prefix}wrest_theme
                     where is_system = 1;");
        $custom_themes = $wpdb->get_results(
            "select *
            from {$wpdb->prefix}wrest_theme
            where is_system = 0;");
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?></div>
				<div class="zent-design-editor__control-group-control">
					<div class="zent-input-wrapper" style="display:flex;flex-direction:center;align-items:center;">
						<select class="zent-input <?php echo esc_attr($data['class'])?>" style="<?php echo esc_attr($data['css'])?>;width:180px;" id="<?php echo $field;?>" >
							<optgroup label="系统内置">
								<?php 
    							if($system_themes){
    							    foreach ($system_themes as $theme){
    							        ?><option value="<?php echo $theme->tid?>"><?php echo $theme->title?></option> <?php 
    							    }
    							}
    							?>
							</optgroup>
							
							<?php if($custom_themes&&count($custom_themes)>0){?>
							<optgroup label="自定义">
								<?php 
    							if($custom_themes){
    							    foreach ($custom_themes as $theme){
    							        ?><option value="<?php echo $theme->tid?>"><?php echo $theme->title?></option> <?php 
    							    }
    							}
    							?>
							</optgroup>
							<?php } ?>
						</select>
						<a id="<?php echo $field;?>-edit" style="margin-left:10rpx;">编辑</a>	
					</div>
					<div><a href="<?php echo admin_url('admin.php?page=wrest_page_default&section=menu_store_settings&sub=menu-store-layout&theme_id=')?>">新建主题</a></div>
					<div><?php echo $data['description'];?></div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			(function($){
				var on_<?php echo $field;?>_change=function(){
					$('#<?php echo $field;?>-edit').attr('href','<?php echo admin_url('admin.php?page=wrest_page_default&section=menu_store_settings&sub=menu-store-layout&theme_id=')?>'+$('#<?php echo $field;?>').val());
				}

				$('#<?php echo $field;?>').change(function(){
					on_<?php echo $field;?>_change();
				});

				on_<?php echo $field;?>_change();
				
				window.<?php echo $field?>={
					onblur:function(){
						console.info('blur:<?php echo $key ?>');
						$(document).trigger("on_<?php echo $this->get_template_key()?>_change");
					},
					get_value:function(){
						return $.trim($('#<?php echo $field?>').val());
					},
					set_value:function(val){
						$('#<?php echo $field?>').val(val);
					}
				};
			})(jQuery);
		</script>
        <?php 
    }
}