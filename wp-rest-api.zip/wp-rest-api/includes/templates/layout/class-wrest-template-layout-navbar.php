<?php
class WRest_Template_Layout_Navbar extends Abstract_WRest_Template{
	public function __construct($version,$id=0,$config = array()){
		parent::__construct($version,$id,$config);
		
		$this->title ="导航菜单";
		
		$this->fields = array(
		    'color'=>array(
		        'title'=>'导航菜单文字默认颜色',
		        'type'=>'color',
		        
		        'default'=>'707070'
		    ),
		    'selectedColor'=>array(
		        'title'=>'导航菜单文字选中时的颜色',
		        'type'=>'color',
		        
		        'default'=>'ec5151'
		    ),
		    'backgroundColor'=>array(
		        'title'=>'导航菜单背景色',
		        'type'=>'color',
		        
		        'default'=>'ffffff'
		    ),
		    'borderStyle'=>array(
		        'title'=>'导航菜单上边框的颜色',
		        'type'=>'select',
		        
		        'default'=>'white',
		        'options'=>array(
		            'white'=>'白色',
		            'black'=>'黑色'
		        )
		    ),
		    'position'=>array(
		        'title'=>'导航菜单的位置',
		        'type'=>'select',
		        
		        'default'=>'bottom',
		        'options'=>array(
		            'bottom'=>'底部',
		            'top'=>'顶部'
		        )
		    ),
            'items'=>array(
                'title'=>'菜单列表',
            	'width'=>81,
            	'height'=>81,
                
                'type'=>'navbar',
                'default'=>array(
                    array(
                        'icon'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-home.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'icon_selected'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-home-selected.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'page_title'=>'首页',
                        'page'=>'/pages/index/index'
                    ),
                    array(
                        'icon'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-category.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'icon_selected'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-category-selected.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'page_title'=>'分类',
                        'page'=>'/pages/category/index'
                    ),
                    array(
                        'icon'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-article.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'icon_selected'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-article-select.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'page_title'=>'资讯',
                        'page'=>'/pages/article/list/index'
                    ),
                    array(
                        'icon'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-cart.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'icon_selected'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-cart-selected.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'page_title'=>'购物车',
                        'page'=>'/pages/cart/index'
                    ),
                    array(
                        'icon'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-account.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'icon_selected'=>array(
                            'url'=>WREST_URL.'/assets/images/icon/navbar-account-selected.png',
                            'width'=>81,
                            'height'=>81
                        ),
                        'page_title'=>'个人中心',
                        'page'=>'/pages/account/index'
                    ),
                )
            ),
            
		);
	}

	public function __actions(){}
	
	public function __preview(){
		parent::__preview();
		?>
        <script type="text/javascript">
			(function($){
				$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();
    				
    				var html='<div class="nav" style="margin-top:0px;">\
                				<div class="nav-editor clearfix">\
                					<div class="show">\
                						<div class="bottom">';
            
                        				var color=config.color;
                    					var selectedColor=config.selectedColor;
                    					var menus = config.items?config.items:[];
                    					
                    					for(var index = 0;index<menus.length;index++){
                    						var menu = menus[index];
                    						if(!menu.icon_selected){menu.icon_selected={url:'<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png',width:0,height:0};}
                    						if(!menu.icon){menu.icon={url:'<?php echo WREST_URL?>/assets/images/woocommerce/empty-cat.png',width:0,height:0};}
                    						var selected = index==0;
                    						html+='<div class="icon-block" style="margin: 0px auto;width:'+(320/menus.length)+'px">';
                    						if(selected){
                    							html+='<div style="color:#'+selectedColor+'">\
                        									<img src="'+menu.icon_selected.url+'" style="width:28px;height:28px;" />\
                        									<div>'+menu.page_title+'</div>\
                        								</div>';
                    						}else{
                    							html+='<div style="color:#'+color+'">\
                        									<img src="'+menu.icon.url+'" style="width:28px;height:28px;" />\
                        									<div>'+menu.page_title+'</div>\
                        								</div>';
                    						}
                    						html+='</div>';
                    					}
            						
                    				html+='</div>\
                						</div>\
                					</div>\
                				</div>';
    				$('#<?php echo $this->get_template_key('preview')?>').html(html);
				});
			})(jQuery);
		</script>
        <?php 
    }
}