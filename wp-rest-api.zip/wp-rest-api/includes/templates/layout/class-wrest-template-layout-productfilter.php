<?php
class WRest_Template_Layout_ProductFilter extends Abstract_WRest_Template_Layout{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="商品筛选 <span style=\"color:red;\">NEW</span>";
       
        $this->init_form_fields( array(
        		'filter'=>array(
        				'title'=>'商品筛选',
        				'type'=>'productfilter'
        		)
        ));
    }
    
    public function getConfigId(){
    	return "productfilter";
    }
    
    public function get_default_filters(){
	    	$default =array();
	    	global $wpdb;
	    	$api = WRest::instance()->get_product_api();
	    	$products = $api->get_product_list(new WRest_Version(), array(
	    			'limit'=>50,
	    			'type'=>'variable',
	    			'sort'=>'publish_date_desc'
	    	),'woocommerce_single',OBJECT);
	    	
	    	if(!$products||!$products['items']){
	    		return $default;
	    	}
    		foreach ($products['items'] as $product){
    			if(!$product->is_load()){
    				continue;
    			}
    			
    			$atts = $product->get_available_variations();
    			if(!$atts||!$atts['attributes1']){
    				continue;
    			}
    			
    			foreach ($atts['attributes1'] as $option=>$att){
    				$options = array();
    				if($att['options']){
    					foreach ($att['options'] as $op=>$s){
    						$options[$op] = $s['name'];
    					}
    				}
    				$default[$att['title']] = $options;
    			}
    		}
    	return $default;
    }
    
    public function generate_productfilter_html($key,$data){
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'field-class'=>''
        );
    
        $data = wp_parse_args ( $data, $defaults );
        $config = $this->get_option($key);
        $uid = WRest_Helper::generate_unique_id();
        
        
        ?>
          <div class="zent-design-editor__control-group <?php echo $data['field-class']?>">
    		<div class="zent-design-editor__control-group-container">
    			<div class="zent-design-editor__control-group-label"><?php echo $data['title'];?> </div>
				<div class="zent-design-editor__control-group-control">
					<div class="rc-design-editor-card rc-design-component-image-ad-editor-card">
						<div id="<?php echo $field ?>-items">
  							
						</div>
						 <div class="rc-design-component-image-ad-editor__add-ads-desc" id="<?php echo $field ?>-drag-tag" style="display:none;">拖动可对其排序</div>
						<div class="rc-design-editor-card-add" id="<?php echo $field ?>-add-item">
							<div class="rc-design-component-image-ad-editor__add-image">
								<div class="rc-design-component-image-ad-editor__add-image-text"><i class="zenticon zenticon-plus rc-design-editor-card-add-icon"></i>添加一个筛选条件</div>
							</div>
						</div>
						<button class="button" id="<?php echo $field ?>-reset">重置筛选条件</button>
        			</div>
				</div>
			</div>
		</div>
			<?php 
			$default = $this->get_default_filters();
			if(is_null($config)){
				$config = $default;
			}
			$items = $this->convert_config_to_js($config);
			$default_items = $this->convert_config_to_js($default);
			?>
			<script type="text/javascript">
				(function($){
					window.<?php echo $field;?>={
						container:'<?php echo $field ?>-items',
						items:<?php echo $items&&count($items)>0?json_encode($items):'[]'?>,
						default_items:<?php echo $default_items&&count($default_items)>0?json_encode($default_items):'[]'?>,
						onKeyup:function(){
							this.save();
							this.preview();
						},
						preview:function(){
							$(document).trigger("on_<?php echo $this->get_template_key() ?>_change");
						},
						get_value:function(){
							if(!this.items){
								return null;
							}

							var new_items = {};
							for(var s in this.items){
								var item = this.items[s];
								if(!item.label||!item.options){
									continue;
								}
								
								var options = item.options.split("\n");

								console.log(options);
								var option_array={};
								for(var p in options){
									var option = options[p].split("|");
									
									if(option.length==2){
										option_array[$.trim(option[0])] = $.trim(option[1]);
									}else if(option.length==1){
										option_array[$.trim(option[0])] = $.trim(option[0]);
									}
								}
								new_items[item.label] = option_array;
							}
							return new_items;
						},
						remove_img:function(index){
							if(confirm('确认删除？')){
								$('#rc-design-editor-card-item-<?php echo $uid?>-'+index).remove();
								this.save();				
								this.preview();
							}
						},
						set_value:function(items){
							if(!items){items=[];}
							this.items = items;
							this.init();
						},
						save:function(){
							var items = [];
							$('#'+this.container+' .rc-design-editor-card-item').each(function(){
								var item = {
									label:$.trim($(this).find('.editor-label').val()),
									options:$.trim($(this).find('.editor-options').val())
								};
								items.push(item);
							});
							this.items = items;
						},
						init:function(){
							var $container = $('#'+this.container).empty();
							var html = '';

							if(this.items.length==0){
								$('#<?php echo $field ?>-drag-tag').css('display','none');		
							}else{
								$('#<?php echo $field ?>-drag-tag').css('display','block');
							}
							
							for(var index = 0 ;index<this.items.length;index++){
								var item = this.items[index];
								
								html+='<div class="rc-design-editor-card-item" draggable="true" style="cursor:move" id="rc-design-editor-card-item-<?php echo $uid?>-'+index+'">\
          								<div class="rc-design-component-editor_subentry-item clearfix">\
          									<div class="subentry-item-editor-form-content" style="margin-left:0;">\
          											<label class="zent-design-editor__control-group-container">\
	          											<div class="zent-design-editor__control-group-label">属性：</div>\
	      												<div class="zent-design-editor__control-group-control">\
	      													<div class="zent-input-wrapper">\
	      														<input value="'+(item.label?item.label:'')+'" class="editor-label" style="width:80px;" placeholder="输入属性名称" type="text" onblur="<?php echo $field;?>.onKeyup();" />\
	      													</div>\
	      												</div>\
          												<div class="zent-design-editor__control-group-label">选项：</div>\
          												<div class="zent-design-editor__control-group-control">\
          													<div class="zent-input-wrapper">\
          														<textarea class="editor-options" style="width:160px;" rows="4" onblur="<?php echo $field;?>.onKeyup();" placeholder="别名|名称\r\或选项2\r\选项3\r\n...">'+(item.options?item.options:'')+'</textarea>\
              												</div>\
              												<div>选项别名和名称不同时，“|”分隔。多个选项换行分割。</div>\
          												</div>\
          											</label>\
          									</div>\
          								</div>\
          								<i class="zenticon zenticon-close-circle rc-design-editor-card-item-delete" onclick="<?php echo $field;?>.remove_img('+index+');"></i>\
          							</div>';
						}
						
						$container.html(html);
						$container.sortable({
							cursor:'move',
							tolerance:'pointer',
							update:function(event, ui){
								<?php echo $field;?>.save();
								<?php echo $field;?>.preview();
							}
					    });
					},
					add_item:function(){
						<?php echo $field?>.items.push({
							label:'',
							options:''
					    });
					    
				    	<?php echo $field?>.init();
				    	<?php echo $field?>.preview();
					    return false;    
					}
				};

				$(document).bind('on_wrest_app_ready',function(){
					<?php echo $field?>.init();
				});
			})(jQuery);
		</script>
		<script type="text/javascript">
			(function($){
				$('#<?php echo $field ?>-add-item').click(function(){
					window.<?php echo $field?>.add_item();
				    return false;    
				});
				$('#<?php echo $field ?>-reset').click(function(){
					if(!confirm('确认重置所有更改？')){
						return;
					}

					window.<?php echo $field;?>.set_value(window.<?php echo $field;?>.default_items);
				});
			})(jQuery);
		    </script>
        <?php 
    }
    
    private function convert_config_to_js($config){
    	if(!$config){
    		return array();
    	}
    	$items=array();
    	foreach ($config as $label=>$options){
    		$option_str = '';
    		if($options){
    			foreach ($options as $key=>$val){
    				if($option_str){
    					$option_str.="\r\n";
    				}
    				
    				if($key==$val){
    					$option_str.=esc_textarea($val);
    				}else{
    					$option_str.=esc_textarea($key).'|'.esc_textarea($val);
    				}
    			}
    		}
    		
    		$items[]=array(
    				'label'=>$label,
    				'options'=>$option_str
    		);
    	}
    	return $items;
    }
}