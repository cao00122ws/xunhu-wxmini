<?php
class WRest_Template_Layout_Products extends Abstract_WRest_Template_Layout{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="商品图标";
       
        $this->init_form_fields( array(
        		'icon_is_on_sale'=>array(
        				'title'=>'图标：促销中',
        				'type'=>'image',
        				'width'=>74,
        				'height'=>74,
        				'default'=>array(
        						'url'=>WREST_URL.'/assets/images/icon/is-promotion.png',
        						'width'=>74,
        						'height'=>74
        				)
        		),
        		'icon_is_featured'=>array(
        				'title'=>'图标：热卖中',
        				'type'=>'image',
        				'width'=>74,
        				'height'=>74,
        				'default'=>array(
        						'url'=>WREST_URL.'/assets/images/icon/is-feature.png',
        						'width'=>74,
        						'height'=>74
        				)
        		),
        		'icon_is_new'=>array(
        				'title'=>'图标：新货',
        				'type'=>'image',
        				'width'=>74,
        				'height'=>74,
        				'default'=>array(
        						'url'=>WREST_URL.'/assets/images/icon/is-new.png',
        						'width'=>74,
        						'height'=>74
        				)
        		),
        		'new_days'=>array(
        				'title'=>'新货显示时间(天)',
        				'type'=>'text',
        				'default'=>3,
        				'description'=>'在设置的天数范围内，标记为新货'
        		),
        		'settings_btn_add_cart'=>array(
        				'title'=>'购物按钮',
        				'type'=>'subtitle',
        				'hr'=>true
        		),
        		'cart_more'=>array(
        				'title'=>'(购物车)更多',
        				'type'=>'image',
        				'width'=>128,
        				'height'=>50,
        				'default'=>array(
        						'width'=>128,
        						'height'=>50,
        						'url'=>WREST_URL.'/assets/images/icon/cart-more.png'
        				)
        		),
        		'cart_add'=>array(
        				'title'=>'(购物车)+',
        				'type'=>'image',
        				'width'=>50,
        				'height'=>50,
        				'default'=>array(
        						'width'=>50,
        						'height'=>50,
        						'url'=>WREST_URL.'/assets/images/icon/cart-add.png'
        				)
        		),
        		'cart_cut'=>array(
        				'title'=>'(购物车)-',
        				'type'=>'image',
        				'width'=>50,
        				'height'=>50,
        				'default'=>array(
        						'width'=>50,
        						'height'=>50,
        						'url'=>WREST_URL.'/assets/images/icon/cart-cut.png'
        				)
        		)
        ));
    }
    
    public function getConfigId(){
    	return "product";
    }
}