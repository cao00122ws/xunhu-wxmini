<?php
class WRest_Template_Layout_Search extends Abstract_WRest_Template_Layout{
     public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);

        $this->title ="商品搜索";
       
        $this->init_form_fields( array(
            'icon'=>array(
                'title'=>'图标',
                'type'=>'image',
                'width'=>60,
                'height'=>60,
                'default'=>array(
                    'width'=>32,
                    'height'=>32,
                    'url'=>WREST_URL.'/assets/images/icon/search.png'
                )
            ),
            'txtcolor'=>array(
                'title'=>'搜索文字颜色',
                'type'=>'color',
                
                'default'=>'999999'
            ),
            'panel_bgcolor'=>array(
                'title'=>'搜索区域背景颜色',
                'type'=>'color',
                
                'default'=>'ffffff'
            ),
            'input_bgcolor'=>array(
                'title'=>'搜索框背景颜色',
                
                'type'=>'color',
                'default'=>'f0f1f2'
            )
        ));
    }
    
    public function getConfigId(){
    	return "search";
    }
}