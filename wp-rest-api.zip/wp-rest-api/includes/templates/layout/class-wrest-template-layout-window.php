<?php

class WRest_Template_Layout_Window extends Abstract_WRest_Template{
    public function __construct($version,$id=0,$config = array()){
        parent::__construct($version,$id,$config);
    
        $this->title ="导航栏";
       
        $this->fields = array(
            'navigationBarTitleText'=>array(
            	'title'=>'导航栏标题文字内容',
                'type'=>'text',
                
                'default'=>get_bloginfo('name')
            ),
            'navigationBarBackgroundColor'=>array(
            	'title'=>'导航栏背景颜色',
                'type'=>'color',
                
                'default'=>'ffffff'
            ),
            'navigationBarTextStyle'=>array(
            	'title'=>'导航栏标题颜色',
                'type'=>'select',
                'default'=>'black',
                
            	'options'=>array(
            		'black'=>'黑色',
            		'white'=>'白色'
            	)
            ),
            'backgroundColor'=>array(
            	'title'=>'窗口的背景色',
                'type'=>'color',
                
                'default'=>'F9F9F9'
            ),
            'backgroundTextStyle'=>array(
            	'title'=>'下拉 loading 的样式',
                'type'=>'select',
                'default'=>'dark',
            	'options'=>array(
            		'dark'=>'深色',
            		'light'=>'浅色'
            	)
            )
        );
    }
    
    public function __actions(){}
    
    public function __preview(){
        parent::__preview();
        ?>
        <script type="text/javascript">
        	(function($){
            	$(document).bind("on_<?php echo $this->get_template_key()?>_change",function(){
    				var config = window.<?php echo $this->get_template_key()?>.config();

    				switch(config.navigationBarTextStyle){
        				case 'black':
        					if(config.navigationBarBackgroundColor=='000000'){
        						config.navigationBarBackgroundColor='ffffff';
        						window.<?php echo $this->get_field_key('navigationBarBackgroundColor')?>.set_value(config.navigationBarBackgroundColor);
        					}
        	    			break;
        				case 'white':
        					if(config.navigationBarBackgroundColor=='ffffff'){
        						config.navigationBarBackgroundColor='000000';
        						window.<?php echo $this->get_field_key('navigationBarBackgroundColor')?>.set_value(config.navigationBarBackgroundColor);
        					}
        	    			break;
        			}
        			
        			var header_style='background-color:#'+config.navigationBarBackgroundColor+';';
        			var title_style = 'color:'+config.navigationBarTextStyle+';';
        			switch(config.navigationBarTextStyle){
        				case 'black':
        			 		header_style+='background-image:url(<?php echo WREST_URL?>/assets/images/woocommerce/header-black.png)';
    				 	break;
        				case 'white':
        					header_style+='background-image:url(<?php echo WREST_URL?>/assets/images/woocommerce/header.png)';
        				break;
        			}

        			var html = '<div style="'+header_style+'" class="rc-design-component-config-preview rc-design-component-config-preview--wechat" >\
                        			<div style="'+title_style+'" class="rc-design-component-config-preview__title">'+config.navigationBarTitleText+'</div>\
                            	</div>';
                	
        			$('#the-app-body').css('background-color','#'+config.backgroundColor);
        	    	$('#<?php echo $this->get_template_key('preview')?>').html(html);
    			});
            })(jQuery);
		</script>
        <?php 
    }
}