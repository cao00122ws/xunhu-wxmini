				/**
				 * Project: Wordpress小程序
				 * Author: hoter@xunhuweb.com
				 * Version: v1.0.3				 * Date :2019-11-30 05:48				 * Copyright: xunhuweb (https://www.wpweixin.net)
				 */
						const extendList = [];
				
		
		App({
		    Util: require('utils/util.js'),
		    formIds:{},
			//已废弃
			data:{ __config__:{}},
			tmpCart:{},
		    config:{
		        sdk:'1.0.6',
		        version:'v1.0.3',
			    apiMain:'https://prelive.eumade.com/?rest_route=',
			    apiAssets:'https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets',
		        theme:{"navigationBar_TextStyle":"black","theme_size":30,"theme_line_height":1.5,"theme_fontsize_sub":"24","theme_c_main":"#353535","theme_panel":"#ffffff"},
		    	menus:{"pages/index/index":[],"pages/category/index":[],"pages/article/list/index":[],"pages/cart/index":[],"pages/account/index":[]},
		    	icons:{"icon_none_comment_items":{"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/v2/product/empty-comment.png","width":360,"height":477},"icon_none_cat_icon":{"url":"https://prelive.eumade.com/wp-content/uploads/woocommerce-placeholder-300x300.png","width":80,"height":80},"icon_none_cart_items":{"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/v2/product/cartsky.png","width":360,"height":477},"icon_is_sale_out":{"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/icon/sale-out.png","width":256,"height":256},"icon_is_on_sale":{"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/icon/is-promotion.png","width":74,"height":74},"icon_is_featured":{"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/icon/is-feature.png","width":74,"height":74},"icon_is_new":{"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/icon/is-new.png","width":74,"height":74},"icon_cart_more":{"width":128,"height":50,"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/icon/cart-more.png"},"icon_cart_add":{"width":50,"height":50,"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/icon/cart-add.png"},"icon_cart_cut":{"width":50,"height":50,"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/icon/cart-cut.png"},"icon_status_header_bg":{"url":"https://prelive.eumade.com/wp-content/plugins/wp-rest-api/assets/images/v2/icon/order/status-bg.jpg","width":1024,"height":120}}		    },
		    apply_filters(action) {
		        if (arguments.length < 2) {
		            throw 'apply filters need argument 2!'
		        }
		        var args = Array.prototype.slice.call(arguments, 1);
		        for (var index in extendList) {
		            var handler = extendList[index];
		            if(!handler.filters){continue;}
                    if (typeof handler.filters[action] != 'function') {
		                continue;
		            }

                    args[0] = handler.filters[action].apply(handler, args);
		        }
		        return args[0];
		    },
		    do_action(action) {
		     	var args = Array.prototype.slice.call(arguments, 1);
		        for (var index in extendList) {
		            var handler = extendList[index];
		            if(!handler.actions){continue;}
                    if (typeof handler.actions[action] != 'function') {
		                continue;
		            }

                    handler.actions[action].apply(handler, args);
		        }
		    },
		    getApi:function(route){
		    	if (!route){
                    return this.config.apiMain;
                }
                route = route.toString();
                if (route[0]!='/'){
                    route = "/" +route;
                 }
                return this.config.apiMain + route;
		    },
		    logout:function(){
		    	this.TOKEN=false;
		    	wx.removeStorageSync('system:token');
		    },
		    isAuthorized: function() {
		        if (typeof this.TOKEN == 'undefined') {
		            try {
		                var cached = wx.getStorageSync('system:token');
		                this.TOKEN = cached ? cached : false;
		            } catch (e) {
		                this.TOKEN = false;
		                //ignore
		            }
		        }

		        return this.TOKEN;
		    },
            onLaunch(){
                wx.getStorageInfo({
                    success: function(res) {
                        if (res.currentSize / res.limitSize>=0.8){
                            wx.clearStorage();
                        }
                    },
                })
            },
			__temp_sys__:false,
		    getSystemInfo: function(onSuccess) {
		        var that = this;
		        if (that.__temp_sys__) {
    		        if (onSuccess) {
                        var pages = getCurrentPages();
                        var obj = Object.assign({}, that.__temp_sys__);
                        var isTab = pages && pages.length > 0 && that.config.menus && typeof that.config.menus[pages[pages.length-1].route]!='undefined';
                        obj.isTab = isTab;
                        obj.isIphoneX = obj.isIphoneX && !isTab;
                        onSuccess(obj);
                    }
		            return;
		        }
		        
				wx.getSystemInfo({
	                success: function(res) {
                 		var isIOS = false;
		                if (res.platform && res.platform.toLowerCase() == 'ios') {
		                    isIOS = true;
		                } else if (res.platform && res.platform.toLowerCase() == 'devtools') {
		                    isIOS = res.system && res.system.toLowerCase().indexOf('ios') > -1;
		                }
		                
                        var statusBarHeight = res.statusBarHeight ? res.statusBarHeight : 20;
                        var navbarHeight = isIOS ? 40 : 48;
		                that.__temp_sys__ = {
		                	isIOS: isIOS,
		                    windowHeight: res.windowHeight,
		                    windowWidth: res.windowWidth,
		                    screenHeight: res.screenHeight,
                    		screenWidth: res.screenWidth,
		                    statusBarHeight: statusBarHeight,
		                    isIphoneX: res.model && res.model.search('iPhone X') != -1,
		                    navbarHeight: navbarHeight,
		                    //v7.0.0以上版本，才支持 自定义navbar
		                    navHeight:res.version >= '7.0.0'?(statusBarHeight+navbarHeight):0
		                };
		                if (onSuccess) {
		                    var pages = getCurrentPages();
	                        var obj = Object.assign({}, that.__temp_sys__);
	                        var isTab = pages && pages.length > 0 && that.config.menus && typeof that.config.menus[pages[pages.length-1].route]!='undefined';
	                        obj.isTab = isTab;
	                        obj.isIphoneX = obj.isIphoneX && !isTab;
	                        onSuccess(obj);
		                }
	                },
	            });
		    }
		})
		