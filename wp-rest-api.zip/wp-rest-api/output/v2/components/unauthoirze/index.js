const app = getApp();
Component({
    options: {
        addGlobalClass: true
    },
    data:{
        apiAssets: app.config.apiAssets
    },
})
