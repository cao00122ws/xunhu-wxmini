// package_a/components/order/address/index.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        orderInfo:Object
    },
    options: {
        addGlobalClass: true
    }
})
