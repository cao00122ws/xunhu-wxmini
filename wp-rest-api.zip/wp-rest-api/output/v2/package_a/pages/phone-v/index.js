const app = getApp();
const pageS = require('../../../utils/pageS.js');
const utilMd5 = require('../../../utils/md5.js');
Page(Object.assign({}, pageS, {
    data: {
        code_btn: {
            txt: '发送验证码',
            can_click: true,
            click_time: null
        },
        bind_btn: {
            txt: '绑定',
            can_click: true,
        }
    },
    onReady: function (refresh = false) {
        var that = this;
        var options = this._options;
        app.Util.network.GET(that, {
            url: app.getApi('wp/v1/user/getValidationPhone'),
            params: options,
            showLoading: 1,
            success: function (res) {
                that.setData(res);
            }
        });
    },
    enterPhone: function (e) {
        let that = this;
        let phone = e.detail.value;
        that.setData({
            "phone": phone
        });
    },
    sendCode: function (e) {
        let that = this;
        let data = that.data;
        let phone = data.phone;
        let code_btn = data.code_btn;
        //判断是否可以点击
        if (!code_btn.can_click) {
            return false;
        }
        //阻止连续点击
        let currentTime = that.getCurrentTimestamp();
        if (code_btn.click_time) {
            let timeDifference = currentTime - code_btn.click_time;
            if (timeDifference < 3) {
                return false;
            }
        }
        that.setData({
            "code_btn.click_time": currentTime
        });
        
        app.Util.network.POST(that, {
            url: app.getApi('wp/v1/user/sendMobileCode'),
            params: {
                phone: phone
            },
            showLoading: 0,
            success: function (res) {
                that.sendCodeSuccessCallback(res);
            }
        });
    },

    //发送成功回调
    sendCodeSuccessCallback: function (res) {
        let that = this;

        that.setData({
            code_btn: {
                txt: '重新发送 60',
                can_click: false,
                click_time: null
            }
        });
        let countdown = setInterval(function () {
            let code_btn = that.data.code_btn;
            let time = parseInt(code_btn.txt.slice(code_btn.txt.length - 2)) - 1;
            if (time <= 0) {
                that.setData({
                    code_btn: {
                        txt: '发送验证码',
                        can_click: true,
                        click_time: null
                    }
                });
                clearInterval(countdown);
            } else {
                that.setData({
                    code_btn: {
                        txt: `重新发送 ${time}`,
                        can_click: false,
                        click_time: null
                    }
                });
            }
        }, 1000);
    },

    //绑定
    onPhoneBindSubmit: function (e) {
        let that = this;
        let bind_btn = that.data.bind_btn;
        //是否可以点击
        if (!bind_btn.can_click) {
            return false;
        }
        var options = this._options;
        //验证
        let params = e.detail.value;
        params.addressId = typeof options.id === 'undefined' ? null : options.id;
        if (!params.terms && this.data.msg) {
            that.errorAlert('请确认条款并勾选！');
            return false;
        };

        //阻止二次提交
        that.setData({
            bind_btn: {
                txt: '绑定中...',
                can_click: false
            }
        });

        app.Util.network.POST(that, {
            url: app.getApi('wp/v1/user/bindMobileCode'),
            params: params,
            showLoading: 0,
            success: function (res) {
                wx.showToast({
                    title: '绑定成功！',
                    icon: 'none',
                    duration: 2000
                })
                that.__go_back__();
            },
            complete: (res) => {
                that.setData({
                    bind_btn: {
                        txt: '绑定',
                        can_click: true
                    }
                });
            }
        });
    },

    //获取当前时间戳，秒
    getCurrentTimestamp: function () {
        let time = Date.parse(new Date());
        time = time / 1000;
        return time;
    },

    //错误提示弹窗
    errorAlert: function (msg) {
        wx.showModal({
            title: '提示',
            content: msg || '未知错误',
            showCancel: false,
        });
    },
}))